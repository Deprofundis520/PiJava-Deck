#!/usr/bin/env python3
"""Linux integration smoke: menu, real MIDlet, rendered pixels and persistent RMS."""
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import zipfile
import struct
import zlib
ROOT = Path(__file__).resolve().parents[1]
exe = Path(sys.argv[1]).resolve()
with tempfile.TemporaryDirectory(prefix="pijava-deck-smoke-") as tmp:
    tmp = Path(tmp)
    subprocess.run(["javac", "-source", "8", "-target", "8", "-encoding", "UTF-8",
                    "-bootclasspath", str(ROOT/"romfs/classes"), "-classpath", str(ROOT/"romfs/classes"),
                    "-d", str(tmp), str(ROOT/"tests/DeckSmoke.java")], check=True)
    jar = tmp/"smoke.jar"
    with zipfile.ZipFile(jar,"w") as z:
        z.writestr("META-INF/MANIFEST.MF", "Manifest-Version: 1.0\r\nMIDlet-1: DeckSmoke,,DeckSmoke\r\n\r\n")
        for c in tmp.glob("*.class"): z.write(c,c.name)
    env = dict(os.environ, SDL_VIDEODRIVER="dummy", SDL_AUDIODRIVER="dummy", XDG_DATA_HOME=str(tmp/"data"))
    env.pop("J2ME_RMS_DIR",None)
    subprocess.run([str(exe),"--windowed","--smoke-frames","3"],cwd=ROOT,env=env,check=True,timeout=30)
    for attempt in range(2):
        png=tmp/(str(attempt)+".png")
        subprocess.run([str(exe),"--windowed","--jar",str(jar),"--size","240x320",
                        "--smoke-frames","30","--screenshot",str(png)],cwd=ROOT,env=env,check=True,timeout=45)
        b=png.read_bytes()
        assert b[:8]==b"\x89PNG\r\n\x1a\n" and struct.unpack(">II",b[16:24])==(240,320)
        pos=8;compressed=b""
        while pos<len(b):
            n=struct.unpack(">I",b[pos:pos+4])[0]
            if b[pos+4:pos+8]==b"IDAT":compressed+=b[pos+8:pos+8+n]
            pos+=12+n
        assert any(zlib.decompress(compressed)),"empty framebuffer"
    assert any((tmp/"data/pijava/rms/suites").rglob("*.bin")),"RMS file missing"
    print("PASS: menu, MIDlet, two launches, framebuffer, persistent RMS; dummy SDL only")

