#!/bin/sh
set -eu
APPDIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$APPDIR"
# Linux native application: do not select Proton in Steam compatibility settings.
exec "$APPDIR/pijava-deck" "$@"
