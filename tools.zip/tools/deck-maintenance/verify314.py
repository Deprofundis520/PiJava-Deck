from pathlib import Path
import tarfile,zipfile,json,hashlib
r=Path('work/PiJava-main');o=Path('outputs');font=Path('F:/Deepseek/02-j2me移植/发布/j2me-nx-port-publish/data/fonts/cjk.ttf').read_bytes()
with tarfile.open(o/'PiJava-Deck-点开即用-v3.14.tar.gz') as t:
 for n in ['PiJava','pijava-deck','Install','Add to Gaming Mode','一键安装','添加到游戏模式','安装到桌面']:
  m=t.getmember('PiJava-Deck/'+n);assert m.mode==0o755;assert t.extractfile(m).read()==Path('work/cross/pijava-deck-v3.14').read_bytes()
 assert t.extractfile('PiJava-Deck/romfs/font/cjk.ttf').read()==font
 assert t.extractfile('PiJava-Deck/README.md').read()==(o/'README-v3.14.md').read_bytes()
 assert not any(n.endswith(('.jar','.exe')) for n in t.getnames())
with zipfile.ZipFile(o/'PiJava-Deck-source-v3.14.zip') as z:
 assert z.testzip() is None
 for p in r.rglob('*'):
  if p.is_file() and '__pycache__' not in p.parts:assert z.read('PiJava-Deck-source/'+p.relative_to(r).as_posix())==p.read_bytes(),p
 assert z.read('PiJava-Deck-source/romfs/font/cjk.ttf')==font
 m=json.loads(z.read('PiJava-Deck-source/STEAMDECK-PORT.json'));assert m['version'].endswith('3.14') and m['languages']['supported']==['zh','en']
for line in (o/'SHA256SUMS-v3.14.txt').read_text(encoding='utf-8').splitlines():
 sha,name=line.split('  ',1);assert hashlib.sha256((o/name).read_bytes()).hexdigest()==sha
print('PASS v3.14 executable aliases and permissions, user font, full source/ROM consistency, metadata, no bundled games and all SHA256 hashes')
