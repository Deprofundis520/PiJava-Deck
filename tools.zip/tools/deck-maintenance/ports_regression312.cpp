#include "font8x8_basic.h"
#include "platform/deck_ui.h"
#include "presentation/orientation.h"
#include "java_fp_text.h"
#include <cassert>
#include <iostream>
int main(int argc,char**argv){assert(argc==2);namespace fs=std::filesystem;fs::path root=argv[1];fs::create_directories(root);
assert(java_fp_text(1.5)=="1.5"&&java_fp_text(-0.0)=="-0.0"&&java_fp_text(1e7)=="1.0E7"&&java_fp_text(1e-4)=="1.0E-4");
assert(java_fp_text(0.1f)=="0.1"&&java_fp_text(std::numeric_limits<double>::infinity())=="Infinity");
assert(java_fp_text(std::numeric_limits<float>::denorm_min())=="1.4E-45"&&java_fp_text(std::numeric_limits<double>::denorm_min())=="4.9E-324");
deck_text::Editor e;e.begin(deck_text::Editor::Purpose::Rename,"a中");e.backspace();assert(e.value=="a");assert(!e.insert("\n"));e.clear();e.max_units=2;assert(e.insert("😀")&&deck_text::units(e.value)==2&&!e.insert("x"));e.backspace();assert(e.value.empty());
deck_game_options::Store store;store.root=root/"game-options";std::string id(64,'b');deck_game_options::Options options;options.rotation=3;options.resolution=21;options.alias="中文名字";assert(store.save(id,options));auto loaded=store.load(id);assert(loaded.rotation==3&&loaded.resolution==21&&loaded.alias==options.alias);options.rotation=4;assert(!store.save(id,options)&&store.load(id).rotation==3);
assert(host_menu::save_record(store.path(id).string(),"PIJAVA_DECK_GAME 2\n8 2\n\"旧名称\"\n\"\"\n"));loaded=store.load(id);assert(loaded.rotation==0&&loaded.profile==2&&loaded.alias=="旧名称");
assert(logical_screen::valid(800,480)&&logical_screen::valid(480,800)&&!logical_screen::valid(800,800));
presentation::orientation::Cache rot;std::vector<uint8_t> rgb(18);for(int i=0;i<6;++i)rgb[i*3]=uint8_t(i+1);auto& turned=rot.apply(rgb,2,3,1,1,1,true);assert(rot.width()==3&&rot.height()==2&&turned[6]==1);rgb[0]=22;assert(rot.apply(rgb,2,3,1,1,1,true)[6]==22);assert(&rot.apply(rgb,2,3,0,1,1,false)==&rgb);
deck_ui::UI ui;ui.settings.show_fps=false;host_skin::Pixels skin(1280*720,0xff111111);deck_custom_skin::Meta meta;meta.rect={100,100,800,500};ui.custom(meta,skin);std::vector<uint8_t> fb(320*240*3);for(size_t i=0;i<fb.size();i+=3){fb[i]=20;fb[i+1]=40;fb[i+2]=60;}ui.game(fb.data(),320,240,"0");assert(ui.pixels[100*1280+100]==0xff000000&&ui.pixels[100*1280+167]==0xff3c2814&&ui.pixels[600*1280+1010]==0xff111111);
std::cout<<"PASS port regression: Java numeric formatting, Unicode editor boundaries, old config migration, rotation/800px budget, custom-mask aspect-fit black bars\n";
}
