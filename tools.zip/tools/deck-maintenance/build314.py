from pathlib import Path
import subprocess,sys
root=Path('work/PiJava-main').resolve();build=Path('work/build314-java').resolve();classes=build/'classes';empty=build/'empty';classes.mkdir(parents=True,exist_ok=True);empty.mkdir(exist_ok=True)
args=['-source','8','-target','8','-encoding','UTF-8','-bootclasspath',str(empty),'-classpath',str(empty),'-sourcepath',str(root/'java'),'-d',str(classes)]+[str(p) for p in sorted((root/'java').rglob('*.java'))]
argfile=build/'sources.args';argfile.write_text('\n'.join('"'+s.replace('\\','/')+'"' for s in args),encoding='utf-8')
subprocess.run(['D:/j2me/jdk1.8.0_281/bin/javac.exe','@'+str(argfile)],check=True)
import shutil
for p in classes.rglob('*.class'):
    dest=root/'romfs/classes'/p.relative_to(classes);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
subprocess.run([sys.executable,str(root/'tools/generate_library_manifest.py')],check=True)
source=Path('work/build39.py').read_text(encoding='utf-8').replace('v3.9','v3.14').replace('experimental3.9','experimental3.14').replace('empty-java39','empty-java314')
# Canvas was compiled with the complete library above; do not change its bytes
# after the manifest has been pinned.
start=source.index('subprocess.run([r\'D:/j2me/');end=source.index('\nzig=',start);source=source[:start]+source[end:]
source=source.replace('Compiled Java Canvas and linked Linux release; no emulator or tests executed.','Compiled complete Java library and linked Linux release; test results are recorded separately.')
exec(compile(source,str(__file__),'exec'))
