from pathlib import Path
import subprocess,sys
base=Path(__file__).resolve().parent.parent
r=base/'work/PiJava-main'
empty=base/'work/empty-java39';empty.mkdir(exist_ok=True)
subprocess.run([r'D:/j2me/jdk1.8.0_281/bin/javac.exe','-encoding','UTF-8','-source','8','-target','8','-classpath',str(r/'romfs/classes'),'-sourcepath',str(empty),'-d',str(r/'romfs/classes'),str(r/'java/javax/microedition/lcdui/Canvas.java')],cwd=base,check=True)
zig=str(base/'work/zig-x86_64-windows-0.14.1/zig.exe')
common=[zig,'c++','-target','x86_64-linux-gnu.2.31']
subprocess.run(common+['-std=c++17','-O2','-fno-exceptions','-DJ2ME_ENABLE_SDL','-DJ2ME_VERSION="0.2.114-deck-experimental3.9"','-Iwork/PiJava-main/src','-Iwork/sdl-dev/usr/include/SDL2','-Iwork/sdl-dev/usr/include/x86_64-linux-gnu','-c','work/PiJava-main/src/j2mevm.cpp','-o','work/cross/j2mevm-v3.9.o'],cwd=base,check=True)
subprocess.run(common+['-O2','work/cross/j2mevm-v3.9.o','work/cross/puff.o','work/sdl-lib/usr/lib/x86_64-linux-gnu/libSDL2-2.0.so.0.2600.5','-ldl','-pthread','-Wl,--allow-shlib-undefined','-o','work/cross/pijava-deck-v3.9'],cwd=base,check=True)
print('Compiled Java Canvas and linked Linux release; no emulator or tests executed.')
