from pathlib import Path
import struct,json
p=Path('work/cross/pijava-deck-v3.14');b=p.read_bytes()
assert b[:4]==b'\x7fELF' and b[4:6]==bytes([2,1])
assert struct.unpack_from('<H',b,18)[0]==62
phoff=struct.unpack_from('<Q',b,32)[0];phsize,phnum=struct.unpack_from('<HH',b,54)
ph=[struct.unpack_from('<IIQQQQQQ',b,phoff+i*phsize) for i in range(phnum)]
def vaoff(v):
    for typ,flags,off,va,pa,fs,ms,align in ph:
        if typ==1 and va<=v<va+fs:return off+v-va
    raise ValueError(hex(v))
interp='';dyn=[]
for typ,flags,off,va,pa,fs,ms,align in ph:
    if typ==3:interp=b[off:off+fs].rstrip(b'\0').decode()
    if typ==2:
        for i in range(off,off+fs,16):
            tag,val=struct.unpack_from('<QQ',b,i)
            if not tag:break
            dyn.append((tag,val))
stroff=vaoff(next(v for t,v in dyn if t==5))
needed=[]
for t,v in dyn:
    if t==1:needed.append(b[stroff+v:b.index(b'\0',stroff+v)].decode())
info={'format':'ELF64 little-endian','architecture':'AMD x86-64','interpreter':interp,'needed':needed,'bytes':len(b),'glibc_target':'2.31','executed_on_linux':False}
print(json.dumps(info,indent=2));Path('work/cross/elf-inspection-v3.14.json').write_text(json.dumps(info,indent=2)+'\n')
