from pathlib import Path
import subprocess,json
r=Path('work/PiJava-main').resolve();out=Path('work/tests313').resolve();zig=str(Path('work/zig-x86_64-windows-0.14.1/zig.exe').resolve());shim=Path('work/win312').resolve();images=out/'ui';images.mkdir(exist_ok=True)
results=[]
for name,source,args in [('navigation',r/'tests/deck_navigation_test.cpp',[]),('port-regression',Path('work/ports_regression312.cpp').resolve(),[str(out/'data')]),('ui',r/'tests/deck_ui_test.cpp',[str(images)])]:
    binary=out/(name+'.exe');cmd=[zig,'c++','-std=c++17','-O1','-fno-exceptions','-I'+str(r/'src'),'-I'+str(shim),'-include',str(shim/'compat.h'),str(source),'-o',str(binary)]
    p=subprocess.run(cmd,capture_output=True)
    if p.returncode:print('compile',name,p.stderr.decode(errors='replace')[-2500:]);results.append({'name':name,'compile':p.returncode});continue
    p=subprocess.run([str(binary)]+args,cwd=r,capture_output=True,timeout=90);(out/(name+'.log')).write_bytes(p.stdout+p.stderr);print(name,p.returncode,(p.stdout+p.stderr).decode(errors='replace')[-1300:],flush=True);results.append({'name':name,'run':p.returncode})
(out/'ui-summary.json').write_text(json.dumps(results,indent=2))
