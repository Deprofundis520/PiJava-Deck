from pathlib import Path
import shutil,tarfile,zipfile,hashlib
root=Path('work/PiJava-main');stage=Path('work/package-v3.14/PiJava-Deck');stage.mkdir(parents=True,exist_ok=True)
for name in ['pijava-deck','PiJava','安装到桌面','一键安装','添加到游戏模式','Install','Add to Gaming Mode']:shutil.copy2('work/cross/pijava-deck-v3.14',stage/name)
for name in ['romfs','licenses','games','state','skins']:shutil.copytree(root/name,stage/name,dirs_exist_ok=True)
for name in ['LICENSE','NOTICE.md','THIRD_PARTY.md','STEAMDECK-PORT.json']:shutil.copy2(root/name,stage/name)
shutil.copy2(root/'docs/STEAMDECK.md',stage/'STEAMDECK.md')
shutil.copy2('outputs/README-v3.14.md',stage/'README.md')
shutil.copy2('outputs/内存修改使用说明-v3.14.md',stage/'内存修改使用说明.md')
shutil.copy2('outputs/作者更新综合说明-v3.14.md',stage/'作者更新综合说明.md')
shutil.copy2('outputs/构建验证记录-v3.14.md',stage/'测试范围.md')
shutil.copy2(root/'tools/launch-steamdeck.sh',stage/'launch-steamdeck.sh')
shutil.copy2(root/'assets/icon.png',stage/'icon.png')
shutil.copy2('outputs/点开即用说明-v3.14.md',stage/'先看这里.md')
shutil.copy2('outputs/点开即用说明-v3.14.md',stage/'更新说明.md')
shutil.copy2('outputs/构建验证记录-v3.14.md',stage/'构建验证记录.md')
archive=Path('outputs/PiJava-Deck-点开即用-v3.14.tar.gz')
executables={'pijava-deck','PiJava','安装到桌面','一键安装','添加到游戏模式','Install','Add to Gaming Mode','launch-steamdeck.sh'}
with tarfile.open(archive,'w:gz') as t:
    for p in sorted(stage.rglob('*')):
        info=t.gettarinfo(str(p),arcname='PiJava-Deck/'+p.relative_to(stage).as_posix())
        info.uid=info.gid=0;info.uname=info.gname='';info.mode=0o755 if p.is_dir() or p.name in executables else 0o644
        if p.is_file():
            with p.open('rb') as f:t.addfile(info,f)
        else:t.addfile(info)
with zipfile.ZipFile('outputs/PiJava-Deck-source-v3.14.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(root.rglob('*')):
        if p.is_file() and '__pycache__' not in p.parts:z.write(p,'PiJava-Deck-source/'+p.relative_to(root).as_posix())
# v3.14 full-source delivery; no stale historical patch copied
shutil.copy2('work/cross/elf-inspection-v3.14.json','outputs/elf-inspection-v3.14.json')
with tarfile.open(archive) as t:
    hashes=[]
    for name in ['pijava-deck','PiJava','安装到桌面','一键安装','添加到游戏模式','Install','Add to Gaming Mode']:
        p=t.getmember('PiJava-Deck/'+name);assert p.mode==0o755
        b=t.extractfile(p).read();assert b[:4]==b'\x7fELF';hashes.append(hashlib.sha256(b).hexdigest())
    assert len(set(hashes))==1
    assert t.getmember('PiJava-Deck/games/游戏放这里.txt')
    assert t.getmember('PiJava-Deck/icon.png')
    assert t.getmember('PiJava-Deck/romfs/classes/java/lang/Object.class')
    assert not any(n.lower().endswith('.jar') for n in t.getnames())
    assert hashlib.sha256(t.extractfile('PiJava-Deck/romfs/font/cjk.ttf').read()).hexdigest()=='aa4560dd8fe5645745fed3ffa301c3ca4d6c03cbd738145b613303961ba733b8'
checks=[]
for p in sorted(Path('outputs').iterdir()):
    if p.is_file() and 'v3.14' in p.name and p.name!='SHA256SUMS-v3.14.txt':checks.append(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name)
Path('outputs/SHA256SUMS-v3.14.txt').write_text('\n'.join(checks)+'\n',encoding='utf-8')
print('PASS: five executable launchers, permissions, icon, games folder, resources, font, no bundled games')
for p in sorted(Path('outputs').iterdir()):
    if 'v3.14' in p.name:print(p.name,p.stat().st_size)
