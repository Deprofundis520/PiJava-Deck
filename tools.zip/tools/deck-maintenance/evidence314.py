from pathlib import Path
import json,zipfile
b=Path('work/tests314');r=Path('work/PiJava-main');o=Path('outputs')
rows=json.loads((b/'summary.json').read_text());assert all(x['returncode']==0 for x in rows)
memory=json.loads(Path('work/tests313/memory-summary.json').read_text());assert memory['returncode']==0
ui=json.loads(Path('work/tests313/ui-summary.json').read_text());assert all(x.get('run')==0 for x in ui)
summary={'language_navigation_install':rows,'memory':memory,'ui':ui,'linux_elf_executed':False,'deck_hardware':False,'user_font_sha256':'aa4560dd8fe5645745fed3ffa301c3ca4d6c03cbd738145b613303961ba733b8'}
(b/'combined-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
with zipfile.ZipFile(o/'测试记录-v3.14.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in b.rglob('*'):
  if p.suffix in ('.png','.log','.json'):z.write(p,'current/'+p.relative_to(b).as_posix())
 for n in ['memory.log','memory-summary.json','navigation.log','port-regression.log','ui.log','ui-summary.json']:z.write(Path('work/tests313')/n,'regression/'+n)
 for p in [r/'tests/deck_language_test.cpp',r/'src/platform/deck_i18n.h',Path('work/test314.py'),Path('work/build314.py'),Path('work/build39.py')]:z.write(p,'harness/'+p.name)
 z.write(o/'构建验证记录-v3.14.md','阅读说明.md')
print('PASS language, installer, memory and UI evidence collected')
