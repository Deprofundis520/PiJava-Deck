from pathlib import Path
import subprocess,json
from PIL import Image
r=Path('work/PiJava-main').resolve();out=Path('work/tests314').resolve();out.mkdir(exist_ok=True);zig=str(Path('work/zig-x86_64-windows-0.14.1/zig.exe').resolve());shim=Path('work/win312').resolve();results=[]
for name,src,args in [('language',r/'tests/deck_language_test.cpp',[str(out/'screens')]),('navigation',r/'tests/deck_navigation_test.cpp',[]),('launcher',r/'tests/deck_launcher_test.cpp',[])]:
 binary=out/(name+'.exe');p=subprocess.run([zig,'c++','-std=c++17','-O1','-fno-exceptions','-I'+str(r/'src'),'-I'+str(shim),'-include',str(shim/'compat.h'),str(src),'-o',str(binary)],capture_output=True)
 if p.returncode:print(p.stderr.decode(errors='replace')[-2500:]);raise SystemExit(1)
 p=subprocess.run([str(binary)]+args,cwd=r,capture_output=True,timeout=120);(out/(name+'.log')).write_bytes(p.stdout+p.stderr);results.append({'name':name,'returncode':p.returncode,'stdout':p.stdout.decode(errors='replace')});print(results[-1],flush=True)
(out/'summary.json').write_text(json.dumps(results,indent=2));
for p in (out/'screens').glob('*.ppm'):Image.open(p).save(p.with_suffix('.png'))
assert all(p['returncode']==0 for p in results)
