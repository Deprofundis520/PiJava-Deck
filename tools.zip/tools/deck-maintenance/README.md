# Maintenance script snapshot / 维护脚本快照

These scripts were used from the original Windows workspace root. They retain workspace-relative `work/PiJava-main` paths, an external JDK8 path, and references to Zig/SDL and Windows test adapters. They are preserved for traceability, not as a portable one-click build. Review paths before use. `build314.py` reads `build39.py`; the latter must not be run directly to build the latest version.

For a Linux source build with the bundled Java class resources, use the root CMakeLists.txt with SDL2 development packages, CMake, pkg-config and a C++17 compiler. CMake does not rebuild Java automatically or run the complete VM test suite. Compile changed Java sources with JDK8 and regenerate tools/generate_library_manifest.py before building the VM.

Actual bilingual implementation: src/platform/deck_i18n.h; readable catalog: docs/ui-english.json; language UI route: sdl_host.inc option 10; settings count: 11; config: user pijava/language.cfg. docs/LANGUAGE.md describes UI use. User/game content must stay raw. Fonts are bundled at romfs/font/cjk.ttf. Production Linux compilation and Windows host tests are described in the delivered build report; Steam Deck hardware execution is not claimed.

本目录为本次维护脚本原样快照，运行前必须按实际工程布局调整路径；Zig、SDL、JDK和测试适配工具没有包含在这里。完整源代码和资源位于源码包根目录。
