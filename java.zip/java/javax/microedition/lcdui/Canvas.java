package javax.microedition.lcdui;
public abstract class Canvas extends Displayable {
    public static final int UP = 1;
    public static final int DOWN = 6;
    public static final int LEFT = 2;
    public static final int RIGHT = 5;
    public static final int FIRE = 8;
    public static final int GAME_A = 9;
    public static final int GAME_B = 10;
    public static final int GAME_C = 11;
    public static final int GAME_D = 12;
    public static final int KEY_NUM0 = 48;
    public static final int KEY_NUM1 = 49;
    public static final int KEY_STAR = 42;
    public static final int KEY_POUND = 35;
    protected Canvas() {}
    protected abstract void paint(Graphics g);
    protected void keyPressed(int keyCode) {}
    protected void keyReleased(int keyCode) {}
    protected void keyRepeated(int keyCode) {}
    public native void repaint();
    public void repaint(int x, int y, int width, int height) {
        if (width <= 0 || height <= 0 || x >= getWidth() || y >= getHeight()
                || (long) x + width <= 0 || (long) y + height <= 0) return;
        // The current software backend coalesces dirty regions into a full repaint.
        repaint();
    }
    public native void serviceRepaints();
    public native void setFullScreenMode(boolean mode);
    public boolean hasPointerEvents() { return false; }
    public boolean hasPointerMotionEvents() { return false; }
    public boolean hasRepeatEvents() { return false; }
    public boolean isDoubleBuffered() { return true; }
    protected void pointerPressed(int x, int y) {}
    protected void pointerReleased(int x, int y) {}
    protected void pointerDragged(int x, int y) {}
    protected void showNotify() {}
    protected void hideNotify() {}
    protected void sizeChanged(int w, int h) {}
    public native String getKeyName(int keyCode);
    public native int getKeyCode(int gameAction);
    public native int getGameAction(int keyCode);
}
