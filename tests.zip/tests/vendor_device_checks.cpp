#define main emulator_main
#include "../src/j2mevm.cpp"
#undef main

static void check(bool ok,const char* label) {
    if(!ok){std::cerr<<"FAIL vendor device API "<<label<<"\n";std::exit(1);}
}
int main(int argc,char** argv) {
    configure_runtime_diagnostics();
    VMS_CL(g_classpath)={"build/vendor-device-classes","romfs/classes"};
    VMS_DIAG(g_log_draw)=false;
    for(const char* name:{"com/siemens/mp/game/Vibrator","com/motorola/multimedia/Lighting","mmpp/media/BackLight"}) {
        std::vector<uint8_t> bytes;
        check(read_whole(std::string("romfs/classes/")+name+".class",bytes),name);
        check(ensure_class(name)>=0,"bundled class loads");
    }
    struct Entry {const char* cls;const char* name;const char* desc;};
    const Entry methods[]={
        {"com/siemens/mp/game/Vibrator","<init>","()V"},
        {"com/siemens/mp/game/Vibrator","startVibrator","()V"},
        {"com/siemens/mp/game/Vibrator","stopVibrator","()V"},
        {"com/siemens/mp/game/Vibrator","triggerVibrator","(I)V"},
        {"com/motorola/multimedia/Lighting","<init>","()V"},
        {"com/motorola/multimedia/Lighting","backlightOn","()V"},
        {"com/motorola/multimedia/Lighting","backlightOff","()V"},
        {"mmpp/media/BackLight","<init>","()V"},
        {"mmpp/media/BackLight","getColor","()I"},
        {"mmpp/media/BackLight","numColors","()I"},
        {"mmpp/media/BackLight","off","()V"},
        {"mmpp/media/BackLight","on","(I)V"},
        {"mmpp/media/BackLight","setColor","(I)V"}
    };
    for(const auto& entry:methods)
        check(find_method(ensure_class(entry.cls),entry.name,entry.desc,false),entry.name);
    if(argc>1&&std::string(argv[1])=="fixture") {
        VMS_RS(g_fb).assign(12,91);const auto original=VMS_RS(g_fb);
        const int width=VMS_RS(g_screen_w),height=VMS_RS(g_screen_h);
        Method* fixture=find_method(ensure_class("VendorDeviceChecks"),"run","()I",false);
        check(fixture,"Java consumer resolves");
        Value result=run(fixture,{});
        check(!VMS_EXEC(g_thrown)&&result.i==10000,"Java API calls and unsupported color contract");
        check(VMS_RS(g_fb)==original&&VMS_RS(g_screen_w)==width&&VMS_RS(g_screen_h)==height,
              "device requests preserve rendered display");
    }
    std::cout<<"PASS vendor device API class loading, public signatures, unsupported color, repeated calls\n";
    p7::pool().shutdown();
}
