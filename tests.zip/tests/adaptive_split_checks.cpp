#include "../src/p7_present.h"
#include <cassert>
#include <cstdio>
int main(){
 assert(p7::pool().start());p7present::g_enabled=true;
 constexpr int pitch=1297;constexpr uint32_t guard=0x12345678;
 for(auto dims:{std::pair<int,int>{240,320},{120,160},{176,220},{640,360},{17,639},{639,17},{640,640},{480,800},{800,480},{512,800},{800,512}}){
  const int w=dims.first,h=dims.second;auto view=j2me_present::game_viewport(w,h,true);
  std::vector<uint8_t> source(size_t(w)*h*3);for(size_t i=0;i<source.size();++i)source[i]=uint8_t(i*71);
  const auto before=source;std::vector<uint32_t> expected(size_t(pitch)*720,guard),actual=expected;
  display_filter::render(expected.data()+size_t(view.y)*pitch+view.x,pitch,source.data(),w,h,display_filter::Filter::Original,view.w,view.h);
  const auto splits=p7present::g_split;
  // Exercise both modes regardless of host timing preference.
  for(int mode=0;mode<2;++mode){
   p7present::g_n[0]=mode?2:0;p7present::g_n[1]=0;
   actual.assign(actual.size(),guard);
   p7present::blit_game(actual.data(),pitch,source.data(),w,h,display_filter::Filter::Original,view);
   assert(actual==expected&&source==before);
  }
  assert(p7present::g_split>splits);
 }
 p7::pool().shutdown();std::puts("PASS adaptive serial/split: integer reference pixels, borders/pitch, source immutable, seven ratios");
}
