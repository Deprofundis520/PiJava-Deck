// Deliberately deferred GPU mock: reads from staging happen later, at a reused
// slot's fence. A checksum proves no in-flight source was overwritten early.
#include "../src/switch_gpu_present.h"
#include "../src/presentation/gpu_filter.h"
#include <algorithm>
#include <cassert>
#include <iostream>
#include <map>
#include <vector>
namespace dk::detail {
struct Device{};
struct MemBlock{std::vector<uint8_t> data;};
struct Queue{unsigned next=0;};
struct Swapchain{std::vector<const DkImage*> images;};
struct Op{const DkImage* source;DkImageRect src;const DkImage* dest;DkImageRect dst;uint64_t hash;bool after_filter;};
struct Draw{const DkImage* dest;DkBufExtents input;DkBufExtents gains;DkScissor rect;uint64_t hash;};
struct CmdBuf{std::vector<Draw> draws;DkBufExtents buffers[2]{};const DkImage* target=nullptr;DkViewport viewport{};DkScissor scissor{};std::vector<Op> ops;DkFence* fence=nullptr;bool inflight=false;};
}
namespace mock {
struct Layout {uint32_t w,h,pitch,flags;};
struct Image {DkMemBlock mem;uint32_t offset;Layout layout;};
std::map<const DkImage*,Image> images;
std::vector<DkCmdBuf> pending;
std::map<DkCmdBuf,std::vector<uint32_t>> expected;
int blocks=0,commands=0,devices=0,queues=0,swapchains=0;
unsigned idle_waits=0,fence_waits=0,max_pending=0,completed=0,allocation=0,fail_allocation=0;
unsigned shader_initializations=0,acquire_calls=0;
bool fail_flush=false,fail_fence=false,fail_acquire=false,bad_queue=false,invalid_shader=false;
uint64_t hash_image(const Image& i){uint64_t h=1469598103934665603ULL;const size_t n=size_t(i.layout.pitch)*i.layout.h;assert(i.offset+n<=i.mem->data.size());for(size_t p=0;p<n;p++){h^=i.mem->data[i.offset+p];h*=1099511628211ULL;}return h;}
Layout layout(const DkImageLayout* p){Layout l;std::memcpy(&l,p,sizeof l);return l;}
uint64_t hash_buffer(const DkBufExtents& b){const auto* p=reinterpret_cast<const uint8_t*>(b.addr);uint64_t h=0;for(unsigned i=0;i<b.size;++i)h=h*131+p[i];return h;}
void execute_one(){
 assert(!pending.empty());auto* cmd=pending.front();pending.erase(pending.begin());assert(cmd->inflight);
 auto execute_blit=[&](const dk::detail::Op& op){const auto src=images.at(op.source),dst=images.at(op.dest);assert(hash_image(src)==op.hash);
  for(unsigned y=0;y<op.dst.height;y++)for(unsigned x=0;x<op.dst.width;x++){
   const size_t sp=src.offset+size_t(op.src.y+y*op.src.height/op.dst.height)*src.layout.pitch+size_t(op.src.x+x*op.src.width/op.dst.width)*4;
   const size_t dp=dst.offset+size_t(op.dst.y+y)*dst.layout.pitch+size_t(op.dst.x+x)*4;
   assert(dp+4<=dst.mem->data.size()&&sp+4<=src.mem->data.size());std::memcpy(dst.mem->data.data()+dp,src.mem->data.data()+sp,4);
  }
 };
 for(const auto& op:cmd->ops)if(!op.after_filter)execute_blit(op);
 for(const auto& draw:cmd->draws){
  assert(hash_buffer(draw.input)==draw.hash);const auto* words=reinterpret_cast<const uint32_t*>(draw.input.addr);const auto* gains=reinterpret_cast<const uint32_t*>(draw.gains.addr);
  const auto rect=j2me_present::gpu_filter::gpu_filter_viewport(words[0],words[1],words[3]);
  assert(draw.rect.x==rect.x&&draw.rect.y==rect.y&&draw.rect.width==rect.w&&draw.rect.height==rect.h);
  const auto dst=images.at(draw.dest);for(unsigned y=0;y<rect.h;++y)for(unsigned x=0;x<rect.w;++x){
   const auto gain=gains[(y%64)*48+x%48];
   uint32_t got=words[3]==0?j2me_present::gpu_filter::gpu_filter_pixel(words+4,x,y,words[0],words[1],words[2],gain):
    j2me_present::gpu_filter::gpu_filter_pixel_extent(words+4,x,y,words[0],words[1],words[2],gain,rect.w,rect.h);
   std::memcpy(dst.mem->data.data()+dst.offset+size_t(y+rect.y)*dst.layout.pitch+(x+rect.x)*4,&got,4);
  }
 }
 for(const auto& op:cmd->ops)if(op.after_filter)execute_blit(op);
 if(expected.count(cmd)){const auto& want=expected.at(cmd);const auto img=images.at(cmd->draws.empty()?cmd->ops.back().dest:cmd->draws.back().dest);assert(std::memcmp(want.data(),img.mem->data.data()+img.offset,want.size()*4)==0);expected.erase(cmd);}
 cmd->inflight=false;completed++;
}
void drained(){while(!pending.empty())execute_one();}
void clean(){assert(!blocks&&!commands&&!devices&&!queues&&!swapchains&&pending.empty()&&expected.empty());}
}
extern "C" {
DkDevice dkDeviceCreate(const DkDeviceMaker*){mock::devices++;return new dk::detail::Device;}
void dkDeviceDestroy(DkDevice p){mock::devices--;delete p;}
DkQueue dkQueueCreate(const DkQueueMaker*){mock::queues++;return new dk::detail::Queue;}
void dkQueueDestroy(DkQueue p){assert(mock::pending.empty());mock::queues--;delete p;}
bool dkQueueIsInErrorState(DkQueue){return mock::bad_queue;}
void dkQueueWaitIdle(DkQueue){mock::idle_waits++;mock::drained();}
DkMemBlock dkMemBlockCreate(const DkMemBlockMaker* m){if(++mock::allocation==mock::fail_allocation)return nullptr;mock::blocks++;auto* b=new dk::detail::MemBlock;b->data.resize(m->size);return b;}
void dkMemBlockDestroy(DkMemBlock p){assert(mock::pending.empty());for(auto i=mock::images.begin();i!=mock::images.end();)if(i->second.mem==p)i=mock::images.erase(i);else ++i;mock::blocks--;delete p;}
void* dkMemBlockGetCpuAddr(DkMemBlock p){return p->data.data();}
DkGpuAddr dkMemBlockGetGpuAddr(DkMemBlock p){return reinterpret_cast<uintptr_t>(p->data.data());}
void dkShaderInitialize(DkShader*,const DkShaderMaker*){++mock::shader_initializations;}
bool dkShaderIsValid(const DkShader*){return !mock::invalid_shader;}
DkResult dkMemBlockFlushCpuCache(DkMemBlock p,uint32_t off,uint32_t n){assert(size_t(off)+n<=p->data.size());return mock::fail_flush?DkResult_Fail:DkResult_Success;}
DkCmdBuf dkCmdBufCreate(const DkCmdBufMaker*){mock::commands++;return new dk::detail::CmdBuf;}
void dkCmdBufDestroy(DkCmdBuf c){assert(!c->inflight);mock::commands--;delete c;}
void dkCmdBufAddMemory(DkCmdBuf,DkMemBlock p,uint32_t off,uint32_t n){assert(size_t(off)+n<=p->data.size());}
void dkCmdBufClear(DkCmdBuf c){assert(!c->inflight);c->ops.clear();c->draws.clear();c->fence=nullptr;}
void dkCmdBufBarrier(DkCmdBuf,DkBarrier,uint32_t){}
void dkCmdBufBindShaders(DkCmdBuf,uint32_t,const DkShader* const*,uint32_t){}
void dkCmdBufBindStorageBuffers(DkCmdBuf c,DkStage stage,uint32_t first,const DkBufExtents* b,uint32_t n){assert(stage==DkStage_Fragment&&first+n<=2);for(unsigned i=0;i<n;++i)c->buffers[first+i]=b[i];}
void dkCmdBufBindRenderTargets(DkCmdBuf c,const DkImageView* const* v,uint32_t n,const DkImageView*){assert(n==1);c->target=v[0]->pImage;assert(mock::images.at(c->target).layout.flags&DkImageFlags_UsageRender);}
void dkCmdBufBindRasterizerState(DkCmdBuf,const DkRasterizerState*){}
void dkCmdBufBindMultisampleState(DkCmdBuf,const DkMultisampleState*){}
void dkCmdBufBindColorState(DkCmdBuf,const DkColorState*){}
void dkCmdBufBindColorWriteState(DkCmdBuf,const DkColorWriteState*){}
void dkCmdBufBindDepthStencilState(DkCmdBuf,const DkDepthStencilState*){}
void dkCmdBufSetViewports(DkCmdBuf c,uint32_t,const DkViewport* v,uint32_t n){assert(n==1&&v->x>=0&&v->y>=0&&v->width>0&&v->height>0&&v->x+v->width<=1280&&v->y+v->height<=720);c->viewport=*v;}
void dkCmdBufSetScissors(DkCmdBuf c,uint32_t,const DkScissor* v,uint32_t n){assert(n==1&&v->x==c->viewport.x&&v->y==c->viewport.y&&v->width==c->viewport.width&&v->height==c->viewport.height);c->scissor=*v;}
void dkCmdBufDraw(DkCmdBuf c,DkPrimitive p,uint32_t count,uint32_t instances,uint32_t,uint32_t){assert(p==DkPrimitive_Triangles&&count==3&&instances==1);c->draws.push_back({c->target,c->buffers[0],c->buffers[1],c->scissor,0});}
void dkCmdBufBlitImage(DkCmdBuf c,const DkImageView* s,const DkImageRect* sr,const DkImageView* d,const DkImageRect* dr,uint32_t,uint32_t){assert(!c->inflight);c->ops.push_back({s->pImage,*sr,d->pImage,*dr,0,!c->draws.empty()});}
void dkCmdBufSignalFence(DkCmdBuf c,DkFence* f,bool flush){assert(flush);c->fence=f;}
DkCmdList dkCmdBufFinishList(DkCmdBuf c){return reinterpret_cast<uintptr_t>(c);}
void dkQueueSubmitCommands(DkQueue,DkCmdList list){auto* c=reinterpret_cast<DkCmdBuf>(list);assert(c->fence&&!c->inflight);for(auto& op:c->ops)op.hash=mock::hash_image(mock::images.at(op.source));for(auto& draw:c->draws)draw.hash=mock::hash_buffer(draw.input);c->inflight=true;mock::pending.push_back(c);mock::max_pending=std::max(mock::max_pending,unsigned(mock::pending.size()));}
DkResult dkFenceWait(DkFence* f,int64_t timeout){assert(timeout>0);mock::fence_waits++;if(mock::fail_fence)return DkResult_Timeout;bool found=false;for(auto* c:mock::pending)if(c->fence==f)found=true;if(found){while(!mock::pending.empty()){auto* c=mock::pending.front();mock::execute_one();if(c->fence==f)break;}}return DkResult_Success;}
int dkQueueAcquireImage(DkQueue q,DkSwapchain s){++mock::acquire_calls;return mock::fail_acquire?-1:int((q->next++)%s->images.size());}
void dkQueuePresentImage(DkQueue,DkSwapchain,int){}
void dkImageLayoutInitialize(DkImageLayout* p,const DkImageLayoutMaker* m){mock::Layout l{m->dimensions[0],m->dimensions[1],m->pitchStride?m->pitchStride:m->dimensions[0]*4,m->flags};std::memcpy(p,&l,sizeof l);}
uint64_t dkImageLayoutGetSize(const DkImageLayout* p){auto l=mock::layout(p);return uint64_t(l.pitch)*l.h;}
uint32_t dkImageLayoutGetAlignment(const DkImageLayout*){return 4096;}
void dkImageInitialize(DkImage* p,const DkImageLayout* l,DkMemBlock m,uint32_t off){mock::images[p]={m,off,mock::layout(l)};}
DkSwapchain dkSwapchainCreate(const DkSwapchainMaker* m){mock::swapchains++;auto* s=new dk::detail::Swapchain;for(unsigned i=0;i<m->numImages;i++){auto* p=m->pImages[i];assert((mock::images.at(p).layout.flags&DkImageFlags_UsagePresent)&&!(mock::images.at(p).layout.flags&DkImageFlags_PitchLinear));s->images.push_back(p);}return s;}
void dkSwapchainDestroy(DkSwapchain p){mock::swapchains--;delete p;}
void dkSwapchainSetSwapInterval(DkSwapchain,uint32_t interval){assert(interval==1);}
}
int main(){
 using namespace j2me_present;std::vector<uint8_t> rgb(size_t(240)*320*3);std::vector<uint32_t> game,chrome(canvas_pixels),want;
 for(size_t i=0;i<rgb.size();i++)rgb[i]=uint8_t(i*37);
 assert(game_rgba(rgb,240,320,game));assert(game.size()==480*640);auto original=rgb;
 for(size_t i=0;i<chrome.size();i++)chrome[i]=0xff000000u|uint32_t(i*23);
 assert(!game_rgba(rgb,239,320,game));assert(compose_reference(chrome,&game,want));assert(rgb==original);
 const size_t top=size_t(game_y)*output_w+game_x;assert(want[top]==game[0]&&want[top+1]==game[1]&&want[top+output_w]==game[480]);assert(want[4]==chrome[4]);
 assert(std::rename("romfs:/shaders/filter.vert.dksh","romfs:/shaders/filter.vert.missing")==0);
 {SwitchGpuPresent p;assert(!p.init());mock::clean();}
 assert(std::rename("romfs:/shaders/filter.vert.missing","romfs:/shaders/filter.vert.dksh")==0);
 // Malformed assets must return before the release SDK can dereference their
 // unchecked DKSH offsets. Mutate real shipped bytes, not an SDK validity flag.
 auto read=[](const char* path){FILE* f=std::fopen(path,"rb");assert(f);assert(std::fseek(f,0,SEEK_END)==0);long n=std::ftell(f);assert(n>0);std::rewind(f);std::vector<uint8_t> bytes(size_t(n),0);assert(std::fread(bytes.data(),1,bytes.size(),f)==bytes.size());assert(std::fclose(f)==0);return bytes;};
 auto write=[](const char* path,const std::vector<uint8_t>& bytes){FILE* f=std::fopen(path,"wb");assert(f);if(!bytes.empty())assert(std::fwrite(bytes.data(),1,bytes.size(),f)==bytes.size());assert(std::fclose(f)==0);};
 const char* vertex_path="romfs:/shaders/filter.vert.dksh";const auto vertex=read(vertex_path),fragment=read("romfs:/shaders/filter.frag.dksh");
 std::vector<std::vector<uint8_t>> malformed;
 malformed.push_back({});malformed.emplace_back(vertex.begin(),vertex.begin()+23);
 malformed.emplace_back(vertex.begin(),vertex.begin()+24); // Header, no program/code.
 malformed.emplace_back(vertex.begin(),vertex.end()-1); // Truncated body.
 for(size_t offset:{size_t(8),size_t(12),size_t(16),size_t(20)}){auto bytes=vertex;for(unsigned i=0;i<4;++i)bytes[offset+i]=0xff;malformed.push_back(bytes);}
 auto wrong_stage=vertex;wrong_stage[24]=1;malformed.push_back(wrong_stage);
 malformed.push_back(fragment); // Valid fragment cannot stand in for vertex.
 auto code_mutation=vertex;code_mutation.back()^=1;malformed.push_back(code_mutation);
 for(const auto& bytes:malformed){
  write(vertex_path,bytes);const unsigned before=mock::shader_initializations;
  {SwitchGpuPresent p;assert(!p.init());mock::clean();}
  assert(mock::shader_initializations==before);
 }
 write(vertex_path,vertex);
 // A corrupt fragment must also be rejected; only the prior valid vertex may
 // have reached initialization in this two-stage setup.
 write("romfs:/shaders/filter.frag.dksh",vertex);const unsigned before_fragment=mock::shader_initializations;
 {SwitchGpuPresent p;assert(!p.init());mock::clean();}assert(mock::shader_initializations==before_fragment+1);
 write("romfs:/shaders/filter.frag.dksh",fragment);
 mock::invalid_shader=true;{SwitchGpuPresent p;assert(!p.init());mock::clean();}mock::invalid_shader=false;
 for(unsigned fail=1;fail<=15;fail++){mock::allocation=0;mock::fail_allocation=fail;SwitchGpuPresent p;assert(!p.init());mock::clean();}mock::fail_allocation=0;
 // Scheduled GPU turns acquire once before Java, then present consumes that
 // same slot. No commands/staging writes occur merely by acquiring a slot.
 {
  SwitchGpuPresent p;assert(p.init());const unsigned first=mock::acquire_calls;
  assert(p.acquire_frame()&&p.acquire_frame());assert(mock::acquire_calls==first+1&&mock::pending.empty());
  mock::fail_acquire=true; // Present must reuse the held slot, never reacquire.
  assert(p.present_layers(reinterpret_cast<uint8_t*>(chrome.data()),1,reinterpret_cast<uint8_t*>(game.data())));
  assert(mock::acquire_calls==first+1);
  assert(p.lastTimings().acquire_before_present_us==p.lastTimings().acquire_wait_us);
  mock::fail_acquire=false;assert(p.acquire_frame());assert(mock::acquire_calls==first+2);
  p.close();mock::clean(); // A slot held without submitting is safe on teardown.
  assert(p.init()&&p.acquire_frame());assert(mock::acquire_calls==first+3);
  assert(p.present_layers(reinterpret_cast<uint8_t*>(chrome.data()),1));p.close();mock::clean();
 }
 {
  SwitchGpuPresent p;assert(p.init());mock::fail_acquire=true;assert(!p.acquire_frame());
  mock::fail_acquire=false;assert(p.acquire_frame());mock::bad_queue=true;
  assert(!p.present_layers(reinterpret_cast<uint8_t*>(chrome.data()),1));
  mock::bad_queue=false;p.close();mock::clean();
 }
 unsigned before=mock::idle_waits;uint64_t chrome_bytes=0,game_bytes=0;{
  SwitchGpuPresent p;assert(p.init()&&p.ready());uint64_t generation=0;
  for(unsigned n=0;n<60;n++){
   if(n%10==0){
    const int sizes[][2]={{240,320},{176,208},{360,360},{360,640},{640,360},{640,640}};
    const int w=sizes[n/10][0],h=sizes[n/10][1];rgb.resize(size_t(w)*h*3);
    for(size_t i=0;i<rgb.size();i++)rgb[i]=uint8_t(i*37+n);
    assert(game_rgba(rgb,w,h,game));
   }
   if(n%10==0){generation++;chrome[4]^=uint32_t(n+37);}game[0]^=uint32_t(n+1);
   const bool layered=n%7!=0;
   assert(p.present_layers(reinterpret_cast<uint8_t*>(chrome.data()),generation,layered?reinterpret_cast<uint8_t*>(game.data()):nullptr));
   if(layered){const auto& op=mock::pending.back()->ops.back();assert(op.src.width==480&&op.src.height==640&&op.dst.width==480&&op.dst.height==640&&op.dst.x==400&&op.dst.y==40);}
   assert(compose_reference(chrome,layered?&game:nullptr,want));mock::expected[mock::pending.back()]=want;
   chrome_bytes+=p.lastTimings().chrome_upload_bytes;game_bytes+=p.lastTimings().frame_upload_bytes;
   assert(mock::idle_waits==before);
  }
  assert(mock::max_pending==3&&mock::fence_waits>=57);p.close();mock::clean();
 }
 assert(chrome_bytes==uint64_t(18)*canvas_pixels*4);assert(game_bytes==uint64_t(51)*game_w*game_h*4);
 for(int failure=0;failure<4;failure++){
  SwitchGpuPresent p;assert(p.init());for(int i=0;i<3;i++)assert(p.present_layers(reinterpret_cast<uint8_t*>(chrome.data()),1,reinterpret_cast<uint8_t*>(game.data())));
  mock::fail_flush=failure==0;mock::fail_fence=failure==1;mock::fail_acquire=failure==2;mock::bad_queue=failure==3;
  assert(!p.present_layers(reinterpret_cast<uint8_t*>(chrome.data()),2,reinterpret_cast<uint8_t*>(game.data())));
  mock::fail_flush=mock::fail_fence=mock::fail_acquire=mock::bad_queue=false;p.close();mock::clean();
 }
 {
  SwitchGpuPresent p;assert(p.init());uint64_t uploaded=0;
  using F=display_filter::Filter;std::vector<uint32_t> raw;
  for(unsigned n=0;n<60;++n){
   const F presets[]={F::Bilinear,F::Scale2x,F::Lcd,F::Crt,F::ScanlinesDX};
   const F f=presets[n/12];int w=n<24?17:239,h=n<24?19:321;
   rgb.resize(size_t(w)*h*3);for(size_t i=0;i<rgb.size();++i)rgb[i]=uint8_t(i*17+n/6);
   j2me_present::gpu_filter::FrameKey key{7,n/6,w,h,f};assert(j2me_present::gpu_filter::pack(rgb,w,h,f,raw));
   assert(game_rgba(rgb,w,h,game,f));assert(compose_reference(chrome,&game,want));
   assert(p.present_layers(reinterpret_cast<uint8_t*>(chrome.data()),77,nullptr,raw.data(),&key));
   mock::expected[mock::pending.back()]=want;uploaded+=p.lastTimings().frame_upload_bytes;
   assert(p.lastTimings().frame_upload_bytes==(n%6<3||n==11?raw.size()*4:0));
   if(n==10)p.invalidate_game(); // Same completed key must refresh on dirty/restore.
   if(n==11||n==23)p.invalidate_game();
  }
  assert(uploaded>0);p.close();mock::clean();
 }
 {
  SwitchGpuPresent p;assert(p.init());using F=display_filter::Filter;
  std::vector<uint32_t> raw;
  const F presets[]={F::Bilinear,F::Scale2x,F::Lcd,F::Crt,F::ScanlinesDX};
  for(auto bad:{std::pair<int,int>{800,513},{513,800},{800,800},{801,16}}){
   uint32_t header[]={unsigned(bad.first),unsigned(bad.second),unsigned(F::Crt),1};
   gpu_filter::FrameKey invalid{12,13,bad.first,bad.second,F::Crt,true};
   const unsigned acquired=mock::acquire_calls;
   assert(!p.present_layers(reinterpret_cast<uint8_t*>(chrome.data()),990,nullptr,header,&invalid));
   assert(mock::acquire_calls==acquired);
  }
  for(unsigned n=0;n<60;++n){
   const int sizes[][2]={{240,320},{239,321},{640,360},{640,640},{17,19},{480,800},{800,480},{512,800},{800,512},{640,640}};
   const unsigned index=n/6;const int w=sizes[index][0],h=sizes[index][1];const F f=presets[index%5];
   // One completed frame and filter, alternating adaptive/fixed within each
   // ring slot. The cache must refresh even though epoch/frame stay equal.
   const bool adaptive=(n%6)>=3;gpu_filter::FrameKey key{88,99,w,h,f,adaptive};
   rgb.resize(size_t(w)*h*3);for(size_t i=0;i<rgb.size();++i)rgb[i]=uint8_t(i*59+index);
   assert(gpu_filter::pack(rgb,w,h,f,raw,adaptive));
   const auto rect=game_viewport(w,h,adaptive);want=chrome;
   display_filter::render(want.data()+size_t(rect.y)*output_w+rect.x,output_w,rgb.data(),w,h,f,rect.w,rect.h);
   const Viewport overlay{630,330,70,25},invalid_overlay{1279,0,2,2};
   const Viewport* overlay_ptr=adaptive?&overlay:nullptr;
   if(overlay_ptr)for(int y=overlay.y;y<overlay.y+overlay.h;++y)for(int x=overlay.x;x<overlay.x+overlay.w;++x)want[size_t(y)*output_w+x]=chrome[size_t(y)*output_w+x];
   const unsigned acquired=mock::acquire_calls;
   assert(!p.present_layers(reinterpret_cast<uint8_t*>(chrome.data()),990,nullptr,raw.data(),&key,&invalid_overlay));
   const uint32_t flag=raw[3];raw[3]=2;assert(!p.present_layers(reinterpret_cast<uint8_t*>(chrome.data()),990,nullptr,raw.data(),&key));
   raw[3]=flag^1u;assert(!p.present_layers(reinterpret_cast<uint8_t*>(chrome.data()),990,nullptr,raw.data(),&key));
   assert(mock::acquire_calls==acquired);raw[3]=flag;
   assert(p.present_layers(reinterpret_cast<uint8_t*>(chrome.data()),990,nullptr,raw.data(),&key,overlay_ptr));
   assert(p.lastTimings().frame_upload_bytes==raw.size()*4);mock::expected[mock::pending.back()]=want;
  }
  p.close();mock::clean();
 }
 std::cout<<"PASS 235 GPU contract: early acquire idempotent/consumed once/close/fallback, 60 deferred frames pixel-exact, 3 simultaneous slots, no per-frame QueueWaitIdle, generations, 15 allocation failures, malformed/truncated/wrong-stage DKSH rejected before SDK, deferred raw shader contracts and repeat-upload cache, flush/fence/acquire/queue failures; adaptive viewport/scissor pixels, raw mode header validation, mode cache transitions and final chrome overlay; NOT hardware validation\n";
}
