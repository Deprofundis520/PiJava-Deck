"""Compile the actual Switch chapter controller with a real temporary filesystem."""
from pathlib import Path
import subprocess,tempfile
root=Path(__file__).resolve().parents[1]
host=(root/'src/platform/switch_host.inc').read_text()
assert 'static void update_chapter_import(' in host, 'chapter launcher controller is not implemented'
a=host.index('static void update_chapter_import(')
controller=host[a:host.index('\n}\n',a)+3]
build=root/'build/chapter-host';build.mkdir(parents=True,exist_ok=True)
prefix=r'''
#include "chapter_save_ui.h"
#include <cassert>
#include <filesystem>
#include <fstream>
using u64=uint64_t;
constexpr u64 HidNpadButton_AnyUp=1,HidNpadButton_AnyDown=2,HidNpadButton_L=4,HidNpadButton_ZL=8,HidNpadButton_R=16,HidNpadButton_ZR=32,HidNpadButton_A=64,HidNpadButton_B=128;
#define VMS_PLAT(x) x
struct Entry{std::string label,path;};
chapter_ui::State g_chapter_import;menu_actions::Repeat g_menu_repeat;
u64 g_chapter_blocked=0;
int g_cpu_cleared=0,presents=0,draws=0;bool g_menu_note_error=false,g_menu_note_neutral=true;
int64_t now=0;int64_t monotonic_ms(){return now;}
void draw_menu(const std::vector<Entry>&,int,const std::string&){++draws;}
void present(){++presents;}void log_line(const std::string&){}
'''
tail=r'''
int main(){namespace fs=std::filesystem;const std::string root="sdmc:/switch/j2me/rms";
std::vector<Entry> items;for(int i=0;i<15;++i){std::string p="game"+std::to_string(i)+".jar";std::ofstream(p)<<i;items.push_back({p,p});}
int sel=0;std::string status;auto step=[&](u64 down,u64 held,int64_t time){now=time;update_chapter_import(down,held,items,sel,status);};
assert(g_chapter_import.begin(items,0));step(0,HidNpadButton_AnyDown,0);assert(g_chapter_import.selected==1);
step(0,HidNpadButton_AnyDown,299);assert(g_chapter_import.selected==1);step(0,HidNpadButton_AnyDown,300);assert(g_chapter_import.selected==2);
step(0,0,301);step(HidNpadButton_R,HidNpadButton_R,302);assert(g_chapter_import.selected==8);
step(HidNpadButton_B|HidNpadButton_A,0,303);assert(!g_chapter_import.open); // cancellation priority
assert(g_chapter_import.begin(items,0));step(HidNpadButton_A,0,304);assert(!g_chapter_import.confirming&&!g_chapter_import.note.empty());
const auto id=chapter_save::jar_identity(items[1].path);fs::create_directories(root+"/suites/"+id);std::ofstream f(root+"/suites/"+id+"/r41.bin",std::ios::binary);const char bytes[]={0,0,0,1,73};f.write(bytes,5);f.close();
step(HidNpadButton_A,0,305);assert(g_chapter_import.confirming);step(HidNpadButton_B,0,306);assert(!g_chapter_import.confirming);
step(HidNpadButton_A,0,307);assert(g_chapter_import.confirming);
// A held while returning from HOME must be released before it can confirm.
g_chapter_blocked=~u64(0);step(HidNpadButton_A,HidNpadButton_A,308);assert(g_chapter_import.open&&g_chapter_import.confirming&&presents==0);
step(0,HidNpadButton_A,309);assert(g_chapter_import.open&&presents==0);step(0,0,310);
step(HidNpadButton_A,HidNpadButton_A,311);assert(!g_chapter_import.open&&presents==1&&!g_menu_note_error);
assert(status.find("按 A")!=std::string::npos&&status.find("即时存档")!=std::string::npos);
std::puts("PASS actual chapter controller: held repeat/page, cancel priority, no-source notice, confirmation, real import and cold-start guidance");}
'''
cpp=build/'checks.cpp';cpp.write_text(prefix+controller+tail);exe=build/'checks'
subprocess.run(['g++','-std=c++17','-O2','-I'+str(root/'src'),cpp,'-o',exe],check=True)
with tempfile.TemporaryDirectory(prefix='chapter-host-') as d:subprocess.run([exe],cwd=d,check=True)
# Audit both launch routes and the actual modal input ordering.
launch_start=host.index('static void launch_entry(')
launch=host[launch_start:host.index('\n}\n',launch_start)+3]
assert 'chapter_save::recover(' in launch
resume=host[host.index('log_line(std::string("CONTINUE begin ")'):host.index('log_line("CONTINUE status=')]
assert 'chapter_save::recover(' in resume and resume.index('chapter_save::recover(')<resume.index('restore_instant_state(')
menu=host[host.index('static void update_menu_delete('):host.index('static std::string button_names(')]
assert 'Result::InheritSave' in menu and 'g_chapter_blocked=held' in menu and 'g_chapter_import.begin(items,sel)' in menu
assert 'HidNpadButton_Y' not in host[host.index('// Horizontal navigation only'):host.index('else if (down & HidNpadButton_X)')]
assert host.index('if (!in_game && g_chapter_import.open)')<host.index('if (!in_game && import_prompt)')
print('PASS chapter launcher hooks: + menu entry, modal routing before launch, recovery before cold/instant launch')

assert "g_chapter_blocked=~u64(0)" in host[host.index("if(!focused) {"):host.index("padUpdate(&pad)")]
