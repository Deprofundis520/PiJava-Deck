// Run once against archived v3.12 source, then against current source.
#define main emulator_main
#include PROBE_VM
#undef main
#include PROBE_HOST_MENU
#include PROBE_HOST_SPEED
static host_menu::Settings g_menu_settings;
static std::string instant_state_path(const std::string&){return "unused-compat-state";}
#include PROBE_STATE
static void check(bool b,const char*n){if(!b){std::cerr<<"FAIL "<<n<<'\n';std::exit(1);}}
static Value call(const char*n,const char*d="()V"){auto*m=find_method(ensure_class("DeckMemoryCases"),n,d,false);check(m,"fixture method");auto v=run_event_callback(m,{});check(!VMS_EXEC(g_thrown)&&!current_context().unhandled,"Java call");return v;}
int main(int argc,char**argv){
    check(argc==5,"fixture library mode state");VMS_CL(g_classpath)={argv[1],argv[2]};VMS_RS(g_fb).assign(240*320*3,0);VMS_EXEC(g_midlet_state)=MidletState::Active;call("setup");int cls=ensure_class("DeckMemoryCases");auto*app=find_field(cls,"app","LDeckMemoryCases$App;");VMS_EXEC(g_midlet)=VMS_CL(g_classes)[cls].statics[app->slot].ref;host_events();
    for(const char*n:{"DeckMemoryCases","DeckMemoryBase","DeckMemoryCases$App","DeckMemoryCases$View"}){std::vector<uint8_t>b;check(read_whole(std::string(argv[1])+"/"+n+".class",b),"fixture class");VMS_CL(g_jar_files)[std::string(n)+".class"]=std::move(b);}
    if(std::string(argv[3])=="produce"){
        auto*p=find_field(cls,"player","LDeckMemoryCases;");int ref=VMS_CL(g_classes)[cls].statics[p->slot].ref;VMS_HEAP(g_heap)[ref].fields[find_field(cls,"gold","I")->slot]=Value::of_i(4242);
        SavState state;std::string bytes;check(capture_state(state,"memory-compat.jar")&&encode_state(state,bytes),"old source captures state");std::ofstream f(argv[4],std::ios::binary);f.write(bytes.data(),bytes.size());check(bool(f),"old state written");std::cout<<"PASS archived v3.12 VM produced J2S5 gold=4242\n";
    }else{
        std::ifstream f(argv[4],std::ios::binary);std::string bytes((std::istreambuf_iterator<char>(f)),{});SavState state;check(decode_state(bytes,state)&&apply_state(state),"current source restores archived state");check(call("gold","()I").i==4242&&call("gems","()I").i==3&&call("item","()I").i==100,"old values restored");call("spend");check(call("gold","()I").i==4232,"restored Java execution continues");std::cout<<"PASS current v3.13 VM loaded v3.12 J2S5 and continued Java\n";
    }
}
