#define main emulator_main
#include "../src/j2mevm.cpp"
#undef main
#include <cassert>
#include <iostream>

static int field_value(int cls,const char* name) {
    const auto* field=find_field(cls,name,"I");assert(field);
    return VMS_CL(g_classes)[field->owner].statics[field->slot].i;
}
int main() {
    VMS_CL(g_classpath)={"build/test-classes","romfs/classes"};VMS_DIAG(g_log_draw)=false;
    for(int cap:{0,30,60})for(int mode:{0,1,2,3,4,5}) {
        if(cap && mode)continue;
        stop_thread();VMS_EXEC(g_speed_cap)=cap;VMS_EXEC(g_slice_ms)=14;
        VMS_HEAP(g_heap).assign(1,Obj{});VMS_HEAP(g_free).clear();VMS_CL(g_classes).clear();VMS_CL(g_class_index).clear();
        VMS_RS(g_fb).assign(size_t(VMS_RS(g_screen_w))*VMS_RS(g_screen_h)*3,0);
        VMS_EXEC(g_midlet_state)=MidletState::Active;
        const int cls=ensure_class("NativeDeadlineFixture");
        run(find_method(cls,"start","(I)V",false),{Value::of_i(mode)});
        auto advance=[&](int milliseconds) {
            const int64_t began=monotonic_ms();
            while(monotonic_ms()-began<milliseconds) {
                speed_wait_paced_sleep();advance_game_frame();
                // Same dirty/group condition as existing gate tests; the new
                // optimization may not consume or manufacture a presentation.
                if(VMS_RS(g_fb_dirty)&&!speed_group_incomplete())VMS_RS(g_fb_dirty)=false;
            }
        };
        advance(400);
        const int prior_updates=field_value(cls,"updates"),prior_paints=field_value(cls,"paints");
        const uint64_t prior_waits=VMS_EXEC(g_poll_waits);
        const int64_t began=monotonic_ms();advance(1000);const int64_t elapsed=monotonic_ms()-began;
        const int updates=field_value(cls,"updates")-prior_updates;
        const int paints=field_value(cls,"paints")-prior_paints;
        const uint64_t waits=VMS_EXEC(g_poll_waits)-prior_waits;
        std::cout<<"deadline cap="<<cap<<" mode="<<mode<<" elapsed_ms="<<elapsed
                 <<" updates="<<updates<<" paints="<<paints<<" waits="<<waits<<'\n';
        if(!cap&&(mode==0||mode==2))assert(waits>0);
        else assert(waits==0);
        if(mode==0&&!cap)assert(updates>=11&&updates<=17);
        if(mode==2)assert(updates>=15&&updates<=24);
        if(mode!=5)assert(std::abs(updates-paints)<=1);
        else assert(paints==0);
        // This fixture's new native-only proof must never enter the existing
        // paced gate learner or turn a method into a global JIT exclusion.
        for(const auto& method:VMS_CL(g_classes)[cls].methods)
            if(method.name=="loop")assert(method.time_gates.empty());
    }
    stop_thread();std::cout<<"PASS native deadline VM timing, mutable fields, volatile/peer/monitor/no-paint rejection and cap isolation\n";
}
