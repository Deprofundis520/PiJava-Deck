#include "../src/canvas_declared_size.h"
#include <cassert>
#include <iostream>
using Bytes=std::vector<uint8_t>;
void n(Bytes& b,uint32_t v,int width){for(int i=width-1;i>=0;--i)b.push_back(uint8_t(v>>(8*i)));}
void utf(Bytes& b,const std::string& s){n(b,1,1);n(b,s.size(),2);b.insert(b.end(),s.begin(),s.end());}
struct Method {int name,flags;Bytes code;};
Bytes cls(const std::string& name,const std::string& parent,std::vector<Method> methods,int flags=1){
 Bytes b;n(b,0xcafebabe,4);n(b,0,2);n(b,48,2);n(b,10,2);
 utf(b,name);n(b,7,1);n(b,1,2);utf(b,parent);n(b,7,1);n(b,3,2);
 utf(b,"getWidth");utf(b,"getHeight");utf(b,"()I");utf(b,"Code");utf(b,"unused");
 n(b,flags,2);n(b,2,2);n(b,4,2);n(b,0,2);n(b,0,2);n(b,methods.size(),2);
 for(const auto& m:methods){n(b,m.flags,2);n(b,m.name,2);n(b,7,2);n(b,m.code.empty()?0:1,2);if(m.code.empty())continue;n(b,8,2);n(b,12+m.code.size(),4);n(b,1,2);n(b,1,2);n(b,m.code.size(),4);b.insert(b.end(),m.code.begin(),m.code.end());n(b,0,2);n(b,0,2);}
 n(b,0,2);return b;
}
Bytes constant(int value){return {17,uint8_t(value>>8),uint8_t(value),172};}
int main(){
 using namespace canvas_declared_size;
 const std::string canvas="javax/microedition/lcdui/Canvas";
 auto base=cls("game/Base",canvas,{{5,1,constant(240)},{6,1,constant(320)}});
 auto inspect_one=[&](const Bytes& b){return inspect({{"game/Base.class",b}});};
 auto r=inspect_one(base);assert(r.found&&!r.conflict&&r.w==240&&r.h==320);
 for(size_t len=0;len<base.size();++len){Bytes cut(base.begin(),base.begin()+len);assert(inspect_one(cut).conflict);}
 auto run=[&](std::vector<Method> methods){return inspect({{"base.class",base},{"sub.class",cls("game/Sub","game/Base",methods)}});};
 assert(run({}).found);
 // Private/static methods do not override the inherited public getter.
 assert(!run({{5,2,constant(640)}}).conflict);
 assert(!run({{5,9,constant(640)}}).conflict);
 // Nonconstant/abstract/native overrides block inheritance for that class.
 assert(!run({{5,1,{3,153,0,1,172}}}).conflict);
 assert(!run({{5,0x0401,{}},{6,1,constant(640)}}).conflict);
 assert(!run({{5,0x0101,{}},{6,1,constant(640)}}).conflict);
 auto bad=cls("game/Bad",canvas,{{5,1,constant(801)},{6,1,constant(320)}});assert(inspect_one(bad).conflict);
 bad=cls("game/Bad",canvas,{{5,1,constant(800)},{6,1,constant(800)}});assert(inspect_one(bad).conflict);
 bad=cls("game/Bad",canvas,{{5,1,constant(800)},{6,1,constant(480)}});assert(inspect_one(bad).found);
 assert(run({{5,1,constant(320)}}).w==320);
 assert(inspect({{"a.class",base},{"b.class",cls("game/Other",canvas,{{5,1,constant(320)},{6,1,constant(320)}})}}).conflict);
 assert(!run({{5,1,{3,153,0,1,172}}}).found);
 assert(!inspect_one(cls("abstract/Base",canvas,{{5,1,constant(240)},{6,1,constant(320)}},0x0401)).found);
 assert(!inspect_one(cls("ordinary/Object","java/lang/Object",{{5,1,constant(240)},{6,1,constant(320)}})).found);
 assert(!inspect_one(cls("branch/Game",canvas,{{5,1,{17,0,240,0,172}},{6,1,constant(320)}})).found);
 Bytes broken=base;broken[10]=255;assert(inspect_one(broken).conflict);
 broken=base;broken[8]=255;broken[9]=255;assert(inspect_one(broken).conflict);
 // Method Code attribute is near the tail; replace its known payload length.
 for(size_t i=0;i+3<base.size();++i)if(base[i]==0&&base[i+1]==0&&base[i+2]==0&&base[i+3]==16){broken=base;broken[i]=255;assert(inspect_one(broken).conflict);break;}
 for(size_t i=0;i<base.size();++i){Bytes malformed=base;malformed[i]=255;(void)inspect_one(malformed);}
 std::cout<<"canvas_declared_size checks passed\n";
}
