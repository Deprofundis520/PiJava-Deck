#define main emulator_main
#include "../src/j2mevm.cpp"
#undef main

static void check(bool ok, const char* label) {
    if (!ok) { std::cerr << "FAIL " << label << '\n'; std::exit(1); }
}
int main(int argc, char** argv) {
    if (argc != 4) return 2;
    VMS_CL(g_classpath) = {argv[1], argv[2]};
    VMS_DIAG(g_log_draw) = false;
    std::string mode = argv[3];
    if (mode == "filter") {
        check(load_class_file("java/io/FilterInputStream", false) >= 0, "FilterInputStream loads from frozen library");
    } else if (mode == "buffered") {
        check(load_class_file("java/io/BufferedInputStream", false) >= 0, "BufferedInputStream loads from frozen library");
    } else if (mode == "exception") {
        int cls = ensure_class("java/lang/StringIndexOutOfBoundsException");
        check(find_method(cls, "<init>", "(I)V", false), "StringIndexOutOfBoundsException integer constructor resolves");
    } else if (mode == "stack") {
        int cls = ensure_class("java/util/Stack");
        check(find_method(cls, "search", "(Ljava/lang/Object;)I", false), "Stack.search resolves");
    } else return 2;
    int fixture = ensure_class("Core48CldcChecks");
    Method* method = find_method(fixture, mode, "()I", false);
    check(method, "Java consumer fixture resolves");
    int assertions = run(method, {}).i;
    std::cout << "actual_java_assertions=" << assertions << '\n';
    check(assertions == (mode == "buffered" ? 341 : mode == "exception" ? 7 : mode == "filter" ? 9 : 10), "actual VM consumer assertions finish");
    std::cout << "PASS Core48Cldc " << mode << '\n';
}
