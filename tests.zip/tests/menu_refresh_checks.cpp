#include "host_display_menu.h"
#include "host_keymap_ui.h"
#include <cstdio>
#include <fstream>
#include <set>

// Exercise production renderers: text callbacks record what a user sees.
struct Call { int x,y,px; std::string text; };
static int failures=0;
static void check(bool ok,const char* message){if(!ok){++failures;std::fprintf(stderr,"FAIL %s\n",message);}}
int main(int argc,char** argv){
    using namespace host_menu;
    if(argc!=2)return 2;
    constexpr size_t pitch=1297;constexpr uint32_t guard=0x12345678;
    std::vector<uint32_t> frame(pitch*720,guard);std::vector<Call> calls;
    const Text text=[&](int x,int y,const std::string& s,uint32_t,int px,int){calls.push_back({x,y,px,s});};
    const CenteredText centered=[&](int x,int y,const std::string& s,uint32_t,int px,int){calls.push_back({x,y-px/2,px,s});};
    const auto find=[&](const std::string& s)->Call{for(const auto& c:calls)if(c.text==s)return c;return {-1,-1,0,s};};
    Settings settings;
    const auto launcher=[&](Focus f){calls.clear();render_menu(frame.data(),pitch,{"测试游戏"},0,f,settings,"",text,centered);};
    launcher(Focus::Games);
    const auto filter=find("滤镜"),rotation=find("画面旋转"),speed=find("速度");
    check(rotation.x>=900&&rotation.y>filter.y&&rotation.y<speed.y,"rotation is rendered in main options immediately below filter");
    std::set<int> reached;Focus focus=Focus::Bezel;
    for(int i=0;i<10;++i){reached.insert(int(focus));focus=option_step(focus,1);}
    check(reached.size()==5,"all five main option rows are reachable with down");
    bool rotation_highlight=false;
    for(int value:reached){launcher(static_cast<Focus>(value));const auto c=find("画面旋转");if(c.x>5&&c.y>=0&&frame[size_t(c.y)*pitch+c.x-6]==color(0xf4dddd))rotation_highlight=true;}
    check(rotation_highlight,"main rotation option receives the visible focus highlight");
    for(int expected:{1,2,3,0}){check(change_rotation(settings,1)&&settings.rotation==expected,"rotation cycles all four quarter turns");}

    launcher(Focus::Games);const auto more=find("更多设置"),title=find("游戏");
    // + is a raster icon; its white pixels reveal its actual center without a mock.
    int sx=0,sy=0,count=0;
    for(int y=20;y<100;++y)for(int x=1080;x<1150;++x)if(frame[size_t(y)*pitch+x]==color(0xffffff)){sx+=x;sy+=y;++count;}
    check(count>0&&std::abs(2*sy/count-(2*more.y+more.px))<=1,"header plus icon and More Settings share one vertical center");
    check(std::abs((2*more.y+more.px)-(2*title.y+title.px))<=1,"header action aligns with title row vertical center");

    host_display_menu::Model panel;panel.begin();std::set<int> actions;
    calls.clear();host_display_menu::render(frame.data(),pitch,panel,settings,text,centered);
    check(find("画面旋转").x<0&&find("画布尺寸").x<0,"More Settings contains neither rotation nor canvas selection");
    for(int i=0;i<10;++i){actions.insert(int(panel.selected()));panel.move(1);}
    check(actions.size()==3&&actions.count(int(host_display_menu::Action::Inherit))&&actions.count(int(host_display_menu::Action::DeleteGame))&&actions.count(int(host_display_menu::Action::DeleteInstant)),"all three remaining More Settings actions remain reachable");

    int bezel=4;for(int expected:{5,6,7,4}){bezel=next_bezel(bezel);check(bezel==expected,"bezel selection cycles Pro 4/5/6 and adaptive 7 with stable IDs");}
    for(int old=0;old<8;++old){
        std::ofstream f(argv[1],std::ios::binary);f<<"J2ME_MENU 2\nbezel="<<old<<"\nshow_fps=0\nfilter=1\nrotation=2\n";f.close();
        Settings loaded;check(load_settings(argv[1],loaded),"legacy bezel settings remain readable");
        check(loaded.bezel==(old<4?7:old),"retired bezel IDs migrate to adaptive while Pro IDs stay stable");
        check(!loaded.show_fps&&int(loaded.filter)==1&&loaded.rotation==2,"skin migration preserves other saved preferences");
    }
    std::remove(argv[1]);

    host_keymap::Editor editor;host_keymap::Store store;editor.begin(store,std::string(64,'a'),"test",false,false);editor.page=host_keymap::Page::Keymap;
    calls.clear();host_keymap::render(frame.data(),pitch,editor,text,centered);
    auto clear=find("清除映射"),save=find("保存当前映射");
    check(clear.x>=0&&save.x>clear.x&&std::abs(clear.y-save.y)<=1,"mapping footer places Clear Mapping immediately left of Save");
    bool minus_icon=false,plus_icon=false;
    if(clear.x>=24&&save.x>=24){
        const int cy=clear.y+11,mx=clear.x-24,px=save.x-24;
        minus_icon=frame[size_t(cy)*pitch+mx]==color(0xffffff)&&frame[size_t(cy)*pitch+mx+5]==color(0xffffff)&&frame[size_t(cy-5)*pitch+mx]!=color(0xffffff);
        plus_icon=frame[size_t(cy)*pitch+px]==color(0xffffff)&&frame[size_t(cy-5)*pitch+px]==color(0xffffff);
    }
    check(minus_icon&&plus_icon,"clear/save footer renders actual Minus and Plus symbols beside their actions");
    bool intervening=false;for(const auto& c:calls)if(c.y==save.y&&c.x>clear.x&&c.x<save.x)intervening=true;
    check(!intervening,"mapping clear and save footer actions are adjacent");
    check(find("方向键选择 · A 确认 · B 返回 · L3 固定菜单").x>=0,"mapping editor identifies L3 as reserved menu input");
    for(int y=0;y<720;++y)for(size_t x=1280;x<pitch;++x)if(frame[size_t(y)*pitch+x]!=guard){check(false,"renderer preserves stride padding");y=720;break;}
    std::printf("menu refresh renderer checks: %d failure(s)\n",failures);return failures?1:0;
}
