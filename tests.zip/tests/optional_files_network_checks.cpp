#define main emulator_main
#include "../src/j2mevm.cpp"
#undef main

static void optional_check(bool ok, const char* label) {
    if (!ok) { std::cerr << "FAIL " << label << "\n"; std::exit(1); }
}
int main(int argc, char** argv) {
    if (argc != 4) return 2;
    VMS_CL(g_classpath) = {argv[1], argv[2]};
    VMS_DIAG(g_log_draw) = false;
    VMS_CL(g_jar_files)["files-network.bin"] = {1, 35};
    VMS_PLAT(g_rms_suite) = rms_class_identity("OptionalFilesNetworkChecks", {});
    std::string mode = argv[3];
    if (mode == "files") {
        optional_check(load_class_file("javax/microedition/io/file/FileSystemRegistry", false) >= 0,
                       "FileSystemRegistry must resolve before game's fallback can run");
        int file = load_class_file("javax/microedition/io/file/FileConnection", false);
        optional_check(file >= 0, "FileConnection ABI loads");
        optional_check((VMS_CL(g_classes)[file].flags & 0x0200) != 0, "FileConnection is an interface");
    } else if (mode == "network") {
        int https = load_class_file("javax/microedition/io/HttpsConnection", false);
        optional_check(https >= 0, "HttpsConnection must resolve before game's fallback can run");
        optional_check(find_method(https, "getSecurityInfo", "()Ljavax/microedition/io/SecurityInfo;", false),
                       "HTTPS security contract resolves");
        optional_check(load_class_file("javax/microedition/io/SecurityInfo", false) >= 0 &&
                       load_class_file("javax/microedition/pki/Certificate", false) >= 0,
                       "HTTPS return type dependencies resolve");
    } else if (mode == "push") {
        optional_check(load_class_file("javax/microedition/io/PushRegistry", false) >= 0,
                       "PushRegistry must resolve before game's fallback can run");
    } else if (mode == "datagram") {
        int datagram = load_class_file("javax/microedition/io/Datagram", false);
        int connection = load_class_file("javax/microedition/io/DatagramConnection", false);
        std::cout << "INFO Datagram=" << datagram << " DatagramConnection=" << connection << "\n";
        optional_check(datagram >= 0 && connection >= 0,
                       "Datagram and DatagramConnection must resolve before game's fallback can run");
    } else if (mode != "resourcesRms") return 2;
    int fixture = ensure_class("OptionalFilesNetworkChecks");
    Method* method = find_method(fixture, mode, "()I", false);
    optional_check(method != nullptr, "Java fixture entry resolves");
    auto result = run(method, {});
    int expected = mode == "files" ? 17 : mode == "network" ? 5 : mode == "push" ? 21 : mode == "datagram" ? 1 : 3;
    optional_check(!VMS_EXEC(g_thrown) && result.i == expected, "actual VM fallback/resource/RMS behavior");
    std::cout << "PASS OptionalFilesNetwork " << mode << " " << expected << " actual VM checks\n";
}
