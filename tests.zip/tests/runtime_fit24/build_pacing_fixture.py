#!/usr/bin/env python3
"""Create a scratch-only host-clock adapter around an unchanged source snapshot."""
import argparse
import difflib
import hashlib
import json
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent


def replace_function(text, signature, body):
    at = text.index(signature)
    begin = text.index("{", at)
    depth, end = 1, begin + 1
    while depth:
        depth += (text[end] == "{") - (text[end] == "}")
        end += 1
    return text[:begin + 1] + "\n" + body + "\n" + text[end - 1:]


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--source", type=Path, default=HERE.parents[1])
    p.add_argument("--output", type=Path, required=True)
    a = p.parse_args()
    source, out = a.source.resolve(), a.output.resolve()
    (out / "adapter/runtime").mkdir(parents=True, exist_ok=True)
    (out / "classes").mkdir(exist_ok=True)
    identities = {}
    differences = []
    for relative in ["j2mevm.cpp", "threading.h", "runtime/interpreter.inc"]:
        raw = (source / "src" / relative).read_bytes()
        original = raw.decode()
        identities[str(source / "src" / relative)] = hashlib.sha256(raw).hexdigest()
        adapted = original.replace("std::this_thread::sleep_for(", "fit24_clock::sleep_for(")
        if relative == "runtime/interpreter.inc":
            marker = "                push(Value::of_l(now));\n                return;\n            }\n            if (mm->native)"
            replacement = "                fit24_clock::note_gate(context.poll_gate.previous_ms, context.poll_gate.deadline_ms, now, VMS_EXEC(g_speed_next_us), VMS_EXEC(g_game_clock).scale);\n" + marker
            if marker not in adapted: raise SystemExit("poll instrumentation anchor changed")
            adapted = adapted.replace(marker, replacement)
        if relative == "j2mevm.cpp":
            adapted = replace_function(adapted, "static int64_t paint_clock_us()", "    return fit24_clock::read();")
            adapted = replace_function(adapted, "static int64_t monotonic_ms()", "    return fit24_clock::read()/1000;")
            adapted = replace_function(adapted, "static int64_t now_ms()", "    return fit24_clock::read()/1000;")
            adapted = adapted.replace("static int64_t speed_begin_frame(JavaThreadContext* owner) {", "static int64_t speed_begin_frame(JavaThreadContext* owner) {\n    fit24_clock::before_draw();")
            adapted = adapted.replace("static void speed_note_paint(int64_t started_us, JavaThreadContext* owner) {", "static void speed_note_paint(int64_t started_us, JavaThreadContext* owner) {\n    fit24_clock::completed_draw(started_us);")
            statement = "VMS_EXEC(g_speed_next_us) = speed_next_paint_deadline(period,VMS_EXEC(g_speed_next_us),anchor);"
            adapted = adapted.replace(statement, "{ const auto fit24_previous = VMS_EXEC(g_speed_next_us); " + statement + " fit24_clock::note_deadline(anchor, fit24_previous, VMS_EXEC(g_speed_next_us)); }")
        (out / "adapter" / relative).write_text(adapted)
        differences.extend(difflib.unified_diff(original.splitlines(True), adapted.splitlines(True), fromfile=str(source / "src" / relative), tofile="test-only/" + relative))
    (out / "test-only-adapter.diff").write_text("".join(differences))
    for base in [source / "src", source / "romfs/classes"]:
        for path in base.rglob("*"):
            if path.is_file(): identities.setdefault(str(path), hashlib.sha256(path.read_bytes()).hexdigest())
    for path in [Path(__file__).resolve(), HERE / "controlled_runtime.cpp", HERE / "ClockPacingFixture.java"]:
        identities[str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
    (out / "source-sha256.json").write_text(json.dumps(identities, indent=2) + "\n")
    commands = [
        ["java", "-m", "jdk.compiler/com.sun.tools.javac.Main", "-source", "8", "-target", "8", "-bootclasspath", str(source / "romfs/classes"), "-classpath", str(source / "romfs/classes"), "-d", str(out / "classes"), str(HERE / "ClockPacingFixture.java")],
        ["gcc", "-O0", "-c", str(source / "src/puff.c"), "-o", str(out / "puff.o")],
        ["g++", "-O0", "-g0", "-std=c++17", "-fno-exceptions", "-ffunction-sections", "-fdata-sections", "-DJ2ME_TEST_VM=\"" + str(out / "adapter/j2mevm.cpp") + "\"", "-I" + str(out / "adapter"), "-I" + str(source / "src"), "-I" + str(source / "src/runtime"), str(HERE / "controlled_runtime.cpp"), str(out / "puff.o"), "-Wl,--gc-sections", "-pthread", "-ldl", "-o", str(out / "controlled-runtime")],
    ]
    if "nap_margin_us()" in (source / "src/poll_gate.h").read_text():
        commands[-1].insert(1,"-DFIT24_ADAPTIVE_POLL_CHECKS=1")
    records = []
    for i, command in enumerate(commands):
        result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=300)
        (out / f"build-{i}.log").write_bytes(result.stdout)
        records.append(dict(command=command, returncode=result.returncode))
        (out / "build-commands.json").write_text(json.dumps(records, indent=2) + "\n")
        print("BUILD", i, "returncode", result.returncode, flush=True)
        if result.returncode: raise SystemExit(result.stdout.decode(errors="replace")[-8000:])
    changed = [path for path, digest in identities.items() if hashlib.sha256(Path(path).read_bytes()).hexdigest() != digest]
    (out / "source-changes.json").write_text(json.dumps(changed, indent=2) + "\n")
    if changed: raise SystemExit("Source changed during build: " + repr(changed))
    print("PASS unchanged source; only scratch adapter replaces host clock and OS sleep", flush=True)


if __name__ == "__main__":
    main()
