import javax.microedition.lcdui.Graphics;

class LineInherited extends Graphics { public int strokeStyle = 1; }
class LineOverride extends Graphics {
    public int calls;
    public void drawLine(int x1,int y1,int x2,int y2) { calls++; }
}
class LineSuper extends Graphics {
    public int strokeStyle = 1;
    public int calls;
    public void drawLine(int x1,int y1,int x2,int y2) {
        calls++;
        super.drawLine(x1,y1,x2,y2);
    }
}

class DrawLineCases {
    public static void superLine(Graphics g) { g.drawLine(1,2,9,2); }
    public static void points(Graphics g,int n) {
        int i=0;
        while(i<n) { g.drawLine(5,6,5,6); i++; }
    }
    public static int nullAfterWarm() {
        try { points(null,1); return 0; }
        catch(NullPointerException e) { return 1; }
    }
}
