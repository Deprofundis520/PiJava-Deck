// The runner includes the actual HUD update block from switch_host.inc, with
// only frame counters and the platform clock supplied by this test.
#include <cstdint>
#include <cstdio>
#include <climits>
#include J2ME_HUD_ADAPTER

static int failures = 0, checks = 0;
static void check(bool ok, const char* message) {
    ++checks;
    if (!ok) { ++failures; std::fprintf(stderr, "FAIL present FPS: %s\n", message); }
}
static int measurement(uint64_t frames, int64_t elapsed_us) {
    hud_state = {};
    hud_update(0, 1000999, false);
    return hud_update(frames, 1000999 + elapsed_us, false);
}
int main() {
    check(measurement(30, 500010) == 60, "59.9988 actual presents/s displays 60");
    check(measurement(30, 500501) == 60, "59.94 actual presents/s displays 60");
    check(measurement(59, 994941) == 59, "59.3 actual presents/s stays 59");
    check(measurement(58, 994854) == 58, "58.3 actual presents/s stays 58");
    check(measurement(30, 1000010) == 30, "29.9997 actual presents/s displays 30");
    check(measurement(30, 1000000) == 30, "exact 30 uses actual presents only");
    check(measurement(10, 1000000) == 10, "slow actual presentation stays 10");
    check(measurement(0, 500000) == 0, "a completed window with no new frames displays zero");
    check(measurement(30, 499999) == 0, "a sub-half-second window retains its previous display");
    hud_state = {};
    check(hud_update(800, 1000999, false) == 0, "first update starts a window without inventing frames");
    check(hud_update(830, 1501009, false) == 60, "cumulative counter delta is measured");
    check(hud_update(800, 1510000, false) == 0, "counter rollback restarts at zero");
    check(hud_update(800, 2010000, false) == 0, "rollback followed by no new frames remains zero");
    check(hud_update(830, 2510000, false) == 60, "measurement resumes after rollback");
    check(hud_update(900, 2510010, true) == 0, "explicit reset clears the display");
    check(!hud_state.g_fps_reset, "explicit reset is consumed once");
    check(hud_update(900, 2510010, false) == 0, "zero elapsed time does not divide or add frames");
    check(hud_update(910, 3010010, false) == 20, "reset does not include pre-reset frames");
    std::printf("%s present FPS checks=%d failures=%d\n", failures ? "FAIL" : "PASS", checks, failures);
    return failures ? 1 : 0;
}
