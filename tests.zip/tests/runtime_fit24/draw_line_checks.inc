// The unchanged native bridge is the dispatch oracle. These checks catch wrong
// coordinate/target/style forwarding, missed counters, missing write barriers,
// duplicate side effects on JIT bailouts, and virtual-dispatch bypasses.
static void raw_line(Method* m,const std::vector<Value>& args){Frame f;f.method=m;f.locals=args;call_native(m,f);check(!VMS_EXEC(g_thrown),"native line returns normally");}
struct LineOutcome {
    std::vector<uint8_t> pixels,alpha;
    uint64_t lines,calls,offscreen,other,image_writes;
};
static LineOutcome line_result(int target,uint64_t writes){
    auto& p=VMS_RS(g_graphics_profile);
    return {target?VMS_HEAP(g_heap)[target].pixels:VMS_RS(g_fb),target?VMS_HEAP(g_heap)[target].alpha:std::vector<uint8_t>{},
        uint64_t(VMS_RS(g_drawacc).lines),p.global_pending.native_calls,p.global_pending.offscreen_calls,p.pending.other_calls,resver::g_stats.image_content-writes};
}
static unsigned line_helper_calls=0,line_helper_pc_ok=0,line_helper_restored=0;
static uint64_t observed_line_helper(int32_t ref,int32_t cls,int32_t pack){
    ++line_helper_calls;if(g_jitr_slots&&g_jitr_slots[0]==14)++line_helper_pc_ok;
    auto* stack=VMS_EXEC(g_active_stack);const int previous=stack->back().op_pc;
    const auto result=jitr_h_icgfx(ref,cls,pack);
    if(stack->back().op_pc==previous)++line_helper_restored;
    return result;
}
static void line_compiled_contract(Method* points,int gfx,int other){
    if(!VMS_NATIVE(g_native_jit).enabled||!graphics_intrinsic(method(VMS_HEAP(g_heap)[gfx].cls,"drawLine","(IIII)V")))return;
    std::vector<jitr::IcSite> ics(points->code.size());ics[14]=jitr_ic_for(points,14);
    check(ics[14].kind==jitr::IC_GFX,"resolved Java call admits the bounded graphics IC");
    std::vector<jit236::Constant> constants;std::vector<int> fields(points->code.size(),-1);
    jitr::Spec spec;spec.code=points->code.data();spec.size=points->code.size();spec.entry=14;spec.max_locals=3;spec.max_stack=5;spec.entry_depth=5;spec.ic=&ics;spec.constants=&constants;spec.field_slot=&fields;
    jitr::Region region;check(jitr::build(spec,region),"real points invocation builds from a full operand stack");
    const jitr::Helpers helpers{jitr_h_getfield,jitr_h_aload,jitr_h_alen,jitr_h_icget,jitr_h_icchk,jitr_h_cast,jitr_h_inst,observed_line_helper,jitr_h_iastore,jitr_h_getstatic};
    const uint32_t id=jit236::next_install_id();jit236::Executable exe;check(exe.install(jitr::emit_host(region,helpers,id),id),"contract region installs");
    auto* saved_stack=VMS_EXEC(g_active_stack);auto* saved_slots=g_jitr_slots;const auto saved_locals=g_jitr_locals;
    std::vector<Frame> active(1);active[0].method=points;active[0].op_pc=101;VMS_EXEC(g_active_stack)=&active;
    for(int receiver:{gfx,0,other})for(unsigned budget:{0u,1u}){
        std::vector<int32_t> slots(2+2*(3+5+1));slots[0]=-77;slots[1]=int32_t(id);slots[3]=receiver;slots[4]=1;slots[6]=0;
        slots[3+2*3]=receiver;for(unsigned i=1;i<=4;++i)slots[2+2*(3+i)]=(i&1)?5:6;
        g_jitr_slots=slots.data();g_jitr_locals=3;line_helper_calls=line_helper_pc_ok=line_helper_restored=0;
        VMS_RS(g_drawacc)={};VMS_RS(g_drawacc).on=true;
        uint64_t result;{jit236::CodeCall call;result=reinterpret_cast<jitr::Fn>(exe.fn)(slots.data(),budget);}
        const bool drawn=receiver==gfx&&budget==1;
        check(uint32_t(result)==unsigned(drawn?17:14)&&unsigned(result>>32)==unsigned(drawn),"budget or class guard exits at original invoke without charging a failed side effect");
        check(VMS_RS(g_drawacc).lines==int(drawn),"budget zero null and wrong receiver have no drawing side effects");
        check(active[0].op_pc==101&&line_helper_restored==line_helper_calls,"helper restores caller BCI before region return");
        check(line_helper_calls==unsigned(budget==1)&&line_helper_pc_ok==line_helper_calls,"native helper receives exact invocation BCI from emitted code");
        if(drawn)check(slots[0]==14,"normal region exit restores original last-executed-PC convention");
    }
    g_jitr_slots=saved_slots;g_jitr_locals=saved_locals;VMS_EXEC(g_active_stack)=saved_stack;
    std::cout<<"LINE_COMPILED_CONTRACT budget_class_null=6 exact_call_bci=14 last_pc_preserved=1\n";
}

static void line_diagnostic_observer(Method* points,int gfx){
    const uint32_t caller=diag_method(points),native=diag_method(method(VMS_HEAP(g_heap)[gfx].cls,"drawLine","(IIII)V"));
    std::atomic<bool> started{false},stop{false};std::atomic<unsigned> seen{0},wrong{0};
    std::thread observer([&](){started.store(true,std::memory_order_release);while(!stop.load(std::memory_order_acquire)){runtime_diag::LiveSnapshot value;if(g_device_diag.live.read(value)&&value.phase==runtime_diag::Phase::Native&&value.method==native&&value.caller==caller){seen.fetch_add(1,std::memory_order_relaxed);if(value.bci!=14)wrong.fetch_add(1,std::memory_order_relaxed);}}});
    while(!started.load(std::memory_order_acquire))std::this_thread::yield();
    for(int trial=0;trial<3&&seen.load(std::memory_order_relaxed)<16;++trial){++VMS_RS(g_paint_depth);run(points,{Value::of_ref(gfx),Value::of_i(20000)});--VMS_RS(g_paint_depth);}
    stop.store(true,std::memory_order_release);observer.join();
    check(seen.load()>0&&wrong.load()==0,"atomic native snapshots from actual execution retain the original invoke BCI");
    std::cout<<"LINE_DIAG observed_native_snapshots="<<seen.load()<<" wrong_bci="<<wrong.load()<<" expected_bci=14 observer_reads_only_atomic_live_state=1\n";
}
static void line_semantics(){
    const int gfxcls=ensure_class("javax/microedition/lcdui/Graphics"),imagecls=ensure_class("javax/microedition/lcdui/Image");
    auto* line=method(gfxcls,"drawLine","(IIII)V");const int kind=graphics_intrinsic(line);
    const int gfx=alloc_obj(gfxcls);root(gfx);invoke(gfxcls,"<init>","()V",{Value::of_ref(gfx)});
    VMS_RS(g_screen_w)=24;VMS_RS(g_screen_h)=18;VMS_RS(g_fb).resize(24*18*3);
    const int image=invoke(imagecls,"createImage","(II)Ljavax/microedition/lcdui/Image;",{Value::of_i(24),Value::of_i(18)}).ref;root(image);
    const int hidden=alloc_obj(ensure_class("LineInherited"));root(hidden);invoke(VMS_HEAP(g_heap)[hidden].cls,"<init>","()V",{Value::of_ref(hidden)});
    struct Shape{int x1,y1,x2,y2;};
    const Shape shapes[]={{5,6,5,6},{0,0,23,17},{23,17,0,0},{0,9,23,9},{12,0,12,17},{-100,7,100,7},{-5,-8,28,20},{3,4,17,15},{7,15,15,0},{-8,-8,-1,-1},{INT_MIN,0,INT_MAX,17},{INT_MAX,INT_MIN,INT_MAX,INT_MIN}};
    const Clip clips[]={{0,0,0,0,false},{3,2,13,10,true},{4,4,0,0,true}};
    unsigned cases=0;
    for(int self:{gfx,hidden})for(int target:{0,image})for(int style:{0,1})for(unsigned alpha:{0u,127u,255u})for(const auto& clip:clips)for(int translation:{0,3,INT_MAX})for(const auto& shape:shapes){
        std::vector<Value> args={Value::of_ref(self),Value::of_i(shape.x1),Value::of_i(shape.y1),Value::of_i(shape.x2),Value::of_i(shape.y2)};
        auto reset=[&](){
            auto& pixels=target?VMS_HEAP(g_heap)[target].pixels:VMS_RS(g_fb);for(size_t i=0;i<pixels.size();++i)pixels[i]=uint8_t(i*17+9);
            if(target)for(size_t i=0;i<VMS_HEAP(g_heap)[target].alpha.size();++i)VMS_HEAP(g_heap)[target].alpha[i]=uint8_t(i*13+3);
            VMS_RS(g_gfx_target)[self]=target;VMS_RS(g_gfx_color)[self]=0xe3517b;VMS_RS(g_gfx_tx)[self]=translation;VMS_RS(g_gfx_ty)[self]=-3;
            VMS_RS(g_clip)[self]=clip;gfx_opacity_set(self,alpha);
            const auto* base=find_field(gfxcls,"strokeStyle","I");VMS_HEAP(g_heap)[self].fields[base->slot]=Value::of_i(style);
            VMS_RS(g_drawacc)={};VMS_RS(g_drawacc).on=true;VMS_RS(g_graphics_profile).reset(true);VMS_RS(g_graphics_profile).sampling=true;
        };
        reset();auto writes=resver::g_stats.image_content;raw_line(line,args);const auto expected=line_result(target,writes);
        reset();writes=resver::g_stats.image_content;VMS_DIAG(g_exception_traces).clear();
        const auto previous=g_device_diag.owner;g_device_diag.owner.point_us=1;
        if(kind)gfx_intrinsic(kind,args.data());else raw_line(line,args);
        const auto actual=line_result(target,writes);
        check(actual.pixels==expected.pixels&&actual.alpha==expected.alpha,"line pixels and destination alpha match original native bridge");
        check(actual.lines==1&&actual.calls==1&&actual.offscreen==uint64_t(target!=0)&&actual.other==1,"line and graphics diagnostic counts each run exactly once");
        check(actual.image_writes==uint64_t(target!=0)&&actual.image_writes==expected.image_writes,"offscreen write barrier occurs exactly once including clipped calls");
        check(g_device_diag.owner.point_us>1&&g_device_diag.owner.phase==previous.phase,"native boundary diagnostics preserved");
        g_device_diag.owner=previous;++cases;
    }
    // Independent literal output for a solid zero-length point.
    VMS_RS(g_gfx_target)[gfx]=0;VMS_RS(g_gfx_color)[gfx]=0x123456;VMS_RS(g_gfx_tx)[gfx]=0;VMS_RS(g_gfx_ty)[gfx]=0;VMS_RS(g_clip)[gfx]={0,0,0,0,false};gfx_opacity_set(gfx,255);
    field(gfx,"strokeStyle","I")=Value::of_i(0);std::fill(VMS_RS(g_fb).begin(),VMS_RS(g_fb).end(),0);
    std::vector<Value> point={Value::of_ref(gfx),Value::of_i(5),Value::of_i(6),Value::of_i(5),Value::of_i(6)};
    if(kind)gfx_intrinsic(kind,point.data());else raw_line(line,point);
    size_t lit=0;for(size_t i=0;i<VMS_RS(g_fb).size();i+=3){const bool on=i==size_t((6*24+5)*3);check(VMS_RS(g_fb)[i]==(on?0x12:0)&&VMS_RS(g_fb)[i+1]==(on?0x34:0)&&VMS_RS(g_fb)[i+2]==(on?0x56:0),"a solid point changes exactly its one pixel");if(on)++lit;}check(lit==1,"literal point visited once");
    std::cout<<"LINE_SEMANTICS cases="<<cases<<" candidate_intrinsic="<<kind<<" preserves_rgba_clip_translate_style_diagnostics=1\n";
}

static void line_super(){
    const int fixture=ensure_class("DrawLineCases"),cls=ensure_class("LineSuper"),gfxcls=ensure_class("javax/microedition/lcdui/Graphics");
    const int gfx=alloc_obj(cls);root(gfx);invoke(cls,"<init>","()V",{Value::of_ref(gfx)});
    VMS_RS(g_screen_w)=24;VMS_RS(g_screen_h)=18;VMS_RS(g_fb).assign(24*18*3,0);
    VMS_RS(g_gfx_color)[gfx]=0x123456;VMS_RS(g_clip)[gfx]={0,0,0,0,false};gfx_opacity_set(gfx,255);
    const auto* base=find_field(gfxcls,"strokeStyle","I");VMS_HEAP(g_heap)[gfx].fields[base->slot]=Value::of_i(0);
    check(field(gfx,"strokeStyle","I").i==1,"subclass hides the Graphics stroke field with a different value");
    VMS_RS(g_drawacc)={};VMS_RS(g_drawacc).on=true;
    invoke(fixture,"superLine","(Ljavax/microedition/lcdui/Graphics;)V",{Value::of_ref(gfx)});
    unsigned lit=0;for(size_t i=0;i<VMS_RS(g_fb).size();i+=3)if(VMS_RS(g_fb)[i]||VMS_RS(g_fb)[i+1]||VMS_RS(g_fb)[i+2])++lit;
    std::cout<<"LINE_SUPER actual_lit="<<lit<<" expected_solid_pixels=9 override_calls="<<field(gfx,"calls","I").i<<" native_lines="<<VMS_RS(g_drawacc).lines<<'\n';
    check(field(gfx,"calls","I").i==1&&VMS_RS(g_drawacc).lines==1,"actual virtual override and its super draw execute exactly once");
    for(size_t i=0;i<VMS_RS(g_fb).size();i+=3){const size_t pixel=i/3;const bool on=pixel/24==2&&pixel%24>=1&&pixel%24<=9;
        check(VMS_RS(g_fb)[i]==(on?0x12:0)&&VMS_RS(g_fb)[i+1]==(on?0x34:0)&&VMS_RS(g_fb)[i+2]==(on?0x56:0),"invokespecial super.drawLine uses the declaring Graphics field and solid pixels");}
}

static void line_vm(){
    const int fixture=ensure_class("DrawLineCases"),gfxcls=ensure_class("javax/microedition/lcdui/Graphics");
    const int gfx=alloc_obj(gfxcls);root(gfx);invoke(gfxcls,"<init>","()V",{Value::of_ref(gfx)});
    const int inherited=alloc_obj(ensure_class("LineInherited"));root(inherited);invoke(VMS_HEAP(g_heap)[inherited].cls,"<init>","()V",{Value::of_ref(inherited)});
    const int overridden=alloc_obj(ensure_class("LineOverride"));root(overridden);invoke(VMS_HEAP(g_heap)[overridden].cls,"<init>","()V",{Value::of_ref(overridden)});
    VMS_RS(g_screen_w)=24;VMS_RS(g_screen_h)=18;VMS_RS(g_fb).assign(24*18*3,0);
    VMS_RS(g_gfx_color)[gfx]=0x123456;VMS_RS(g_gfx_color)[inherited]=0x123456;
    auto* points=method(fixture,"points","(Ljavax/microedition/lcdui/Graphics;I)V");
    // First invocation also initializes the fixture class; exclude that
    // one-time synthetic initializer return from the hand-counted method.
    run(points,{Value::of_ref(gfx),Value::of_i(0)});
    const auto jit_begin=g_jitr_gfx_ok;
    for(int self:{gfx,gfx,inherited,overridden,gfx}){
        const int n=200;VMS_RS(g_drawacc)={};VMS_RS(g_drawacc).on=true;
        const auto before=VMS_EXEC(g_fast_ops)+VMS_EXEC(g_slow_ops)+VMS_NATIVE(g_native_jit).stats.ops;
        run(points,{Value::of_ref(self),Value::of_i(n)});check(!VMS_EXEC(g_thrown)&&!current_context().unhandled,"virtual points loop succeeds");
        const auto ops=VMS_EXEC(g_fast_ops)+VMS_EXEC(g_slow_ops)+VMS_NATIVE(g_native_jit).stats.ops-before;
        std::cout<<"LINE_BUDGET receiver="<<VMS_CL(g_classes)[VMS_HEAP(g_heap)[self].cls].name<<" n="<<n<<" measured="<<ops<<" literal_expected="<<11*n+6<<'\n';
        if(self==overridden){check(field(self,"calls","I").i==n&&VMS_RS(g_drawacc).lines==0,"virtual override receives every call once and emits no native pixels");}
        else {check(VMS_RS(g_drawacc).lines==n,"JIT and interpreter emit every drawLine once");check(ops==uint64_t(11*n+6),"loop preserves hand-counted original operation budget");}
    }
    const auto lines=VMS_RS(g_drawacc).lines;
    check(invoke(fixture,"nullAfterWarm","()I",{}).i==1&&VMS_RS(g_drawacc).lines==lines,"null receiver throws at original invocation without duplicate draw");
    auto& deterministic=r4::state;const auto previous_profile=deterministic.cfg.profile;
    for(const char* profile:{"reference-v1","optimized-v1"}){
        deterministic.cfg.profile=profile;deterministic.remaining=1000000;deterministic.worker_phase=false;deterministic.opcodes=0;
        VMS_RS(g_drawacc)={};VMS_RS(g_drawacc).on=true;const auto compiled_begin=g_jitr_gfx_ok;
        deterministic.active=true;run(points,{Value::of_ref(gfx),Value::of_i(200)});deterministic.active=false;
        check(!VMS_EXEC(g_thrown)&&!current_context().unhandled&&VMS_RS(g_drawacc).lines==200,"deterministic engine draws every original line exactly once");
        check(deterministic.opcodes==2206&&deterministic.remaining==1000000-2206,"reference and optimized R4 preserve literal original fuel");
        std::cout<<"LINE_R4 profile="<<profile<<" opcodes="<<deterministic.opcodes<<" expected=2206 lines="<<VMS_RS(g_drawacc).lines<<" gfx_jit_calls="<<g_jitr_gfx_ok-compiled_begin<<'\n';
    }
    deterministic.cfg.profile=previous_profile;
    if(VMS_NATIVE(g_native_jit).enabled&&graphics_intrinsic(method(gfxcls,"drawLine","(IIII)V")))check(g_jitr_gfx_ok>jit_begin,"actual compiled region executes generic drawLine helper");
    line_compiled_contract(points,gfx,overridden);
    line_diagnostic_observer(points,gfx);
    std::cout<<"LINE_VM gfx_jit_calls="<<g_jitr_gfx_ok-jit_begin<<" original_points_ops="<<11*200+6<<" virtual_override_and_null=1\n";
}
