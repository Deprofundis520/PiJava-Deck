// Actual production Java interpreter, scheduler, frame ownership and clock learner.
// Only host clock/OS sleep and fixed external work costs are controlled.
#include <algorithm>
#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <map>
#include <vector>

namespace fit24_clock {
int64_t us = 1000000, tick_us = 1, overshoot_us = 0;
int64_t prepare_us = 0, draw_us = 0;
int64_t stall_us = 0;
size_t stall_frame = 240;
bool stalled = false;
uint64_t sleeps = 0;
uint64_t clock_reads = 0;
int64_t requested_sleep_us = 0, actual_sleep_us = 0;
std::vector<int64_t> jitter_pattern;
std::vector<int64_t> anchors;
struct WorkCount { uint64_t sleeps=0, reads=0; int64_t requested=0, elapsed=0; };
std::vector<WorkCount> work_counts;
struct Deadline { int64_t anchor = 0, old_due = 0, next_due = 0; };
std::vector<Deadline> deadlines;
struct Gate { int64_t host=0, previous=0, due=0, returned=0, draw_due=0; double scale=1; };
std::vector<Gate> gates;
int64_t read() { const auto value = us; us += tick_us; ++clock_reads; return value; }
template<class Rep, class Period>
void sleep_for(std::chrono::duration<Rep, Period> duration) {
    const auto request = std::chrono::duration_cast<std::chrono::microseconds>(duration).count();
    if (request > 0) {
        const int64_t late = jitter_pattern.empty() ? overshoot_us : jitter_pattern[sleeps % jitter_pattern.size()];
        ++sleeps; requested_sleep_us += request; actual_sleep_us += request + late; us += request + late;
    }
}
void before_draw() { if (!stalled && anchors.size() == stall_frame && stall_us) { us += stall_us; stalled = true; } us += prepare_us; }
void completed_draw(int64_t anchor) { us += draw_us; anchors.push_back(anchor); work_counts.push_back({sleeps, clock_reads, requested_sleep_us, actual_sleep_us}); }
void note_deadline(int64_t anchor, int64_t previous, int64_t next) { deadlines.push_back({anchor, previous, next}); }
void note_gate(int64_t previous, int64_t due, int64_t returned, int64_t draw_due, double scale) {
    if (due > 0 && returned >= due && (gates.empty() || gates.back().previous != previous))
        gates.push_back({us, previous, due, returned, draw_due, scale});
}
}

#define main emulator_main
#include J2ME_TEST_VM
#undef main
#include "host_menu_settings.h"
#include "host_speed.h"
static host_menu::Settings g_menu_settings;
static std::string instant_state_path(const std::string&) { return "unused-fit24-pacing.state"; }
#include "instant_state.inc"

static int static_int(const char* name) {
    const int c = ensure_class("ClockPacingFixture");
    const auto* field = find_field(c, name, "I");
    if (!field) { std::cerr << "Missing fixture field " << name << '\n'; std::exit(2); }
    return VMS_CL(g_classes)[field->owner].statics[field->slot].i;
}

int main(int argc, char** argv) {
    if (argc != 13) {
        std::cerr << "classes library mode cap overshoot_us prepare_us draw_us present_us tick_us frames csv minimum_fps\n";
        return 2;
    }
    const int mode = std::atoi(argv[3]), cap = std::atoi(argv[4]);
    fit24_clock::overshoot_us = std::atoll(argv[5]);
    fit24_clock::prepare_us = std::atoll(argv[6]);
    fit24_clock::draw_us = std::atoll(argv[7]);
    const int64_t present_us = std::atoll(argv[8]);
    fit24_clock::tick_us = std::atoll(argv[9]);
    const int total_frames = std::atoi(argv[10]);
    const double minimum_fps = std::atof(argv[12]);
    if (const char* value = std::getenv("FIT24_STALL_US")) fit24_clock::stall_us = std::atoll(value);
    if (const char* value = std::getenv("FIT24_STALL_FRAME")) fit24_clock::stall_frame = size_t(std::atoll(value));
    if (const char* value = std::getenv("FIT24_OVERSLEEP_SEQUENCE")) {
        while (*value) {
            char* end = nullptr;
            const int64_t amount = std::strtoll(value, &end, 10);
            if (end == value || amount < 0 || (*end && *end != ',')) return 2;
            fit24_clock::jitter_pattern.push_back(amount);
            value = *end ? end + 1 : end;
        }
    }
    VMS_CL(g_classpath) = {argv[1], argv[2]};
    VMS_DIAG(g_log_draw) = false;
    VMS_PLAT(g_boot_ms) = now_ms();
    VMS_EXEC(g_speed_cap) = cap;
    speed_sync_clock();
    VMS_RS(g_fb).assign(size_t(VMS_RS(g_screen_w)) * VMS_RS(g_screen_h) * 3, 0);
    VMS_EXEC(g_midlet_state) = MidletState::Active;
    const int cls = ensure_class("ClockPacingFixture");
    run(find_method(cls, "start", "(I)V", false), {Value::of_i(mode)});
    if (mode == 7) {
        int checks = 0, failures = 0;
        const auto check = [&](bool ok, const char* what) {
            ++checks;
            if (!ok) { ++failures; std::cerr << "FAIL phase contract: " << what << '\n'; }
        };
        fit24_clock::tick_us = fit24_clock::overshoot_us = fit24_clock::prepare_us = fit24_clock::draw_us = 0;
        fit24_clock::jitter_pattern.clear();
        VMS_RS(g_repaint) = VMS_RS(g_fb_dirty) = false;
        VMS_EXEC(g_speed_next_us) = VMS_EXEC(g_speed_last_paint_us) = 0;
        auto& thread = VMS_EXEC(g_threads).front();
        speed_reset_learning();
        fit24_clock::us = 1000000;
        const auto draw = [&]() { const auto at = speed_begin_frame(&thread); speed_note_paint(at, &thread); return at; };
        check(draw() == 1000000, "first capped drawing starts at current clock");
        fit24_clock::us = 1019667;
        check(draw() == 1019667, "3ms late work is drawn once, without changing its timestamp");
        fit24_clock::us += 100;
        check(draw() == 1034334, "first recovery interval is bounded to 14667us");
        fit24_clock::us += 100;
        check(draw() == 1050001, "small lateness is repaid on the original absolute grid");
        fit24_clock::us += 100;
        check(draw() == 1066668, "following frame keeps the recovered absolute phase");
        fit24_clock::us += 200000;
        const auto after_stall = draw();
        check(VMS_EXEC(g_speed_next_us) == after_stall + 16667, "a missed full period discards catch-up debt");
        auto previous = after_stall;
        for (int i = 0; i < 5; ++i) {
            fit24_clock::us += 100;
            const auto next = draw();
            check(next - previous == 16667, "long stall is followed by full ordinary periods, not a burst");
            previous = next;
        }
        for (int i = 0; i < 20; ++i) {
            fit24_clock::us += 25000;
            const auto next = draw();
            check(next - previous == 25000, "continuously expensive work never schedules catch-up drawings");
            previous = next;
        }
        const auto pending = VMS_EXEC(g_speed_next_us);
        check(speed_next_paint_deadline(16667, pending, pending-500) == pending,
              "an early timestamp retains its existing upcoming slot");
        stop_thread();
        check(!VMS_EXEC(g_speed_next_us) && !VMS_EXEC(g_speed_last_paint_us), "existing lifecycle reset clears the old cap clock");
        fit24_clock::us = 500000;
        const auto fresh = speed_begin_frame(nullptr);
        speed_note_paint(fresh, nullptr);
        check(fresh == 500000 && VMS_EXEC(g_speed_next_us) == 516667, "new clock epoch starts afresh without stale waiting");
        std::cout << (failures ? "FAIL" : "PASS") << " phase contracts checks=" << checks << " failures=" << failures << '\n';
        return failures ? 1 : 0;
    }
#ifdef FIT24_ADAPTIVE_POLL_CHECKS
    if (mode == 8) {
        int checks = 0, failures = 0;
        const auto check = [&](bool ok, const char* what) {
            ++checks;
            if (!ok) { ++failures; std::cerr << "FAIL adaptive poll contract: " << what << '\n'; }
        };
        PollGateState state;
        int site = 0;
        for (int i=0; i<4; ++i) state.observe(&site,7,100,70,110,true);
        state.observe(&site,7,100,70,170,true);
        for (int i=0; i<4; ++i) state.observe(&site,7,170,70,180,true);
        check(state.wait_us(238,4.2,true) == 226, "no measured lateness retains the old 250us margin");
        state.note_wait(500,1700);
        check(state.wait_us(238,4.2,true) == 0 && state.wait_us(233,4.2,true) == 216,
              "actual 1200us OS error is excluded from the next certified nap");
        check(state.wait_us(233,4.2,false) == 500, "native and unverified wait policy ignores paced calibration");
        state.note_wait(500,1000000000);
        check(state.wait_us(230,4.2,true) == 130, "one extreme delay cannot grow the added margin beyond 2000us");
        state.note_wait(0,1000000); state.note_wait(500,400);
        check(state.wait_us(230,4.2,true) == 130, "invalid delay samples cannot alter the bounded history");
        int64_t previous = 170;
        for (int i=0; i<7; ++i) { previous += 70; state.observe(&site,7,previous,70,previous+10,true); }
        check(state.nap_margin_us() == 2250, "seven gate cycles without any nap retain the recent late observation");
        previous += 70; state.observe(&site,7,previous,70,previous+10,true);
        check(state.nap_margin_us() == 250, "eight gate cycles expire stale lateness even when no new nap is possible");
        state.note_wait(500,1700);
        state.observe(&site,8,170,70,180,true);
        check(state.nap_margin_us() == 250 && !state.certified, "a different gate site loses its prior evidence and latency history");
        auto& thread = VMS_EXEC(g_threads).front();
        thread.poll_gate.note_wait(500,1700);
        speed_pause_clock(true);
        check(thread.poll_gate.nap_margin_us() == 250, "pause discards measured host latency");
        thread.poll_gate.note_wait(500,1700);
        speed_pause_clock(false);
        check(thread.poll_gate.nap_margin_us() == 250, "resume starts with no inherited host latency");
        thread.poll_gate.note_wait(500,1700);
        VMS_EXEC(g_speed_cap) = 30; speed_sync_clock();
        check(thread.poll_gate.nap_margin_us() == 250, "mode change discards measured host latency");
        thread.poll_gate.note_wait(500,1700);
        const auto saved = sav_thread(thread);
        VMS_EXEC(g_save_clock).ms = fit24_clock::us / 1000; VMS_EXEC(g_save_clock).us = fit24_clock::us;
        check(apply_thread(thread,saved,"") && thread.poll_gate.nap_margin_us() == 250,
              "restore reconstructs transient latency history empty");
        std::cout << (failures ? "FAIL" : "PASS") << " adaptive poll contracts checks=" << checks << " failures=" << failures << '\n';
        return failures ? 1 : 0;
    }
#else
    if (mode == 8) {
        std::cerr << "FAIL source has no adaptive paced nap calibration\n";
        return 1;
    }
#endif
    if (mode == 5) {
        int checks = 0, failures = 0;
        const auto check = [&](bool ok, const char* what) {
            ++checks;
            if (!ok) { ++failures; std::cerr << "FAIL idle deadline contract: " << what << '\n'; }
        };
        fit24_clock::tick_us = 0;
        fit24_clock::us = 1000000;
        VMS_RS(g_repaint) = VMS_RS(g_fb_dirty) = false;
        VMS_EXEC(g_running_thread) = nullptr;
        VMS_EXEC(g_can_suspend) = true;
        auto& thread = VMS_EXEC(g_threads).front();
        const int ref = thread.ref;
        auto sleeping = [&](int64_t millis, int64_t micros = 0) {
            thread = JavaThreadContext{};
            thread.ref = ref;
            thread.state = ThreadState::Sleeping;
            thread.wake = millis;
            thread.wake_us = micros;
        };
        sleeping(1130);
        check(idle_sleep_ms() == 8 && thread.state == ThreadState::Sleeping && thread.wake == 1130,
              "unowned 130ms Java wait retains its deadline and bounded host nap");
        fit24_clock::us = 1129000;
        check(idle_sleep_ms() == 0 && thread.state == ThreadState::Sleeping,
              "a near ordinary Java sleep stays asleep until its own deadline");
        fit24_clock::us = 1130000;
        check(idle_sleep_ms() == 0 && thread.state == ThreadState::Runnable,
              "an ordinary sleep expiring during refresh does not get a 4ms fallback");
        fit24_clock::us = 1000000;
        sleeping(1030, 1000550);
        check(idle_sleep_ms() == 0 && thread.state == ThreadState::Sleeping,
              "precise deadline takes priority over a later compatibility timer without early wake");
        fit24_clock::us = 1000549;
        check(idle_sleep_ms() == 0 && thread.state == ThreadState::Sleeping,
              "one microsecond before due remains sleeping");
        fit24_clock::us = 1000550;
        check(idle_sleep_ms() == 0 && thread.state == ThreadState::Runnable,
              "precise deadline becomes runnable at due, not the later millisecond timer");
        fit24_clock::us = 1000000;
        sleeping(1000, 1000450);
        const auto saved = sav_thread(thread);
        check(saved.has_wake && saved.has_wake_us && saved.wake_delta == 0 && saved.wake_us_delta == 450,
              "existing state capture preserves the short precise remainder independently");
        fit24_clock::us = 21000000;
        VMS_EXEC(g_save_clock).ms = 21000;
        VMS_EXEC(g_save_clock).us = fit24_clock::us;
        check(apply_thread(thread, saved, ""), "existing thread restore accepts the saved waiting context");
        check(thread.wake == 21000 && thread.wake_us == 21000450 && idle_sleep_ms() == 0 && thread.state == ThreadState::Sleeping,
              "restored microsecond deadline is rebased and visible even when millisecond remainder is zero");
        fit24_clock::us = 21000450;
        refresh_thread(thread);
        check(thread.state == ThreadState::Runnable, "restored worker resumes at its rebased precise due");
        fit24_clock::us = 1000000;
        sleeping(1130);
        VMS_EXEC(g_threads).emplace_back();
        auto& peer = VMS_EXEC(g_threads).back();
        peer.state = ThreadState::Sleeping;
        peer.wake = 1000;
        peer.wake_us = 1000450;
        check(idle_sleep_ms() == 0 && peer.state == ThreadState::Sleeping && thread.state == ThreadState::Sleeping,
              "a second thread's nearer exact deadline wins without waking either early");
        peer.wake_us = 1030000;
        peer.wake = 1030;
        peer.state = ThreadState::Runnable;
        check(idle_sleep_ms() == 0, "another live runnable Java worker prevents host idle");
        peer.state = ThreadState::Terminated;
        check(idle_sleep_ms() == 8, "a terminated peer does not prevent a bounded timer nap");
        VMS_EXEC(g_threads).pop_back();
        thread.state = ThreadState::Waiting;
        thread.wake_us = 1000450;
        thread.wake = 1000;
        thread.monitor = ref;
        thread.reacquire = true;
        thread.restore_depth = 1;
        VMS_EXEC(g_monitors)[ref].owner = &VMS_EXEC(g_main_thread);
        VMS_EXEC(g_monitors)[ref].depth = 1;
        check(idle_sleep_ms() == 0 && thread.state == ThreadState::Waiting,
              "Object.wait precise timer remains waiting before timeout");
        fit24_clock::us = 1000450;
        check(idle_sleep_ms() == 4 && thread.state == ThreadState::Blocked,
              "timed-out waiter still respects the held monitor");
        VMS_EXEC(g_monitors)[ref].owner = nullptr;
        VMS_EXEC(g_monitors)[ref].depth = 0;
        check(idle_sleep_ms() == 0 && thread.state == ThreadState::Runnable,
              "released monitor admits the ready waiter without extra host nap");
        VMS_EXEC(g_monitors).erase(ref);
        thread = JavaThreadContext{};
        thread.begun = true;
        check(idle_sleep_ms() == 4, "empty completed Java context does not cause busy polling");
        thread.state = ThreadState::Terminated;
        check(idle_sleep_ms() == 4, "terminated context retains no-work fallback nap");
        VMS_EXEC(g_threads).clear();
        check(idle_sleep_ms() == 4, "empty thread list retains no-work fallback nap");
        std::cout << (failures ? "FAIL" : "PASS") << " idle deadline contracts checks=" << checks << " failures=" << failures << '\n';
        return failures ? 1 : 0;
    }
    if (mode == 4) {
        // Exercise the actual Thread.sleep conversion, not a hand-written
        // mismatch: a 600us precise wait requested at .900ms also gets a
        // compatibility millisecond timer which lies before the precise due.
        auto& thread = VMS_EXEC(g_threads).front();
        VMS_RS(g_repaint) = VMS_RS(g_fb_dirty) = false;
        VMS_EXEC(g_last_slice_us) = 0;
        VMS_EXEC(g_running_thread) = &thread;
        VMS_EXEC(g_can_suspend) = true;
        fit24_clock::us = 1000900;
        thread.state = ThreadState::Runnable;
        thread.frame_due_us = 1001500;
        Method* method = find_method(ensure_class("java/lang/Thread"), "sleep", "(J)V", false);
        Frame frame;
        frame.method = method;
        frame.locals = {Value::of_l(70), Value{}};
        thread_native(method, frame);
        const auto precise = thread.wake_us, rounded = thread.wake;
        VMS_EXEC(g_running_thread) = nullptr;
        fit24_clock::us = rounded*1000 + 50;
        if (!(thread.state == ThreadState::Sleeping && fit24_clock::us < precise)) {
            std::cerr << "FAIL fixture did not produce the real dual-deadline state\n";
            return 2;
        }
        int64_t slept = 0;
        const auto before = fit24_clock::us;
        const auto work = p1_host_work_turn(true, false, [](bool) {}, [&](int64_t ms) { slept = ms; });
        std::cout << "DUAL_DEADLINE now_us=" << before << " precise_wake_us=" << precise
                  << " compatibility_wake_ms=" << rounded << " remaining_us=" << precise-before
                  << " selected_nap_ms=" << slept << " work=" << int(work) << '\n';
        if (slept*1000 > precise-before) {
            std::cerr << "FAIL host idle nap ignored the still-pending precise Java deadline\n";
            return 1;
        }
        std::cout << "PASS precise Java wake remains visible to host idle scheduling\n";
        return 0;
    }
    if (mode == 3) {
        // Regression: a thread can become runnable between the first runnable
        // query and idle_sleep_ms(). A second refresh must not turn that wake
        // into the no-timer fallback nap. Uses the actual scheduler entry.
        VMS_RS(g_repaint) = VMS_RS(g_fb_dirty) = false;
        VMS_EXEC(g_last_slice_us) = 0;
        auto& thread = VMS_EXEC(g_threads).front();
        int bad = 0;
        for (int offset = 1; offset <= 80; ++offset) {
            fit24_clock::us = 1000000;
            const auto due = fit24_clock::us + offset;
            thread.state = ThreadState::Sleeping;
            thread.wake_us = due;
            thread.wake = (due + 999) / 1000;
            thread.sleep_request = 0;
            int64_t slept = 0, entered = 0;
            bool ready_at_nap = false;
            const auto work = p1_host_work_turn(true, false, [](bool) {}, [&](int64_t ms) {
                entered = fit24_clock::us;
                slept = ms;
                ready_at_nap = thread.state == ThreadState::Runnable;
            });
            if (slept && ready_at_nap) {
                ++bad;
                std::cout << "RACE offset_us=" << offset << " due_us=" << due
                          << " nap_entered_us=" << entered << " nap_ms=" << slept
                          << " work=" << int(work) << " runnable_at_nap=1\n";
            }
        }
        if (bad) {
            std::cerr << "FAIL a ready Java worker was postponed by an idle nap cases=" << bad << '\n';
            return 1;
        }
        std::cout << "PASS no host idle nap after a Java worker becomes ready\n";
        return 0;
    }
    std::map<int, uint64_t> work_turns;
    uint64_t idle_after_ready = 0;
    const int64_t begin = fit24_clock::us;
    int turns = 0;
    while (static_int("paints") < total_frames && turns++ < 5000000 && fit24_clock::us - begin < 240000000) {
        host_lifecycle_poll242();
        const auto work = sched_game_work(true, [] {}, [&](int64_t ms) {
            for (const auto& thread : VMS_EXEC(g_threads)) {
                if (thread.state == ThreadState::Runnable && (!thread.begun || !thread.frames.empty())) {
                    ++idle_after_ready;
                    break;
                }
            }
            fit24_clock::sleep_for(std::chrono::milliseconds(ms));
        });
        ++work_turns[int(work)];
        sched_present_turn(true, false, true, 3, [&] { fit24_clock::us += present_us; });
    }
    if (fit24_clock::anchors.size() < 100 || static_int("paints") < total_frames) {
        std::cerr << "FAIL fixture progress frames=" << static_int("paints") << " turns=" << turns << '\n';
        return 2;
    }
    const size_t first = std::min<size_t>(120, fit24_clock::anchors.size() / 2);
    const auto elapsed = fit24_clock::anchors.back() - fit24_clock::anchors[first];
    const double fps = (fit24_clock::anchors.size() - first - 1) * 1000000.0 / elapsed;
    const auto work_first = fit24_clock::work_counts[first], work_last = fit24_clock::work_counts.back();
    const auto sleep_elapsed = work_last.elapsed - work_first.elapsed;
    const double nonsleep_percent = 100.0 * (elapsed - sleep_elapsed) / elapsed;
    int64_t min_interval = INT64_MAX, max_interval = 0;
    unsigned reanchors = 0;
    unsigned deadline_reanchors = 0;
    int64_t deadline_slip = 0;
    const int64_t period = speed_period_us();
    std::ofstream trace(argv[11]);
    trace << "frame,draw_start_us,interval_us,phase_us\n";
    const auto initial = fit24_clock::anchors[first];
    for (size_t i = first; i < fit24_clock::anchors.size(); ++i) {
        const auto interval = i == first ? 0 : fit24_clock::anchors[i] - fit24_clock::anchors[i - 1];
        if (i > first) { min_interval = std::min(min_interval, interval); max_interval = std::max(max_interval, interval); }
        // A change of modulo phase is diagnostic only; actual deadlines also appear in snapshots.
        if (period && i > first && interval > period + 2000) ++reanchors;
        trace << i << ',' << fit24_clock::anchors[i] << ',' << interval << ','
              << (period ? fit24_clock::anchors[i] - initial - int64_t(i - first) * period : 0) << '\n';
    }
    if (period) for (size_t i = first; i < fit24_clock::deadlines.size(); ++i) {
        const auto d = fit24_clock::deadlines[i];
        const auto slip = d.next_due - d.old_due - period;
        if (d.old_due && slip > 0) { ++deadline_reanchors; deadline_slip += slip; }
    }
    std::ofstream deadlines(std::string(argv[11]) + ".deadlines.csv");
    deadlines << "frame,anchor_us,old_due_us,new_due_us,lost_phase_us\n";
    for (size_t i = 0; i < fit24_clock::deadlines.size(); ++i) {
        const auto d = fit24_clock::deadlines[i];
        deadlines << i << ',' << d.anchor << ',' << d.old_due << ',' << d.next_due << ','
                  << (d.old_due ? d.next_due-d.old_due-period : 0) << '\n';
    }
    std::ofstream gates(std::string(argv[11]) + ".gates.csv");
    gates << "gate,host_us,java_previous_ms,java_deadline_ms,java_returned_ms,draw_due_us,scale\n";
    for (size_t i=0; i<fit24_clock::gates.size(); ++i) {
        const auto g = fit24_clock::gates[i];
        gates << i << ',' << g.host << ',' << g.previous << ',' << g.due << ',' << g.returned
              << ',' << g.draw_due << ',' << g.scale << '\n';
    }
    std::cout << "RESULT mode=" << mode << " cap=" << cap
              << " overshoot_us=" << fit24_clock::overshoot_us
              << " prepare_us=" << fit24_clock::prepare_us << " draw_us=" << fit24_clock::draw_us
              << " present_us=" << present_us << " tick_us=" << fit24_clock::tick_us
              << " frames=" << fit24_clock::anchors.size() << " measured_intervals=" << fit24_clock::anchors.size()-first-1
              << " elapsed_us=" << elapsed << " fps=" << fps
              << " min_interval_us=" << min_interval << " max_interval_us=" << max_interval
              << " phase_drift_us=" << (period ? elapsed - int64_t(fit24_clock::anchors.size()-first-1)*period : 0)
              << " intervals_gt_period_plus_2ms=" << reanchors
              << " deadline_reanchors=" << deadline_reanchors << " deadline_lost_phase_us=" << deadline_slip
              << " scale=" << VMS_EXEC(g_game_clock).scale
              << " sleep_requests=" << g_frame_sleep_stats.requested_ms
              << " os_sleeps=" << fit24_clock::sleeps << " os_sleep_requested_us=" << fit24_clock::requested_sleep_us
              << " poll_calls=" << VMS_EXEC(g_poll_calls) << " poll_waits=" << VMS_EXEC(g_poll_waits)
              << " idle_after_ready=" << idle_after_ready
              << " stall_us=" << fit24_clock::stall_us
              << " measured_os_sleeps=" << work_last.sleeps-work_first.sleeps
              << " measured_os_sleep_us=" << sleep_elapsed << " measured_clock_reads=" << work_last.reads-work_first.reads
              << " nonsleep_wall_pct=" << nonsleep_percent
              << " turns=" << turns;
    for (auto entry : work_turns) std::cout << " work" << entry.first << '=' << entry.second;
    std::cout << '\n';
    if (minimum_fps > 0 && fps < minimum_fps) {
        std::cerr << "FAIL sustained selected cap: actual_draw_fps=" << fps << " expected_at_least=" << minimum_fps << '\n';
        return 1;
    }
    std::cout << "PASS controlled-runtime observation\n";
    return 0;
}
