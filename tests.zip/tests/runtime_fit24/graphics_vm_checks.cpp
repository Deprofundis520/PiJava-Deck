// Diagnostic/controlled replay of original Pet Kingdom 6 font and text methods.
// The original JAR and its font resource remain byte-for-byte unchanged.
#define main emulator_main
#include PROBE_VM
#undef main

static unsigned checks=0;
static void check(bool ok,const char* why){++checks;if(!ok){std::cerr<<"FAIL "<<why<<'\n';std::exit(1);}}
static Method* method(int cls,const char* name,const char* desc){auto* m=find_method(cls,name,desc,true);check(m,"method exists");return m;}
static Value invoke(int cls,const char* name,const char* desc,std::vector<Value> a){auto out=run(method(cls,name,desc),a);check(!VMS_EXEC(g_thrown)&&!current_context().unhandled,"original method returns normally");return out;}
static Value& field(int ref,const char* name,const char* desc){auto* f=find_field(VMS_HEAP(g_heap)[ref].cls,name,desc);check(f&&!f->is_static,"instance field exists");return VMS_HEAP(g_heap)[ref].fields[f->slot];}
static void root(int ref){VMS_CL(g_classes)[ensure_class("java/lang/Object")].statics.push_back(Value::of_ref(ref));}
static uint64_t digest(const std::vector<uint8_t>& data){uint64_t h=14695981039346656037ULL;for(uint8_t b:data)h=(h^b)*1099511628211ULL;return h;}

#include "draw_line_checks.inc"

static void profile_report(){
    std::vector<Method*> methods;
    for(auto& c:VMS_CL(g_classes))for(auto& m:c.methods)if(m.cpu_profile.calls)methods.push_back(&m);
    std::sort(methods.begin(),methods.end(),[](Method* a,Method* b){return a->cpu_profile.self_cpu_ns>b->cpu_profile.self_cpu_ns;});
    uint64_t total=0;for(auto* m:methods)total+=m->cpu_profile.self_cpu_ns;
    for(auto* m:methods)std::cout<<"PROFILE "<<VMS_CL(g_classes)[m->class_id].name<<'.'<<m->name<<m->desc<<" calls="<<m->cpu_profile.calls<<" self_cpu_ns="<<m->cpu_profile.self_cpu_ns<<'\n';
    std::cout<<"PROFILE_TOTAL self_cpu_ns="<<total<<" method_clocks_perturb_execution=1 compiled_regions_disabled=1\n";
}

static void font_probe(const char* jar,const std::string& scenario,unsigned repeats,unsigned frames){
    std::vector<uint8_t> bytes;std::string error;
    check(read_whole(jar,bytes)&&unzip(bytes,VMS_CL(g_jar_files),error),"original JAR loads");
    const std::string jar_hash=rms_jar_identity(bytes.data(),bytes.size());
    VMS_RS(g_screen_w)=240;VMS_RS(g_screen_h)=320;VMS_RS(g_fb).assign(240*320*3,0);
    const int common=ensure_class("CWA2DAPI/CWACommon");
    invoke(common,"setScreen","(SS)V",{Value::of_i(240),Value::of_i(320)});
    const int gfxcls=ensure_class("javax/microedition/lcdui/Graphics"),gfx=alloc_obj(gfxcls);root(gfx);
    invoke(gfxcls,"<init>","()V",{Value::of_ref(gfx)});
    const int fontcls=ensure_class("CWAUI/CWAUIFonts"),font=alloc_obj(fontcls);root(font);
    invoke(fontcls,"<init>","(I)V",{Value::of_ref(font),Value::of_i(12)});
    const int path=make_string("/data/script/fonts_12.mid");root(path);
    invoke(fontcls,"LoadFonts","(Ljava/lang/String;)V",{Value::of_ref(font),Value::of_ref(path)});
    check(field(font,"a","[B").ref&&field(font,"a","[S").ref&&field(font,"b","[B").ref&&field(font,"c","[B").ref,"original font resource loads both code tables and bitmaps");
    const int midpcls=ensure_class("javax/microedition/lcdui/Font");
    const int midp=invoke(midpcls,"getDefaultFont","()Ljavax/microedition/lcdui/Font;",{}).ref;root(midp);
    const int offsets=alloc_array("[I",2),flags=alloc_array("[Z",2);root(offsets);root(flags);
    // Short constructed labels model the observed UI call pattern. They are
    // inputs to the original methods, not replacements of their algorithms.
    std::vector<int> strings;
    for(const char* text:{"1234567","HP 234","火球攻击","宠物王国","防御","50/100","回合","67890"}){int ref=make_string(text);root(ref);strings.push_back(ref);}
    const bool wrapper=scenario=="wrapper"||scenario=="profile-wrapper";
    const bool profile=scenario=="profile"||scenario=="profile-wrapper";
    const int toolscls=ensure_class("CWA2DAPI/CWATools");
    Method* draw=wrapper?method(toolscls,"drawString","(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;IIIIIILjavax/microedition/lcdui/Font;ZI[IIBLCWAUI/CWAUIFonts;B[Z)V"):
        method(fontcls,"drawString","(Ljava/lang/String;IIIILjavax/microedition/lcdui/Graphics;)V");
    // Publish ordinary initialized static state and warm lazy members first.
    auto paint=[&](){
        for(size_t i=0;i<strings.size();++i){
            // Original UI callers restore each control's clip before entering
            // CWATools; the original method itself only intersects clipRect.
            invoke(gfxcls,"setClip","(IIII)V",{Value::of_ref(gfx),Value::of_i(0),Value::of_i(0),Value::of_i(240),Value::of_i(320)});
            std::vector<Value> a;
            if(wrapper)a={Value::of_ref(gfx),Value::of_ref(strings[i]),Value::of_i(0xe6d7ad),Value::of_i(12),Value::of_i(12+int(i)*24),Value::of_i(12),Value::of_i(210),Value::of_i(20),Value::of_ref(midp),Value::of_i(0),Value::of_i(0),Value::of_ref(offsets),Value::of_i(1),Value::of_i(0),Value::of_ref(font),Value::of_i(0),Value::of_ref(flags)};
            else a={Value::of_ref(font),Value::of_ref(strings[i]),Value::of_i(12),Value::of_i(12+int(i)*24),Value::of_i(20),Value::of_i(0xe6d7ad),Value::of_ref(gfx)};
            run(draw,a);check(!VMS_EXEC(g_thrown)&&!current_context().unhandled,"complete original draw method succeeds");
        }
    };
    ++VMS_RS(g_paint_depth);paint();--VMS_RS(g_paint_depth);
    gc_collect("font-probe-setup");
    VMS_EXEC(g_execution_profile).enabled=profile;
    for(auto& c:VMS_CL(g_classes))for(auto& m:c.methods)m.cpu_profile={};
    for(unsigned trial=0;trial<=repeats;++trial){
        const uint64_t fast=VMS_EXEC(g_fast_ops),slow=VMS_EXEC(g_slow_ops),jit=VMS_NATIVE(g_native_jit).stats.ops,entries=g_jit_region_stats.entries,gfxjit=g_jitr_gfx_ok;
        const uint64_t alloc=VMS_HEAP(g_alloc_since),arrays=VMS_HEAP(g_array_alloc_since_gc);
        VMS_RS(g_drawacc)={};VMS_RS(g_drawacc).on=true;VMS_RS(g_graphics_profile).reset(false);
        std::fill(VMS_RS(g_fb).begin(),VMS_RS(g_fb).end(),uint8_t(0));
        const auto start=std::chrono::steady_clock::now();
        for(unsigned f=0;f<frames;++f){++VMS_RS(g_paint_depth);paint();--VMS_RS(g_paint_depth);gc_collect("font-probe-frame");}
        const double ms=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();
        const uint64_t hash=digest(VMS_RS(g_fb));
        check(hash!=digest(std::vector<uint8_t>(VMS_RS(g_fb).size(),0)),"font actually changes pixels");
        std::cout<<"FONT trial="<<trial<<" scenario="<<scenario<<" frames="<<frames<<" labels="<<strings.size()<<" pixel_digest="<<hash<<" wall_ms="<<ms<<" fast="<<VMS_EXEC(g_fast_ops)-fast<<" slow="<<VMS_EXEC(g_slow_ops)-slow<<" jitops="<<VMS_NATIVE(g_native_jit).stats.ops-jit<<" region_entries="<<g_jit_region_stats.entries-entries<<" gfx_jit_calls="<<g_jitr_gfx_ok-gfxjit<<" lines="<<VMS_RS(g_drawacc).lines<<" profile="<<profile<<'\n';
        (void)alloc;(void)arrays;
    }
    if(profile)profile_report();
    std::cout<<"FONT_INPUT ascii_chars="<<VMS_HEAP(g_heap)[field(font,"a","[B").ref].elems.size()<<" cjk_chars="<<VMS_HEAP(g_heap)[field(font,"a","[S").ref].elems.size()<<" font_bytes="<<VMS_CL(g_jar_files)["data/script/fonts_12.mid"].size()<<'\n';
    std::cout<<"PROVENANCE jar_sha256="<<jar_hash<<" original_bytecode=1 original_font_data=1 constructed_text_inputs=1 entire_original_drawString=1 synthetic_frame=1 natural_scene=0 desktop_not_switch=1\n";
}

int main(int argc,char** argv){
    check(argc>=5,"romfs engine scenario jar [repeats] [frames]");
    VMS_CL(g_classpath)={argv[1]};VMS_DIAG(g_log_draw)=false;VMS_EXEC(g_slice_ms)=4;VMS_EXEC(g_speed_cap)=0;
    if(const char* fixtures=std::getenv("FIT24_CLASSES"))VMS_CL(g_classpath).insert(VMS_CL(g_classpath).begin(),fixtures);
    VMS_NATIVE(g_native_jit).configure(std::string(argv[2])=="jit");
    check(std::string(argv[2])!="jit"||VMS_NATIVE(g_native_jit).available,"requested host JIT available");
    const std::string scenario=argv[3];
    if(scenario=="admission"){
        auto* line=method(ensure_class("javax/microedition/lcdui/Graphics"),"drawLine","(IIII)V");
        check(graphics_intrinsic(line)!=0,"Graphics.drawLine has generic bounded dispatch");
    }else if(scenario=="semantics")line_semantics();
    else if(scenario=="line-super")line_super();
    else if(scenario=="line-vm")line_vm();
    else font_probe(argv[4],scenario,argc>5?std::atoi(argv[5]):0,argc>6?std::atoi(argv[6]):2);
    check(g_gc_sp.violations==0,"GC only at valid safepoints");
    check(jit236::active_code_calls()==0,"no live JIT activation at teardown");
    VMS_NATIVE(g_native_jit).clear();jit_region_reset();
    std::cout<<"PASS font-probe checks="<<checks<<'\n';
}
