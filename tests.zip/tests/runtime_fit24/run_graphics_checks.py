#!/usr/bin/env python3
"""Exercise drawLine through the real VM and optional original Pet font methods.

Host and optional QEMU AArch64 runs verify behavior; QEMU timings are never used
for performance claims. The original JAR is an external, unchanged test input.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess
import time


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    here = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, default=here.parents[1])
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--cross-root', type=Path)
    parser.add_argument('--arch', choices=['x64', 'a64', 'both'])
    parser.add_argument('--opt', choices=['O0', 'O2'], default='O0')
    parser.add_argument('--baseline', action='store_true', help='Skip admission assertion on the unchanged Fit23 source')
    parser.add_argument('--build-only', action='store_true')
    parser.add_argument('--pet-jar', type=Path, help='Optional unchanged Pet Kingdom 6 JAR for original font + wrapper replay')
    args = parser.parse_args()
    source, out = args.source.resolve(), args.output.resolve()
    out.mkdir(parents=True, exist_ok=True)
    arch = args.arch or ('both' if args.cross_root else 'x64')
    if arch in ('a64', 'both') and not args.cross_root:
        parser.error('--arch a64/both requires --cross-root')
    files = [p for subdir in ('src', 'third_party', 'romfs/classes')
             for p in sorted((source / subdir).rglob('*')) if p.is_file()]
    files += [here / name for name in ('graphics_vm_checks.cpp', 'draw_line_checks.inc', 'DrawLineCases.java', 'run_graphics_checks.py')]
    if args.pet_jar:
        files.append(args.pet_jar.resolve())
    inputs = {str(p): sha(p) for p in files}
    (out / 'input-sha256.json').write_text(json.dumps(inputs, indent=2) + '\n')
    records, binaries = [], {}

    def run(label, command, env=None):
        command = list(map(str, command))
        start = time.monotonic()
        print(label + ': ' + shlex.join(command), flush=True)
        result = subprocess.run(command, cwd=source, env=env, stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT, timeout=300)
        (out / (label + '.log')).write_bytes(result.stdout)
        records.append({'label': label, 'command': command, 'returncode': result.returncode,
                        'seconds': time.monotonic() - start})
        (out / 'commands.json').write_text(json.dumps(records, indent=2) + '\n')
        print(result.stdout.decode(errors='replace'), end='', flush=True)
        print(label + '_signedrc=' + str(result.returncode), flush=True)
        if result.returncode:
            raise SystemExit(result.returncode)
        return result.stdout.decode(errors='replace')

    classes = out / 'classes'
    classes.mkdir(exist_ok=True)
    run('build-java', ['java', '-m', 'jdk.compiler/com.sun.tools.javac.Main', '-source', '8', '-target', '8',
                      '-bootclasspath', source / 'romfs/classes', '-classpath', source / 'romfs/classes',
                      '-d', classes, here / 'DrawLineCases.java'])
    arches = []
    if arch in ('x64', 'both'):
        arches.append(('x64', ['gcc'], ['g++'], [], os.environ.copy()))
    if arch in ('a64', 'both'):
        cross = args.cross_root.resolve()
        env = os.environ.copy()
        env['LD_LIBRARY_PATH'] = str(cross / 'usr/lib/x86_64-linux-gnu')
        sysroot = '--sysroot=' + str(cross)
        arches.append(('a64', [cross / 'usr/bin/aarch64-linux-gnu-gcc', sysroot],
                       [cross / 'usr/bin/aarch64-linux-gnu-g++', sysroot],
                       [cross / 'usr/bin/qemu-aarch64', '-L', cross / 'usr/aarch64-linux-gnu'], env))
    font_outputs = {}
    for name, cc, cxx, qemu, env in arches:
        archout = out / name
        archout.mkdir(exist_ok=True)
        puff, binary = archout / 'puff.o', archout / 'graphics-vm-checks'
        run('build-puff-' + name, cc + ['-' + args.opt, '-g0', '-c', source / 'src/puff.c', '-o', puff], env)
        run('build-vm-' + name, cxx + ['-' + args.opt, '-g0', '-std=c++17', '-fno-exceptions',
             '-ffunction-sections', '-fdata-sections', '-DPROBE_VM="' + str(source / 'src/j2mevm.cpp') + '"',
             here / 'graphics_vm_checks.cpp', puff, '-Wl,--gc-sections', '-pthread', '-ldl', '-o', binary], env)
        binaries[str(binary)] = sha(binary)
        (out / 'binary-sha256.json').write_text(json.dumps(binaries, indent=2) + '\n')
        if args.build_only:
            continue
        env['FIT24_CLASSES'] = str(classes)
        scenarios = ([] if args.baseline else ['admission']) + ['semantics', 'line-super', 'line-vm']
        if args.pet_jar:
            scenarios += ['font', 'wrapper']
        for engine in ('fast', 'jit'):
            for scenario in scenarios:
                text = run(name + '-' + engine + '-' + scenario, qemu + [binary, source / 'romfs/classes',
                           engine, scenario, args.pet_jar.resolve() if args.pet_jar else '-', '0', '2'], env)
                for line in text.splitlines():
                    if line.startswith('FONT '):
                        fields = dict(word.split('=', 1) for word in line.split()[1:])
                        actual = (fields['pixel_digest'], int(fields['lines']),
                                  sum(int(fields[key]) for key in ('fast', 'slow', 'jitops')))
                        if scenario in font_outputs and actual != font_outputs[scenario]:
                            raise SystemExit('Original font replay differs between engines/architectures: ' + str(actual))
                        font_outputs[scenario] = actual
    changed = [str(path) for path in files if sha(path) != inputs[str(path)]]
    (out / 'input-changes-during-run.json').write_text(json.dumps(changed, indent=2) + '\n')
    if changed:
        raise SystemExit('Inputs changed during build/run: ' + repr(changed))
    (out / 'summary.json').write_text(json.dumps({'architectures': [a[0] for a in arches],
         'baseline': args.baseline, 'build_only': args.build_only, 'font_outputs': font_outputs,
         'commands': len(records), 'all_returncodes_zero': all(r['returncode'] == 0 for r in records),
         'inputs_unchanged': True}, indent=2) + '\n')
    print('PASS graphics checks; inputs unchanged', flush=True)


if __name__ == '__main__':
    main()
