import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Graphics;

/** Generic frame loops; no supplied game code and no fixture timing shortcuts. */
public class ClockPacingFixture extends Canvas implements Runnable {
    static int mode, updates, paints;
    public static void start(int selected) {
        mode = selected;
        updates = paints = 0;
        ClockPacingFixture canvas = new ClockPacingFixture();
        Display.getDisplay(null).setCurrent(canvas);
        new Thread(canvas).start();
    }
    protected void paint(Graphics g) {
        ++paints;
        g.setColor(updates);
        g.fillRect(0, 0, 8, 8);
    }
    public void run() {
        long previous = System.currentTimeMillis();
        while (true) {
            if (mode == 1) {
                while (System.currentTimeMillis() - previous < 70) Thread.yield();
                previous = System.currentTimeMillis();
            }
            ++updates;
            repaint();
            serviceRepaints();
            if (mode != 1 && mode != 6) {
                try { Thread.sleep(mode == 2 ? 130 : 70); }
                catch (InterruptedException ignored) { }
            }
        }
    }
}
