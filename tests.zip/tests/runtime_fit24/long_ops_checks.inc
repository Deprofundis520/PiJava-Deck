// Catch wrong 64-bit wrapping, unsigned right shift, fuel/PC accounting,
// stack consumption, and any mutation before insufficient-stack fallback.
// Reference execution uses the real VM's unchanged slow opcode switch.
#include <random>
static bool same_value(const Value& a,const Value& b){return a.i==b.i&&a.ref==b.ref&&a.l==b.l&&a.is_long==b.is_long;}
static void long_ops_checks(){
    const int cls=ensure_class("java/lang/Object");
    invoke(cls,"<init>","()V",{Value::of_ref(object("java/lang/Object"))});
    const bool was_jit=VMS_NATIVE(g_native_jit).enabled;VMS_NATIVE(g_native_jit).enabled=false;
    struct Literal {int op;int64_t a,b,want;};
    const Literal literals[]={
        {97,INT64_MAX,1,INT64_MIN},{97,INT64_MIN,-1,INT64_MAX},{97,-1,-1,-2},
        {105,INT64_MIN,-1,INT64_MIN},{105,INT64_MAX,INT64_MAX,1},{105,INT64_C(0x4000000000000000),4,0},{105,-3,7,-21},
        {127,-1,INT64_MIN,INT64_MIN},{127,240,15,0},{131,-1,INT64_MIN,INT64_MAX},{131,240,15,255},
        {125,-1,1,INT64_MAX},{125,INT64_MIN,63,1},{125,-1,64,-1},{125,INT64_MIN,-1,1},{125,-1,65,INT64_MAX}
    };
    unsigned vectors=0;
    auto one=[&](int op,int64_t a,int64_t b,const int64_t* literal){
        Method reference;reference.class_id=cls;reference.name="longFixture";reference.flags=8;
        reference.desc=op==125?"(JI)J":"(JJ)J";reference.max_locals=4;reference.max_stack=4;
        reference.code={30,uint8_t(op==125?28:32),uint8_t(op),173};
        const Value left=Value::of_l(a),right=op==125?Value::of_i(int32_t(b)):Value::of_l(b);
        r4::state.active=true;r4::state.cfg.profile="reference-v1";r4::state.remaining=10000;
        const uint64_t old_ops=r4::state.opcodes;Value expected=call(&reference,{left,right});
        check(r4::state.opcodes-old_ops==4,"slow reference exact four bytecodes");r4::state.active=false;
        check(expected.is_long,"reference returns Java long");if(literal)check(expected.l==*literal,"hand-checked literal result");
        for(int budget=0;budget<=5;++budget){
            Frame frame;frame.method=&reference;frame.locals={left,Value{},right,Value{}};
            int done=execute_fast_batch(frame,budget);check(done==std::min(budget,3),"all three non-return opcodes remain in a bounded fast batch");
            check(frame.pc==std::min(budget,3),"bytecode PC/fuel boundary exact");
            if(budget>=3)check(frame.stack.size()==1&&same_value(frame.stack.back(),expected),"fast result equals original slow switch");
            if(budget==0)check(frame.stack.empty(),"zero fuel leaves stack unchanged");
            if(budget==1)check(frame.stack.size()==1&&same_value(frame.stack[0],left),"one fuel only loads first operand");
            if(budget==2)check(frame.stack.size()==2&&same_value(frame.stack[0],left)&&same_value(frame.stack[1],right),"two fuel leaves both operands unconsumed");
        }
        Method isolated=reference;isolated.code={uint8_t(op),173};
        for(unsigned depth=0;depth<2;++depth){
            Frame frame;frame.method=&isolated;if(depth)frame.stack.push_back(left);
            check(execute_fast_batch(frame,16)==0&&frame.pc==0&&frame.stack.size()==depth,"underflow declines before side effects");
            if(depth)check(same_value(frame.stack[0],left),"declined opcode preserves operand bits");
        }
        ++vectors;
    };
    for(const auto& t:literals)one(t.op,t.a,t.b,&t.want);
    std::mt19937_64 rng(0x24e6ec7);
    for(unsigned n=0;n<500;++n){int64_t a=long_bits(rng()),b=long_bits(rng());for(int op:{97,105,125,127,131})one(op,a,b,nullptr);}
    // Timing-aware lsub and all potentially throwing division/remainder
    // remain owned by the existing slow path; this candidate must not admit them.
    for(int op:{101,109,113}){
        Method m;m.class_id=cls;m.name="slowBoundary";m.code={uint8_t(op),173};
        Frame f;f.method=&m;f.stack={Value::of_l(9),Value::of_l(3)};
        check(execute_fast_batch(f,16)==0&&f.pc==0&&f.stack.size()==2,"slow timing/exception boundary retained");
    }
    VMS_NATIVE(g_native_jit).enabled=was_jit;
    std::cout<<"PASS long-ops vectors="<<vectors<<" budgets=0..5 slow_switch_reference=1 literal_edges=16 underflow_preserved=1 excluded_lsub_ldiv_lrem=1\n";
}
