#!/usr/bin/env python3
"""Compile and execute the real HUD calculation with a controlled host clock."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, default=ROOT)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    source, out = args.source.resolve(), args.output.resolve()
    out.mkdir(parents=True, exist_ok=True)
    host = source / "src/platform/switch_host.inc"
    text = host.read_text()
    start = text.index("    VMS_PLAT_LOCAL(fps_shown, present_fps_shown,")
    end = text.index("    std::string label =", start)
    block = text[start:end]
    helper = source / "src/present_fps.h"
    include = '#include "' + str(helper) + '"\n' if helper.exists() else ""
    adapter = include + '''
struct HudState {
    int present_fps_shown = 0;
    uint64_t present_fps_seen = 0, g_present_frames = 0;
    int64_t present_fps_t0 = 0;
    bool g_fps_reset = false;
};
static HudState hud_state;
static int64_t hud_clock_us;
[[maybe_unused]] static int64_t monotonic_ms() { return hud_clock_us / 1000; }
[[maybe_unused]] static int64_t paint_clock_us() { return hud_clock_us; }
#define VMS_PLAT_LOCAL(alias, storage, ...) auto& alias = hud_state.storage;
#define VMS_PLAT(name) (hud_state.name)
#define VMS_RS(name) (hud_state.name)
static int hud_update(uint64_t frames, int64_t clock_us, bool reset) {
    hud_state.g_present_frames = frames;
    hud_state.g_fps_reset = reset;
    hud_clock_us = clock_us;
''' + block + '''
    return fps_shown;
}
#undef VMS_PLAT_LOCAL
#undef VMS_PLAT
#undef VMS_RS
'''
    (out / "actual-hud-block.h").write_text(adapter)
    identities = {str(host): hashlib.sha256(host.read_bytes()).hexdigest()}
    if helper.exists(): identities[str(helper)] = hashlib.sha256(helper.read_bytes()).hexdigest()
    (out / "input-sha256.json").write_text(json.dumps(identities, indent=2) + "\n")
    binary = out / "present-fps-checks"
    commands = [
        ["g++", "-O2", "-std=c++17", "-Wall", "-Wextra", "-DJ2ME_HUD_ADAPTER=\"" + str(out / "actual-hud-block.h") + "\"", str(HERE / "present_fps_checks.cpp"), "-o", str(binary)],
        [str(binary)],
    ]
    records = []
    for i, command in enumerate(commands):
        result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=60)
        (out / f"step-{i}.log").write_bytes(result.stdout)
        records.append(dict(command=command, returncode=result.returncode))
        (out / "commands.json").write_text(json.dumps(records, indent=2) + "\n")
        print("step", i, "returncode", result.returncode)
        if result.stdout: print(result.stdout.decode(errors="replace").strip())
        if result.returncode: raise SystemExit(result.returncode)


if __name__ == "__main__":
    main()
