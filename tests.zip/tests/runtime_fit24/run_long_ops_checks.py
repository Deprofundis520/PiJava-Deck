#!/usr/bin/env python3
"""Exercise bounded long bytecodes in the actual VM, plus optional external game replay.

No commercial JAR, class bytecode, image, or font data is included. The optional
Immortal Slayer input supplies its own original methods at runtime. Replay uses
constructed typed heap inputs and a fixed virtual clock, not a natural scene.
"""
import argparse
import hashlib
import json
import subprocess
import time
from pathlib import Path


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, default=Path(__file__).resolve().parents[2])
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--immortal-jar', type=Path)
    args = parser.parse_args()
    source, output = args.source.resolve(), args.output.resolve()
    here = Path(__file__).resolve().parent
    output.mkdir(parents=True, exist_ok=True)
    if args.immortal_jar and not args.immortal_jar.is_file():
        parser.error('--immortal-jar must identify an existing external JAR')
    inputs = {str(path): sha(path) for name in ['src', 'third_party', 'romfs/classes']
              for path in sorted((source / name).rglob('*')) if path.is_file()}
    for name in ['long_ops_checks.cpp', 'long_ops_checks.inc', 'run_long_ops_checks.py']:
        inputs[str(here / name)] = sha(here / name)
    if args.immortal_jar:
        inputs[str(args.immortal_jar.resolve())] = sha(args.immortal_jar)
    (output / 'input-sha256.json').write_text(json.dumps(inputs, indent=2) + '\n')
    commands, cases = [], {}

    def execute(name, command):
        started = time.monotonic()
        log_path = output / (name + '.log')
        with log_path.open('w') as log:
            result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, timeout=300)
        commands.append({'name': name, 'command': command, 'returncode': result.returncode,
                         'seconds': time.monotonic() - started, 'log': str(log_path)})
        (output / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
        print(name, 'returncode', result.returncode, flush=True)
        if result.returncode:
            raise RuntimeError(log_path.read_text()[-8000:])
        return log_path.read_text()

    binary = output / 'long-ops-checks'
    execute('build-puff', ['gcc', '-O2', '-g0', '-c', str(source / 'src/puff.c'),
                           '-o', str(output / 'puff.o')])
    execute('build-probe', ['g++', '-O2', '-g0', '-std=c++17', '-fno-exceptions',
                            '-ffunction-sections', '-fdata-sections',
                            '-DPROBE_VM="' + str(source / 'src/j2mevm.cpp') + '"',
                            str(here / 'long_ops_checks.cpp'), str(output / 'puff.o'),
                            '-Wl,--gc-sections', '-pthread', '-ldl', '-o', str(binary)])
    execute('long-semantics', [str(binary), str(source / 'romfs/classes'),
                               'fast', 'long-semantics', '-'])
    if args.immortal_jar:
        for scenario in ['weather', 'occlusion']:
            for engine in ['fast', 'jit']:
                text = execute(engine + '-' + scenario,
                               [str(binary), str(source / 'romfs/classes'), engine,
                                scenario, str(args.immortal_jar.resolve()), '1', '8'])
                rows = [line for line in text.splitlines() if line.startswith('EFFECTS ')]
                if len(rows) != 1:
                    raise RuntimeError('missing unique effects result')
                row = dict(token.split('=', 1) for token in rows[0].split()[1:])
                # Native JIT stats.ops includes region operations: never add
                # the separately reported jitregion count a second time.
                row['total_original_ops'] = sum(int(row[key]) for key in ['fast', 'slow', 'jitleaf'])
                cases[engine + '-' + scenario] = row
            fast, jit = cases['fast-' + scenario], cases['jit-' + scenario]
            for key in ['pixels', 'frames', 'lines', 'images', 'clips', 'gfx_calls',
                        'offscreen_calls', 'total_original_ops']:
                if fast[key] != jit[key]:
                    raise RuntimeError(f'{scenario}: fast/JIT mismatch in {key}')
            if scenario == 'weather' and fast['lines'] != '320':
                raise RuntimeError('original forty-particle path was not exercised')
            if scenario == 'occlusion' and (fast['images'], fast['clips']) != ('88', '352'):
                raise RuntimeError('original layer clipping/drawing path was not exercised')
    changed = [path for path, digest in inputs.items() if sha(Path(path)) != digest]
    (output / 'input-changes.json').write_text(json.dumps(changed, indent=2) + '\n')
    if changed:
        raise RuntimeError('inputs changed during verification: ' + repr(changed))
    report = {'passed': True, 'source': str(source), 'binary_sha256': sha(binary),
              'long_vectors': 2516, 'budgets': [0, 1, 2, 3, 4, 5],
              'reference': 'actual original slow interpreter switch',
              'external_jar_replay': bool(args.immortal_jar), 'replay_cases': cases,
              'natural_scene': False, 'switch_performance_claim': False}
    (output / 'results.json').write_text(json.dumps(report, indent=2) + '\n')
    print('PASS bounded long arithmetic; original op budgets and optional game replay verified')


if __name__ == '__main__':
    main()
