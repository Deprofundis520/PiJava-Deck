#!/usr/bin/env python3
"""Real VM pacing regressions with a deterministic host clock and OS boundary.

This measures selected synthetic host timing, not physical Switch performance.
The Java interpreter, native Thread.sleep, thread refresh, frame ownership,
deadline policy, clock learner and host scheduler are the production code.
"""
import argparse
import csv
import json
import os
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, default=ROOT)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--skip-build", action="store_true")
    args = parser.parse_args()
    source, out = args.source.resolve(), args.output.resolve()
    out.mkdir(parents=True, exist_ok=True)
    records = []

    def run(label, command, environment=None):
        environment = environment or {}
        result = subprocess.run(list(map(str, command)), env=dict(os.environ, **environment),
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=300)
        (out / (label + ".log")).write_bytes(result.stdout)
        record = dict(label=label, command=list(map(str, command)), returncode=result.returncode,
                      environment=environment, log=str(out / (label + ".log")))
        records.append(record)
        print(label, "returncode", result.returncode, flush=True)
        for line in result.stdout.decode(errors="replace").splitlines():
            if line.startswith(("RESULT", "FAIL", "PASS", "DUAL_DEADLINE", "RACE")):
                print(line, flush=True)
        return result, record

    if not args.skip_build:
        result, _ = run("build", [sys.executable, "-B", HERE / "build_pacing_fixture.py", "--source", source, "--output", out])
        if result.returncode:
            print(result.stdout.decode(errors="replace")[-6000:])
            raise SystemExit(result.returncode)
    # Expectations are throughput of actual Java drawings, never cap/HUD values.
    cases = []
    def add(label, mode, cap, overshoot, minimum, maximum, *, prepare=500, environment=None, phase=True):
        cases.append(dict(label=label,mode=mode,cap=cap,overshoot=overshoot,minimum=minimum,maximum=maximum,
                          prepare=prepare,environment=environment or {},phase=phase))
    for label,mode in [("precise-deadline",4),("ready-race",3),("deadline-boundaries-peers-restore",5),
                       ("bounded-phase-contracts",7),("adaptive-margin-contracts",8)]:
        add(label,mode,60,0,0,0)
    for name,mode in [("sleep",0),("poll",1)]:
        for late in [0,500,1200,1500,2500]:
            add(f"{name}-60-late-{late}",mode,60,late,59.8,60.2)
        for late in [0,1500]:
            add(f"{name}-30-late-{late}",mode,30,late,29.8,30.2)
        add(f"{name}-60-variable-lateness",mode,60,0,59.8,60.2,
            environment={"FIT24_OVERSLEEP_SEQUENCE":"0,1000,1500,100,2500,0,500,1200"})
        add(f"{name}-60-long-stall",mode,60,1500,57.5,59.8,phase=False,
            environment={"FIT24_STALL_US":"200000"})
        add(f"{name}-60-continuous-overload",mode,60,1500,30,40,prepare=25000,phase=False)
    add("native-sleep-70",0,0,0,13.8,14.5,phase=False)
    add("native-sleep-70-late-1500",0,0,1500,13.5,14.5,phase=False)
    add("native-poll-70-late-1500",1,0,1500,13.8,14.5,phase=False)
    add("authored-sleep-130",2,60,0,7.3,8.0,phase=False)
    add("authored-sleep-130-late-1500",2,60,1500,7.3,8.0,phase=False)
    add("draw-only-long-stall",6,60,0,57.5,59.8,phase=False,environment={"FIT24_STALL_US":"200000"})
    failed = False
    for case in cases:
        label,mode,cap=case["label"],case["mode"],case["cap"]
        minimum,maximum=case["minimum"],case["maximum"]
        command = [out / "controlled-runtime", out / "classes", source / "romfs/classes",
                   mode, cap, case["overshoot"], case["prepare"], 100, 700, 1, 600, out / (label + ".csv"), minimum]
        result, record = run(label, command, case["environment"])
        record["validation_errors"]=[]
        def error(message): record["validation_errors"].append(message)
        lines = [line for line in result.stdout.decode(errors="replace").splitlines() if line.startswith("RESULT ")]
        if minimum:
            if len(lines) != 1:
                error("Expected exactly one completed runtime measurement")
            else:
                data = dict(token.split("=", 1) for token in lines[0].split()[1:])
                record["measurements"] = data
                if not minimum <= float(data["fps"]) <= maximum:
                    error("Actual draw rate outside independent expected range")
                if case["phase"] and cap and mode in (0, 1) and abs(int(data["phase_drift_us"])) > 2000:
                    error("Light-load phase error accumulated beyond bounded jitter")
                if mode in (0, 2) and float(data["scale"]) != 1.0:
                    error("Authored sleep changed the Java clock scale")
                if cap:
                    period=16667 if cap==60 else 33333
                    if int(data["min_interval_us"]) < period-2000:
                        error("Actual drawings violated the original minimum frame interval")
                if case["prepare"]>=25000 and int(data["min_interval_us"])<case["prepare"]:
                    error("Continuous overload caused drawing intervals shorter than the actual work")
                if case["environment"].get("FIT24_STALL_US"):
                    with (out/(label+".csv")).open() as handle: rows=list(csv.DictReader(handle))
                    post=[row for row in rows if int(row["frame"])>=250]
                    post_rate=(len(post)-1)*1000000/(int(post[-1]["draw_start_us"])-int(post[0]["draw_start_us"]))
                    record["post_stall_fps"]=post_rate
                    if not 59.8<=post_rate<=60.2:error("Long stall left persistent phase debt")
                    if int(data["max_interval_us"])<200000:error("Long stall was not actually exercised")
        failed |= bool(result.returncode or record["validation_errors"])
        summary = dict(passed=not failed, scope="deterministic host timing; not physical Switch FPS", results=records)
        (out / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
        for message in record["validation_errors"]: print("FAIL", label, message, flush=True)
    print("FAIL" if failed else "PASS", "Fit24 pacing checks", len(cases), flush=True)
    raise SystemExit(1 if failed else 0)


if __name__ == "__main__":
    main()
