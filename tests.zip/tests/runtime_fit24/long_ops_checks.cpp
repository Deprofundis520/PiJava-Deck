// Controlled input replay of unmodified Immortal Slayer methods.
// No game algorithm is replaced. The q world is a constructed, typed heap
// fixture; its full map/UI-loading constructor is deliberately not run.
#define main emulator_main
#include PROBE_VM
#undef main

static unsigned checks=0;
static void check(bool ok,const char* why){++checks;if(!ok){std::cerr<<"FAIL "<<why<<'\n';std::exit(1);}}
static Method* method(int cls,const char* name,const char* desc){auto* m=find_method(cls,name,desc,true);check(m,"method exists");return m;}
static Value call(Method* m,const std::vector<Value>& a){auto v=run(m,a);if(VMS_EXEC(g_thrown)||current_context().unhandled){std::cerr<<"THROW "<<VMS_CL(g_classes)[m->class_id].name<<'.'<<m->name<<m->desc<<'\n';check(false,"original method returns normally");}return v;}
static Value invoke(int cls,const char* name,const char* desc,std::vector<Value> a){return call(method(cls,name,desc),a);}
static Value& field(int ref,const char* name,const char* desc){auto* f=find_field(VMS_HEAP(g_heap)[ref].cls,name,desc);check(f&&!f->is_static,"instance field exists");return VMS_HEAP(g_heap)[ref].fields[f->slot];}
static Value& stat(int cls,const char* name,const char* desc){auto* f=find_field(cls,name,desc);check(f&&f->is_static,"static field exists");return VMS_CL(g_classes)[cls].statics[f->slot];}
static void root(int ref){VMS_CL(g_classes)[ensure_class("java/lang/Object")].statics.push_back(Value::of_ref(ref));}
static int object(const char* name){int ref=alloc_obj(ensure_class(name));root(ref);return ref;}
static int array(const char* desc,int n){int ref=alloc_array(desc,n);root(ref);return ref;}
static uint64_t digest(const std::vector<uint8_t>& data){uint64_t h=14695981039346656037ULL;for(uint8_t b:data)h=(h^b)*1099511628211ULL;return h;}
static void profile_report(){
    std::vector<Method*> methods;uint64_t total=0;
    for(auto& c:VMS_CL(g_classes))for(auto& m:c.methods)if(m.cpu_profile.calls||m.cpu_profile.self_cpu_ns){methods.push_back(&m);total+=m.cpu_profile.self_cpu_ns;}
    std::sort(methods.begin(),methods.end(),[](Method* a,Method* b){return a->cpu_profile.self_cpu_ns>b->cpu_profile.self_cpu_ns;});
    for(auto* m:methods)std::cout<<"PROFILE "<<VMS_CL(g_classes)[m->class_id].name<<'.'<<m->name<<m->desc<<" calls="<<m->cpu_profile.calls<<" self_cpu_ns="<<m->cpu_profile.self_cpu_ns<<'\n';
    std::cout<<"PROFILE_TOTAL self_cpu_ns="<<total<<" method_clocks_perturb_execution=1 compiled_regions_and_readleaf_disabled=1\n";
}
static uint64_t readleaf_calls(){uint64_t n=0;for(auto& c:VMS_CL(g_classes))for(auto& m:c.methods)n+=m.read_leaf_calls;return n;}

#include "long_ops_checks.inc"

int main(int argc,char** argv){
    check(argc>=5,"romfs engine scenario jar [trials] [frames]");
    const std::string scenario=argv[3];const bool weather=scenario.find("weather")!=std::string::npos,profile=scenario.find("profile")!=std::string::npos;
    const unsigned trials=argc>5?std::atoi(argv[5]):1,frames=argc>6?std::atoi(argv[6]):16;
    VMS_CL(g_classpath)={argv[1]};VMS_DIAG(g_log_draw)=false;VMS_EXEC(g_slice_ms)=4;VMS_EXEC(g_speed_cap)=0;
    VMS_NATIVE(g_native_jit).configure(std::string(argv[2])=="jit");
    check(std::string(argv[2])!="jit"||VMS_NATIVE(g_native_jit).available,"host JIT available");
    if(scenario=="long-semantics"){long_ops_checks();return 0;}
    std::vector<uint8_t> bytes;std::string error;
    check(read_whole(argv[4],bytes)&&unzip(bytes,VMS_CL(g_jar_files),error),"original JAR loads");
    const std::string jar_hash=rms_jar_identity(bytes.data(),bytes.size());
    VMS_RS(g_screen_w)=240;VMS_RS(g_screen_h)=320;VMS_RS(g_fb).assign(240*320*3,0);
    const int imgcls=ensure_class("javax/microedition/lcdui/Image"),gfxcls=ensure_class("javax/microedition/lcdui/Graphics");
    const int target=invoke(imgcls,"createImage","(II)Ljavax/microedition/lcdui/Image;",{Value::of_i(240),Value::of_i(320)}).ref;root(target);
    const int gfx=invoke(imgcls,"getGraphics","()Ljavax/microedition/lcdui/Graphics;",{Value::of_ref(target)}).ref;root(gfx);
    const int bcls=ensure_class("b"),draw=object("b");invoke(bcls,"<init>","(Ljavax/microedition/lcdui/Graphics;)V",{Value::of_ref(draw),Value::of_ref(gfx)});
    const int qcls=ensure_class("q"),world=object("q");
    // An ordinary harmless method initializes q/m/y statics through the VM.
    invoke(qcls,"b","(I)I",{Value::of_ref(world),Value::of_i(0)});
    field(world,"h","I")=Value::of_i(0);field(world,"i","I")=Value::of_i(0);field(world,"j","I")=Value::of_i(240);field(world,"k","I")=Value::of_i(320);
    Method* paint=nullptr;std::vector<Value> paint_args;std::vector<int> particle_arrays;
    if(weather){
        // Original default S=40. All positions and lengths stay within the
        // original 120-entry arrays. m=true retains updates and Random calls.
        stat(qcls,"S","I")=Value::of_i(40);stat(qcls,"A","Z")=Value::of_i(1);stat(qcls,"m","Z")=Value::of_i(1);
        field(world,"y","Z")=Value::of_i(1);field(world,"aB","I")=Value::of_i(2);
        for(const char* n:{"j","k","l","m"})particle_arrays.push_back(stat(qcls,n,"[I").ref);
        particle_arrays.push_back(stat(qcls,"c","[B").ref);
        paint=method(qcls,"d","(Lb;)V");paint_args={Value::of_ref(world),Value::of_ref(draw)};
    }else{
        const int icls=ensure_class("i"),actor=object("i");invoke(icls,"<init>","()V",{Value::of_ref(actor)});
        const int kcls=ensure_class("k"),zcls=ensure_class("z"),sprite=object("z");invoke(zcls,"<init>","()V",{Value::of_ref(sprite)});
        for(const char* n:{"a","b","c","d"}){int a=array("[S",1);VMS_HEAP(g_heap)[a].elems.set(0,Value::of_i((n[0]=='a'||n[0]=='b')?-20:20));field(sprite,n,"[S")=Value::of_ref(a);}
        field(actor,"a","Lm;")=Value::of_ref(world);field(actor,"a","Lz;")=Value::of_ref(sprite);field(actor,"J","I")=Value::of_i(100);field(actor,"K","I")=Value::of_i(100);
        const int scls=ensure_class("s"),map=object("s");invoke(scls,"<init>","(II)V",{Value::of_ref(map),Value::of_i(240),Value::of_i(320)});
        field(world,"a","Ls;")=Value::of_ref(map);field(map,"b","Z")=Value::of_i(1);
        int marks=array("[B",1);VMS_HEAP(g_heap)[marks].elems.set(0,Value::of_i(-1));field(world,"a","[B")=Value::of_ref(marks);
        const int layer_count=32,layers=array("[Laa;",layer_count);field(map,"a","[Laa;")=Value::of_ref(layers);field(map,"f","I")=Value::of_i(layer_count);
        const int atlas=invoke(imgcls,"createImage","(II)Ljavax/microedition/lcdui/Image;",{Value::of_i(48),Value::of_i(64)}).ref;root(atlas);
        for(size_t p=0;p<VMS_HEAP(g_heap)[atlas].pixels.size();++p)VMS_HEAP(g_heap)[atlas].pixels[p]=uint8_t(p*29+13);
        const int pcls=ensure_class("p"),picture=object("p");invoke(pcls,"<init>","(Ljavax/microedition/lcdui/Image;)V",{Value::of_ref(picture),Value::of_ref(atlas)});
        const int acls=ensure_class("aa");
        for(int n=0;n<layer_count;++n){
            int layer=object("aa");invoke(acls,"<init>","(Ls;)V",{Value::of_ref(layer),Value::of_ref(map)});
            field(layer,"a","Lp;")=Value::of_ref(picture);field(layer,"b","I")=Value::of_i(n%3==0?96:160+n);field(layer,"c","I")=Value::of_i(64+n%7);
            int flags=array("[S",2);field(layer,"a","[S")=Value::of_ref(flags);VMS_HEAP(g_heap)[layers].elems.set(n,Value::of_ref(layer));
        }
        paint=method(kcls,"a","(Lb;)V");paint_args={Value::of_ref(actor),Value::of_ref(draw)};
    }
    auto reset=[&](){
        std::fill(VMS_HEAP(g_heap)[target].pixels.begin(),VMS_HEAP(g_heap)[target].pixels.end(),uint8_t(0));
        if(weather){
            stat(qcls,"aD","I")=Value::of_i(1);stat(qcls,"aC","I")=Value::of_i(0);
            for(int n=0;n<40;++n){
                VMS_HEAP(g_heap)[particle_arrays[0]].elems.set(n,Value::of_i(n*5+8));
                VMS_HEAP(g_heap)[particle_arrays[1]].elems.set(n,Value::of_i(n*7+5));
                VMS_HEAP(g_heap)[particle_arrays[2]].elems.set(n,Value::of_i(10));
                VMS_HEAP(g_heap)[particle_arrays[3]].elems.set(n,Value::of_i(3));
                VMS_HEAP(g_heap)[particle_arrays[4]].elems.set(n,Value::of_i(n%2));
            }
        }
    };
    // Pause only this harness's game clock so original Random constructors
    // receive exactly the same per-frame seed in both engines/builds.
    speed_sync_clock();VMS_EXEC(g_game_clock_inherited)=true;VMS_EXEC(g_game_clock).start(paint_clock_us(),946684800000LL);VMS_EXEC(g_game_clock).paused=true;
    reset();for(int n=0;n<128;++n){VMS_EXEC(g_game_clock).game_us=946684800000000LL+n*16667;call(paint,paint_args);}gc_collect("effects-warmup");
    VMS_EXEC(g_execution_profile).enabled=profile;for(auto& c:VMS_CL(g_classes))for(auto& m:c.methods)m.cpu_profile={};
    for(unsigned trial=0;trial<trials;++trial){
        reset();VMS_RS(g_drawacc)={};VMS_RS(g_drawacc).on=true;VMS_RS(g_graphics_profile).reset(true);
        const uint64_t fast=VMS_EXEC(g_fast_ops),slow=VMS_EXEC(g_slow_ops),jleaf=VMS_NATIVE(g_native_jit).stats.ops,jreg=g_jit_region_stats.ops,rleaf=readleaf_calls(),gfxjit=g_jitr_gfx_ok;
        const int64_t cpu=j2me_cpu_clock::now_ns();const auto start=std::chrono::steady_clock::now();
        for(unsigned frame=0;frame<frames;++frame){VMS_EXEC(g_game_clock).game_us=946684800000000LL+int64_t(frame)*16667;call(paint,paint_args);gc_collect("effects-frame");}
        const double ms=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count(),cpu_ms=(j2me_cpu_clock::now_ns()-cpu)/1000000.0;
        auto gg=VMS_RS(g_graphics_profile).take_global();
        std::cout<<"EFFECTS trial="<<trial<<" scenario="<<scenario<<" frames="<<frames<<" pixels="<<digest(VMS_HEAP(g_heap)[target].pixels)<<" wall_ms="<<ms<<" cpu_ms="<<cpu_ms<<" fast="<<VMS_EXEC(g_fast_ops)-fast<<" slow="<<VMS_EXEC(g_slow_ops)-slow<<" jitleaf="<<VMS_NATIVE(g_native_jit).stats.ops-jleaf<<" jitregion="<<g_jit_region_stats.ops-jreg<<" readleaf="<<readleaf_calls()-rleaf<<" gfxjit="<<g_jitr_gfx_ok-gfxjit<<" lines="<<VMS_RS(g_drawacc).lines<<" images="<<VMS_RS(g_drawacc).images<<" clips="<<VMS_RS(g_drawacc).clips<<" gfx_calls="<<gg.native_calls<<" sampled="<<gg.sampled_calls<<" sampled_native_ns="<<gg.native_ns<<" offscreen_calls="<<gg.offscreen_calls<<'\n';
    }
    if(profile)profile_report();
    check(g_gc_sp.violations==0,"GC safepoints preserved");check(jit236::active_code_calls()==0,"no live JIT activation");
    std::cout<<"PROVENANCE jar_sha256="<<jar_hash<<" original_methods=1 original_random=1 fixed_virtual_clock=1 constructed_heap=1 q_resource_constructor_skipped=1 natural_scene=0 desktop_not_switch=1\n";
    VMS_NATIVE(g_native_jit).clear();jit_region_reset();std::cout<<"PASS effects-probe checks="<<checks<<'\n';
}
