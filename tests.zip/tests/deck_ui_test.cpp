#ifdef _WIN32
// UI-only harness never calls the game deletion helper.
#define lstat stat
#endif
#include "font8x8_basic.h"
#include "platform/deck_ui.h"
#include <fstream>
#include <iostream>
#include <iterator>
static void ppm(const std::string& name,const std::vector<uint32_t>& p){
    std::ofstream f(name,std::ios::binary);f<<"P6\n1280 720\n255\n";
    for(uint32_t c:p){char b[]={char(c),char(c>>8),char(c>>16)};f.write(b,3);}
}
int main(int argc,char** argv){
    const std::string output=argc>1?argv[1]:".";
    deck_ui::UI ui;ui.load_fonts();if(!ui.font.ready())return 29;
    std::ifstream f("romfs/font/cjk16.bin",std::ios::binary);
    std::vector<uint8_t> raw((std::istreambuf_iterator<char>(f)),{});
    ui.cjk=[&](int cp)->const uint8_t*{
        for(size_t i=4;i+34<=raw.size();i+=34)if((raw[i]|(raw[i+1]<<8))==cp)return raw.data()+i+2;
        return nullptr;
    };
    ui.settings.bezel=3;
    ui.menu({"帝国时代 III.jar","3D QBlast.jar","测试游戏.jar"},0,"游戏已暂停，X 继续；A 启动选中的游戏",60,true,0);
    ppm(output+"/menu-v2.ppm",ui.pixels);
    std::vector<uint8_t> fb(240*320*3);for(int y=0;y<320;++y)for(int x=0;x<240;++x){size_t i=(y*240+x)*3;fb[i]=uint8_t(x);fb[i+1]=uint8_t(y);fb[i+2]=70;}
    for(int b=1;b<=6;++b){
        ui.settings.bezel=b;ui.game(fb.data(),240,320,"59");
        if(!ui.skin.data())return 10+b;
        if(b==3)ppm(output+"/phone-v2.ppm",ui.pixels);
        if(b==4)ppm(output+"/controller-v2.ppm",ui.pixels);
        if(ui.pixels[40*1280+400]!=(0xff000000u|70u<<16))return 20;
    }
    ui.settings.bezel=0;ui.game(fb.data(),240,320,"1");
    if(ui.pixels[300*1280+200]!=0xff000000u)return 21;
    for(int filter=0;filter<display_filter::count;++filter){ui.settings.filter=display_filter::Filter(filter);ui.game(fb.data(),240,320,"30");}
    int px=0,py=0;
    if(!deck_ui::UI::point(1280,800,1120,90,px,py)||!deck_ui::UI::menu_hit(px,py))return 27;
    if(deck_ui::UI::point(1280,800,640,20,px,py))return 28;
    if(!deck_ui::UI::close_hit(1160,50)||!deck_ui::UI::library_settings_hit(1000,50))return 30;
    ui.settings.bezel=3;ui.settings.filter=display_filter::Filter::Original;ui.game(fb.data(),240,320,"59");
    ui.pause_menu(1);ppm(output+"/pause-v2.ppm",ui.pixels);
    ui.game(fb.data(),240,320,"59");ui.pause_menu(2,"即时存档已保存，可关闭程序后用 X 继续");ppm(output+"/instant-v37.ppm",ui.pixels);
    ui.menu({"帝国时代 III.jar","3D QBlast.jar","测试游戏.jar"},0,"读取到 3 个 JAR",60,false,0,{1,0,1});ppm(output+"/saved-library-v37.ppm",ui.pixels);
    ui.settings_menu(4,60,true,"设置已保存");ppm(output+"/settings-v3.ppm",ui.pixels);
    deck_keymap::Editor editor;editor.begin(deck_keymap::Config{});editor.selected=2;
    ui.keymap_menu(editor,"");ppm(output+"/keymap-v3.ppm",ui.pixels);
    editor.menu();ui.keymap_menu(editor,"");ppm(output+"/capture-v3.ppm",ui.pixels);
    editor.capture(deck_keymap::DUp);editor.release(deck_keymap::DUp);ui.keymap_menu(editor,"");ppm(output+"/review-v3.ppm",ui.pixels);
    deck_games::Browser browser;browser.folder=std::filesystem::u8path("/home/deck/Desktop/java/PiJava-Deck/games");browser.items={ {std::filesystem::u8path("/home/deck/Desktop/java/PiJava-Deck"),true,false},{std::filesystem::u8path("/home/deck/Desktop/java/PiJava-Deck/games/帝国时代.jar"),false,true} };
    ui.folder_menu(browser);ppm(output+"/folder-v3.ppm",ui.pixels);
    const auto original=ui.settings;
    if(!host_menu::save_settings(output+"/ui-test.cfg",original))return 23;
    host_menu::Settings loaded;if(!host_menu::load_settings(output+"/ui-test.cfg",loaded)||loaded.bezel!=original.bezel||loaded.filter!=original.filter||loaded.show_fps!=original.show_fps)return 24;
    ui.settings.bezel=0;ui.focus=host_menu::Focus::Bezel;ui.change(1);if(ui.settings.bezel!=4)return 25;
    ui.change(-1);if(ui.settings.bezel!=0)return 26;
    std::cout<<"PASS: six real skins, no-bezel, six filters, phone capture editor, menu, settings roundtrip\n";
}
