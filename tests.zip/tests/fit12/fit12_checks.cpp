#define main emulator_main
#include "../../src/j2mevm.cpp"
#undef main

// Native input goes through dispatch_key, including its normal Java execution
// and repaint path. VM field inspection is read-only and adds no product fields.
static int fixture;
struct Assertion { std::string id; int actual, expected; };
static std::vector<Assertion> assertions;
static std::map<std::string,int> data;
static void hard(bool ok,const char* reason) {
    if (!ok) { std::cerr << "HARNESS_ERROR " << reason << "\n"; std::exit(2); }
}
static int field(const char* name) {
    Field* f=find_field(fixture,name,"I"); hard(f,"fixture field");
    return VMS_CL(g_classes)[fixture].statics[f->slot].i;
}
static int formField(const char* name) {
    Field* ref=find_field(fixture,"form","Ljavax/microedition/lcdui/Form;"); hard(ref,"form reference");
    int form=VMS_CL(g_classes)[fixture].statics[ref->slot].ref;
    Field* f=find_field(ensure_class("javax/microedition/lcdui/Form"),name,"I"); hard(f&&form,"Form field");
    return VMS_HEAP(g_heap)[form].fields[f->slot].i;
}
static void call(const char* name) {
    Method* m=find_method(fixture,name,"()V",false); hard(m,"fixture method");
    run(m,{}); hard(!VMS_EXEC(g_thrown),"uncaught Java exception");
}
static void setup(const char* name) { call(name); display_visibility(); repaint_current(); hard(!VMS_EXEC(g_thrown),"setup repaint exception"); }
static void key(int code,bool release) { dispatch_key(code,release); hard(!VMS_EXEC(g_thrown),"native input Java exception"); }
static void pair(int code) { key(code,false); key(code,true); }
static void expect(const char* id,int actual,int expected) { assertions.push_back({id,actual,expected}); }
static bool hasBottomStripe() {
    for(int y=44;y<288;y++) for(int x=12;x<112;x++) {
        size_t i=(size_t(y)*240+x)*3;
        if(VMS_RS(g_fb)[i]==0xED&&VMS_RS(g_fb)[i+1]==0x31&&VMS_RS(g_fb)[i+2]==0x75)return true;
    }
    return false;
}
int main(int argc,char**argv) {
    hard(argc==4,"arguments: classes api case");
    VMS_CL(g_classpath)={argv[1],argv[2]}; VMS_DIAG(g_log_draw)=false;
    VMS_RS(g_screen_w)=240; VMS_RS(g_screen_h)=320; VMS_RS(g_fb).assign(240*320*3,0);
    fixture=ensure_class("Fit12Checks"); hard(fixture>=0,"fixture class");
    std::string mode=argv[3];
    if(mode=="scroll") {
        setup("tall"); expect("initial_top",formField("top"),0);
        for(int i=0;i<5;i++)pair(-2);
        data["down_top"]=formField("top"); data["viewport"]=242;
        expect("tall_bottom_reached",formField("top")+242>=600,1);
        expect("tall_bottom_pixels",hasBottomStripe(),1);
        expect("tall_focus_retained",formField("focus"),0);
        for(int i=0;i<5;i++)pair(-1);
        expect("up_returns_top",formField("top"),0);
        int presses=field("presses"),releases=field("releases");
        setup("handled"); int traverses=field("traverses");
        pair(-2); expect("handled_traverse_called",field("traverses")-traverses,1);
        expect("handled_keeps_top",formField("top"),0); expect("handled_keeps_focus",formField("focus"),0);
        setup("handledExit"); traverses=field("traverses");
        expect("handled_exit_entry_top",formField("top"),0);
        pair(-2); expect("handled_exit_traverse_called",field("traverses")-traverses,1);
        expect("handled_later_false_exits",formField("focus"),1);
        setup("boundary"); pair(-2); expect("boundary_moves_focus",formField("focus"),1);
        pair(-1); expect("boundary_returns_focus",formField("focus"),0);
        expect("directions_not_raw_press",field("presses")-presses,0);
        expect("directions_not_raw_release",field("releases")-releases,0);
        expect("new_focus_no_direction_release",field("secondReleases"),0);
        setup("belowTall"); expect("below_tall_initial_focus",formField("focus"),1);
        pair(-1); expect("up_entry_focus",formField("focus"),0);
        expect("enter_tall_from_below_bottom",formField("top"),358);
        expect("enter_tall_from_below_pixels",hasBottomStripe(),1);
        pair(-2); expect("tall_bottom_boundary_exits",formField("focus"),1);
        setup("shortRows"); pair(-2); pair(-2);
        expect("two_down_cross_three_short_rows",formField("focus"),2);
        setup("tall"); for(int i=0;i<5;i++)pair(-2);
        call("shrink"); repaint_current(); hard(!VMS_EXEC(g_thrown),"shrink repaint exception");
        expect("shrink_keeps_focus",formField("focus"),0);
        expect("shrink_clamps_top",formField("top"),0);
        expect("shrink_content_visible",hasBottomStripe(),1);
    } else if(mode=="digits") {
        setup("digits"); for(int code=48;code<=57;code++)pair(code);
        data["press_mask"]=field("pressMask"); data["release_mask"]=field("releaseMask");
        expect("all_digit_presses",field("pressMask"),1023); expect("all_digit_releases",field("releaseMask"),1023);
        expect("digit_press_once",field("presses"),10); expect("digit_release_once",field("releases"),10);
        expect("digits_no_commands",field("commands"),0);
        int p=field("presses"),r=field("releases");
        for(int code=-1;code>=-4;code--)pair(code);
        expect("directions_not_raw_press",field("presses")-p,0); expect("directions_not_raw_release",field("releases")-r,0);
        call("command"); for(int code=48;code<=57;code++)pair(code);
        expect("digits_with_default_command_no_activation",field("commands"),0);
        expect("digits_with_default_command_raw_press",field("presses")-p,10);
        expect("digits_with_default_command_raw_release",field("releases")-r,10);
        p=field("presses"); int commands=field("commands"); pair(-5);
        expect("physical_fire_activates_command",field("commands")-commands,1);
        expect("physical_fire_not_raw_press",field("presses")-p,0);
    } else if(mode=="registry") {
        call("registry");
        for(const char* name:{"added","removed","addedAgain","removedAgain","roots","callbacks"}) {
            data[name]=field(name); expect(name,field(name),0);
        }
        expect("null_listener_errors",field("nullErrors"),2); expect("file_backend_rejected",field("fileRejected"),1);
    } else if(mode=="sensor") {
        call("sensor"); data["malformed_rejected"]=field("malformed"); data["malformed_total"]=field("malformedCount");
        expect("literal_whitespace_rejected",field("malformed"),field("malformedCount"));
        expect("valid_custom_quantities",field("validCustom"),6); expect("dual_argument_wildcards",field("wildcards"),4);
        expect("null_sensor_url",field("sensorNull"),1);
    } else hard(false,"unknown case");
    int failures=0;
    std::cout<<"FIT12_RESULT {\"case\":\""<<mode<<"\",\"data\":{";
    bool comma=false;for(const auto& item:data){if(comma)std::cout<<",";comma=true;std::cout<<"\""<<item.first<<"\":"<<item.second;}
    std::cout<<"},\"assertions\":[";
    comma=false;for(const auto& a:assertions){bool passed=a.actual==a.expected;if(!passed)failures++;if(comma)std::cout<<",";comma=true;
        std::cout<<"{\"id\":\""<<a.id<<"\",\"actual\":"<<a.actual<<",\"expected\":"<<a.expected<<",\"passed\":"<<(passed?"true":"false")<<"}";}
    std::cout<<"],\"failures\":"<<failures<<"}\n";
    return failures?1:0;
}
