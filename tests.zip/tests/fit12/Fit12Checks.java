import javax.microedition.lcdui.*;
import javax.microedition.io.*;
import javax.microedition.io.file.*;
import javax.microedition.sensor.*;

/** Fixtures are compiled by javac, but executed exclusively by the actual VM. */
public final class Fit12Checks {
    public static Form form;
    static Display display;
    static Raw first, second;
    public static int pressMask, releaseMask, presses, releases, secondReleases;
    public static int commands, traverses, outs, callbacks;
    public static int added, removed, addedAgain, removedAgain, nullErrors, roots, fileRejected;
    public static int malformed, malformedCount, validCustom, wildcards, sensorNull;

    static class Raw extends CustomItem {
        int height;
        final boolean other;
        Raw(int h, boolean second) { super(null); height = h; other = second; }
        protected int getMinContentWidth() { return 20; }
        protected int getMinContentHeight() { return 20; }
        protected int getPrefContentWidth(int h) { return 100; }
        protected int getPrefContentHeight(int w) { return height; }
        protected void paint(Graphics g, int w, int h) {
            g.setColor(0x2375A1); g.fillRect(0, 0, w, h);
            g.setColor(0xED3175); g.fillRect(0, h - 8, w, 8);
        }
        protected void keyPressed(int key) {
            presses++;
            if (key >= 48 && key <= 57) pressMask |= 1 << (key - 48);
        }
        protected void keyReleased(int key) {
            if (other) secondReleases++;
            else { releases++; if (key >= 48 && key <= 57) releaseMask |= 1 << (key - 48); }
        }
        protected void traverseOut() { outs++; }
        void resize(int h) { height = h; invalidate(); }
        // Deliberately no traverse override: the tall regression uses default false.
    }
    static final class Handled extends Raw {
        Handled() { super(600, false); }
        protected boolean traverse(int dir, int w, int h, int[] rect) {
            traverses++; rect[0] = 0; rect[1] = 0; rect[2] = 20; rect[3] = 20;
            return true;
        }
    }
    static final class ExitHandled extends Raw {
        ExitHandled() { super(600, false); }
        protected boolean traverse(int dir, int w, int h, int[] rect) {
            traverses++; rect[0] = 0; rect[1] = 0; rect[2] = 20; rect[3] = 20;
            return dir == NONE;
        }
    }
    static void show(Raw item, boolean withSecond) {
        display = Display.getDisplay(null); form = new Form("Fit12"); first = item;
        form.append(first);
        if (withSecond) { second = new Raw(24, true); form.append(second); }
        display.setCurrentItem(first);
    }
    public static void tall() { show(new Raw(600, false), false); }
    public static void handled() { show(new Handled(), true); }
    public static void handledExit() { show(new ExitHandled(), true); }
    public static void boundary() { show(new Raw(24, false), true); }
    public static void shortRows() { show(new Raw(24, false), true); form.append(new Raw(24, true)); }
    public static void shrink() { first.resize(24); }
    public static void belowTall() { show(new Raw(600, false), true); display.setCurrentItem(second); }
    public static void digits() { show(new Raw(24, false), false); }
    public static void command() {
        first.setDefaultCommand(new Command("activate", Command.ITEM, 1));
        first.setItemCommandListener(new ItemCommandListener() {
            public void commandAction(Command command, Item item) { commands++; }
        });
    }
    public static void registry() throws Exception {
        FileSystemListener listener = new FileSystemListener() {
            public void rootChanged(int state, String rootName) { callbacks++; }
        };
        added = FileSystemRegistry.addFileSystemListener(listener) ? 1 : 0;
        addedAgain = FileSystemRegistry.addFileSystemListener(listener) ? 1 : 0;
        removed = FileSystemRegistry.removeFileSystemListener(listener) ? 1 : 0;
        removedAgain = FileSystemRegistry.removeFileSystemListener(listener) ? 1 : 0;
        try { FileSystemRegistry.addFileSystemListener(null); } catch (NullPointerException e) { nullErrors++; }
        try { FileSystemRegistry.removeFileSystemListener(null); } catch (NullPointerException e) { nullErrors++; }
        roots = FileSystemRegistry.listRoots().hasMoreElements() ? 1 : 0;
        try { Connection c = Connector.open("file:///fit12-no-backend"); c.close(); }
        catch (ConnectionNotFoundException e) { fileRejected = 1; }
    }
    public static void sensor() {
        String[] bad = {"sensor:acceleration bad", "sensor:custom\tquantity", "sensor:custom\nquantity", "sensor:custom\rquantity", "sensor:custom quantity;model=x"};
        malformedCount = bad.length;
        for (int i = 0; i < bad.length; i++) {
            try { SensorManager.findSensors(bad[i]); } catch (IllegalArgumentException e) { malformed++; }
        }
        String[] valid = {"sensor:acceleration", "sensor:custom-quantity", "sensor:custom_quantity", "sensor:custom.quantity", "sensor:custom%20quantity", "sensor:custom-quantity;contextType=user;model=x;location=phone"};
        for (int i = 0; i < valid.length; i++) if (SensorManager.findSensors(valid[i]).length == 0) validCustom++;
        if (SensorManager.findSensors(null, null).length == 0) wildcards++;
        if (SensorManager.findSensors("", null).length == 0) wildcards++;
        if (SensorManager.findSensors("custom quantity", null).length == 0) wildcards++;
        if (SensorManager.findSensors(null, SensorInfo.CONTEXT_TYPE_USER).length == 0) wildcards++;
        try { SensorManager.findSensors((String)null); } catch (NullPointerException e) { sensorNull++; }
    }
}
