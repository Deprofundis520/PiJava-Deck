#include "platform/deck_navigation.h"
#include <iostream>
using namespace deck_navigation;
#define CHECK(x) do {if(!(x)){std::cerr<<"Failed at line "<<__LINE__<<"\n";return 1;}}while(0)
int main(){
    State n;CHECK(n.input(Input::Close)==Effect::Quit);
    n.input(Input::Menu);CHECK(n.screen==Screen::Settings&&!n.active);
    CHECK(n.input(Input::Right)==Effect::ValueNext);
    n.input(Input::Down);CHECK(n.option==1);
    n.input(Input::Back);CHECK(n.screen==Screen::Library);
    n.launched();n.input(Input::Menu);CHECK(n.screen==Screen::Pause&&n.frozen());
    n.input(Input::Down);CHECK(n.pause_selection==1);
    n.input(Input::Confirm);CHECK(n.screen==Screen::Settings&&n.settings_return==Screen::Pause&&n.frozen());
    CHECK(n.input(Input::Left)==Effect::ValuePrevious);
    n.input(Input::Back);CHECK(n.screen==Screen::Pause&&n.frozen());
    n.input(Input::Back);CHECK(n.screen==Screen::Game&&!n.frozen());
    n.input(Input::View);CHECK(n.screen==Screen::Library&&n.active&&n.frozen());
    n.input(Input::Menu);CHECK(n.screen==Screen::Settings&&n.settings_return==Screen::Library);
    n.input(Input::Menu);CHECK(n.screen==Screen::Library);
    CHECK(n.input(Input::Resume)==Effect::RestoreInstant);n.launched();CHECK(n.screen==Screen::Game);
    n.input(Input::Menu);for(int i=0;i<4;++i)n.input(Input::Down);n.input(Input::Confirm);CHECK(n.screen==Screen::Library&&n.active);
    n.launched();n.input(Input::Menu);n.input(Input::Up);CHECK(n.pause_selection==7);CHECK(n.input(Input::Confirm)==Effect::OpenMemory);n.input(Input::Up);CHECK(n.pause_selection==6);CHECK(n.input(Input::Confirm)==Effect::OpenText);n.input(Input::Up);CHECK(n.pause_selection==5);
    CHECK(n.input(Input::Confirm)==Effect::Stop);n.stopped();CHECK(!n.active&&n.screen==Screen::Library);
    CHECK(n.input(Input::Back)==Effect::Quit);
    n.input(Input::Right);CHECK(n.screen==Screen::Settings);
    n.input(Input::Up);CHECK(n.option==10);CHECK(n.input(Input::Confirm)==Effect::ValueNext);for(int i=0;i<6;++i)n.input(Input::Up);CHECK(n.option==4);
    CHECK(n.input(Input::Confirm)==Effect::OpenKeymap);
    CHECK(n.screen==Screen::Keymap);
    CHECK(n.input(Input::Menu)==Effect::CaptureKeymap);
    CHECK(n.input(Input::View)==Effect::SaveKeymap);
    CHECK(n.input(Input::Confirm)==Effect::ConfirmKeymap);
    CHECK(n.input(Input::Back)==Effect::BackKeymap);n.screen=Screen::Settings;
    n.stopped();CHECK(n.input(Input::OpenGames)==Effect::OpenFolderBrowser&&n.screen==Screen::Folders);
    CHECK(n.input(Input::Down)==Effect::SelectNext);CHECK(n.input(Input::Confirm)==Effect::EnterFolder);CHECK(n.input(Input::Save)==Effect::UseFolder);
    n.input(Input::Back);CHECK(n.screen==Screen::Library);
    n.launched();n.input(Input::View);n.input(Input::OpenGames);CHECK(n.frozen());n.input(Input::Back);CHECK(n.screen==Screen::Library&&n.frozen());CHECK(n.input(Input::Resume)==Effect::RestoreInstant);n.launched();CHECK(n.screen==Screen::Game&&!n.frozen());
    n.launched();n.input(Input::Menu);n.input(Input::Down);n.input(Input::Down);
    CHECK(n.input(Input::Confirm)==Effect::SaveInstant&&n.screen==Screen::Pause&&n.frozen());
    n.input(Input::Down);CHECK(n.input(Input::Confirm)==Effect::RestoreInstant&&n.frozen());
    n.stopped();CHECK(n.input(Input::Resume)==Effect::RestoreInstant&&!n.active);
    std::cout<<"PASS: library menu key, game pause -> display settings, back/resume, view key, stop, settings values\n";
}
