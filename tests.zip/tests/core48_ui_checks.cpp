#define main emulator_main
#include "../src/j2mevm.cpp"
#undef main
#include "../src/host_menu.h"
#include "../src/host_speed.h"
static host_menu::Settings g_menu_settings;
static std::string instant_state_path(const std::string&) { return "build/core48-ui/state.bin"; }
#include "../src/instant_state.inc"
static void check(bool b,const char* s){if(!b){std::cerr<<"FAIL "<<s<<"\n";std::exit(1);}}
static int cls;static int field(const char* n){return VMS_CL(g_classes)[cls].statics[find_field(cls,n,"I")->slot].i;}
static Value call(const char* n,const char* sig="()V"){Method* m=find_method(cls,n,sig,false);check(m,"fixture method");auto v=run(m,{});check(!VMS_EXEC(g_thrown),"Java assertion/exception");return v;}
static int rgb(int x,int y){auto p=(size_t(y)*VMS_RS(g_screen_w)+x)*3;auto& f=VMS_RS(g_fb);return (f[p]<<16)|(f[p+1]<<8)|f[p+2];}
int main(int argc,char**argv){
 check(argc==4 || argc==5,"arguments");VMS_CL(g_classpath)={argv[1],argv[2]};VMS_DIAG(g_log_draw)=false;VMS_RS(g_screen_w)=240;VMS_RS(g_screen_h)=320;VMS_RS(g_fb).assign(240*320*3,0);
 std::string mode=argv[3];
 if(mode=="legacy-string-write"||mode=="legacy-form-write"||mode=="legacy-string-read"||mode=="legacy-form-read") {
  check(argc==5,"legacy state file");int c=ensure_class("Core48UiLegacyChecks");bool strings=mode.find("string")!=std::string::npos;
  check(run(find_method(c,"setup","(I)I",false),{Value::of_i(strings?1:0)}).i==1,"legacy fixture setup");display_visibility();repaint_current();
  VMS_EXEC(g_midlet)=alloc_obj(ensure_class("java/lang/Object"));VMS_EXEC(g_midlet_state)=MidletState::Active;
  if(mode.find("write")!=std::string::npos){SavState s;std::string bytes;check(capture_state(s,"core48-ui-legacy.jar")&&encode_state(s,bytes),"baseline snapshot captured");std::ofstream f(argv[4],std::ios::binary);f.write(bytes.data(),bytes.size());check(bool(f),"snapshot written");write_png(std::string(argv[4])+".png",VMS_RS(g_fb),240,320);}
  else{std::ifstream f(argv[4],std::ios::binary);std::string bytes(std::istreambuf_iterator<char>(f),{});SavState s;check(decode_state(bytes,s),"actual baseline snapshot decoded");int current=VMS_RS(g_current);auto pixels=VMS_RS(g_fb);size_t heap=VMS_HEAP(g_heap).size();bool accepted=apply_state(s);check(accepted!=strings,"StringItem old schema rejected, unchanged Form/Item schema accepted");if(strings)check(current==VMS_RS(g_current)&&pixels==VMS_RS(g_fb)&&heap==VMS_HEAP(g_heap).size(),"rejected old StringItem state preserves live heap/pixels");write_png(std::string(argv[4])+".candidate.png",VMS_RS(g_fb),240,320);}
  std::cout<<"PASS Core48Ui "<<mode<<" pixels="<<crc32(VMS_RS(g_fb).data(),VMS_RS(g_fb).size())<<"\n";return 0;
 }

 if(mode=="focus")check(find_method(ensure_class("javax/microedition/lcdui/Display"),"setCurrentItem","(Ljavax/microedition/lcdui/Item;)V",false),"Display.setCurrentItem missing");
 if(mode=="strings")check(find_method(ensure_class("javax/microedition/lcdui/StringItem"),"<init>","(Ljava/lang/String;Ljava/lang/String;I)V",false),"StringItem appearance constructor missing");
 if(mode=="custom")check(load_class_file("javax/microedition/lcdui/CustomItem",false)>=0,"CustomItem class missing");
 cls=ensure_class("Core48UiChecks");check(call(mode=="lifecycle"?"custom":mode.c_str(),"()I").i==1,"Java API contracts");display_visibility();repaint_current();
 write_png("build/core48-ui/"+mode+"-initial.png",VMS_RS(g_fb),240,320);
 if(mode=="edge"){
  check(field("edgeShows")==1&&field("edgePaints")==1,"edge item initially visible and painted");
  call("edgeScroll");repaint_current();
  check(field("edgeHiddenPaints")==0,"scrolled content must not paint after hideNotify");
  check(field("edgeHides")==1&&field("edgePaints")==1,"spacing-only row intersection causes hide without content paint");
 }
 if(mode=="focus"){check(rgb(8,260)==0x1E3A34,"requested last row scrolled visible");}
 if(mode=="strings"){auto large=VMS_RS(g_fb);int f=VMS_CL(g_classes)[cls].statics[find_field(cls,"string","Ljavax/microedition/lcdui/StringItem;")->slot].ref;Method* m=find_method(VMS_HEAP(g_heap)[f].cls,"setFont","(Ljavax/microedition/lcdui/Font;)V",true);run(m,{Value::of_ref(f),Value::of_ref(0)});repaint_current();check(large!=VMS_RS(g_fb),"StringItem font changes actual rendered pixels");}
 if(mode=="custom"){
 check(field("paints")==2&&field("sizes")==2&&field("shows")==2&&field("traverses")>=1,"show size paint traversal lifecycle");check(rgb(12,64)==0xD03070&&rgb(11,64)!=0xD03070&&rgb(82,64)!=0xD03070,"custom rendered content cannot escape bounds");
 int t=field("traverses");dispatch_key(-2,false);check(field("traverses")==t+1&&field("outs")==0,"internal traversal retained");dispatch_key(-2,false);check(field("outs")==1,"edge traversal exits to next item");
 dispatch_key(53,false);dispatch_key(53,true);check(field("presses")==1&&field("releases")==1,"actual dispatch press/release callbacks");
 call("focusSecond");call("invalidateProbe");repaint_current();check(field("sizes")==3,"invalidate reruns layout and size callback");call("repaintProbe");check(VMS_RS(g_repaint),"custom repaint schedules paint");repaint_current();
 call("hide");display_visibility();check(field("hides")==2&&field("outs")==2,"screen hide delivers lifecycle");
 }
 if(mode=="lifecycle"){
 VMS_EXEC(g_midlet)=alloc_obj(ensure_class("java/lang/Object"));VMS_EXEC(g_midlet_state)=MidletState::Active;
 SavState captured,decoded;std::string bytes;check(capture_state(captured,"core48-ui-custom.jar")&&encode_state(captured,bytes)&&bytes.substr(0,4)=="J2S5"&&decode_state(bytes,decoded)&&apply_state(decoded),"CustomItem existing J2S5 image/lifecycle state roundtrip");
 cls=ensure_class("Core48UiChecks");
 int show=field("shows"),traverse=field("traverses");call("focusProbe");display_visibility();repaint_current();check(field("shows")==show&&field("traverses")==traverse,"same item focus does not duplicate callbacks");
 int probe=VMS_CL(g_classes)[cls].statics[find_field(cls,"probe","LCore48UiChecks$Probe;")->slot].ref;
 Field* buffer=find_field(ensure_class("javax/microedition/lcdui/CustomItem"),"buffer","Ljavax/microedition/lcdui/Image;");check(buffer,"cached render surface field");int image=VMS_HEAP(g_heap)[probe].fields[buffer->slot].ref;
 gc_collect("custom item cached surface");call("repaintProbe");repaint_current();check(image&&VMS_HEAP(g_heap)[probe].fields[buffer->slot].ref==image,"custom surface retained by item across repaint/GC");
 dispatch_key(-2,false);dispatch_key(-2,true);check(field("releases")==0&&field("presses")==0,"traversal keys not delivered as raw key callbacks");
 call("remove");check(field("hides")==1&&field("outs")==1,"detach focused item hides and leaves exactly once");repaint_current();check(field("hides")==1&&field("outs")==1,"deleted item receives no duplicate callbacks");
 call("reparent");display_visibility();repaint_current();check(field("shows")==3&&field("hides")==2,"detached custom item can join another form");
 call("tall");repaint_current();int before=field("traverses");dispatch_key(-2,false);check(field("traverses")==before+1,"tall item internal traversal");check(rgb(12,260)==0xD03070&&rgb(12,30)!=0xD03070,"tall custom content scrolls within viewport");
 call("replace");check(field("hides")==3&&field("outs")==3,"replacement detaches custom item");call("clearReattach");repaint_current();check(field("shows")==4,"clear/reappend custom item visible again");
 }
 std::cout<<"PASS Core48Ui "<<mode<<" actual VM contracts/pixels/callbacks\n";
}
