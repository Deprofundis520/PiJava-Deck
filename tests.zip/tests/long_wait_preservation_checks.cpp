#define main emulator_main
#ifndef J2ME_TEST_VM
#define J2ME_TEST_VM "../src/j2mevm.cpp"
#endif
#include J2ME_TEST_VM
#undef main
#include <iostream>

// Characterize the safety boundary exposed by Shanhai's event-driven extra
// 83ms delay. A completed drawing alone cannot certify a long frame sleep.
static int checks=0;
static void check(bool ok,const char* message) {
    ++checks;
    if(!ok){std::cerr<<"FAIL "<<message<<"\n";std::exit(1);}
}
int main() {
    VMS_CL(g_classpath)={"romfs/classes"};VMS_DIAG(g_log_draw)=false;
    VMS_EXEC(g_midlet_state)=MidletState::Active;
    Method* sleep=find_method(ensure_class("java/lang/Thread"),"sleep","(J)V",false);
    check(sleep!=nullptr,"Thread.sleep fixture resolves");
    for(int cap:{0,30,60})for(bool drawn:{false,true})for(int request:{83,147,148,149,150,151,152,153,166,500}) {
        VMS_EXEC(g_running_thread)=nullptr;speed_reset_learning();VMS_EXEC(g_threads).clear();
        VMS_EXEC(g_speed_next_us)=0;VMS_EXEC(g_speed_cap)=cap;speed_sync_clock();
        VMS_EXEC(g_threads).emplace_back();auto& thread=VMS_EXEC(g_threads).back();
        VMS_EXEC(g_running_thread)=&thread;VMS_EXEC(g_can_suspend)=true;
        if(drawn)speed_note_paint(paint_clock_us(),&thread);
        Frame frame;frame.method=sleep;frame.locals={Value::of_l(request)};
        const auto before=monotonic_ms();thread_native(sleep,frame);const auto after=monotonic_ms();
        const bool paced=cap&&drawn&&request==83;
        check(thread.state==ThreadState::Sleeping,"positive sleep suspends its caller");
        check(thread.sleep_paced==paced,"only ordinary owned frame wait is paced");
        check(thread.frame_due_us==0,"sleep consumes or discards the earned deadline");
        if(paced) {
            check(thread.wake_us>0,"ordinary frame wait retains cap deadline");
            check(thread.wake-before<request,"ordinary frame wait still accelerates");
        } else {
            check(thread.wake_us==0,"deliberate or unowned wait has no cap deadline");
            check(thread.wake>=before+request&&thread.wake<=after+request,
                  "deliberate or unowned wait retains its Java duration");
        }
        check(VMS_EXEC(g_game_clock).scale==1.0,"frame ownership alone never scales Java time");
    }
    VMS_EXEC(g_running_thread)=nullptr;speed_reset_learning();VMS_EXEC(g_threads).clear();
    std::cout<<"LongWaitPreservation checks="<<checks<<" PASS\n";
}
