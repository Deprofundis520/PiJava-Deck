#include "../src/chapter_save.h"
#include <cassert>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <set>
namespace fs=std::filesystem;
static int rename_fail=0;static bool nonreplace=false,write_fail=false;
extern "C" int __real_rename(const char*,const char*);
extern "C" int __wrap_rename(const char* a,const char* b){
 if(rename_fail>0 && --rename_fail==0){errno=EIO;return -1;}
 if(nonreplace&&fs::exists(b)){errno=EEXIST;return -1;}
 return __real_rename(a,b);
}
extern "C" size_t __real_fwrite(const void*,size_t,size_t,FILE*);
extern "C" size_t __wrap_fwrite(const void* p,size_t s,size_t n,FILE* f){if(write_fail){errno=ENOSPC;return 0;}return __real_fwrite(p,s,n,f);}
static std::string read(const std::string& p){std::ifstream in(p,std::ios::binary);return {std::istreambuf_iterator<char>(in),{}};}
static void put(const std::string& p,const std::string& s){fs::create_directories(fs::path(p).parent_path());std::ofstream(p,std::ios::binary)<<s;}
static std::string snap(char c){return std::string("\0\0\0\1",4)+c;}
int main(int argc,char** argv){
 assert(argc==3);const std::string root=argv[1],a(64,'a'),b(64,'b'),c(64,'c');nonreplace=std::string(argv[2])=="nonreplace";
 const std::string sa=root+"/suites/"+a,sb=root+"/suites/"+b;
 std::string err;assert(chapter_save::recover(root,b,err));
 put(sa+"/r53617665.bin",snap('A'));put(sa+"/r58.bin.previous",snap('X'));put(sa+"/r58.bin.tmp","ignored");
 put(sb+"/r53617665.bin",snap('B'));put(sb+"/r546172676574.bin",snap('T'));put(sb+"/note.txt","preserve unknown files");
 put(root+"/../state/game.jar.sav","instant snapshot");put(root+"/../keymap.cfg","mapping");
 const auto before=read(sa+"/r53617665.bin");auto r=chapter_save::import_stores(root,a,b);
 assert(r.ok&&r.stores==2&&!r.backup.empty());assert(read(sb+"/r53617665.bin")==snap('A'));assert(read(sb+"/r58.bin")==snap('X'));
 assert(!fs::exists(sb+"/r546172676574.bin"));assert(read(r.backup+"/r546172676574.bin")==snap('T'));assert(read(r.backup+"/note.txt")=="preserve unknown files");
 assert(read(sa+"/r53617665.bin")==before&&fs::exists(sa+"/r58.bin.previous")&&read(sa+"/r58.bin.tmp")=="ignored");
 assert(read(root+"/../state/game.jar.sav")=="instant snapshot"&&read(root+"/../keymap.cfg")=="mapping");
 auto second=chapter_save::import_stores(root,a,b);assert(second.ok&&second.backup!=r.backup&&fs::exists(r.backup));
 assert(!chapter_save::import_stores(root,a,a).ok);assert(!chapter_save::import_stores(root,"../escape",b).ok);assert(!chapter_save::import_stores(root,c,b).ok);
 put(sa+"/r426164.bin","corrupt");assert(!chapter_save::import_stores(root,a,b).ok);assert(read(sb+"/r53617665.bin")==snap('A'));fs::remove(sa+"/r426164.bin");
 put(sa+"/r58.bin","bad primary");assert(!chapter_save::import_stores(root,a,b).ok);fs::remove(sa+"/r58.bin");
 fs::create_symlink(sa+"/r53617665.bin",sa+"/r59.bin");assert(!chapter_save::import_stores(root,a,b).ok);fs::remove(sa+"/r59.bin");
 fs::create_directory(sa+"/r59.bin");assert(!chapter_save::import_stores(root,a,b).ok);fs::remove(sa+"/r59.bin");
 // Real partial-write and failed publication paths retain the existing target.
 write_fail=true;assert(!chapter_save::import_stores(root,a,b).ok);write_fail=false;assert(read(sb+"/r53617665.bin")==snap('A'));
 assert(chapter_save::recover(root,b,err));rename_fail=2;assert(!chapter_save::import_stores(root,a,b).ok);rename_fail=0;
 assert(chapter_save::recover(root,b,err));assert(read(sb+"/r53617665.bin")==snap('A'));
 // Archiving is optional for launching intact progress, mandatory before re-import.
 const std::string blocked=root+"/blocked",ba=blocked+"/suites/"+a,bb=blocked+"/suites/"+b;
 put(ba+"/r41.bin",snap('S'));put(bb+"/r41.bin",snap('D'));put(blocked+"/chapter-backups","blocked by file");
 auto retained=chapter_save::import_stores(blocked,a,b);assert(retained.ok&&read(bb+"/r41.bin")==snap('S'));
 assert(read(bb+".chapter-old/r41.bin")==snap('D'));
 assert(chapter_save::recover(blocked,b,err));assert(!chapter_save::import_stores(blocked,a,b).ok);
 fs::remove(blocked+"/chapter-backups");assert(chapter_save::recover(blocked,b,err));
 write_fail=true;assert(!chapter_save::import_stores(blocked,a,b).ok);write_fail=false;
 put(blocked+"/chapter-backups-block","unused");fs::rename(blocked+"/chapter-backups",blocked+"/saved-backups");put(blocked+"/chapter-backups","blocked again");
 assert(chapter_save::recover(blocked,b,err));assert(read(bb+"/r41.bin")==snap('S'));
 assert(!chapter_save::import_stores(blocked,a,b).ok);fs::remove(blocked+"/chapter-backups");
 assert(chapter_save::recover(blocked,b,err));
 rename_fail=3;auto archive_failed=chapter_save::import_stores(blocked,a,b);rename_fail=0;assert(archive_failed.ok&&fs::exists(bb+".chapter-old"));
 rename_fail=1;assert(chapter_save::recover(blocked,b,err));rename_fail=0;assert(read(bb+"/r41.bin")==snap('S'));
 assert(chapter_save::recover(blocked,b,err));
 // Interrupted between target->old and stage->target: old wins on recovery.
 fs::rename(sb,sb+".chapter-old");put(sb+".chapter-new/r53617665.bin",snap('N'));
 assert(chapter_save::recover(root,b,err));assert(read(sb+"/r53617665.bin")==snap('A'));assert(!fs::exists(sb+".chapter-old")&&!fs::exists(sb+".chapter-new"));
 // Published target with unarchived old directory: keep new, archive old.
 put(sb+".chapter-old/r53617665.bin",snap('O'));assert(chapter_save::recover(root,b,err));assert(read(sb+"/r53617665.bin")==snap('A'));
 assert(chapter_save::import_stores(root,a,c).ok);assert(read(root+"/suites/"+c+"/r53617665.bin")==snap('A'));
 fs::remove_all(root+"/suites/"+c);fs::create_symlink(sb,root+"/suites/"+c);assert(!chapter_save::import_stores(root,a,c).ok);fs::remove(root+"/suites/"+c);
 put(root+"/jars/one.jar","same bytes");put(root+"/jars/two.jar","same bytes");assert(chapter_save::jar_identity(root+"/jars/one.jar")==chapter_save::jar_identity(root+"/jars/two.jar"));
 put(root+"/jars/two.jar","other bytes");assert(chapter_save::jar_identity(root+"/jars/one.jar")!=chapter_save::jar_identity(root+"/jars/two.jar"));
 assert(chapter_save::jar_identity(root+"/missing.jar").empty());
 std::cout<<"PASS chapter save: copy, journal precedence, complete unique backups, source immutability, independent files, validation, real write/rename failures, rollback, restart recovery, fresh JAR identity ("<<argv[2]<<")\n";
}
