#ifdef _WIN32
#define lstat stat
#endif
#include "platform/deck_keymap.h"
#include "platform/deck_input.h"
#include <filesystem>
#include <iostream>
#define CHECK(x) do{if(!(x)){std::cerr<<"Phone mapping test line "<<__LINE__<<"\n";return 1;}}while(0)
int main(){
    using namespace deck_keymap;namespace fs=std::filesystem;
    Config defaults;CHECK(valid(defaults));for(int code:editable_codes)CHECK(bindings(defaults,code)!="未绑定");Editor e;e.begin(defaults);
    CHECK(e.phone()==-6&&editable_codes.size()==15);
    e.move(2);CHECK(e.phone()==49);e.menu();CHECK(e.phase==Phase::Capture);
    CHECK(!e.capture(LUp));CHECK(e.phase==Phase::Capture);
    CHECK(e.capture(A)&&e.phase==Phase::Review);CHECK(!e.confirm());
    e.move(1);CHECK(e.phone()==49);e.release(B);CHECK(!e.confirm());
    e.release(A);CHECK(e.confirm());CHECK(e.phase==Phase::Browse&&e.dirty);
    CHECK(e.draft.code(A)==49&&e.draft.code(L1)==0);
    CHECK(e.draft.code(LUp)==-1&&e.draft.code(LDown)==-2&&e.draft.code(LLeft)==-3&&e.draft.code(LRight)==-4);
    e.menu();CHECK(e.capture(DUp));e.release(DUp);CHECK(e.confirm());CHECK(e.draft.code(DUp)==49&&e.draft.code(A)==0);
    const auto file=(fs::temp_directory_path()/"pijava-keymap-test-v2.cfg").string();CHECK(save(file,e.draft));Config restored;CHECK(load(file,restored)&&restored.codes==e.draft.codes);
    e.menu();CHECK(e.capture(B));e.release(B);e.retry();CHECK(e.phase==Phase::Capture&&!e.released);e.menu();CHECK(e.phase==Phase::Browse);
    e.reset();CHECK(e.draft.codes==defaults.codes);
    e.menu();CHECK(e.capture(L3));e.release(L3);CHECK(e.confirm());
    CHECK(bind(e.draft,42,L3)&&e.draft.code(L3)==42);CHECK(!bind(e.draft,49,LUp));
    // Version-1 files retain non-direction bindings and release the old D-pad directions.
    {std::ofstream f(file);f<<"PIJAVA_DECK_KEYMAP 1\n";for(int i=0;i<25;++i)f<<(i==DUp?-1:defaults.codes[size_t(i)])<<' ';}
    CHECK(load(file,restored)&&restored.code(DUp)==0&&restored.code(LUp)==-1&&restored.code(L3)==0);
    const auto before=restored.codes;std::ofstream(file)<<"PIJAVA_DECK_KEYMAP 2\n999\n";CHECK(!load(file,restored)&&restored.codes==before);
    CHECK(right_source(-25000,-25000)==RNW);
    std::cout<<"PASS: phone-first capture, reserved left stick, release-before-confirm, reused binding, save/reload, cancel/reset, legacy migration\n";
}
