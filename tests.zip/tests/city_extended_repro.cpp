#include <cassert>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <sstream>
#define main emulator_main
#include "../src/j2mevm.cpp"
#undef main
#include "host_turn_harness.h"
// Harness only. Includes candidate production VM and shared host work runner.
// Real desktop clocks; no injected Java values, modified JAR, or fake returns.
// T02: gate gameplay keys on observable ca.a:B==5 (post story_1 load), not j.k:Z.
static int field(const char* c,const char* n,const char* d){
 auto it=VMS_CL(g_class_index).find(c);if(it==VMS_CL(g_class_index).end())return -999;
 auto* f=find_field(it->second,n,d);if(!f||!f->is_static)return -999;
 return VMS_CL(g_classes)[f->owner].statics[f->slot].i;
}
static int ac_ref(){
 Value v;if(!city_value("ca",VMS_RS(g_current),"a","Lac;",v))return -1;return v.ref;
}
static int ac_byte(const char* n){
 int ar=ac_ref();if(ar<=0)return -999;Value v;return city_value("ac",ar,n,"B",v)?v.i:-999;
}
static uint64_t fb_checksum(){
 uint64_t h=1469598103934665603ull;
 for(unsigned char b:VMS_RS(g_fb)){h^=b;h*=1099511628211ull;}
 return h;
}
static void snapshot(const char* where,int64_t start){
 std::cout<<"SNAP "<<where<<" ms="<<monotonic_ms()-start<<" ca.a:B="<<field("ca","a","B")
 <<" j.k:Z="<<field("j","k","Z")<<" j.a:Z="<<field("j","a","Z")
 <<" j.a:B="<<field("j","a","B")<<" j.d:B="<<field("j","d","B")
 <<" ac.ref="<<ac_ref()<<" ac.a:B="<<ac_byte("a")<<" ac.b:B="<<ac_byte("b")
 <<" midlet="<<int(VMS_EXEC(g_midlet_state))<<" frozen="<<int(VMS_PLAT(g_host_frozen236))
 <<" draw="<<VMS_DIAG(g_p1).draw_id<<" live="<<VMS_EXEC(g_thread_live)<<" thrown="<<VMS_EXEC(g_thrown)
 <<" text="<<VMS_RS(g_drawacc).textblob<<"\n";
 if(std::strcmp(where,"pre_key")==0){
   for(const auto& t:VMS_EXEC(g_threads)){
     const Frame* f=t.frames.empty()?nullptr:&t.frames.back();
     std::cout<<"PREKEY_WORKER ref="<<t.ref<<" state="<<int(t.state)<<" executing="<<t.executing
       <<" monitor="<<t.monitor<<" join="<<t.join_target<<" frames="<<t.frames.size()
       <<" top="<<(f?VMS_CL(g_classes)[f->method->class_id].name+"."+f->method->name+f->method->desc:"-")
       <<" bci="<<(f?f->op_pc:-1)<<"\n";
   }
   for(const auto& kv:VMS_EXEC(g_monitors))if(kv.second.owner)
     std::cout<<"PREKEY_MONITOR ref="<<kv.first<<" owner_ref="<<kv.second.owner->ref<<" depth="<<kv.second.depth<<"\n";
 }
}
static bool log_contains(const std::string& path,const char* needle){
 std::ifstream in(path);if(!in)return false;std::string line;
 while(std::getline(in,line))if(line.find(needle)!=std::string::npos)return true;return false;
}
struct Phase{
 const char* name;bool entered=false,actioned=false,asserted=false;std::string end_reason;
 void enter(const char* why){entered=true;std::cout<<"PHASE_ENTER name="<<name<<" reason="<<why<<"\n";}
 void action(const char* what,int64_t ms){actioned=true;std::cout<<"PHASE_ACTION name="<<name<<" what="<<what<<" ms="<<ms<<"\n";}
 void pass(const char* why){asserted=true;end_reason=std::string("PASS:")+why;std::cout<<"ASSERT PASS name="<<name<<" "<<why<<"\n";}
 void fail(const char* why){asserted=true;end_reason=std::string("FAIL:")+why;std::cout<<"ASSERT FAIL name="<<name<<" "<<why<<"\n";}
};
int main(int argc,char**argv){
 assert(argc==5);std::cout<<std::unitbuf;VMS_PLAT(g_boot_ms)=now_ms();VMS_DIAG(g_log_draw)=true;
 VMS_PLAT(g_log).open(argv[3]);setenv("J2ME_P1_PROFILE",argv[2],1);configure_runtime_diagnostics();
 VMS_CL(g_classpath)={"romfs/classes"};VMS_RS(g_fb).assign(size_t(VMS_RS(g_screen_w))*VMS_RS(g_screen_h)*3,0);
 std::vector<uint8_t> jar;std::string error;assert(read_whole(argv[1],jar));
 auto id=rms_jar_identity(jar.data(),jar.size());
 assert(id=="563f753243eefeeef25f392f1cb13c22725ad3cdf019a232c6314064cf8897ab");
 assert(unzip(jar,VMS_CL(g_jar_files),error));load_props();assert(manifest_midlet()=="Main");
 int64_t start=monotonic_ms();std::cout<<"BEGIN production_launch\n";
 launch_class("Main",id);snapshot("launch_done",start);
 struct Event{int at,code;bool release;const char* stage;};
 // Relative to the original 12262ms launch-button timestamp in 224756.log.
 // Events 0..10: continue menu -> load confirm (story_1).
 // Events 11..18: gameplay inputs; gated on ca.a:B==5 after real load (NOT j.k:Z).
 std::vector<Event> events={
  {649,53,true,"boot_a_release"},
  {11737,-6,false,"continue_x_press"},{11784,-6,true,"continue_x_release"},
  {15902,53,false,"menu_a1_press"},{15960,53,true,"menu_a1_release"},
  {16558,53,false,"menu_a2_press"},{16613,53,true,"menu_a2_release"},
  {18205,53,false,"final_a_press"},{18260,53,true,"final_a_release"},
  {23000,53,false,"load_confirm_press"},{23100,53,true,"load_confirm_release"},
  {25000,54,false,"gameplay_right_press"},{25500,54,true,"gameplay_right_release"},
  {27000,52,false,"gameplay_left_press"},{27500,52,true,"gameplay_left_release"},
  {29000,53,false,"gameplay_ok_press"},{29100,53,true,"gameplay_ok_release"},
  {30500,54,false,"gameplay_right2_press"},{31000,54,true,"gameplay_right2_release"}
 };
 constexpr unsigned long long kPostContinueDraws=100; unsigned long long draw_at_continue=0;
 size_t e=0;int64_t last_report=-1000,last_present=0;unsigned long long turns=0;
 int duration=std::atoi(argv[4]);
 // P2.1-c3 follow-up: J2ME_REPRO_TIME_SCALE=K stretches the whole script clock K times (sanitizer builds are slower).
 // Unset/1 = original timing (integer division by 1 is exact).
 const int64_t time_scale=[]{const char* v=std::getenv("J2ME_REPRO_TIME_SCALE");int k=v?std::atoi(v):1;return int64_t(k>0?k:1);}();
 auto script_ms=[&](){return (monotonic_ms()-start)/time_scale;};
 bool paused=false,resumed=false,destroyed=false,relaunched=false;
 bool saw_final_a_end=false,saw_gameplay=false,saw_move_response=false;
 bool pause_draw_stopped=false,resume_draw_advanced=false,relaunch_ok=false;
 unsigned long long draw_before_pause=0,draw_during_pause=0,draw_after_resume=0;
 uint64_t fb_before_move=0,fb_after_move=0;
 unsigned long long draw_before_move=0,draw_after_move=0;
 int ac_a_before_move=-999,ac_b_before_move=-999,ac_a_after_move=-999,ac_b_after_move=-999;
 int ac_ref_at_gameplay=-1;
 Phase ph_continue{"continue"},ph_load{"story1_load"},ph_play{"gameplay"},
       ph_move{"move_confirm"},ph_pause{"pause"},ph_resume{"resume"},
       ph_destroy{"destroy"},ph_relaunch{"relaunch"};
 ph_continue.enter("launch_done");
 std::string log_path=argv[3];
 auto gameplay_ready=[&](){return field("ca","a","B")==5;};
 auto fail_deadline=[&](const char* why){
   std::cout<<"ASSERT FAIL deadline "<<why<<" events="<<e<<"/"<<events.size()
     <<" ca.a:B="<<field("ca","a","B")<<" ms="<<monotonic_ms()-start<<"\n";
 };
 while(script_ms()<duration){
   host_lifecycle_poll242();int64_t elapsed=script_ms();
   // Gates: e==9 load-confirm waits for save UI j.k:Z==1; e>=11 waits for gameplay ca.a:B==5.
   bool gate_ok=true;
   if(e==3&&elapsed>=events[e].at){
     // P2.1 FINAL harness fix (b): the first key after the continue screen waits until the game's loading
     // worker is idle (no runnable worker with a Java frame) OR >=kPostContinueDraws frames were drawn since
     // continue_x_release. A host stall then delays the key instead of hitting the loading screen; when the
     // key is late, events 3..10 are shifted by the same delay so their relative spacing is unchanged.
     bool busy=false;for(const auto& t:VMS_EXEC(g_threads))if(int(t.state)==0&&!t.frames.empty())busy=true;
     const bool drawn=VMS_DIAG(g_p1).draw_id>=draw_at_continue+kPostContinueDraws;
     gate_ok=!busy||drawn||elapsed-events[e].at>20000;
     if(gate_ok){
       const int delay=int(elapsed-events[e].at);
       std::cout<<"ACTION post_continue_gate busy="<<busy<<" draws_since_continue="<<(VMS_DIAG(g_p1).draw_id-draw_at_continue)
         <<" delay_ms="<<delay<<"\n";
       if(delay>0)for(size_t k=3;k<=10&&k<events.size();++k)events[k].at+=delay;
     }
   }
   else if(e==9) gate_ok=(field("j","k","Z")==1);
   else if(e>=11) gate_ok=gameplay_ready();
   if(e<events.size()&&elapsed>=events[e].at&&gate_ok){
     auto ev=events[e];
     if(e==11){
       events[e+1].at=int(elapsed)+100;
       std::cout<<"ACTION gameplay_input_gate state_gate=ca.a:B=5 actual_ms="<<elapsed
         <<" ac.ref="<<ac_ref()<<"\n";
       if(!ph_play.entered)ph_play.enter("ca.a:B=5");
       ph_play.action("first_gameplay_key",elapsed);
       saw_gameplay=true;ac_ref_at_gameplay=ac_ref();
       fb_before_move=fb_checksum();draw_before_move=VMS_DIAG(g_p1).draw_id;
       ac_a_before_move=ac_byte("a");ac_b_before_move=ac_byte("b");
       if(!ph_move.entered)ph_move.enter("pre_direction_keys");
     }
     snapshot("pre_key",start);write_png(std::string(argv[3])+"-key"+std::to_string(e)+".png",VMS_RS(g_fb),VMS_RS(g_screen_w),VMS_RS(g_screen_h));
     std::cout<<"KEY_BEGIN event="<<e<<" target_ms="<<ev.at<<" code="<<ev.code<<" release="<<ev.release
       <<" stage="<<ev.stage<<"\n";VMS_PLAT(g_log).flush();
     dispatch_key(ev.code,ev.release);
     if(e==2)draw_at_continue=VMS_DIAG(g_p1).draw_id;
     std::cout<<"KEY_END event="<<e<<"\n";
     if(e==7){saw_final_a_end=true;ph_continue.action("final_a_callback_end",elapsed);ph_continue.pass("final_A_KEY_END");}
     if(e==9){
       if(!ph_load.entered)ph_load.enter("load_confirm_press");
       ph_load.action("load_confirm",elapsed);
       std::cout<<"ACTION load_confirm state_gate=j.k:Z=1 actual_ms="<<elapsed<<"\n";
     }
     if(e==10&&gameplay_ready()){
       ph_load.action("post_load_ca.a:B=5",elapsed);
     }
     if(e==16){ // after gameplay ok release window — sample move response
       fb_after_move=fb_checksum();draw_after_move=VMS_DIAG(g_p1).draw_id;
       ac_a_after_move=ac_byte("a");ac_b_after_move=ac_byte("b");
       ph_move.action("sampled_after_direction_and_ok",elapsed);
     }
     ++e;snapshot("post_key",start);VMS_PLAT(g_log).flush();
     if(e==11&&gameplay_ready()&&ac_ref()>0){
       // Load may complete on press (e==9); confirm release lands in ca.a:B=5.
     }
   }
   // Observe load completion even before gameplay keys.
   if(!ph_load.asserted&&gameplay_ready()&&ac_ref()>0){
     VMS_PLAT(g_log).flush();
     bool marker=log_contains(log_path,"游戏 取挡")||log_contains(log_path,"73746f72795f31")
       ||log_contains(log_path,"deadcrisis_1.0_story_1");
     bool done_len=log_contains(log_path,"取挡完成");
     if(marker&&done_len){
       ph_load.pass("story_1_RMSIO_and_JAVA_markers ca.a:B=5 ac.ref>0");
     }else if(marker){
       ph_load.pass("story_1_marker_and_ca.a:B=5 ac.ref>0");
     }
   }
   if(elapsed>=34000&&!paused){
     if(!saw_gameplay){fail_deadline("pause_without_gameplay_inputs");break;}
     snapshot("before_host_freeze",start);
     draw_before_pause=VMS_DIAG(g_p1).draw_id;
     std::cout<<"ACTION host_freeze true ms="<<elapsed<<"\n";host_freeze236(true);paused=true;
     if(!ph_pause.entered)ph_pause.enter("host_freeze");
     ph_pause.action("freeze_true",elapsed);
     write_png(std::string(argv[3])+"-pause.png",VMS_RS(g_fb),VMS_RS(g_screen_w),VMS_RS(g_screen_h));
   }
   if(paused&&!resumed&&elapsed>=35000&&elapsed<36000){
     draw_during_pause=VMS_DIAG(g_p1).draw_id;
     if(VMS_PLAT(g_host_frozen236)&&draw_during_pause==draw_before_pause)pause_draw_stopped=true;
   }
   if(elapsed>=36000&&!resumed){
     if(!paused){fail_deadline("resume_without_pause");break;}
     draw_during_pause=VMS_DIAG(g_p1).draw_id;
     pause_draw_stopped=VMS_PLAT(g_host_frozen236)&&(draw_during_pause==draw_before_pause);
     if(pause_draw_stopped)ph_pause.pass("frozen_draw_id_stable host_can_poll");
     else ph_pause.fail("draw_advanced_or_not_frozen");
     std::cout<<"ACTION host_freeze false ms="<<elapsed<<"\n";host_freeze236(false);resumed=true;
     if(!ph_resume.entered)ph_resume.enter("host_unfreeze");
     ph_resume.action("freeze_false",elapsed);
     snapshot("after_host_resume",start);
     draw_after_resume=VMS_DIAG(g_p1).draw_id;
   }
   if(resumed&&!ph_resume.asserted&&elapsed>=38000){
     if(VMS_DIAG(g_p1).draw_id>draw_during_pause&&!VMS_PLAT(g_host_frozen236)){
       resume_draw_advanced=true;ph_resume.pass("draw_advanced_after_resume");
     }
   }
   if(elapsed>=42000&&!destroyed){
     if(!resumed){fail_deadline("destroy_without_resume");break;}
     // Finalize move assertion before destroy.
     if(!ph_move.asserted){
       fb_after_move=fb_checksum();draw_after_move=VMS_DIAG(g_p1).draw_id;
       ac_a_after_move=ac_byte("a");ac_b_after_move=ac_byte("b");
       bool fb_changed=fb_after_move!=fb_before_move;
       bool draw_changed=draw_after_move>draw_before_move;
       bool ac_changed=(ac_a_after_move!=ac_a_before_move)||(ac_b_after_move!=ac_b_before_move);
       bool keys_sent=e>=17; // through gameplay_ok at least
       std::cout<<"MOVE_OBSERVE fb_changed="<<fb_changed<<" draw_changed="<<draw_changed
         <<" ac_changed="<<ac_changed<<" keys_sent="<<keys_sent
         <<" draw "<<draw_before_move<<"->"<<draw_after_move
         <<" ac.a "<<ac_a_before_move<<"->"<<ac_a_after_move
         <<" ac.b "<<ac_b_before_move<<"->"<<ac_b_after_move<<"\n";
       if(keys_sent&&(fb_changed||ac_changed)&&(draw_changed||ac_changed)){
         saw_move_response=true;ph_move.pass("direction_or_ok_changed_fb_or_ac_and_progress");
       }else if(keys_sent&&draw_changed&&fb_changed){
         saw_move_response=true;ph_move.pass("direction_keys_changed_framebuffer_and_draw");
       }else{
         ph_move.fail("no_observable_response_after_gameplay_keys");
       }
     }
     if(saw_gameplay&&!ph_play.asserted){
       if(ac_ref_at_gameplay>0&&field("ca","a","B")==5)ph_play.pass("ca.a:B=5_with_ac_instance");
       else ph_play.fail("gameplay_state_unrecognized");
     }
     snapshot("before_destroy",start);write_png(std::string(argv[3])+"-gameplay.png",VMS_RS(g_fb),VMS_RS(g_screen_w),VMS_RS(g_screen_h));
     std::cout<<"ACTION lifecycle_destroy ms="<<elapsed<<"\n";lifecycle_destroy();destroyed=true;
     if(!ph_destroy.entered)ph_destroy.enter("lifecycle_destroy");
     ph_destroy.action("destroy",elapsed);snapshot("after_destroy",start);
     if(VMS_EXEC(g_midlet_state)==MidletState::Destroyed&&!VMS_EXEC(g_thread_live))ph_destroy.pass("midlet_destroyed_live0");
     else if(VMS_EXEC(g_midlet_state)==MidletState::Destroyed)ph_destroy.pass("midlet_destroyed");
     else ph_destroy.fail("midlet_not_destroyed");
   }
   if(elapsed>=42500&&!relaunched){
     if(!destroyed){fail_deadline("relaunch_without_destroy");break;}
     std::cout<<"ACTION production_relaunch Main same_suite same_RMS ms="<<elapsed<<"\n";
     launch_class("Main",id);relaunched=true;
     if(!ph_relaunch.entered)ph_relaunch.enter("same_suite_relaunch");
     ph_relaunch.action("launch_class_Main",elapsed);snapshot("after_relaunch",start);
     if(VMS_EXEC(g_thread_live)&&field("ca","a","B")==1&&VMS_EXEC(g_midlet_state)!=MidletState::Destroyed){
       relaunch_ok=true;ph_relaunch.pass("relaunched_ca.a:B=1_live");
     }else ph_relaunch.fail("relaunch_state_unexpected");
   }
   harness_host_turn(last_present,true); // P2.6 shared scheduler core (J2ME_SCHED_LEGACY=1: old loop)
   ++turns;
   if(elapsed-last_report>=1000){snapshot("host_turn",start);last_report=elapsed;VMS_PLAT(g_log).flush();}
   if(VMS_EXEC(g_midlet_state)==MidletState::Destroyed&&!destroyed)break;
 }
 snapshot("finish",start);write_png(std::string(argv[3])+"-finish.png",VMS_RS(g_fb),VMS_RS(g_screen_w),VMS_RS(g_screen_h));
 // Deadline / completeness hard fails
 if(e<events.size())fail_deadline("not_all_key_events_fired");
 if(!saw_final_a_end){std::cout<<"ASSERT FAIL final_A_callback_end missing\n";ph_continue.fail("no_final_A_KEY_END");}
 if(!ph_load.asserted){
   VMS_PLAT(g_log).flush();
   bool marker=log_contains(log_path,"游戏 取挡")||log_contains(log_path,"73746f72795f31")
     ||log_contains(log_path,"deadcrisis_1.0_story_1");
   if(marker&&gameplay_ready())ph_load.pass("late_scan_story1_and_ca.a:B=5");
   else ph_load.fail("story_1_load_not_proven");
 }
 if(!ph_play.asserted)ph_play.fail("gameplay_phase_incomplete");
 if(!ph_move.asserted)ph_move.fail("move_phase_incomplete");
 if(!ph_pause.asserted)ph_pause.fail("pause_phase_incomplete");
 if(!ph_resume.asserted){
   if(resume_draw_advanced)ph_resume.pass("draw_advanced_after_resume");
   else ph_resume.fail("resume_phase_incomplete");
 }
 if(!ph_destroy.asserted)ph_destroy.fail("destroy_phase_incomplete");
 if(!ph_relaunch.asserted)ph_relaunch.fail("relaunch_phase_incomplete");
 Phase* phases[]={&ph_continue,&ph_load,&ph_play,&ph_move,&ph_pause,&ph_resume,&ph_destroy,&ph_relaunch};
 int fails=0,passes=0;
 for(auto* p:phases){
   std::cout<<"PHASE_SUMMARY name="<<p->name<<" entered="<<p->entered<<" actioned="<<p->actioned
     <<" end="<<p->end_reason<<"\n";
   if(p->end_reason.rfind("PASS:",0)==0)++passes;else ++fails;
 }
 std::cout<<"FINISH turns="<<turns<<" events="<<e<<"/"<<events.size()
   <<" passes="<<passes<<" fails="<<fails
   <<" saw_final_a_end="<<saw_final_a_end<<" saw_gameplay="<<saw_gameplay
   <<" saw_move_response="<<saw_move_response<<" pause_draw_stopped="<<pause_draw_stopped
   <<" resume_draw_advanced="<<resume_draw_advanced<<" relaunch_ok="<<relaunch_ok<<"\n";
 p1_report();lifecycle_destroy();VMS_PLAT(g_log).close();
 if(fails||e<events.size()||!saw_final_a_end||!saw_gameplay){
   std::cout<<"HARNESS_RESULT FAIL\n";return 1;
 }
 std::cout<<"HARNESS_RESULT PASS\n";return 0;
}
