// Actual VM regression and original-JAR fixed-work probe. No game bytecode is
// rewritten and the production implementation has no game-specific predicate.
#define main emulator_main
#ifndef J2ME_TEST_VM
#define J2ME_TEST_VM "../../src/j2mevm.cpp"
#endif
#include J2ME_TEST_VM
#undef main

static unsigned checks=0;
static void check(bool ok,const char* why){++checks;if(!ok){std::cerr<<"FAIL Vector "<<why<<'\n';std::exit(1);}}
static Method* method(int cls,const char* name,const char* desc){auto* m=find_method(cls,name,desc,true);check(m,"fixture method exists");return m;}
static Value invoke(const char* name,const char* desc="()V",std::vector<Value> args={}){
    Value out=run(method(ensure_class("VectorChecks"),name,desc),args);check(!VMS_EXEC(g_thrown)&&!current_context().unhandled,"fixture returns without uncaught exception");return out;
}
static Value stat(const char* name,const char* desc){auto* f=find_field(ensure_class("VectorChecks"),name,desc);check(f&&f->is_static,"fixture static exists");return VMS_CL(g_classes)[f->owner].statics[f->slot];}
static Value& objfield(int ref,const char* name,const char* desc){auto* f=find_field(VMS_HEAP(g_heap)[ref].cls,name,desc);check(f&&!f->is_static,"fixture instance field exists");return VMS_HEAP(g_heap)[ref].fields[f->slot];}
static int backing(int ref){return objfield(ref,"elementData","[Ljava/lang/Object;").ref;}
static bool direct(const char* name,const char* desc,Value* args,Value& out){
    auto* m=method(ensure_class("java/util/Vector"),name,desc);
    return library_intrinsic_dispatch(library_intrinsic_kind(m),m,args,out);
}
static void monitor_clear(int ref){auto found=VMS_EXEC(g_monitors).find(ref);check(found==VMS_EXEC(g_monitors).end()||(!found->second.owner&&!found->second.depth),"method releases its monitor");}

static void admission(const char* classes){
    invoke("setup");const int ref=stat("saved","Ljava/util/Vector;").ref,left=stat("left","Ljava/lang/Object;").ref,right=stat("right","Ljava/lang/Object;").ref;
    Value args[]={Value::of_ref(ref),Value::of_i(0),Value::of_i(0)},out;
    check(direct("size","()I",args,out)&&out.i==3,"reviewed synchronized Vector size takes bounded path"); // Fit22 RED: no Vector admission.
    monitor_clear(ref);
    check(direct("elementAt","(I)Ljava/lang/Object;",args,out)&&out.ref==left,"elementAt returns exact reference");
    auto version=VMS_HEAP(g_heap)[backing(ref)].elems.reference_version();
    args[1]=Value::of_ref(right);args[2]=Value::of_i(0);
    check(direct("setElementAt","(Ljava/lang/Object;I)V",args,out),"setElementAt admits valid bounded mutation");
    check(VMS_HEAP(g_heap)[backing(ref)].elems.get(0).ref==right&&VMS_HEAP(g_heap)[backing(ref)].elems.reference_version()==version+1,"reference-array write barrier runs exactly once");
    monitor_clear(ref);
    args[1]=Value::of_ref(0);check(direct("setElementAt","(Ljava/lang/Object;I)V",args,out)&&VMS_HEAP(g_heap)[backing(ref)].elems.get(0).ref==0,"null write supported");
    args[1]=Value::of_i(-1);check(!direct("elementAt","(I)Ljava/lang/Object;",args,out),"negative index retains Java exception path");
    args[1]=Value::of_i(3);check(!direct("elementAt","(I)Ljava/lang/Object;",args,out),"count boundary retains Java exception path");
    args[1]=Value::of_ref(left);args[2]=Value::of_i(3);check(!direct("setElementAt","(Ljava/lang/Object;I)V",args,out),"invalid write retains Java exception path");
    args[0]=Value::of_ref(stat("inherited","LVectorInherited;").ref);check(!direct("size","()I",args,out),"inherited method on subclass retains Java path");
    args[0]=Value::of_ref(stat("overridden","LVectorOverride;").ref);check(!direct("size","()I",args,out),"override receiver declines reviewed method");
    args[0]=Value::of_ref(0);check(!direct("size","()I",args,out),"null direct receiver declines");
    args[0]=Value::of_ref(ref);args[1]=Value::of_i(0);args[2]=Value::of_i(0);
    const int array=backing(ref),count=objfield(ref,"elementCount","I").i;
    objfield(ref,"elementData","[Ljava/lang/Object;")=Value::of_ref(0);check(!direct("elementAt","(I)Ljava/lang/Object;",args,out),"null backing declines");
    check(invoke("sizeOnly","()I").i==3,"malformed backing still preserves Java size result through fallback");
    objfield(ref,"elementData","[Ljava/lang/Object;")=Value::of_ref(alloc_array("[Ljava/lang/String;",4));
    check(!direct("elementAt","(I)Ljava/lang/Object;",args,out),"covariant backing declines");
    args[1]=Value::of_ref(left);check(!direct("setElementAt","(Ljava/lang/Object;I)V",args,out),"covariant store retains Java type check");
    objfield(ref,"elementData","[Ljava/lang/Object;")=Value::of_ref(array);
    objfield(ref,"elementCount","I")=Value::of_i(-1);check(!direct("size","()I",args,out),"negative count declines");
    objfield(ref,"elementCount","I")=Value::of_i(5);check(!direct("size","()I",args,out),"count outside capacity declines");
    objfield(ref,"elementCount","I")=Value::of_i(count);
    objfield(ref,"elementCount","I").ref=left;check(!direct("size","()I",args,out),"mixed count Value preserves Java fallback");
    objfield(ref,"elementCount","I")=Value::of_l(count);check(!direct("size","()I",args,out),"wide count Value preserves Java fallback");
    objfield(ref,"elementCount","I")=Value::of_i(count);
    objfield(ref,"elementData","[Ljava/lang/Object;").i=7;check(!direct("size","()I",args,out),"mixed backing Value declines");
    objfield(ref,"elementData","[Ljava/lang/Object;")=Value::of_ref(array);
    args[0].i=1;check(!direct("size","()I",args,out),"mixed receiver Value declines");args[0]=Value::of_ref(ref);
    args[1]=Value::of_i(0);args[1].ref=left;check(!direct("elementAt","(I)Ljava/lang/Object;",args,out),"mixed index Value declines");
    args[1]=Value::of_ref(left);args[1].i=7;check(!direct("setElementAt","(Ljava/lang/Object;I)V",args,out),"mixed write Value declines");
    args[1]=Value::of_ref(left);args[2]=Value::of_l(0);check(!direct("setElementAt","(Ljava/lang/Object;I)V",args,out),"wide write index declines");args[2]=Value::of_i(0);
    args[1]=Value::of_ref(int(VMS_HEAP(g_heap).size())+100);check(!direct("setElementAt","(Ljava/lang/Object;I)V",args,out),"invalid stored reference declines");
    VMS_HEAP(g_heap)[array].elems.set(0,args[1]);args[1]=Value::of_i(0);
    check(!direct("elementAt","(I)Ljava/lang/Object;",args,out),"invalid loaded reference declines");VMS_HEAP(g_heap)[array].elems.set(0,Value::of_ref(left));
    args[1]=Value::of_ref(left);const int cls=VMS_HEAP(g_heap)[ref].cls;
    VMS_CL(g_classes)[cls].init_state=0;check(!direct("size","()I",args,out),"uninitialized class declines");VMS_CL(g_classes)[cls].init_state=2;
    check(monitor_enter(ref)&&monitor_enter(ref),"outer monitor is reentrant");
    check(direct("size","()I",args,out)&&out.i==3&&VMS_EXEC(g_monitors)[ref].depth==2,"shortcut preserves outer monitor depth");
    monitor_exit(ref);monitor_exit(ref);monitor_clear(ref);
    std::vector<uint8_t> bytes;check(read_whole(std::string(classes)+"/java/util/Vector.class",bytes),"reviewed bytes readable");
    const auto trusted=VMS_CL(g_classes)[cls].trusted_library;
    VMS_CL(g_classes)[cls].trusted_library=0;bytes.back()^=1;bind_library_layout(cls,bytes);
    check(!VMS_CL(g_classes)[cls].trusted_library&&!direct("size","()I",args,out),"one changed class byte cannot authorize shortcut");
    bytes.back()^=1;bind_library_layout(cls,bytes);check(VMS_CL(g_classes)[cls].trusted_library==trusted&&direct("size","()I",args,out),"exact class bytes restore admission");
}

static JavaThreadContext& worker(){auto* t=thread_context(stat("worker","Ljava/lang/Thread;").ref);check(t,"real started worker has scheduler context");return *t;}
static void finish_worker(){for(int i=0;i<30&&VMS_EXEC(g_thread_live);++i)check(pump_one_thread(),"ready worker makes progress");check(!VMS_EXEC(g_thread_live),"worker completes within bounded turns");}
static void contention(const char* start,const char* target){
    invoke("setup");const int ref=stat("saved","Ljava/util/Vector;").ref,left=stat("left","Ljava/lang/Object;").ref,right=stat("right","Ljava/lang/Object;").ref;
    check(monitor_enter(ref)&&monitor_enter(ref),"main owns vector recursively");invoke(start);check(pump_one_thread(),"peer reaches synchronized call");
    auto& t=worker();check(t.state==ThreadState::Blocked&&t.monitor==ref&&t.restore_depth==1&&!t.reacquire,"contended call uses ordinary monitor wait state");
    check(t.frames.size()==2&&t.frames.back().method->name==target&&t.frames.back().pc==0&&!t.frames.back().sync_acquired,"contended invocation retains original Java callee frame and PC");
    const int caller_pc=t.frames.front().pc;check(caller_pc>t.frames.front().op_pc,"caller already points after pending invocation");
    check(stat("completed","I").i==0&&VMS_HEAP(g_heap)[backing(ref)].elems.get(0).ref==left,"blocked call has no visible read/write completion");
    if(std::string(start)=="startRead")invoke("ownerWrite");
    check(VMS_EXEC(g_monitors)[ref].owner==&current_context()&&VMS_EXEC(g_monitors)[ref].depth==2,"owner reentrant call retains both locks");
    monitor_exit(ref);check(!pump_one_thread()&&stat("completed","I").i==0,"peer remains blocked until final recursive exit");monitor_exit(ref);
    finish_worker();check(stat("completed","I").i==1,"resumed invocation completes once");
    if(std::string(start)=="startRead")check(stat("observed","Ljava/lang/Object;").ref==right,"read sees owner mutation after acquisition");
    if(std::string(start)=="startWrite")check(VMS_HEAP(g_heap)[backing(ref)].elems.get(0).ref==right,"write occurs after owner releases monitor");
    if(std::string(start)=="startNegative")check(stat("caught","I").i==1,"invalid index throws only after acquiring monitor");
    monitor_clear(ref);
}

static void semantics(){
    invoke("setup");check(invoke("semantics","()I").i==0,"normal values exceptions covariance and overrides match Java");
    contention("startRead","elementAt");contention("startWrite","setElementAt");contention("startNegative","elementAt");
    invoke("setup");const int ref=stat("saved","Ljava/util/Vector;").ref,cls=VMS_HEAP(g_heap)[ref].cls;
    VMS_CL(g_classes)[cls].init_state=0;const auto calls=VMS_NATIVE(g_library_leaf_calls);
    check(invoke("sizeOnly","()I").i==3&&VMS_CL(g_classes)[cls].init_state==2,"uninitialized class executes original initialization");
    check(VMS_NATIVE(g_library_leaf_calls)==calls,"initialization is not bypassed by shortcut");
    VMS_CL(g_classes)[cls].init_state=1;VMS_CL(g_classes)[cls].init_owner=&VMS_EXEC(g_main_thread);
    invoke("startSize");check(pump_one_thread(),"peer reaches initializing class");auto& t=worker();
    check(t.state==ThreadState::Initializing&&t.init_wait==cls&&t.frames.size()==2&&!t.frames.back().sync_acquired,"class initialization wait precedes monitor entry");
    check(stat("completed","I").i==0,"initializing class has no visible call result");
    VMS_CL(g_classes)[cls].init_state=2;VMS_CL(g_classes)[cls].init_owner=nullptr;finish_worker();
    check(stat("caught","I").i==3&&stat("completed","I").i==1,"initialization waiter resumes once");monitor_clear(ref);
    // Compare exact execution fuel in the two deterministic engines. Both
    // retain the original checked synchronized method bodies.
    uint64_t fuel[2]={};
    for(int mode=0;mode<2;++mode){invoke("setup");auto& s=r4::state;s.cfg.profile=mode?"optimized-v1":"reference-v1";s.remaining=1000000;s.worker_phase=false;s.opcodes=0;s.certified_shortcuts=0;s.active=true;
        const auto leaf=VMS_NATIVE(g_library_leaf_calls);check(invoke("r4Work","()I").i==140,"deterministic workload exact result");fuel[mode]=s.opcodes;
        check(VMS_NATIVE(g_library_leaf_calls)==leaf,"deterministic mode retains synchronized Java calls");s.active=false;}
    check(fuel[0]==fuel[1]&&fuel[0]>1000,"reference and optimized modes charge identical bytecodes");
    invoke("setup");const auto before=VMS_EXEC(g_fast_ops)+VMS_EXEC(g_slow_ops)+VMS_NATIVE(g_native_jit).stats.ops;
    check(invoke("r4Work","()I").i==140,"normal engine workload exact result");
    check(VMS_EXEC(g_fast_ops)+VMS_EXEC(g_slow_ops)+VMS_NATIVE(g_native_jit).stats.ops-before==fuel[0],"bounded shortcuts retain every original operation in scheduler accounting");
    std::cout<<"R4 Vector opcodes="<<fuel[0]<<" conservative_sync_fallback=1\n";
}

static int construct(const char* name){int cls=ensure_class(name),ref=alloc_obj(cls);VMS_CL(g_classes)[cls].statics.push_back(Value::of_ref(ref));run(method(cls,"<init>","()V"),{Value::of_ref(ref)});check(!VMS_EXEC(g_thrown),"original game constructor succeeds");return ref;}
static uint64_t mix(uint64_t h,uint32_t value){return (h^value)*1099511628211ULL;}
static void world(const char* jar,bool profile,unsigned repeats){
    std::vector<uint8_t> bytes;std::string error;check(read_whole(jar,bytes)&&unzip(bytes,VMS_CL(g_jar_files),error),"original JAR loaded");
    const std::string jar_hash=rms_jar_identity(bytes.data(),bytes.size());
    const int common=ensure_class("CWA2DAPI/CWACommon");run(method(common,"setScreen","(SS)V"),{Value::of_i(240),Value::of_i(320)});check(!VMS_EXEC(g_thrown),"original common initialization succeeds");
    const int w=construct("CWA2DAPI/cwaEX/CWAWorld"),camera=construct("CWA2DAPI/cwabase2d/CWACamera"),map=construct("CWA2DAPI/cwabase2d/CWAMap");
    objfield(camera,"actorX","I")=Value::of_i(120);objfield(camera,"actorY","I")=Value::of_i(160);
    for(const char* n:{"a","b"})objfield(map,n,"S")=Value::of_i(128);
    for(const char* n:{"c","d"})objfield(map,n,"S")=Value::of_i(16);
    objfield(map,"mapW","I")=Value::of_i(2048);objfield(map,"mapH","I")=Value::of_i(2048);
    run(method(VMS_HEAP(g_heap)[w].cls,"setCamera","(LCWA2DAPI/cwabase2d/CWACamera;)V"),{Value::of_ref(w),Value::of_ref(camera)});
    run(method(VMS_HEAP(g_heap)[w].cls,"setMap","(LCWA2DAPI/cwabase2d/CWAMap;)V"),{Value::of_ref(w),Value::of_ref(map)});
    constexpr int per_layer=48;std::vector<int> original[3],sorted[3];int vectors[3],arrays[3];
    for(int layer=0;layer<3;++layer){vectors[layer]=objfield(w,layer==0?"a":layer==1?"b":"c","Ljava/util/Vector;").ref;
        for(int i=0;i<per_layer;++i){const int actor=construct("CWA2DAPI/cwaEX/CWASprActor");objfield(actor,"layer","I")=Value::of_i(layer);objfield(actor,"actorX","I")=Value::of_i(i*2);objfield(actor,"actorY","I")=Value::of_i((i*29+7)%per_layer+layer*100);original[layer].push_back(actor);
            run(method(VMS_HEAP(g_heap)[w].cls,"addActor","(LCWA2DAPI/cwabase2d/CWAActor;)V"),{Value::of_ref(w),Value::of_ref(actor)});check(!VMS_EXEC(g_thrown),"original actor registration succeeds");}
        arrays[layer]=backing(vectors[layer]);sorted[layer]=original[layer];std::sort(sorted[layer].begin(),sorted[layer].end(),[](int a,int b){return objfield(a,"actorY","I").i<objfield(b,"actorY","I").i;});}
    auto* update=method(VMS_HEAP(g_heap)[w].cls,"update","()V");
    // Profile separately from timings: method accounting adds clock overhead
    // and disables compiled regions. It establishes where these exact inputs go.
    VMS_EXEC(g_execution_profile).enabled=profile;
    for(auto& c:VMS_CL(g_classes))for(auto& m:c.methods)m.cpu_profile={};
    const unsigned updates=profile?2:40;
    for(unsigned trial=0;trial<=repeats;++trial){uint64_t checksum=1469598103934665603ULL;const auto fast=VMS_EXEC(g_fast_ops),slow=VMS_EXEC(g_slow_ops),leaf=VMS_NATIVE(g_library_leaf_calls),compiled=VMS_NATIVE(g_native_jit).stats.ops;const auto begin=std::chrono::steady_clock::now();
        for(unsigned u=0;u<updates;++u){for(int layer=0;layer<3;++layer)for(int i=0;i<per_layer;++i)VMS_HEAP(g_heap)[arrays[layer]].elems.set(i,Value::of_ref(original[layer][i]));
            run(update,{Value::of_ref(w)});check(!VMS_EXEC(g_thrown)&&!current_context().unhandled,"complete original world update succeeds");
            for(int layer=0;layer<3;++layer){check(objfield(vectors[layer],"elementCount","I").i==per_layer,"original Vector count preserved");
                for(int i=0;i<per_layer;++i){int actor=VMS_HEAP(g_heap)[arrays[layer]].elems.get(i).ref;check(actor==sorted[layer][i],"original bytecode sorts exact actor identities");checksum=mix(checksum,uint32_t(objfield(actor,"actorX","I").i));checksum=mix(checksum,uint32_t(objfield(actor,"actorY","I").i));}}
            check(objfield(map,"leftTopX","I").i==0&&objfield(map,"leftTopY","I").i==0,"original camera and map result preserved");}
        const double ms=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-begin).count();
        std::cout<<"WORLD trial="<<trial<<" updates="<<updates<<" actors="<<per_layer*3<<" checksum="<<checksum<<" ms="<<ms<<" fast="<<VMS_EXEC(g_fast_ops)-fast<<" slow="<<VMS_EXEC(g_slow_ops)-slow<<" jitops="<<VMS_NATIVE(g_native_jit).stats.ops-compiled<<" leaf="<<VMS_NATIVE(g_library_leaf_calls)-leaf<<" profile="<<profile<<'\n';}
    if(profile){std::vector<Method*> methods;for(auto& c:VMS_CL(g_classes))for(auto& m:c.methods)if(m.cpu_profile.calls)methods.push_back(&m);std::sort(methods.begin(),methods.end(),[](Method* a,Method* b){return a->cpu_profile.self_cpu_ns>b->cpu_profile.self_cpu_ns;});
        for(auto* m:methods)std::cout<<"PROFILE "<<VMS_CL(g_classes)[m->class_id].name<<'.'<<m->name<<m->desc<<" calls="<<m->cpu_profile.calls<<" self_cpu_ns="<<m->cpu_profile.self_cpu_ns<<'\n';}
    std::cout<<"PROVENANCE jar_sha256="<<jar_hash<<" original_bytecode=1 full_update=1 original_constructors=1 constructed_inputs=1 inactive_sprite_actions=1 natural_scene=0 rendering=0 desktop_not_switch=1\n";
}

int main(int argc,char** argv){
    check(argc>=5,"classes romfs engine scenario [jar] [repeats]");VMS_CL(g_classpath)={argv[1],argv[2]};VMS_DIAG(g_log_draw)=false;VMS_EXEC(g_slice_ms)=4;
    VMS_NATIVE(g_native_jit).configure(std::string(argv[3])=="jit");check(std::string(argv[3])!="jit"||VMS_NATIVE(g_native_jit).available,"requested host JIT is available");
    const std::string scenario=argv[4];
    if(scenario=="admission")admission(argv[2]);
    else if(scenario=="semantics")semantics();
    else {check(argc>=6&&(scenario=="world"||scenario=="profile"),"known scenario with external JAR");world(argv[5],scenario=="profile",argc>6?unsigned(std::atoi(argv[6])):0);}
    check(g_gc_sp.violations==0,"no illegal GC safepoints");
    // Match stop_thread's JIT teardown before C++ static destruction. Leaving
    // resident regions alive would retire them into an already-destroyed
    // quarantine deque at process exit; that is not the production lifecycle.
    check(jit236::active_code_calls()==0,"no compiled activation during teardown");
    VMS_NATIVE(g_native_jit).clear();jit_region_reset();
    std::cout<<"PASS Vector scenario="<<scenario<<" checks="<<checks<<'\n';
}
