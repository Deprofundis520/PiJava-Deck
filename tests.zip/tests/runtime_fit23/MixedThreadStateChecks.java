public class MixedThreadStateChecks implements Runnable {
    public static final Object lock = new Object(), ownedLock = new Object();
    public static Thread owner, second, monitorWaiter, joiner, lockHolder;
    public static int completed;
    private int mode;
    MixedThreadStateChecks(int mode) { this.mode = mode; }
    public void run() {
        try {
            if (mode == 0) {
                if (MixedStateSlow.value != 7) throw new RuntimeException("initializer value");
            } else if (mode == 1) {
                synchronized (lock) { lock.wait(); }
            } else if (mode == 2) {
                owner.join();
            } else {
                synchronized (ownedLock) { Thread.sleep(100000); }
            }
            ++completed;
        } catch (InterruptedException e) { throw new RuntimeException("unexpected interruption"); }
    }
    public static int setup() throws InterruptedException {
        FinishedThreadStateChecks.finishNested();
        owner = new Thread(new MixedThreadStateChecks(0)); owner.start();
        second = new Thread(new MixedThreadStateChecks(0)); second.start();
        monitorWaiter = new Thread(new MixedThreadStateChecks(1)); monitorWaiter.start();
        joiner = new Thread(new MixedThreadStateChecks(2)); joiner.start();
        lockHolder = new Thread(new MixedThreadStateChecks(3)); lockHolder.start();
        for (int i = 0; i < 20; ++i) Thread.sleep(1);
        return 1;
    }
    public static void notifyWaiter() { synchronized (lock) { lock.notifyAll(); } }
}
class MixedStateSlow {
    static int value;
    static {
        try { Thread.sleep(100000); } catch (InterruptedException e) {}
        value = 7;
    }
}
