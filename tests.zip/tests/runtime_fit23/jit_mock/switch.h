#pragma once
// Test-only libnx boundary. Retain real RW/RX mappings from the Fit13 fixture,
// and model libnx's CodeMemory cache publication plus fallback failures.
#define jitCreate fit23_base_jitCreate
#define jitClose fit23_base_jitClose
#define jitTransitionToWritable fit23_base_jitTransitionToWritable
#define jitTransitionToExecutable fit23_base_jitTransitionToExecutable
#define armDCacheFlush fit23_base_armDCacheFlush
#define armICacheInvalidate fit23_base_armICacheInvalidate
#include "../../runtime_fit13/jit_mock/switch.h"
#undef jitCreate
#undef jitClose
#undef jitTransitionToWritable
#undef jitTransitionToExecutable
#undef armDCacheFlush
#undef armICacheInvalidate
#include <vector>

namespace fit23_mock {
struct CacheRange {void* address;size_t bytes;bool instruction;};
inline std::vector<CacheRange> ranges;
inline std::vector<Jit*> mappings;
inline JitType type=JitType_CodeMemory;
inline Result write_error=0,execute_error=0;
inline size_t reserved=0,peak_reserved=0;
}
inline Result jitCreate(Jit* j,size_t size){
    const Result rc=fit23_base_jitCreate(j,size);
    if(!rc){j->type=fit23_mock::type;fit23_mock::mappings.push_back(j);
        fit23_mock::reserved+=size;fit23_mock::peak_reserved=std::max(fit23_mock::peak_reserved,fit23_mock::reserved);}
    return rc;
}
inline Result jitClose(Jit* j){
    fit23_mock::reserved-=j->size;
    auto& v=fit23_mock::mappings;v.erase(std::remove(v.begin(),v.end(),j),v.end());
    return fit23_base_jitClose(j);
}
inline void armDCacheFlush(void* p,size_t n){
    fit23_mock::ranges.push_back({p,n,false});fit23_base_armDCacheFlush(p,n);
}
inline void armICacheInvalidate(void* p,size_t n){
    fit23_mock::ranges.push_back({p,n,true});fit23_base_armICacheInvalidate(p,n);
}
inline Result jitTransitionToWritable(Jit* j){
    if(fit23_mock::write_error){++fit13_mock::writable;return fit23_mock::write_error;}
    return fit23_base_jitTransitionToWritable(j);
}
inline Result jitTransitionToExecutable(Jit* j){
    if(fit23_mock::execute_error){++fit13_mock::executable;return fit23_mock::execute_error;}
    if(j->type==JitType_CodeMemory){armDCacheFlush(j->rw_addr,j->size);armICacheInvalidate(j->rx_addr,j->size);}
    return fit23_base_jitTransitionToExecutable(j);
}
