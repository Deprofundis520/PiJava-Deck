import java.util.Vector;

class VectorChecks {
    static Vector saved;
    static Object left, right, observed;
    static VectorInherited inherited;
    static VectorOverride overridden;
    static Thread worker;
    static int completed, caught;

    static void setup() {
        left = new Object(); right = new Object(); observed = null;
        completed = caught = 0;
        saved = new Vector(4);
        saved.addElement(left); saved.addElement(null); saved.addElement(right);
        inherited = new VectorInherited(); inherited.addElement(left);
        overridden = new VectorOverride();
    }

    static int semantics() {
        if (saved.size() != 3 || saved.elementAt(0) != left || saved.elementAt(1) != null) return 1;
        saved.setElementAt(right, 0);
        if (saved.elementAt(0) != right || saved.size() != 3) return 2;
        saved.setElementAt(null, 0);
        if (saved.elementAt(0) != null) return 3;
        try { saved.elementAt(-1); return 4; }
        catch (ArrayIndexOutOfBoundsException e) { if (!"-1".equals(e.getMessage())) return 5; }
        try { saved.setElementAt(left, 3); return 6; }
        catch (ArrayIndexOutOfBoundsException e) { if (!"3".equals(e.getMessage())) return 7; }
        if (saved.size() != 3 || saved.elementAt(0) != null) return 8;
        Vector missing = null;
        try { missing.size(); return 9; } catch (NullPointerException e) { }
        if (inherited.size() != 1 || inherited.elementAt(0) != left) return 10;
        inherited.setElementAt(right, 0);
        if (inherited.elementAt(0) != right) return 11;
        inherited.badBacking();
        try { inherited.setElementAt(left, 0); return 12; } catch (ArrayStoreException e) { }
        if (overridden.size() != 17 || overridden.elementAt(0) != right) return 13;
        overridden.setElementAt(left, 0);
        if (overridden.calls != 3 || observed != left) return 14;
        return 0;
    }

    static int sizeOnly() { return saved.size(); }
    static Object elementOnly(int index) { return saved.elementAt(index); }
    static void setOnly(Object value, int index) { saved.setElementAt(value, index); }
    static void ownerWrite() { saved.setElementAt(right, 0); }

    static void startRead() { worker = new VectorWorker(0); worker.start(); }
    static void startWrite() { worker = new VectorWorker(1); worker.start(); }
    static void startNegative() { worker = new VectorWorker(2); worker.start(); }
    static void startSize() { worker = new VectorWorker(3); worker.start(); }

    static int r4Work() {
        int sum = 0;
        for (int i = 0; i < 40; i++) {
            sum += saved.size();
            saved.setElementAt((i & 1) == 0 ? left : right, 1);
            if (saved.elementAt(1) == left) sum++;
        }
        return sum;
    }
}

class VectorInherited extends Vector {
    void badBacking() { elementData = new String[1]; elementCount = 1; }
}

class VectorOverride extends Vector {
    int calls;
    public synchronized int size() { calls++; return 17; }
    public synchronized Object elementAt(int index) { calls++; return VectorChecks.right; }
    public synchronized void setElementAt(Object value, int index) { calls++; VectorChecks.observed = value; }
}

class VectorWorker extends Thread {
    int action;
    VectorWorker(int action) { this.action = action; }
    public void run() {
        if (action == 0) VectorChecks.observed = VectorChecks.saved.elementAt(0);
        else if (action == 1) VectorChecks.saved.setElementAt(VectorChecks.right, 0);
        else if (action == 2) {
            try { VectorChecks.saved.elementAt(-1); }
            catch (ArrayIndexOutOfBoundsException e) { if ("-1".equals(e.getMessage())) VectorChecks.caught++; }
        } else VectorChecks.caught = VectorChecks.saved.size();
        VectorChecks.completed++;
    }
}
