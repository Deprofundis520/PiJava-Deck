#!/usr/bin/env python3
"""Build the real VM Vector checks, optionally against an immutable baseline.

The external-JAR probe runs the complete unmodified world update on constructed
valid objects. Timings need exclusive CPU use; profile output is not a timing.
"""
import argparse
import hashlib
import json
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, default=ROOT)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--jar', type=Path)
    parser.add_argument('--build-only', action='store_true')
    parser.add_argument('--baseline', action='store_true', help='run semantics without requiring new admission')
    parser.add_argument('--sanitize', action='store_true')
    parser.add_argument('--optimize', action='store_true', help='O2 for controlled timings')
    args = parser.parse_args()
    source, out = args.source.resolve(), args.output.resolve()
    out.mkdir(parents=True, exist_ok=True)
    classes = out / 'classes'
    classes.mkdir(exist_ok=True)
    flags = ['-O1' if args.sanitize else '-O2' if args.optimize else '-O0', '-g0']
    if args.sanitize:
        flags += ['-fsanitize=undefined', '-fno-sanitize-recover=all']
    binary = out / 'vector-vm-checks'
    commands = [
        ['java', '-m', 'jdk.compiler/com.sun.tools.javac.Main', '-source', '8', '-target', '8', '-bootclasspath', str(source / 'romfs/classes'), '-classpath', str(source / 'romfs/classes'), '-d', str(classes), str(HERE / 'vector_checks.java')],
        ['gcc', *flags, '-c', str(source / 'src/puff.c'), '-o', str(out / 'puff.o')],
        ['g++', *flags, '-std=c++17', '-fno-exceptions', '-ffunction-sections', '-fdata-sections', '-DJ2ME_TEST_VM="' + str(source / 'src/j2mevm.cpp') + '"', str(HERE / 'vector_vm_checks.cpp'), str(out / 'puff.o'), '-Wl,--gc-sections', '-pthread', '-ldl', '-o', str(binary)],
    ]
    identities = {str(p): sha(p) for base in ['src', 'romfs/classes', 'third_party'] for p in sorted((source / base).rglob('*')) if p.is_file()}
    identities.update({str(p): sha(p) for p in [HERE / 'vector_checks.java', HERE / 'vector_vm_checks.cpp', Path(__file__).resolve()]})
    if args.jar:
        identities[str(args.jar.resolve())] = sha(args.jar.resolve())
    (out / 'input-sha256.json').write_text(json.dumps(identities, indent=2) + '\n')
    if not args.build_only:
        for engine in ['fast', 'jit']:
            commands.append([str(binary), str(classes), str(source / 'romfs/classes'), engine, 'semantics'])
            if not args.baseline:
                commands.append([str(binary), str(classes), str(source / 'romfs/classes'), engine, 'admission'])
        if args.jar:
            commands.append([str(binary), str(classes), str(source / 'romfs/classes'), 'fast', 'profile', str(args.jar.resolve()), '0'])
    records = []
    for i, command in enumerate(commands):
        result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=300)
        (out / f'step-{i}.log').write_bytes(result.stdout)
        records.append({'command': command, 'returncode': result.returncode})
        (out / 'commands.json').write_text(json.dumps(records, indent=2) + '\n')
        print('step', i, 'returncode', result.returncode, flush=True)
        if result.returncode:
            raise SystemExit(result.stdout.decode(errors='replace')[-6000:])
        if i >= 3:
            print('\n'.join(line for line in result.stdout.decode(errors='replace').splitlines() if line.startswith(('PASS', 'WORLD', 'PROFILE', 'PROVENANCE', 'R4'))), flush=True)
    (out / 'binary-sha256.txt').write_text(sha(binary) + '  ' + binary.name + '\n')
    changed = [path for path, digest in identities.items() if sha(Path(path)) != digest]
    (out / 'input-changes-during-build.json').write_text(json.dumps(changed, indent=2) + '\n')
    if changed:
        print('Other parallel edits observed; binary provenance is the recorded initial hashes and commands:', ', '.join(changed), flush=True)


if __name__ == '__main__':
    main()
