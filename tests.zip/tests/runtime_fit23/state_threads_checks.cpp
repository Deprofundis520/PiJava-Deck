// Real Java worker completion under a nested native wait, followed by legal GC
// and J2S5 capture. The shipped legacy fixture was produced by unmodified fit22.
#define main emulator_main
#include J2ME_TEST_VM
#undef main
#include J2ME_TEST_HOST_MENU
#include J2ME_TEST_HOST_SPEED
static host_menu::Settings g_menu_settings;
static std::string instant_state_path(const std::string&) { return "unused-state-thread-file"; }
#include J2ME_TEST_STATE
static void check(bool ok,const char* why) {
    if(!ok){std::cerr<<"FAIL state-threads "<<why<<'\n';std::exit(1);}
}
static Value field(const char* cls,const char* name,const char* desc) {
    const int cid=ensure_class(cls);const auto* f=find_field(cid,name,desc);
    check(f&&f->is_static,"fixture field exists");return VMS_CL(g_classes)[f->owner].statics[f->slot];
}
static Value invoke(const char* cls,const char* method,const char* desc) {
    auto* m=find_method(ensure_class(cls),method,desc,false);check(m,"fixture method exists");
    const Value result=run(m,{});check(!VMS_EXEC(g_thrown),"fixture invocation returned normally");return result;
}
static void canvas_fixture() {
    const int cid=ensure_class("FinishedThreadStateChecks");VMS_RS(g_current)=alloc_obj(cid);
    run(find_method(cid,"<init>","()V",false),{Value::of_ref(VMS_RS(g_current))});
    VMS_EXEC(g_midlet)=alloc_obj(ensure_class("java/lang/Object"));VMS_EXEC(g_midlet_state)=MidletState::Active;
}
static void collect_dead_objects() {
    for(int n=0;n<300;++n)alloc_obj(ensure_class("java/lang/Object"));
    gc_safepoint(GcPoint::Paint);check(g_gc_sp.violations==0,"GC at legal host boundary");
}
static SavState round_trip(const SavState& s) {
    SavState decoded;std::string bytes;
    check(encode_state(s,bytes)&&bytes.substr(0,4)=="J2S5","unchanged J2S5 format");
    check(decode_state(bytes,decoded),"saved bytes decode");return decoded;
}
static void fresh_check() {
    canvas_fixture();check(invoke("FinishedThreadStateChecks","finishNested","()I").i==1,"worker completed once");
    check(!VMS_EXEC(g_thread_live),"joined worker is not runnable");collect_dead_objects();
    SavState saved;check(capture_state(saved,"fixture.jar"),"fresh capture succeeds");
    SavState decoded=round_trip(saved);
    check(apply_state(decoded),"fresh completed-worker snapshot restores");
    check(field("FinishedThreadStateChecks","completed","I").i==1,"completed worker did not run again");
    std::cout<<"PASS state-threads fresh_finished_worker_gc_restore=1 threads="<<decoded.threads.size()<<'\n';
}
static void legacy_check(const char* path) {
    std::vector<uint8_t> input;check(read_whole(path,input),"legacy fixture read");
    SavState decoded;const std::string bytes(input.begin(),input.end());
    check(decode_state(bytes,decoded)&&apply_state(decoded),"fit22 snapshot with collected finished worker restores");
    check(field("FinishedThreadStateChecks","completed","I").i==1,"legacy completion count retained");
    check(!VMS_EXEC(g_thread_live),"legacy dead worker not resurrected");
    SavState recaptured;check(capture_state(recaptured,"fixture.jar"),"legacy restored state recaptures");
    const auto again=round_trip(recaptured);check(apply_state(again),"legacy state remains restorable after resave");
    std::cout<<"PASS state-threads legacy_fit22_bytes=1 reread_after_resave=1\n";
}
static void mixed_check() {
    canvas_fixture();check(invoke("MixedThreadStateChecks","setup","()I").i==1,"mixed workers started");
    collect_dead_objects();SavState saved;check(capture_state(saved,"fixture.jar"),"mixed capture succeeds");
    const char* fields[]={"owner","second","monitorWaiter","joiner","lockHolder"};
    check(saved.threads.size()==5,"only five live continuations remain");
    for(size_t i=0;i<5;++i)check(saved.threads[i].ref==field("MixedThreadStateChecks",fields[i],"Ljava/lang/Thread;").ref,"live worker order retained");
    bool init=false,waiter=false,owner=false;
    for(const auto& c:saved.classes)if(c.name=="MixedStateSlow"){init=c.init_state==1&&c.init_owner==1;}
    const int lock=field("MixedThreadStateChecks","lock","Ljava/lang/Object;").ref;
    const int held=field("MixedThreadStateChecks","ownedLock","Ljava/lang/Object;").ref;
    for(const auto& m:saved.monitors){
        if(m.ref==lock)waiter=m.waiters.size()==1&&m.waiters[0]==3;
        if(m.ref==held)owner=m.owner==5&&m.depth==1;
    }
    check(init&&waiter&&owner,"initializer owner monitor owner and waiter IDs remapped");
    const auto decoded=round_trip(saved);check(apply_state(decoded),"mixed snapshot restores");
    invoke("MixedThreadStateChecks","notifyWaiter","()V");
    for(auto& t:VMS_EXEC(g_threads))if(t.state==ThreadState::Sleeping){t.wake=monotonic_ms();t.wake_us=0;}
    for(int turn=0;turn<64&&VMS_EXEC(g_thread_live);++turn)advance_game_frame();
    check(!VMS_EXEC(g_thread_live)&&field("MixedThreadStateChecks","completed","I").i==5,"all five continuations finish with correct synchronization");
    for(const auto& m:VMS_EXEC(g_monitors))check(!m.second.owner&&m.second.waiters.empty(),"restored synchronization released");
    std::cout<<"PASS state-threads live_order=1 initializer_owner=1 monitor_owner=1 monitor_waiter=1 join_target=1 resumed_workers=5\n";
}
static void malformed_checks() {
    canvas_fixture();invoke("FinishedThreadStateChecks","finishNested","()I");
    check(VMS_EXEC(g_threads).size()==1,"fixture has finished context before safe cleanup");
    auto& live=VMS_EXEC(g_threads).front();const SavThread finished=sav_thread(live);
    live.executing=true;SavState blocked;
    check(!capture_state(blocked,"fixture.jar"),"executing terminated context cannot be captured");live.executing=false;
    SavState base;check(capture_state(base,"fixture.jar"),"nonexecuting capture succeeds");
    check(base.threads.empty(),"finished context omitted from new snapshot");
    const int midlet=VMS_EXEC(g_midlet);const size_t heap=VMS_HEAP(g_heap).size();
    int rejected=0;
    auto reject=[&](SavState bad,const char* why){
        std::string bytes;check(encode_state(bad,bytes),"malformed semantic fixture encodes structurally");
        SavState decoded;const bool read=decode_state(bytes,decoded);
        check(!read||!apply_state(decoded),why);
        check(VMS_EXEC(g_midlet)==midlet&&VMS_HEAP(g_heap).size()==heap,"rejection leaves live VM untouched");++rejected;
    };
    auto bad=[&](){SavState s=base;s.threads.push_back(finished);return s;};
    {auto s=bad();SavFrame f;f.cls="FinishedThreadStateChecks";f.name="run";f.desc="()V";f.locals.push_back(sav_value(Value::of_ref(s.current)));s.threads[0].frames.push_back(f);reject(s,"terminated worker with continuation rejected");}
    {auto s=bad();s.threads[0].monitor=s.current;reject(s,"terminated monitor reference rejected");}
    {auto s=bad();s.threads[0].join_target=finished.ref;reject(s,"terminated join target rejected");}
    {auto s=bad();s.threads[0].init_wait_class="FinishedThreadStateChecks";reject(s,"terminated initialization waiter rejected");}
    {auto s=bad();s.threads[0].reacquire=true;reject(s,"terminated reacquisition rejected");}
    {auto s=bad();s.threads[0].interrupt_exception=true;reject(s,"terminated pending interrupt rejected");}
    {auto s=bad();s.threads[0].ref=-1;reject(s,"negative finished identity rejected");}
    {auto s=bad();s.threads[0].ref=int(s.heap.size());reject(s,"out-of-bounds finished identity rejected");}
    {auto s=bad();s.classes[0].init_state=1;s.classes[0].init_owner=1;reject(s,"terminated class initializer owner rejected");}
    {auto s=bad();SavMonitor m;m.ref=s.current;m.owner=1;m.depth=1;s.monitors.push_back(m);reject(s,"terminated monitor owner rejected");}
    {auto s=bad();SavMonitor m;m.ref=s.current;m.waiters.push_back(1);s.monitors.push_back(m);reject(s,"terminated monitor waiter rejected");}
    {auto s=bad();SavMonitor m;m.ref=s.current;m.owner=2;m.depth=1;s.monitors.push_back(m);reject(s,"out-of-bounds owner index rejected before remap");}
    {auto s=bad();s.threads[0].state=int(ThreadState::Runnable);s.threads[0].ref=-1;reject(s,"live invalid reference remains rejected");}
    std::cout<<"PASS state-threads malformed_rejected="<<rejected<<" executing_capture_rejected=1 live_vm_untouched=1\n";
}
static std::string load_hero(const char* jar) {
    std::vector<uint8_t> bytes;std::string error;
    check(read_whole(jar,bytes)&&unzip(bytes,VMS_CL(g_jar_files),error),"original JAR loads");
    load_props();load_sidecar_jad(jar);
    const auto identity=rms_jar_identity(bytes.data(),bytes.size());check(identity=="79bac8f14e7f522c2a79e3a9ca9caf4c3a94a1ba3f2266fa86b11c26425f2c78","original Hero JAR identity");
    return identity;
}
static void hero_check(const char* jar,const char* output,int cap) {
    const auto identity=load_hero(jar);std::string main=manifest_midlet();if(main.empty())main=find_midlet_class();for(char& c:main)if(c=='.')c='/';
    VMS_EXEC(g_speed_cap)=cap;speed_sync_clock();launch_class(main,identity);const int64_t start=paint_clock_us();
    while(paint_clock_us()-start<5000000){advance_game_frame();VMS_RS(g_fb_dirty)=false;}
    host_freeze236(true);SavState saved,decoded;std::string encoded;
    check(capture_state(saved,jar)&&encode_state(saved,encoded),"original Hero capture encodes");
    std::ofstream file(std::string(output)+"/hero-state.j2s",std::ios::binary);file.write(encoded.data(),encoded.size());file.close();
    check(decode_state(encoded,decoded)&&apply_state(decoded,true),"original Hero snapshot restores");
    check(VMS_EXEC(g_midlet_state)==MidletState::Active&&!VMS_EXEC(g_thrown),"original Hero restored active");
    const int64_t after=paint_clock_us();while(paint_clock_us()-after<1000000){advance_game_frame();VMS_RS(g_fb_dirty)=false;}
    check(!VMS_EXEC(g_thrown)&&VMS_EXEC(g_midlet_state)==MidletState::Active,"original Hero runs after restore");
    std::cout<<"PASS state-threads original_hero=1 cap="<<cap<<" bytes="<<encoded.size()<<" saved_threads="<<saved.threads.size()<<" desktop_not_switch=1\n";
}
static void hero_legacy_check(const char* jar,const char* state,int cap) {
    const auto identity=load_hero(jar);VMS_EXEC(g_speed_cap)=cap;speed_sync_clock();
    std::vector<uint8_t> bytes;check(read_whole(state,bytes),"legacy Hero state read");SavState decoded;
    check(decode_state(std::string(bytes.begin(),bytes.end()),decoded)&&decoded.rms==identity,"legacy Hero state decodes and identity matches");
    check(apply_state(decoded,true),"legacy original-JAR Hero snapshot restores");
    const int64_t start=paint_clock_us();while(paint_clock_us()-start<1000000){advance_game_frame();VMS_RS(g_fb_dirty)=false;}
    check(!VMS_EXEC(g_thrown)&&VMS_EXEC(g_midlet_state)==MidletState::Active,"legacy original Hero runs after restore");
    SavState saved;check(capture_state(saved,jar),"legacy original Hero recaptures");
    check(apply_state(round_trip(saved),true),"legacy original Hero resave reloads");
    std::cout<<"PASS state-threads legacy_original_hero=1 cap="<<cap<<" continued_execution=1 reread_after_resave=1 desktop_not_switch=1\n";
}
int main(int argc,char** argv) {
    check(argc>=7,"mode classes api output fast|jit fixture-or-jar [cap]");std::cout<<std::unitbuf;
    const std::string mode=argv[1],out=argv[4];setenv("J2ME_RMS_DIR",(out+"/rms").c_str(),1);
    VMS_CL(g_classpath)={argv[2],argv[3]};VMS_DIAG(g_log_draw)=false;VMS_PLAT(g_boot_ms)=now_ms();
    VMS_RS(g_screen_w)=240;VMS_RS(g_screen_h)=320;VMS_RS(g_fb).assign(240*320*3,0);
    const bool jit=std::string(argv[5])=="jit";VMS_NATIVE(g_native_jit).configure(jit);
    check(!jit||VMS_NATIVE(g_native_jit).available,"requested host JIT available");
    log_open((out+"/"+mode+"-"+argv[5]+".log").c_str(),true);
    if(mode=="fresh")fresh_check();else if(mode=="legacy")legacy_check(argv[6]);else if(mode=="mixed")mixed_check();else if(mode=="malformed")malformed_checks();else if(mode=="hero")hero_check(argv[6],argv[4],argc>7?std::atoi(argv[7]):60);else if(mode=="hero-legacy"){check(argc>=9,"hero-legacy jar snapshot cap");hero_legacy_check(argv[6],argv[7],std::atoi(argv[8]));}else check(false,"known test mode");
    stop_thread();p7::pool().shutdown();log_shutdown();return 0;
}
