// Real allocator and emitter; only the native libnx boundary is controlled.
// Compile baseline with J2ME_TEST_JIT_HEADER pointing to the unchanged Fit22.
#ifndef J2ME_TEST_JIT_HEADER
#define J2ME_TEST_JIT_HEADER "../../src/native_jit236.h"
#endif
#include J2ME_TEST_JIT_HEADER
#include <iostream>
#include <set>
#include <string>

static void check(bool ok,const char* what){
    if(ok)return;
    const auto& s=jit236::code_pool_stats();
    std::cerr<<"FAIL "<<what<<" result="<<jit236::Executable::last_result()
        <<" error="<<jit236::Executable::last_error()<<" blocks="<<s.blocks
        <<" slices="<<s.slices<<" used_bytes="<<s.used_bytes
        <<" native_objects="<<fit13_mock::live<<" reserved="<<fit23_mock::reserved<<'\n';
    std::exit(1);
}
static std::vector<uint8_t> code(uint32_t id,size_t bytes=0){
    static const uint8_t op[]={26,4,96,172};static const std::string desc="(I)I";
    jit236::Program p;jit236::Spec s{op,sizeof(op),&desc,8,1,2,false,false,nullptr};
    check(jit236::verify(s,p),"fixture verifies");auto out=jit236::emit_host(p,id);
    check(!out.empty(),"native emitter is available");if(bytes)out.resize(bytes,0);return out;
}
static void install(jit236::Executable& e,size_t bytes=0,jit236::InstallMode mode=jit236::InstallMode::Normal){
    const auto id=jit236::next_install_id();check(e.install(code(id,bytes),id,mode),"admitted function installs");
}
static uint64_t call(jit236::Executable& e,uint32_t id){
    check(e.executable(),"live code remains executable");int32_t args[jit236::StaleIdSlot+1]{};
    args[0]=41;args[jit236::StaleIdSlot]=int32_t(id);jit236::CodeCall active;
#if defined(_WIN32) && defined(__x86_64__)
    using HostFn=uint64_t (__attribute__((sysv_abi)) *)(const int32_t*);
    return reinterpret_cast<HostFn>(e.fn)(args);
#else
    return e.fn(args);
#endif
}
static void runs(jit236::Executable& e){const auto r=call(e,e.id);check(uint32_t(r)==42&&uint32_t(r>>32)==4,"exact Java value and bytecode cost");}
static void cleanup(){
    while(!jit236::code_quarantine().empty())jit236::release_oldest_quarantine();
    jit236::dedicated_blocks().clear();
    check(!jit236::code_pool_stats().blocks&&!jit236::code_pool_stats().slices&&
        !jit236::code_pool_stats().used_bytes&&!fit13_mock::live&&!fit23_mock::reserved,
        "all mappings and slices close exactly once");
}
static void capacity(){
    fit13_mock::limit=10;jit236::Executable self;install(self,0,jit236::InstallMode::Dedicated);
    const auto self_fn=self.fn;std::vector<jit236::Executable> live(1800);size_t installed=0;
    for(auto& e:live){const auto id=jit236::next_install_id();if(!e.install(code(id),id))break;++installed;}
    std::cout<<"CAPACITY installed="<<installed<<" requested=1800 objects="<<fit13_mock::live
        <<" reserved="<<fit23_mock::reserved<<" slices="<<jit236::code_pool_stats().slices<<'\n';
    check(installed==1800,"1800 one-page functions fit below byte budget with ten native objects");
    check(fit13_mock::peak<=10&&fit23_mock::peak_reserved<=20*1024*1024,"native and configured byte ceilings respected");
    check(self.fn==self_fn,"dedicated self-test address retained");runs(self);
    std::set<void*> addresses;for(auto& e:live){runs(e);check(addresses.insert(reinterpret_cast<void*>(e.fn)).second,"ordinary pages never overlap");}
    check(!addresses.count(reinterpret_cast<void*>(self_fn)),"ordinary code never uses dedicated self-test pages");
    auto fn=live[0].fn;{jit236::CodeCall active;check(!live[0].install(code(jit236::next_install_id())),"active compiled call forbids install");}
    check(live[0].fn==fn&&live[0].executable(),"active exclusion retains original code");runs(live[0]);
    const auto stale=call(live.back(),live.back().id^0x01010101u);
    check(jit236::stale_result(stale)&&uint32_t(stale)==live.back().id,"install-ID rejects stale target");
    self.close();live.clear();cleanup();
}
static void publish(){
    jit236::Executable a,b;const auto id=jit236::next_install_id();const auto bytes=code(id);
    check(a.install(bytes,id),"CodeMemory code installs");runs(a);
    check(fit23_mock::ranges.size()==2,"CodeMemory publishes one data and one instruction range");
    auto* mapping=fit23_mock::mappings.front();
    check(fit23_mock::ranges[0].address==mapping->rw_addr&&!fit23_mock::ranges[0].instruction&&
        fit23_mock::ranges[0].bytes==bytes.size(),"data-cache publication covers only installed bytes");
    check(fit23_mock::ranges[1].address==mapping->rx_addr&&fit23_mock::ranges[1].instruction&&
        fit23_mock::ranges[1].bytes==bytes.size(),"instruction-cache publication covers matching RX bytes");
    check(mapping->is_executable,"libnx CodeMemory state is executable after publication");
    fit23_mock::ranges.clear();install(b);runs(a);runs(b);
    check(fit23_mock::mappings.size()==1&&fit23_mock::ranges.size()==2,"new immutable slice reuses its arena without recreating mapping");
    check(fit23_mock::ranges[0].address==static_cast<uint8_t*>(mapping->rw_addr)+4096&&
        fit23_mock::ranges[1].address==reinterpret_cast<void*>(b.fn),"second-page cache ranges preserve alias offset");
    a.close();b.close();cleanup();
}
static void cross_words(unsigned pages){
    fit13_mock::limit=1;std::vector<jit236::Executable> prefix(63),tail(512-63-pages);
    for(auto& e:prefix)install(e);jit236::Executable crossing;install(crossing,pages*4096);
    check(reinterpret_cast<uintptr_t>(crossing.fn)==reinterpret_cast<uintptr_t>(prefix[0].fn)+63*4096,
        "contiguous slice crosses bit63 into next bitmap word");
    for(auto& e:tail)install(e);check(fit13_mock::live==1,"512 live pages fit one mapping");
    std::set<void*> starts;for(auto& e:prefix){runs(e);check(starts.insert(reinterpret_cast<void*>(e.fn)).second,"prefix pages distinct");}
    for(auto& e:tail){runs(e);check(starts.insert(reinterpret_cast<void*>(e.fn)).second,"high pages distinct");}
    runs(crossing);const auto old=crossing.fn;crossing.close();
    const auto id=jit236::next_install_id();jit236::Executable fresh;
    check(!fresh.install(code(id,pages*4096),id,jit236::InstallMode::Fresh),"Fresh never takes written cross-word pages");
    check(crossing.install(code(id,pages*4096),id),"normal pressure reclaim reuses complete cross-word range");
    check(crossing.fn==old,"only retired contiguous range reused");runs(crossing);
    const auto high=tail.back().fn;tail.back().close();jit236::Executable high_replacement;install(high_replacement);
    check(high_replacement.fn==high,"page511 is safely cleared and reused");runs(high_replacement);
    for(auto& e:prefix)runs(e);for(size_t i=0;i+1<tail.size();++i)runs(tail[i]);
    crossing.close();high_replacement.close();prefix.clear();tail.clear();cleanup();
}
static void max_slice(){
    jit236::Executable a,b;install(a,262144);runs(a);
    const auto id=jit236::next_install_id();check(!b.install(code(id,262145),id),"individual slice remains capped at256KiB");
    check(std::string(jit236::Executable::last_error())=="empty_or_too_large","oversize slice retains existing failure category");
    runs(a);a.close();cleanup();
}
static void budget(){
    fit13_mock::limit=100;jit236::Executable self;install(self,0,jit236::InstallMode::Dedicated);
    std::vector<jit236::Executable> live(100);size_t installed=0;
    for(auto& e:live){const auto id=jit236::next_install_id();if(!e.install(code(id,262144),id))break;++installed;}
    check(installed==72,"mixed-size mapping budget admits nine2MiB game arenas and one256KiB self-test arena");
    check(fit23_mock::reserved==19136512&&fit23_mock::peak_reserved<=20971520,
        "actual backing bytes stay within20MiB including dedicated mapping");
    check(std::string(jit236::Executable::last_error())=="code_pool_budget_full","configured byte budget reports bounded fallback");
    for(auto& e:live)if(e.fn)runs(e);runs(self);self.close();live.clear();cleanup();
}
static void fallback(bool writing){
    fit23_mock::type=JitType_SetProcessMemoryPermission;jit236::Executable peer,failed;install(peer);runs(peer);
    if(writing)fit23_mock::write_error=0xd401;else fit23_mock::execute_error=0xd401;
    check(!failed.install(code(jit236::next_install_id())),"fallback transition failure rejects installation");
    check(!peer.executable()&&!failed.executable(),"failed fallback mapping poisons all peer dispatch");
    check(fit13_mock::writable>=2&&(writing||fit13_mock::executable>=2),"fallback retains libnx permission transitions");
    peer.close();cleanup();
}
int main(int argc,char** argv){
    if(argc!=2)return 2;const std::string test=argv[1];
    if(test=="capacity")capacity();else if(test=="publish")publish();else if(test=="cross"){cross_words(3);cross_words(64);}
    else if(test=="slice")max_slice();else if(test=="budget")budget();
    else if(test=="writefail")fallback(true);else if(test=="execfail")fallback(false);else return 2;
    std::cout<<"PASS Fit23 arena "<<test<<" arch="<<jit236::architecture()<<'\n';
}
