import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Graphics;

public class FinishedThreadStateChecks extends Canvas implements Runnable {
    public static int completed;
    public void paint(Graphics g) {}
    public void run() { ++completed; }
    public static int finishNested() throws InterruptedException {
        Thread worker = new Thread(new FinishedThreadStateChecks());
        worker.start();
        worker.join();
        return completed;
    }
}
