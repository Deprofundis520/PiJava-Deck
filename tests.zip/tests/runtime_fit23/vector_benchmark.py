#!/usr/bin/env python3
"""Alternate frozen baseline/candidate original-JAR world-update workloads.

Build first with run_vector_checks.py --optimize --build-only. Stop unrelated
CPU work before invoking this script. Results describe host fixed work on
constructed valid original-game objects; they are not natural-scene Switch FPS.
"""
import argparse
import hashlib
import json
import resource
import statistics
import subprocess
import time
from pathlib import Path


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for label in ['baseline', 'candidate']:
        parser.add_argument('--' + label + '-source', type=Path, required=True)
        parser.add_argument('--' + label + '-build', type=Path, required=True)
    parser.add_argument('--jar', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--rounds', type=int, default=5)
    parser.add_argument('--repeats', type=int, default=3)
    parser.add_argument('--exclusive-agent-cpu', action='store_true', help='record that all collaborating agents paused heavy work')
    args = parser.parse_args()
    if not 2 <= args.rounds <= 10 or not 1 <= args.repeats <= 10:
        parser.error('rounds must be 2..10 and repeats 1..10')
    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=True)
    builds = {label: getattr(args, label + '_build').resolve() for label in ['baseline', 'candidate']}
    sources = {label: getattr(args, label + '_source').resolve() for label in builds}
    jar = args.jar.resolve()
    identities = {str(jar): sha(jar), str(Path(__file__).resolve()): sha(Path(__file__).resolve())}
    for build in builds.values():
        identities[str(build / 'vector-vm-checks')] = sha(build / 'vector-vm-checks')
        identities[str(build / 'input-sha256.json')] = sha(build / 'input-sha256.json')
        identities.update(json.loads((build / 'input-sha256.json').read_text()))
    assert all(sha(Path(path)) == digest for path, digest in identities.items()), 'A build input changed before timings'
    (out / 'provenance.json').write_text(json.dumps({'sha256': identities, 'exclusive_agent_cpu': args.exclusive_agent_cpu,
        'rounds': args.rounds, 'warm_trials_per_process': args.repeats,
        'scope': 'original full CWAWorld.update, constructed original objects, inactive sprite actions; no rendering or natural scene',
        'timed_work': '40 updates per trial plus identical input reset and value verification',
        'comparability': 'host fixed work only; not a Switch FPS prediction'}, indent=2) + '\n')
    records = []
    for round_number in range(args.rounds):
        for engine in ['fast', 'jit']:
            order = ['baseline', 'candidate'] if round_number % 2 == 0 else ['candidate', 'baseline']
            for label in order:
                build = builds[label]
                command = [str(build / 'vector-vm-checks'), str(build / 'classes'), str(sources[label] / 'romfs/classes'), engine, 'world', str(jar), str(args.repeats)]
                before = resource.getrusage(resource.RUSAGE_CHILDREN)
                started = time.monotonic()
                result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=120)
                elapsed = (time.monotonic() - started) * 1000
                after = resource.getrusage(resource.RUSAGE_CHILDREN)
                log = out / f'{round_number}-{engine}-{label}.log'
                log.write_text(result.stdout)
                if result.returncode or 'PASS Vector scenario=world' not in result.stdout:
                    raise SystemExit('Fixed workload failed: ' + str(log) + '\n' + result.stdout[-5000:])
                rows = []
                for line in result.stdout.splitlines():
                    if line.startswith('WORLD '):
                        data = dict(item.split('=', 1) for item in line.split()[1:])
                        rows.append({key: float(value) if key == 'ms' else int(value) for key, value in data.items()})
                assert len(rows) == args.repeats + 1 and all(row['profile'] == 0 for row in rows), 'Unprofiled cold and warm trials required'
                record = {'round': round_number, 'engine': engine, 'variant': label, 'command': command, 'log': str(log), 'rows': rows,
                          'warm_median_ms': statistics.median(row['ms'] for row in rows if row['trial'] > 0),
                          'process_cpu_ms': ((after.ru_utime + after.ru_stime) - (before.ru_utime + before.ru_stime)) * 1000,
                          'process_elapsed_ms': elapsed}
                records.append(record)
                (out / 'records.json').write_text(json.dumps(records, indent=2) + '\n')
                print(round_number, engine, label, 'warm_median_ms', record['warm_median_ms'], flush=True)
    rows = [row for record in records for row in record['rows']]
    assert len({row['checksum'] for row in rows}) == 1, 'Original actor-state checksum changed'
    assert {row['updates'] for row in rows} == {40} and {row['actors'] for row in rows} == {144}, 'Fixed work changed'
    assert len({row['fast'] + row['slow'] + row['jitops'] for row in rows}) == 1, 'Complete original operation total changed'
    summary = {'checksum': rows[0]['checksum'], 'updates_per_trial': 40, 'actors': 144,
               'all_engine_original_ops_per_trial': rows[0]['fast'] + rows[0]['slow'] + rows[0]['jitops'], 'engines': {}}
    for engine in ['fast', 'jit']:
        samples = {label: [record['warm_median_ms'] for record in records if record['engine'] == engine and record['variant'] == label] for label in builds}
        ratios = [a / b for a, b in zip(samples['baseline'], samples['candidate'])]
        summary['engines'][engine] = {'baseline_warm_ms': statistics.median(samples['baseline']), 'candidate_warm_ms': statistics.median(samples['candidate']),
                                      'paired_speedup_median': statistics.median(ratios), 'paired_speedup_min': min(ratios), 'paired_speedup_max': max(ratios),
                                      'all_pairs_faster': min(ratios) > 1, 'process_medians_ms': samples}
    assert all(sha(Path(path)) == digest for path, digest in identities.items()), 'Recorded binary or workload input changed during timings'
    (out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary, indent=2), flush=True)


if __name__ == '__main__':
    main()
