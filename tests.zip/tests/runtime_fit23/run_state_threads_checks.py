#!/usr/bin/env python3
"""Compile actual production VM and exercise J2S5 finished-thread compatibility."""
import argparse, hashlib, json, subprocess
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--source',type=Path);p.add_argument('--hero',type=Path);p.add_argument('--hero-legacy',type=Path);p.add_argument('--sanitize',action='store_true');p.add_argument('--build-only',action='store_true');a=p.parse_args()
if a.hero_legacy and not a.hero:p.error('--hero-legacy requires --hero')
here=Path(__file__).resolve().parent;source=(a.source or here.parents[1]).resolve();out=a.output.resolve();out.mkdir(parents=True,exist_ok=True);classes=out/'classes';classes.mkdir(exist_ok=True)
flags=['-O1' if a.sanitize else '-O0','-g0']+(['-fsanitize=undefined','-fno-sanitize-recover=all'] if a.sanitize else [])
defines=[f'-D{k}="{source/v}"' for k,v in [('J2ME_TEST_VM','src/j2mevm.cpp'),('J2ME_TEST_STATE','src/instant_state.inc'),('J2ME_TEST_HOST_MENU','src/host_menu.h'),('J2ME_TEST_HOST_SPEED','src/host_speed.h')]]
commands=[['java','-m','jdk.compiler/com.sun.tools.javac.Main','-source','8','-target','8','-bootclasspath',str(source/'romfs/classes'),'-classpath',str(source/'romfs/classes'),'-d',str(classes),str(here/'FinishedThreadStateChecks.java'),str(here/'MixedThreadStateChecks.java')],['gcc',*flags,'-c',str(source/'src/puff.c'),'-o',str(out/'puff.o')],['g++',*flags,'-std=c++17','-fno-exceptions','-ffunction-sections','-fdata-sections',*defines,str(here/'state_threads_checks.cpp'),str(out/'puff.o'),'-Wl,--gc-sections','-pthread','-ldl','-o',str(out/'state-threads-checks')]]
inputs={str(path):hashlib.sha256(path.read_bytes()).hexdigest() for path in [*(source/'src').rglob('*'),*here.glob('*.cpp'),*here.glob('*.java')] if path.is_file()}
(out/'inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
if not a.build_only:
    for engine in ['fast','jit']:
        for mode in ['fresh','legacy','mixed','malformed']:
            commands.append([str(out/'state-threads-checks'),mode,str(classes),str(source/'romfs/classes'),str(out),engine,str(here/'fixtures/finished-thread-fit22.j2s')])
    if a.hero:
        for engine in ['fast','jit']:
            for cap in [0,30,60]:
                dest=out/f'hero-{engine}-{cap}';dest.mkdir(exist_ok=True)
                commands.append([str(out/'state-threads-checks'),'hero',str(classes),str(source/'romfs/classes'),str(dest),engine,str(a.hero.resolve()),str(cap)])
                if a.hero_legacy:
                    legacy=out/f'hero-legacy-{engine}-{cap}';legacy.mkdir(exist_ok=True)
                    commands.append([str(out/'state-threads-checks'),'hero-legacy',str(classes),str(source/'romfs/classes'),str(legacy),engine,str(a.hero.resolve()),str(a.hero_legacy.resolve()),str(cap)])
records=[]
for i,command in enumerate(commands):
    r=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=300);(out/f'step-{i}.log').write_bytes(r.stdout)
    records.append({'command':command,'returncode':r.returncode});(out/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print('step',i,'returncode',r.returncode,flush=True)
    if r.returncode:raise SystemExit(r.stdout.decode(errors='replace')[-6000:])
    if i>=3:print('\n'.join(x for x in r.stdout.decode(errors='replace').splitlines() if x.startswith('PASS')),flush=True)
