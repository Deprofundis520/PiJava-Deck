// Real VM + real filesystem. Link wrappers only count directory metadata calls
// and inject an inspection error; commit/read/rollback paths are production.
#define main emulator_main
#ifndef FIT23_RMS_VM
#define FIT23_RMS_VM "../../src/j2mevm.cpp"
#endif
#include FIT23_RMS_VM
#undef main
#include <filesystem>
#include <unistd.h>

static std::string directory, parent_directory, suite_directory;
static unsigned dir_stats=0, dir_mkdirs=0, checks=0;
static int suite_stat_error=0;
extern "C" int __real_stat(const char*, struct stat*);
extern "C" int __real_mkdir(const char*, mode_t);
static bool tracked(const char* path) {
    return directory == path || parent_directory == path || suite_directory == path;
}
extern "C" int __wrap_stat(const char* path, struct stat* st) {
    if(tracked(path)) ++dir_stats;
    if(suite_stat_error && suite_directory == path) { errno=suite_stat_error; return -1; }
    return __real_stat(path,st);
}
extern "C" int __wrap_mkdir(const char* path, mode_t mode) {
    if(tracked(path)) ++dir_mkdirs;
    return __real_mkdir(path,mode);
}
static void require(bool ok,const char* reason) {
    ++checks;if(!ok){std::cerr<<"FAIL "<<reason<<" checks="<<checks<<'\n';std::exit(1);}
}
static int invoke(const char* name) {
    Method* m=find_method(ensure_class("RmsDirectoryChecks"),name,"()I",false);
    require(m,"Java fixture method exists");const int result=run(m,{}).i;
    require(!VMS_EXEC(g_thrown),"no uncaught exception");return result;
}
static void reset_counts() { dir_stats=dir_mkdirs=0; }
int main(int argc,char** argv) {
    const std::string classes=argc>1?argv[1]:"build/test-classes";
    const std::string library=argc>2?argv[2]:"romfs/classes";
    char temp[]="/tmp/fit23-rms-directory-XXXXXX";
    char* made=mkdtemp(temp);require(made,"temporary root created");
    const std::string root=made;directory=root+"/data";parent_directory=directory+"/suites";
    require(setenv("J2ME_RMS_DIR",directory.c_str(),1)==0,"isolated RMS root configured");
    VMS_CL(g_classpath)={classes,library};VMS_DIAG(g_log_draw)=false;
    VMS_NATIVE(g_native_jit).configure(argc>3 && std::string(argv[3])=="jit");
    VMS_PLAT(g_rms_suite)=rms_class_identity("RmsDirectoryChecks",{});
    suite_directory=parent_directory+"/"+VMS_PLAT(g_rms_suite);
    require(invoke("populate")==1,"absent hierarchy is created and content committed");
    reset_counts();for(int i=0;i<10;++i)require(invoke("read")==1,"ten independent opens preserve content");
    std::cout<<"DIRECTORY_META reads=10 stat="<<dir_stats<<" mkdir="<<dir_mkdirs<<'\n';
    require(dir_mkdirs==0,"existing complete hierarchy performs no repeated mkdir");
    require(dir_stats==10,"existing hierarchy needs one fresh directory inspection per native call");
    reset_counts();require(invoke("write")==1 && invoke("read")==1,"synchronous write then reopen sees bytes");
    require(dir_mkdirs==0 && dir_stats==3,"load/save/load each validates the existing suite once");
    reset_counts();require(invoke("list")==1,"catalog contents unchanged");
    require(dir_mkdirs==0 && dir_stats==1,"listing shares the directory fast path");

    for(int error : {EIO,EACCES}) {
        suite_stat_error=error;reset_counts();require(invoke("read")==-1,"inspection failure remains a checked RMS error");
        require(dir_mkdirs==0 && dir_stats==1,"inspection error never authorizes creation");
        require(invoke("list")==-1,"listing fails conservatively on inspection error");
        suite_stat_error=0;require(invoke("read")==1,"inspection error does not damage stored bytes");
    }
    const std::string backup=suite_directory+"-kept";
    require(std::rename(suite_directory.c_str(),backup.c_str())==0,"move actual suite temporarily");
    {std::ofstream f(suite_directory,std::ios::binary);f<<"not a directory";require(bool(f),"create non-directory path");}
    reset_counts();require(invoke("read")==-1,"non-directory suite rejected");
    require(dir_mkdirs==0 && dir_stats==1,"non-directory suite is not cached or recreated");
    require(std::remove(suite_directory.c_str())==0,"remove invalid path");
    require(std::rename(backup.c_str(),suite_directory.c_str())==0,"restore actual suite");
    require(invoke("read")==1,"original state survives path replacement");

    // Deletion or switching to another suite cannot be hidden by a stale cache.
    require(std::rename(suite_directory.c_str(),backup.c_str())==0,"move suite again");
    reset_counts();require(invoke("populate")==1,"missing suite is recreated through original slow path");
    require(dir_mkdirs>0,"absent hierarchy uses creation path");
    require(invoke("read")==1,"recreated suite is usable");
    VMS_PLAT(g_rms_suite)=rms_class_identity("RmsDirectoryOther",{});
    suite_directory=parent_directory+"/"+VMS_PLAT(g_rms_suite);
    require(invoke("populate")==1 && invoke("read")==1,"new suite gets its own hierarchy");
    require(g_gc_sp.violations==0,"no illegal GC safepoint");
    jit_region_reset();VMS_NATIVE(g_native_jit).clear();
    std::filesystem::remove_all(root);
    std::cout<<"PASS RmsDirectory checks="<<checks<<" sync_commit_preserved=1 inspection_cache=none\n";
}
