import javax.microedition.rms.RecordStore;
import javax.microedition.rms.RecordStoreException;

public final class RmsDirectoryChecks {
    public static int populate() throws RecordStoreException {
        RecordStore rs = RecordStore.openRecordStore("Fit23Directory", true);
        if (rs.getNumRecords() == 0) rs.addRecord(new byte[]{17, 29, 41}, 0, 3);
        int count = rs.getNumRecords();
        rs.closeRecordStore();
        return count;
    }
    public static int read() {
        try {
            RecordStore rs = RecordStore.openRecordStore("Fit23Directory", false);
            byte[] b = rs.getRecord(1);
            rs.closeRecordStore();
            return b.length == 3 && b[0] == 17 && b[1] == 29 && b[2] == 41 ? 1 : 0;
        } catch (RecordStoreException expected) { return -1; }
    }
    public static int write() throws RecordStoreException {
        RecordStore rs = RecordStore.openRecordStore("Fit23Directory", false);
        rs.setRecord(1, new byte[]{17, 29, 41}, 0, 3);
        rs.closeRecordStore();
        return 1;
    }
    public static int list() { String[] names = RecordStore.listRecordStores(); return names == null ? -1 : names.length; }
}
