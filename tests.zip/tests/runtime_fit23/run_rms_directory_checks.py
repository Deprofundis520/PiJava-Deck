#!/usr/bin/env python3
"""Build the actual VM and count real RMS directory syscalls; no timing claim."""
import argparse, hashlib, json, subprocess
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--source',type=Path);p.add_argument('--output',type=Path,required=True);p.add_argument('--sanitize',action='store_true');a=p.parse_args()
here=Path(__file__).resolve().parent;root=here.parents[1];src=(a.source or root).resolve();out=a.output.resolve();out.mkdir(parents=True,exist_ok=True);classes=out/'classes';classes.mkdir(exist_ok=True)
flags=['-O1' if a.sanitize else '-O0','-g0']+(['-fsanitize=undefined','-fno-sanitize-recover=all'] if a.sanitize else [])
commands=[['java','-m','jdk.compiler/com.sun.tools.javac.Main','-source','8','-target','8','-bootclasspath',str(src/'romfs/classes'),'-classpath',str(src/'romfs/classes'),'-d',str(classes),str(here/'RmsDirectoryChecks.java')],['gcc',*flags,'-c',str(src/'src/puff.c'),'-o',str(out/'puff.o')],['g++',*flags,'-std=c++17','-fno-exceptions','-ffunction-sections','-fdata-sections','-DFIT23_RMS_VM="'+str(src/'src/j2mevm.cpp')+'"',str(here/'rms_directory_checks.cpp'),str(out/'puff.o'),'-Wl,--gc-sections','-Wl,--wrap=stat','-Wl,--wrap=mkdir','-pthread','-ldl','-o',str(out/'rms-directory-checks')]]
commands += [[str(out/'rms-directory-checks'),str(classes),str(src/'romfs/classes'),mode] for mode in ['fast','jit']]
ident={str(x.relative_to(src)):hashlib.sha256(x.read_bytes()).hexdigest() for x in (src/'src').rglob('*') if x.is_file()}
(out/'inputs.json').write_text(json.dumps({'source':str(src),'sha256':ident,'test_sha256':hashlib.sha256((here/'rms_directory_checks.cpp').read_bytes()).hexdigest()},indent=2))
records=[]
for i,cmd in enumerate(commands):
 r=subprocess.run(cmd,capture_output=True,timeout=300);(out/f'step-{i}.log').write_bytes(r.stdout+r.stderr);records.append({'command':cmd,'returncode':r.returncode});(out/'commands.json').write_text(json.dumps(records,indent=2));print('step',i,'rc',r.returncode,flush=True)
 if r.returncode:print((r.stdout+r.stderr).decode(errors='replace')[-4000:]);raise SystemExit(r.returncode)
 if i>=3:print(r.stdout.decode(errors='replace'),end='')
