// Standalone proposal: real leaf Engine + finite libnx boundary only.
// Regression: a CE01-rejected Site must regain eligibility after independent
// retirement progress, without clearing the Engine or evicting healthy code.
// Build/run: ./run-jit-retry.ps1 (Windows) or see run-jit-retry.sh (Linux CI).
#ifndef J2ME_TEST_JIT_HEADER
#define J2ME_TEST_JIT_HEADER "../../src/native_jit236.h"
#endif
#include J2ME_TEST_JIT_HEADER
#include <cstdlib>
#include <iostream>
#include <vector>

namespace jit236 {
struct EngineTestAccess {
    static Executable& code(Engine& engine, const Site& site) {
        return engine.entries_[static_cast<size_t>(site.entry)].code;
    }
};
}

static void check(bool ok, const char* message) {
    if (ok) return;
    const auto& pool = jit236::code_pool_stats();
    std::cerr << "FAIL " << message << " result=" << jit236::Executable::last_result()
              << " blocks=" << pool.blocks << " slices=" << pool.slices
              << " quarantine=" << pool.quarantined_pages
              << " releases=" << pool.quarantine_releases
              << " native_live=" << fit13_mock::live
              << " creates=" << fit13_mock::creates << " closes=" << fit13_mock::closes << '\n';
    std::exit(1);
}

static constexpr size_t pages_per_block = jit236::CodeBlockBytes / jit236::CodePage;
static const uint8_t bytecode[] = {26, 4, 96, 172}; // (I)I: arg + 1; exactly 4 operations
static const std::string descriptor = "(I)I";
static jit236::Spec spec() {
    return {bytecode, sizeof(bytecode), &descriptor, 8, 1, 2, false, false, nullptr};
}
static std::vector<uint8_t> code(uint32_t id) {
    jit236::Program program;
    check(jit236::verify(spec(), program), "fixture verifies");
    auto bytes = jit236::emit_host(program, id);
    check(!bytes.empty() && bytes.size() <= jit236::CodePage, "fixture occupies one page");
    return bytes;
}
static bool heat(jit236::Engine& engine, jit236::Site& site) {
    for (unsigned i = 0; i <= jit236::Engine::HotThreshold; ++i)
        if (engine.prepare(site, spec())) return true;
    return false;
}
static uint64_t invoke(jit236::Executable& executable, uint32_t expected) {
    check(executable.executable(), "invoke only a live executable");
    int32_t args[jit236::StaleIdSlot + 1]{};
    args[0] = 41;
    args[jit236::StaleIdSlot] = static_cast<int32_t>(expected);
    const auto before = std::vector<int32_t>(args, args + jit236::StaleIdSlot + 1);
    uint64_t value;
    {
        jit236::CodeCall active;
#if defined(_WIN32) && defined(__x86_64__)
        // Production x64 emitter uses SysV, while MinGW defaults to MS ABI.
        using HostFn = uint64_t (__attribute__((sysv_abi)) *)(const int32_t*);
        value = reinterpret_cast<HostFn>(executable.fn)(args);
#else
        value = executable.fn(args);
#endif
    }
    check(std::equal(before.begin(), before.end(), args), "compiled leaf preserves all arguments");
    return value;
}
static void runs(jit236::Engine& engine, const jit236::Site& site) {
#if defined(_WIN32) && defined(__x86_64__)
    const auto value = invoke(jit236::EngineTestAccess::code(engine, site),
                              jit236::EngineTestAccess::code(engine, site).id);
    check(uint32_t(value) == 42 && uint32_t(value >> 32) == 4,
          "healthy Engine executable returns exact result 42 and cost 4 (SysV adapter)");
#else
    int32_t arg = 41, result = -7;
    unsigned ops = 0;
    check(engine.call(site, &arg, 1, 100, result, ops) && result == 42 && ops == 4 && arg == 41,
          "real Engine.call returns exact result 42 and cost 4");
#endif
}
static void guard(jit236::Executable& executable, uint32_t wrong_id) {
    check(wrong_id != executable.id, "guard probe uses a mismatched install id");
    const auto stale = invoke(executable, wrong_id);
    check(jit236::stale_result(stale) && uint32_t(stale) == executable.id,
          "install-id mismatch exits before Java body and reports current id");
}
static void accounting() {
    const auto& pool = jit236::code_pool_stats();
    check(pool.blocks == fit13_mock::live && pool.blocks <= fit13_mock::limit &&
          pool.blocks <= jit236::CodePoolMaxBlocks && fit13_mock::peak <= fit13_mock::limit,
          "real pool respects native resource ceiling and configured cap");
    check(pool.used_bytes <= pool.blocks * jit236::CodeBlockBytes,
          "live bytes fit owned backing blocks");
}

int main() {
    fit13_mock::limit = 1; // Test policy, not a Horizon resource-limit claim.
    jit236::Engine engine;
    // Skip Dedicated startup selftest so the single block belongs to game code.
    engine.enabled = engine.available = true;
    std::vector<jit236::Executable> fillers(pages_per_block - 1);
    for (auto& filler : fillers) {
        const uint32_t id = jit236::next_install_id();
        check(filler.install(code(id), id), "one-page filler installs");
    }
    jit236::Site healthy;
    check(heat(engine, healthy), "real Engine prepares healthy final page");
    const uint64_t epoch = engine.epoch();
    const int healthy_entry = healthy.entry;
    const auto healthy_id = jit236::EngineTestAccess::code(engine, healthy).id;
    const auto healthy_fn = jit236::EngineTestAccess::code(engine, healthy).fn;
    const auto entries = engine.entries();
    const auto bytes = engine.bytes();
    const auto& pool = jit236::code_pool_stats();
    check(pool.blocks == 1 && pool.slices == pages_per_block && pool.used_bytes == jit236::CodeBlockBytes &&
          pool.quarantined_pages == 0 && fit13_mock::creates == 1,
          "fillers and healthy Engine leaf fill every page in one block");
    runs(engine, healthy);
    guard(jit236::EngineTestAccess::code(engine, healthy), healthy_id ^ 0x01010101u);
    accounting();

    jit236::Site failed;
    const unsigned before_failure = fit13_mock::creates;
    check(!heat(engine, failed) && engine.admission_closed && failed.entry == -2,
          "second hot Engine leaf fails and closes admission");
    check(jit236::Executable::last_result() == fit13_mock::OutOfResource &&
          fit13_mock::creates == before_failure + 1,
          "initial install records CE01 with one bounded native allocation attempt");
    const unsigned paused_creates = fit13_mock::creates;
    jit236::Site paused;
    for (unsigned i = 0; i < 10000; ++i) {
        check(!engine.prepare(failed, spec()), "failed candidate remains paused without progress");
        check(!engine.prepare(paused, spec()), "new candidate remains paused without progress");
    }
    check(fit13_mock::creates == paused_creates && engine.epoch() == epoch &&
          engine.entries() == entries && engine.bytes() == bytes,
          "10000 no-progress rounds do not allocate or reset healthy Engine state");
    runs(engine, healthy);
    std::cout << "PASS prerequisites healthy=42 cost=4 epoch=" << epoch
              << " no_progress_rounds=10000 creates=" << fit13_mock::creates
              << " paused_site=" << paused.entry << std::endl;

    // Independent resource progress: retire one filler, keeping the other
    // fillers and healthy leaf live. The backing block cannot close.
    const uint32_t retired_id = fillers.front().id;
    const unsigned closes = fit13_mock::closes;
    const size_t q = pool.quarantined_pages;
    fillers.front().close();
    check(pool.quarantined_pages == q + 1 && pool.slices == pages_per_block - 1 &&
          fit13_mock::closes == closes && pool.blocks == 1,
          "one independent retirement enters quarantine without evicting live peers");
    const unsigned before_retry = fit13_mock::creates;
    const bool recovered = engine.prepare(failed, spec());
    check(fit13_mock::creates <= before_retry + 2 && fit13_mock::closes == closes,
          "retirement recovery is bounded and preserves mixed-live backing");
    check(engine.epoch() == epoch && healthy.entry == healthy_entry &&
          jit236::EngineTestAccess::code(engine, healthy).id == healthy_id &&
          jit236::EngineTestAccess::code(engine, healthy).fn == healthy_fn,
          "recovery preserves epoch and healthy executable identity");
    runs(engine, healthy);
    guard(jit236::EngineTestAccess::code(engine, healthy), healthy_id ^ 0x01010101u);
    accounting();
    std::cout << "OBSERVED after_retirement recovered=" << recovered
              << " admission_closed=" << engine.admission_closed << " failed_site=" << failed.entry
              << " creates_delta=" << fit13_mock::creates - before_retry
              << " quarantine=" << pool.quarantined_pages << " epoch=" << engine.epoch() << std::endl;
    check(recovered, "TARGET: same failed Site retries after independent retirement in the same epoch");

    check(!engine.admission_closed && engine.entries() == entries + 1 &&
          engine.bytes() == bytes + jit236::CodePage && pool.slices == pages_per_block && pool.quarantined_pages == q,
          "successful recovery publishes exactly one leaf using the retired Normal page");
    runs(engine, failed);
    // Probe the currently live replacement with the retired install id; never
    // dereference the old closed filler pointer to test stale protection.
    guard(jit236::EngineTestAccess::code(engine, failed), retired_id);
    const unsigned recovered_creates = fit13_mock::creates;
    for (unsigned i = 0; i < 10000; ++i)
        check(engine.prepare(failed, spec()), "recovered candidate remains ready");
    check(fit13_mock::creates == recovered_creates, "ready candidate does not allocate again");
    accounting();
    engine.clear();
    fillers.clear();
    while (!jit236::code_quarantine().empty()) jit236::release_oldest_quarantine();
    check(!pool.blocks && !pool.slices && !pool.used_bytes && !fit13_mock::live,
          "all test resources close exactly once");
    std::cout << "PASS same_epoch_retry real_engine=1 finite_libnx_mock=1 host="
              << jit236::architecture() << '\n';
}
