// Standalone real Engine/pool tests with the existing finite libnx mock.
// Run each named scenario in a fresh process; never change production sources.
#ifndef J2ME_TEST_JIT_HEADER
#define J2ME_TEST_JIT_HEADER "../../src/native_jit236.h"
#endif
#include J2ME_TEST_JIT_HEADER
#include "../jit_small_arena_fixture.h"
#include <cstdlib>
#include <iostream>
#include <vector>

namespace jit236 {
struct EngineTestAccess {
    static Executable& code(Engine& engine, const Site& site) {
        return engine.entries_[static_cast<size_t>(site.entry)].code;
    }
};
}
static void check(bool ok, const char* why) {
    if (ok) return;
    const auto& pool = jit236::code_pool_stats();
    std::cerr << "FAIL JitRetryBackoff " << why << " result=" << jit236::Executable::last_result()
              << " creates=" << fit13_mock::creates << " closes=" << fit13_mock::closes
              << " blocks=" << pool.blocks << " slices=" << pool.slices
              << " q=" << pool.quarantined_pages << " retirement=" << jit236::retirement_sequence() << std::endl;
    std::exit(1);
}
static constexpr size_t pages_per_block = jit236::CodeBlockBytes / jit236::CodePage;
static const uint8_t bytecode[] = {26, 4, 96, 172};
static const std::string descriptor = "(I)I";
static jit236::Spec spec() {
    return {bytecode, sizeof(bytecode), &descriptor, 8, 1, 2, false, false, nullptr};
}
static std::vector<uint8_t> code(uint32_t id) {
    jit236::Program p;
    check(jit236::verify(spec(), p), "fixture verifies");
    auto bytes = jit236::emit_host(p, id);
    check(!bytes.empty() && bytes.size() <= jit236::CodePage, "fixture needs one page");
    return bytes;
}
static void install(jit236::Executable& executable, bool whole_block = false) {
    const uint32_t id = jit236::next_install_id();
    auto bytes = code(id);
    if (whole_block) bytes.resize(262144, 0);
    check(executable.install(bytes, id), "real filler installs");
}
static bool heat(jit236::Engine& engine, jit236::Site& site, const jit236::Spec& input = spec()) {
    for (unsigned i = 0; i <= jit236::Engine::HotThreshold; ++i)
        if (engine.prepare(site, input)) return true;
    return false;
}
static void runs(jit236::Engine& engine, const jit236::Site& site) {
#if defined(_WIN32) && defined(__x86_64__)
    auto& executable = jit236::EngineTestAccess::code(engine, site);
    int32_t args[jit236::StaleIdSlot + 1]{};
    args[0] = 41;
    args[jit236::StaleIdSlot] = static_cast<int32_t>(executable.id);
    uint64_t value;
    {
        jit236::CodeCall active;
        using HostFn = uint64_t (__attribute__((sysv_abi)) *)(const int32_t*);
        value = reinterpret_cast<HostFn>(executable.fn)(args);
    }
    check(uint32_t(value) == 42 && uint32_t(value >> 32) == 4 && args[0] == 41,
          "real executable returns 42/cost4 through Windows SysV adapter");
#else
    int32_t arg = 41, result = -7;
    unsigned ops = 999;
    check(engine.call(site, &arg, 1, 100, result, ops) && result == 42 && ops == 4 && arg == 41,
          "real Engine.call returns 42/cost4");
#endif
}
static void accounting() {
    const auto& pool = jit236::code_pool_stats();
    check(pool.blocks == fit13_mock::live && pool.blocks <= fit13_mock::limit &&
          fit13_mock::peak <= fit13_mock::limit && pool.reserved_bytes <= jit236::CodePoolMaxBytes &&
          pool.used_bytes <= pool.reserved_bytes,
          "pool respects real ownership and configured finite caps");
}
static void cleanup(jit236::Engine& engine) {
    engine.clear();
    while (!jit236::code_quarantine().empty()) jit236::release_oldest_quarantine();
    const auto& pool = jit236::code_pool_stats();
    check(!pool.blocks && !pool.slices && !pool.used_bytes && !pool.reserved_bytes && !fit13_mock::live,
          "all resources close exactly once");
}
static void paused_rounds(jit236::Engine& engine, jit236::Site& failed) {
    const unsigned creates = fit13_mock::creates;
    const auto failures = engine.stats.permission_failures;
    const auto reopens = engine.stats.resource_reopens;
    jit236::Site other;
    for (unsigned i = 0; i < 10000; ++i) {
        check(!engine.prepare(failed, spec()) && !engine.prepare(other, spec()),
              "same and other candidates remain paused without independent progress");
        int32_t arg = 41, result = -7;
        unsigned ops = 999;
        check(!engine.call(failed, &arg, 1, 100, result, ops) && result == -7 && ops == 999,
              "paused Engine.call leaves result and cost untouched");
    }
    check(fit13_mock::creates == creates && engine.stats.permission_failures == failures &&
          engine.stats.resource_reopens == reopens && engine.admission_closed,
          "10000 no-progress rounds do not allocate, reopen or erase failure history");
}

static void backoff() {
    fit13_mock::limit = 1;
    jit236::Engine engine;
    engine.enabled = engine.available = true;
    // One slice occupies the whole block. With separate one-page slices,
    // Normal could reuse the first released page while q owns the other pages;
    // a forced jitCreate error would then correctly NOT force install failure.
    // One whole-block quarantine entry instead makes actual reclamation destroy
    // the backing, so the post-reclamation jitCreate must see forced CE01 too.
    auto arena = small_retry_arena(code(jit236::next_install_id()));
    check(bool(arena), "small whole-mapping backoff fixture allocates and publishes");
    jit236::Executable filler;
    install(filler, true);
    arena.reset();
    jit236::Site failed;
    check(!heat(engine, failed) && engine.resource_paused() && failed.entry == -2 &&
          engine.stats.permission_failures == 1 && jit236::Executable::last_result() == fit13_mock::OutOfResource,
          "initial exhausted Engine install records resource pause");
    const auto epoch = engine.epoch();
    const auto retirement = jit236::retirement_sequence();
    filler.close();
    check(jit236::retirement_sequence() == retirement + 1 &&
          jit236::code_pool_stats().quarantined_pages == 262144 / jit236::CodePage && fit13_mock::live == 1,
          "all occupied block pages retire into one real quarantine entry");
    fit13_mock::forced_error = fit13_mock::OutOfResource;
    const unsigned creates = fit13_mock::creates;
    const unsigned closes = fit13_mock::closes;
    check(!engine.prepare(failed, spec()), "one independently permitted recovery still fails native CE01");
    check(fit13_mock::creates == creates + 2 && fit13_mock::closes == closes + 1 &&
          !jit236::code_pool_stats().blocks && !jit236::code_pool_stats().quarantined_pages,
          "failed recovery actually reclaims backing and makes exactly two bounded create attempts");
    check(engine.resource_paused() && engine.stats.permission_failures == 2 &&
          engine.stats.resource_reopens == 1 && engine.epoch() == epoch,
          "failed retry records renewed pause and historical counters in the same epoch");
    paused_rounds(engine, failed);
    fit13_mock::forced_error = 0;
    const unsigned cleared_creates = fit13_mock::creates;
    paused_rounds(engine, failed);
    check(fit13_mock::creates == cleared_creates,
          "clearing external native error without pool retirement is not a retry token");

    // A real independent install/retirement creates the next opportunity.
    jit236::Executable independent;
    install(independent);
    const auto next_retirement = jit236::retirement_sequence();
    independent.close();
    check(jit236::retirement_sequence() == next_retirement + 1,
          "independent live slice retirement produces new resource progress");
    check(engine.prepare(failed, spec()) && !engine.admission_closed && engine.epoch() == epoch &&
          engine.stats.permission_failures == 2 && engine.stats.resource_reopens == 2,
          "only the later independent retirement recovers the original Site without clearing history");
    runs(engine, failed);
    accounting();
    std::cout << "PASS backoff no_progress_rounds=20000 failed_retry_create_delta=2 same_epoch=1 failures=2\n";
    cleanup(engine);
}

static void nonresource() {
    fit13_mock::limit = 1;
    jit236::Engine engine;
    engine.enabled = engine.available = true;
    std::vector<jit236::Executable> fillers(pages_per_block);
    for (auto& filler : fillers) install(filler);
    fit13_mock::forced_error = 0xd401;
    jit236::Site failed;
    const unsigned creates = fit13_mock::creates;
    check(!heat(engine, failed) && engine.admission_closed && !engine.resource_paused() &&
          !failed.resource_wait && engine.stats.permission_failures == 1 &&
          jit236::Executable::last_result() == 0xd401 && fit13_mock::creates == creates + 1,
          "D401 installation failure is permanent admission pause with one native attempt");
    const auto epoch = engine.epoch();
    const auto retirement = jit236::retirement_sequence();
    fillers.front().close();
    check(jit236::retirement_sequence() == retirement + 1,
          "real retirement occurs after the nonresource failure");
    fit13_mock::forced_error = 0;
    paused_rounds(engine, failed);
    check(engine.epoch() == epoch && engine.stats.permission_failures == 1 &&
          engine.stats.resource_reopens == 0 && !engine.resource_paused() && failed.entry == -2,
          "retirement and clearing D401 do not reopen nonresource failures or erase history");
    accounting();
    fillers.clear();
    cleanup(engine);
    std::cout << "PASS nonresource result=D401 no_progress_rounds=10000 reopens=0 failures=1\n";
}

static void normal_reuse() {
    fit13_mock::limit = 1;
    jit236::Engine engine;
    engine.enabled = engine.available = true;
    std::vector<jit236::Executable> fillers(pages_per_block);
    for (auto& filler : fillers) install(filler);
    jit236::Site failed;
    check(!heat(engine, failed) && engine.resource_paused(), "single-page control initially pauses at CE01");
    const auto epoch = engine.epoch();
    for (auto& filler : fillers) filler.close();
    check(jit236::code_quarantine().size() == pages_per_block && jit236::code_pool_stats().quarantined_pages == pages_per_block,
          "each single-page retirement has its own quarantine owner");
    fit13_mock::forced_error = fit13_mock::OutOfResource;
    const unsigned creates = fit13_mock::creates;
    const unsigned closes = fit13_mock::closes;
    const auto reused = jit236::code_pool_stats().reused_installs;
    check(engine.prepare(failed, spec()) && engine.epoch() == epoch && !engine.admission_closed &&
          engine.stats.permission_failures == 1,
          "Normal may recover a safely retired written page despite forced native create failure");
    check(fit13_mock::creates == creates + 1 && fit13_mock::closes == closes &&
          jit236::code_pool_stats().slices == 1 && jit236::code_pool_stats().quarantined_pages == pages_per_block - 1 &&
          jit236::code_pool_stats().reused_installs == reused + 1,
          "first released single page is reused while remaining quarantine owners preserve the backing");
    runs(engine, failed);
    accounting();
    fillers.clear();
    cleanup(engine);
    std::cout << "PASS normal-reuse single_page_retirements=" << pages_per_block << " create_delta=1 reused_written_page=1\n";
}

static void permanent() {
    fit13_mock::limit = 1;
    jit236::Engine engine;
    engine.enabled = engine.available = true;
    static const uint8_t invalid[] = {177}; // void return is structurally invalid for (I)I.
    auto bad = spec();
    bad.code = invalid;
    bad.size = sizeof(invalid);
    jit236::Site rejected;
    check(!heat(engine, rejected, bad) && rejected.entry == -2 && !rejected.resource_wait &&
          engine.stats.rejected == 1 && !engine.admission_closed && fit13_mock::creates == 0,
          "verifier rejection is permanent and does not close resource admission");
    std::vector<jit236::Executable> fillers(pages_per_block);
    for (auto& filler : fillers) install(filler);
    jit236::Site failed;
    check(!heat(engine, failed) && engine.resource_paused(), "different valid candidate enters resource wait");
    const auto epoch = engine.epoch();
    fillers.front().close();
    check(engine.prepare(failed, spec()), "valid resource-wait candidate recovers after independent progress");
    const unsigned creates = fit13_mock::creates;
    const auto compiled = engine.stats.compiled;
    for (unsigned i = 0; i < 10000; ++i)
        check(!engine.prepare(rejected, bad), "permanent structural rejection stays rejected after generation change");
    check(engine.stats.rejected == 1 && engine.stats.compiled == compiled && fit13_mock::creates == creates &&
          rejected.entry == -2 && !rejected.resource_wait && engine.epoch() == epoch,
          "resource reopening does not reverify or revive permanent sites");
    runs(engine, failed);
    accounting();
    fillers.clear();
    cleanup(engine);
    std::cout << "PASS permanent no_progress_rounds=10000 verifier_rejections=1 resource_candidate_recovers=1\n";
}

int main(int argc, char** argv) {
    if (argc != 2) { std::cerr << "scenario required: backoff nonresource permanent normal-reuse\n"; return 2; }
    const std::string scenario = argv[1];
    if (scenario == "backoff") backoff();
    else if (scenario == "nonresource") nonresource();
    else if (scenario == "permanent") permanent();
    else if (scenario == "normal-reuse") normal_reuse();
    else return 2;
    return 0;
}
