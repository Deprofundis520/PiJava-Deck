// Real VM contract tests. The runner makes a diagnostic j2mevm.cpp copy whose
// native_jit236.h include alone sees __SWITCH__; all other VM code stays Linux.
// No Java fixture files, JARs, user state, production field overrides or stubs.
#ifndef J2ME_TEST_VM
#error "Build with run-jit-retry-vm.py; J2ME_TEST_VM must select its diagnostic copy"
#endif
#define main emulator_main
#include J2ME_TEST_VM
#undef main

namespace jit236 {
struct EngineTestAccess {
    static Executable& code(Engine& engine, const Site& site) {
        return engine.entries_[static_cast<size_t>(site.entry)].code;
    }
};
}

static constexpr size_t pages_per_block = jit236::CodeBlockBytes / jit236::CodePage;
static void check(bool ok, const char* why) {
    if (ok) return;
    const auto& pool = jit236::code_pool_stats();
    std::cerr << "FAIL JitRetryVM " << why << " native_result=" << jit236::Executable::last_result()
              << " creates=" << fit13_mock::creates << " closes=" << fit13_mock::closes
              << " blocks=" << pool.blocks << " slices=" << pool.slices
              << " quarantine=" << pool.quarantined_pages
              << " admission_closed=" << VMS_NATIVE(g_native_jit).admission_closed
              << " epoch=" << VMS_NATIVE(g_native_jit).epoch() << std::endl;
    std::cout.flush();
    std::_Exit(1);
}

static int fixture_class() {
    Class cls;
    cls.name = "JitRetryVMFixture";
    cls.init_state = 2; // Synthetic class is already initialized, like invokestatic's admission contract.
    cls.cp.resize(2);
    cls.cp[1].tag = 3;
    cls.cp[1].a = 1;
    const int id = static_cast<int>(VMS_CL(g_classes).size());
    VMS_CL(g_classes).push_back(std::move(cls));
    VMS_CL(g_class_index)["JitRetryVMFixture"] = id;
    return id;
}
static Method method(int owner, const char* name, const char* desc,
                     std::vector<uint8_t> bytes, unsigned locals, unsigned stack) {
    Method m;
    m.class_id = owner;
    m.name = name;
    m.desc = desc;
    m.flags = 8;
    m.code = std::move(bytes);
    m.max_locals = static_cast<uint16_t>(locals);
    m.max_stack = static_cast<uint16_t>(stack);
    return m;
}
static std::vector<jit236::Executable> fill(unsigned count) {
    static const uint8_t bytecode[] = {26, 4, 96, 172};
    static const std::string descriptor = "(I)I";
    const jit236::Spec s{bytecode, sizeof(bytecode), &descriptor, 8, 1, 2, false, false, nullptr};
    jit236::Program program;
    check(jit236::verify(s, program), "one-page filler verifies");
    std::vector<jit236::Executable> fillers(count);
    for (auto& filler : fillers) {
        const auto id = jit236::next_install_id();
        const auto bytes = jit236::emit_host(program, id);
        check(!bytes.empty() && bytes.size() <= jit236::CodePage && filler.install(bytes, id),
              "one-page filler installs through real CodeSlice");
    }
    return fillers;
}
static void accounting() {
    const auto& pool = jit236::code_pool_stats();
    check(pool.blocks == fit13_mock::live && pool.blocks <= 1 && fit13_mock::peak <= 1 &&
          pool.blocks <= jit236::CodePoolMaxBlocks &&
          pool.used_bytes <= pool.blocks * jit236::CodeBlockBytes,
          "real pool stays within finite resource cap");
}
static void cleanup(std::vector<jit236::Executable>& fillers) {
    check(!jit236::active_code_calls(), "cleanup outside compiled execution");
    jit_region_reset();
    VMS_NATIVE(g_native_jit).clear();
    fillers.clear();
    while (!jit236::code_quarantine().empty()) jit236::release_oldest_quarantine();
    const auto& pool = jit236::code_pool_stats();
    check(!pool.blocks && !pool.slices && !pool.used_bytes && !fit13_mock::live,
          "all resources close exactly once");
}
static bool leaf_call(Method& m, Value& result, unsigned& ops, int32_t arg = 41) {
    const Value value = Value::of_i(arg);
    return jit_try_call(&m, &value, 1, 100, result, ops);
}
static void exact_leaf(Method& m, unsigned expected_ops) {
    Value result = Value::of_i(-7);
    unsigned ops = 999;
    check(leaf_call(m, result, ops) && result.i == 42 && !result.ref && !result.is_long && ops == expected_ops,
          "real jit_try_call returns exact result and operation count");
}

static void leaf_outer_retry() {
    fit13_mock::limit = 1; // Mock policy; not a real Horizon limit.
    auto& engine = VMS_NATIVE(g_native_jit);
    engine.enabled = engine.available = true; // Do not occupy the block with a Dedicated selftest.
    const int owner = fixture_class();
    Method healthy = method(owner, "healthy", "(I)I", {26, 4, 96, 172}, 1, 2);
    // Five operations: iload_0; ldc CP1 (Integer 1); iadd; nop; ireturn.
    Method failed = method(owner, "constant", "(I)I", {26, 18, 1, 96, 0, 172}, 1, 2);
    auto fillers = fill(pages_per_block - 1);
    Value result;
    unsigned ops = 0;
    for (unsigned i = 0; i <= jit236::Engine::HotThreshold; ++i)
        (void)leaf_call(healthy, result, ops);
    check(healthy.jit_site.entry >= 0, "healthy leaf enters through VM outer call");
    exact_leaf(healthy, 4);
    const uint64_t epoch = engine.epoch();
    const auto healthy_entry = healthy.jit_site.entry;
    const auto healthy_id = jit236::EngineTestAccess::code(engine, healthy.jit_site).id;
    const auto healthy_fn = jit236::EngineTestAccess::code(engine, healthy.jit_site).fn;
    const auto entries = engine.entries();
    const auto bytes = engine.bytes();
    const auto& pool = jit236::code_pool_stats();
    check(pool.blocks == 1 && pool.slices == pages_per_block && pool.used_bytes == jit236::CodeBlockBytes &&
          pool.quarantined_pages == 0 && fit13_mock::creates == 1,
          "fillers and real VM healthy leaf fill every page in one block");
    for (unsigned i = 0; i <= jit236::Engine::HotThreshold; ++i)
        check(!leaf_call(failed, result, ops), "second leaf falls back until its exhausted install");
    check(engine.admission_closed && failed.jit_site.entry == -2 &&
          jit236::Executable::last_result() == fit13_mock::OutOfResource,
          "VM outer leaf caches the native CE01 resource failure");
    const unsigned paused_creates = fit13_mock::creates;
    for (unsigned i = 0; i < 10000; ++i)
        check(!leaf_call(failed, result, ops), "negative cache remains paused without progress");
    check(fit13_mock::creates == paused_creates && engine.entries() == entries && engine.bytes() == bytes,
          "10000 outer leaf calls without progress do not allocate");
    exact_leaf(healthy, 4);
    accounting();

    const auto closes = fit13_mock::closes;
    fillers.front().close();
    check(pool.quarantined_pages == 1 && pool.slices == pages_per_block - 1 && fit13_mock::closes == closes,
          "independent filler retirement supplies a Normal reusable page");
    const unsigned retry_creates = fit13_mock::creates;
    result = Value::of_i(-7);
    ops = 999;
    const bool recovered = leaf_call(failed, result, ops);
    std::cout << "OBSERVED VM leaf recovered=" << recovered << " result=" << result.i << " ops=" << ops
              << " site=" << failed.jit_site.entry << " creates_delta=" << fit13_mock::creates - retry_creates
              << " quarantine=" << pool.quarantined_pages << std::endl;
    check(recovered && result.i == 42 && !result.ref && !result.is_long && ops == 5,
          "TARGET: jit_try_call re-arms original failed leaf and rebuilds Integer CP1 before prepare");
    check(VMS_CL(g_classes)[owner].cp[1].tag == 3 && VMS_CL(g_classes)[owner].cp[1].a == 1,
          "constant pool integer remains unchanged");
    check(engine.epoch() == epoch && healthy.jit_site.entry == healthy_entry &&
          jit236::EngineTestAccess::code(engine, healthy.jit_site).id == healthy_id &&
          jit236::EngineTestAccess::code(engine, healthy.jit_site).fn == healthy_fn &&
          engine.entries() == entries + 1 && engine.bytes() == bytes + jit236::CodePage,
          "outer recovery preserves epoch and exact healthy executable identity");
    check(fit13_mock::creates <= retry_creates + 2 && fit13_mock::closes == closes &&
          pool.quarantined_pages == 0 && pool.slices == pages_per_block,
          "outer leaf recovery is bounded and keeps all peers");
    exact_leaf(healthy, 4);
    exact_leaf(failed, 5);
    accounting();
    cleanup(fillers);
    std::cout << "PASS VM leaf outer_negative_cache=1 constant_pool=1 result=42 cost=5 same_epoch=1\n";
}

static void exact_loop(Method& loop) {
    const Value result = run(&loop, {});
    check(result.i == 1000 && !result.ref && !result.is_long && !VMS_EXEC(g_thrown) && VMS_EXEC(g_error).empty(),
          "real interpreter run returns int 1000 without exception");
}
static void region_outer_retry() {
    fit13_mock::limit = 1;
    auto& engine = VMS_NATIVE(g_native_jit);
    engine.enabled = engine.available = true;
    check(!VMS_EXEC(g_execution_profile).enabled, "normal interpreter path is selected");
    const int owner = fixture_class();
    // int n=0; do { ++n; } while (n<1000); return n;
    // PCs: 0 iconst_0, 1 istore_0, 2 iinc, 5 iload_0, 6 sipush 1000,
    // 9 if_icmplt -7 -> 2, 12 iload_0, 13 ireturn. Exactly 4004 Java ops.
    Method loop = method(owner, "count", "()I", {3, 59, 132, 0, 1, 26, 17, 3, 232, 161, 255, 249, 26, 172}, 1, 2);
    auto fillers = fill(pages_per_block);
    const uint64_t epoch = engine.epoch();
    for (unsigned i = 0; i < 200 && !engine.admission_closed; ++i) exact_loop(loop);
    check(engine.admission_closed && jit236::Executable::last_result() == fit13_mock::OutOfResource &&
          g_jit_region_stats.compiled == 0 && g_jit_region_stats.entries == 0,
          "real run reaches region install CE01 while all block-filling slices remain live");
    check(loop.jitr_skip_epoch == epoch, "region skip cache belongs to the same engine epoch");
    int resource_pc = -1;
    for (size_t pc = 0; pc < loop.jitr_skip.size(); ++pc)
        if (loop.jitr_skip[pc] == 2) { resource_pc = static_cast<int>(pc); break; }
    check(resource_pc >= 0, "actual region failure records a resource skip ticket");
    // A permanent marker on this method must survive the resource generation.
    // Return is an ordinary interpreter exit even when another PC is compiled.
    jitr_mark_skip(&loop, 13);
    check(loop.jitr_skip[13] == 1, "permanent region skip marker installed");
    const unsigned paused_creates = fit13_mock::creates;
    for (unsigned i = 0; i < 100; ++i) exact_loop(loop);
    check(fit13_mock::creates == paused_creates && loop.jitr_skip[resource_pc] == 2 && loop.jitr_skip[13] == 1,
          "repeated real run without progress preserves both skip reasons and does not allocate");
    accounting();

    const auto& pool = jit236::code_pool_stats();
    const unsigned closes = fit13_mock::closes;
    fillers.front().close();
    check(pool.quarantined_pages == 1 && pool.slices == pages_per_block - 1 && fit13_mock::closes == closes,
          "retirement progress does not destroy mixed-live backing");
    const unsigned retry_creates = fit13_mock::creates;
    exact_loop(loop); // Must pass the interpreter's real jitr_skipped() outer gate.
    std::cout << "OBSERVED VM region resource_pc=" << resource_pc
              << " compiled=" << g_jit_region_stats.compiled << " entries=" << g_jit_region_stats.entries
              << " ops=" << g_jit_region_stats.ops << " permanent_skip=" << unsigned(loop.jitr_skip[13])
              << " creates_delta=" << fit13_mock::creates - retry_creates << std::endl;
    check(g_jit_region_stats.compiled > 0 && g_jit_region_stats.entries > 0 && g_jit_region_stats.ops > 0,
          "TARGET: real run clears resource skip and executes recovered region");
    check(loop.jitr_skip[13] == 1 && loop.jitr_skip[resource_pc] != 2 && engine.epoch() == epoch,
          "resource recovery preserves permanent skip and engine epoch");
    check(!engine.admission_closed && fit13_mock::creates <= retry_creates + 2 && fit13_mock::closes == closes &&
          pool.slices == pages_per_block && pool.quarantined_pages == 0,
          "region recovery uses one retired page and preserves live filler peers");
    exact_loop(loop);
    accounting();
    cleanup(fillers);
    std::cout << "PASS VM region interpreter_skip_gate=1 result=1000 permanent_skip_preserved=1 same_epoch=1\n";
}

int main(int argc, char** argv) {
    if (argc != 2) { std::cerr << "scenario required: leaf region\n"; return 2; }
    const std::string scenario = argv[1];
    if (scenario == "leaf") leaf_outer_retry();
    else if (scenario == "region") region_outer_retry();
    else return 2;
    return 0;
}
