#!/usr/bin/env python3
"""Linux-only diagnostic build of real VM contracts; never changes the source tree.

Use --build-only, then record each <output>/jit_retry_vm_checks leaf|region with
the outer CI common.record helper to preserve its actual signed return code.
"""
import argparse
import hashlib
import os
from pathlib import Path
import shlex
import signal
import shutil
import subprocess
import sys


def exit_with_status(status):
    if status < 0:
        signum = -status
        signal.signal(signum, signal.SIG_DFL)
        os.kill(os.getpid(), signum)
    raise SystemExit(status)


def run(label, command, output):
    print(label + ': ' + shlex.join(map(str, command)), flush=True)
    completed = subprocess.run(list(map(str, command)), stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (output / (label + '.log')).write_bytes(completed.stdout)
    sys.stdout.buffer.write(completed.stdout)
    sys.stdout.buffer.flush()
    print(f'{label}_signedrc={completed.returncode}', flush=True)
    return completed.returncode


def main():
    here = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-root', type=Path, default=here.parent.parent)
    parser.add_argument('--output', type=Path, default=here / 'vm-linux')
    parser.add_argument('--build-only', action='store_true')
    parser.add_argument('--reuse-puff-from', type=Path, help='externally identity-verified Linux puff object')
    parser.add_argument('--case', choices=('all', 'leaf', 'region'), default='all')
    args = parser.parse_args()
    if not sys.platform.startswith('linux'):
        raise SystemExit('This runner needs Linux: real Engine.call/region use the SysV ABI; Windows is not adapted.')
    source = args.source_root.resolve()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    vm = source / 'src/j2mevm.cpp'
    original = vm.read_text(encoding='utf-8')
    needle = '#include "native_jit236.h"'
    if original.count(needle) != 1:
        raise SystemExit('Diagnostic boundary requires exactly one native_jit236.h include')
    diagnostic = output / 'j2mevm-jit-mock.cpp'
    hybrid=original.replace(needle, '#define __SWITCH__ 1\n' + needle + '\n#undef __SWITCH__')
    # The pool intentionally has the Switch fault switch (always zero), while
    # the rest of this TU uses Linux. Desktop-only fault injection is excluded
    # from this specific contract environment, as on the real Switch build.
    stale_setter="jit236::fault_stale()=(f[0]=='1');"
    if hybrid.count(stale_setter)!=1:raise SystemExit('Expected one desktop-only stale fault setter')
    hybrid=hybrid.replace(stale_setter,"if(f[0]=='1')die(\"hybrid boundary does not enable desktop stale injection\");")
    if os.environ.get('J2ME_JIT_FAULT_STALE'):raise SystemExit('Stale fault environment is not supported by this hybrid boundary')
    diagnostic.write_text(hybrid, encoding='utf-8')
    paths = [vm, source / 'src/native_jit236.h', source / 'src/jit_code_pool.h',
             source / 'src/runtime/native_jit.inc', source / 'src/runtime/interpreter.inc',
             source / 'src/runtime/object_model.inc', source / 'tests/runtime_fit13/jit_mock/switch.h',
             here / 'jit_retry_vm_checks.cpp', diagnostic]
    fingerprints = '\n'.join(f'{hashlib.sha256(path.read_bytes()).hexdigest()}  {path}' for path in paths) + '\n'
    (output / 'source-sha256.txt').write_text(fingerprints, encoding='utf-8')
    print(fingerprints, end='', flush=True)
    puff = output / 'puff.o'
    exe = output / 'jit_retry_vm_checks'
    if args.reuse_puff_from:
        old=args.reuse_puff_from.resolve();data=old.read_bytes()
        if data[:6]!=b'\x7fELF\x02\x01' or data[18:20]!=b'>\0':raise SystemExit('Expected externally verified x86_64 ELF object')
        shutil.copy2(old,puff);print('REUSED_PUFF_SHA256 '+hashlib.sha256(data).hexdigest(),flush=True)
    else:
        rc = run('build-puff', ['gcc', '-O1', '-std=c11', '-c', source / 'src/puff.c', '-o', puff], output)
        if rc: exit_with_status(rc)
    rc = run('build-vm', ['g++', '-O0', '-g0', '-std=c++17', '-fno-exceptions',
                         '-ffunction-sections', '-fdata-sections',
                         '-I' + str(source / 'src'), '-I' + str(source / 'tests/runtime_fit13/jit_mock'),
                         '-DJ2ME_TEST_VM="' + str(diagnostic) + '"',
                         here / 'jit_retry_vm_checks.cpp', puff,
                         '-Wl,--gc-sections', '-pthread', '-ldl', '-o', exe], output)
    if rc: exit_with_status(rc)
    print('EXECUTABLE ' + str(exe), flush=True)
    if args.build_only: return
    failures = []
    for case in ('leaf', 'region') if args.case == 'all' else (args.case,):
        rc = run(case, [exe, case], output)  # Each scenario owns a fresh process/pool.
        if rc: failures.append(rc)
    if failures: exit_with_status(failures[0])


if __name__ == '__main__':
    main()
