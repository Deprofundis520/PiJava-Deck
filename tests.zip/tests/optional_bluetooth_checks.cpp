#define main emulator_main
#include "../src/j2mevm.cpp"
#undef main
static void check(bool ok,const char* label){if(!ok){std::cerr<<"FAIL "<<label<<'\n';std::exit(1);}}
int main(int argc,char**argv){
 if(argc!=4)return 2;
 VMS_CL(g_classpath)={argv[1],argv[2]};VMS_DIAG(g_log_draw)=false;std::string mode=argv[3];
 if(mode=="declarations"){
  struct Contract{const char* cls;const char* name;const char* desc;};
  Contract c[]={
   {"javax/bluetooth/ServiceRecord","getAttributeValue","(I)Ljavax/bluetooth/DataElement;"},
   {"javax/bluetooth/ServiceRecord","getAttributeIDs","()[I"},
   {"javax/bluetooth/ServiceRecord","populateRecord","([I)Z"},
   {"javax/bluetooth/ServiceRecord","setAttributeValue","(ILjavax/bluetooth/DataElement;)Z"},
   {"javax/bluetooth/ServiceRecord","setDeviceServiceClasses","(I)V"},
   {"javax/bluetooth/LocalDevice","getRecord","(Ljavax/microedition/io/Connection;)Ljavax/bluetooth/ServiceRecord;"},
   {"javax/bluetooth/LocalDevice","updateRecord","(Ljavax/bluetooth/ServiceRecord;)V"},
   {"javax/bluetooth/ServiceRegistrationException","<init>","()V"},
   {"javax/bluetooth/ServiceRegistrationException","<init>","(Ljava/lang/String;)V"}
  };
  for(auto& x:c){int cls=load_class_file(x.cls,false);check(cls>=0,x.cls);check(find_method(cls,x.name,x.desc,false),x.name);}
  std::cout<<"actual_descriptor_assertions=9\nPASS OptionalBluetooth declarations\n";return 0;
 }
 if(mode!="unavailable"&&mode!="fallback")check(load_class_file("javax/bluetooth/DataElement",false)>=0,"DataElement exists in frozen library");
 int fixture=ensure_class("OptionalBluetoothChecks");
 Method* method=find_method(fixture,mode,mode=="unavailable"?"(Ljavax/bluetooth/LocalDevice;)I":"()I",false);check(method,"fixture method");
 // An isolated unreachable local object exercises argument contracts only. Public acquisition still throws.
 std::vector<Value> args;if(mode=="unavailable")args.push_back(Value::of_ref(alloc_obj(ensure_class("javax/bluetooth/LocalDevice"))));
 int count=run(method,args).i;std::cout<<"actual_java_assertions="<<count<<'\n';check(count==(mode=="numeric"?50:mode=="objects"?45:mode=="sequence"?26:mode=="fallback"?3:32),"fixture completes exact assertion count");
 std::cout<<"PASS OptionalBluetooth "<<mode<<'\n';
}
