#!/usr/bin/env python3
"""Verify real homebrew content and prove corruption/version checks fail closed."""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import struct

ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location('verify_nsp', ROOT/'tools/verify_nsp.py')
verify = importlib.util.module_from_spec(spec)
spec.loader.exec_module(verify)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ['package', 'build-dir', 'control-dir', 'npdm-config', 'keyset', 'output']:
        parser.add_argument('--'+name, type=Path, required=True)
    parser.add_argument('--version', required=True)
    args = parser.parse_args()
    for key, value in vars(args).items():
        if isinstance(value, Path):
            setattr(args, key, value.resolve())
    args.output.mkdir(parents=True, exist_ok=True)
    dkp = Path(os.environ['DEVKITPRO']).resolve()
    def check(package, label, version):
        return verify.verify_package(package, args.build_dir, args.control_dir, args.npdm_config,
                                     dkp, args.keyset, args.output/label, version)
    passed = check(args.package, 'valid', args.version)
    negative = []
    try:
        check(args.package, 'wrong-version', 'wrong-version')
    except ValueError as error:
        assert str(error) == 'Application version mismatch', str(error)
        negative.append({'case':'wrong-version','rejected':str(error)})
    else:
        raise AssertionError('accepted an incorrect application version')

    # Corrupt a sizeable Program NCA's encrypted content, then update its outer
    # filename hash. Thus outer PFS0/name validation passes and the real NCA
    # section-integrity check must catch the corruption (hactool can exit 0).
    raw = bytearray(args.package.read_bytes())
    entries = verify.read_pfs0(args.package)
    item = max(entries, key=lambda entry:entry['bytes'])
    assert item['bytes'] > 0x7000
    raw[item['offset']+0x6000] ^= 0x40
    digest = verify.sha(raw[item['offset']:item['offset']+item['bytes']])
    strings_at = 16 + 24 * 3
    index = next(i for i, entry in enumerate(entries) if entry is item)
    name_at = strings_at + struct.unpack_from('<I', raw, 16+24*index+16)[0]
    raw[name_at:name_at+32] = digest[:32].encode()
    corrupted = args.output/'corrupted-retagged.nsp'
    corrupted.write_bytes(raw)
    verify.read_pfs0(corrupted)
    try:
        check(corrupted, 'corrupted-retagged', args.version)
    except ValueError as error:
        assert 'NCA integrity failed:' in str(error), str(error)
        negative.append({'case':'encrypted-content-corruption-with-correct-filename-hash','rejected':str(error)})
    else:
        raise AssertionError('accepted corrupted NCA content')
    result = {'passed':True, 'valid_package_sha256':passed['sha256'], 'positive':1,
              'negative':negative, 'physical_switch_tested':False}
    (args.output/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
    print('PASS real NSP verification positive=1 negative='+str(len(negative)))


if __name__ == '__main__':
    main()
