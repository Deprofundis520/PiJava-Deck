#!/usr/bin/env python3
"""Original natural-world renderer correctness only; external JAR/state inputs."""
import argparse, hashlib, json, os, subprocess, sys, time
from pathlib import Path

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--source', type=Path, required=True)
p.add_argument('--output', type=Path, required=True)
p.add_argument('--jar', type=Path, required=True)
p.add_argument('--state', type=Path, required=True)
a = p.parse_args()
source, out = a.source.resolve(), a.output.resolve()
here = Path(__file__).resolve().parent/'original_world'
out.mkdir(parents=True, exist_ok=True)
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
identity = {'jar_sha256': sha(a.jar), 'state_sha256': sha(a.state),
    'probe_sha256': sha(here/'frame_probe.cpp'), 'source': str(source),
    'purpose': 'correctness only, 128 warm frames then 8 original full-world renderer frames per engine',
    'performance_claim': False}
(out/'identity.json').write_text(json.dumps(identity, indent=2)+'\n')
assert identity['jar_sha256'] == '0d01deea860b8e53301630a69d6edc4bdc69dcc853acc193e3739b2bfe718c77', 'This fixture requires the original recorded JAR.'
assert identity['state_sha256'] == 'd48bf069dda10dee00ded60cfd44528cb22ff8afd96498e507e1d861812a45ba', 'This fixed regression requires the recorded external natural snapshot; use the A/B runner for newly captured states.'
records = []
def run(label, command, env=None):
    command = list(map(str, command));begin = time.monotonic()
    r = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, env=env, timeout=300)
    (out/(label+'.txt')).write_bytes(r.stdout)
    records.append({'label': label, 'command': command, 'returncode': r.returncode,
                    'seconds': time.monotonic()-begin})
    (out/'commands.json').write_text(json.dumps(records, indent=2)+'\n')
    assert r.returncode == 0, r.stdout.decode(errors='replace')[-8000:]
    return r.stdout.decode(errors='replace')
run('build', [sys.executable, here/'build_probe.py', '--source', source,
    '--probe', here/'frame_probe.cpp', '--output', out/'build', '--optimization', 'O2'])
expected = {'frames': 8, 'pixels': 9775253628526092253, 'ops': 626842,
            'gfx': 736, 'images': 584, 'clips': 32, 'lines': 0}
results = {}
for engine, enabled in [('fast', '0'), ('jit', '1')]:
    env = os.environ.copy();env['J2ME_JIT'] = enabled
    output = run(engine, [out/'build/probe', source/'romfs/classes', a.jar.resolve(),
        a.state.resolve(), out/engine, '8', '1'], env)
    scene = next(line for line in output.splitlines() if line.startswith('SCENE '))
    scene = dict(item.split('=', 1) for item in scene.split()[1:])
    assert (int(scene['actors']), int(scene['visible']), scene['class']) == (25, 17, 'q'), scene
    line = next(line for line in output.splitlines() if line.startswith('FRAME '))
    frame = {k: int(v) for k, v in (item.split('=', 1) for item in line.split()[1:])}
    frame['ops'] = frame['fast']+frame['slow']+frame['jit']
    observed = {k: frame[k] for k in expected}
    assert observed == expected, (engine, observed, expected)
    assert (frame['jit'] == 0 and frame['entries'] == 0) == (engine == 'fast'), frame
    assert 'PASS frame checks=' in output, 'VM safepoint/return checks did not complete'
    results[engine] = {'passed': True, 'invariants': observed, 'actors': 25,
                       'visible': 17, 'engine_exercised': True}
    print(engine, 'PASS original renderer correctness', flush=True)
(out/'results.json').write_text(json.dumps({'passed': True, 'performance_claim': False,
    'engines': results, 'external_inputs': identity}, indent=2)+'\n')
