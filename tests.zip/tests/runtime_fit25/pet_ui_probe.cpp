// Diagnostic original-game UI replay. Original JAR/resources are read only.
#define main emulator_main
#include PROBE_VM
#undef main

static unsigned checks=0;
static void check(bool ok,const char* why){++checks;if(!ok){std::cerr<<"FAIL "<<why<<'\n';std::exit(1);}}
static Method* method(int cls,const char* name,const char* desc){auto* m=find_method(cls,name,desc,true);check(m,"original method exists");return m;}
static Value invoke(int cls,const char* name,const char* desc,std::vector<Value> a){auto out=run(method(cls,name,desc),a);check(!VMS_EXEC(g_thrown)&&!current_context().unhandled,"original method returns normally");return out;}
static Value& field(int ref,const char* name,const char* desc){auto* f=find_field(VMS_HEAP(g_heap)[ref].cls,name,desc);check(f&&!f->is_static,"instance field exists");return VMS_HEAP(g_heap)[ref].fields[f->slot];}
static void root(int ref){VMS_CL(g_classes)[ensure_class("java/lang/Object")].statics.push_back(Value::of_ref(ref));}
static uint64_t digest(const std::vector<uint8_t>& data){uint64_t h=14695981039346656037ULL;for(uint8_t b:data)h=(h^b)*1099511628211ULL;return h;}
static void profile_report(){
    std::vector<Method*> methods;
    for(auto& c:VMS_CL(g_classes))for(auto& m:c.methods)if(m.cpu_profile.calls)methods.push_back(&m);
    std::sort(methods.begin(),methods.end(),[](Method* a,Method* b){return a->cpu_profile.self_cpu_ns>b->cpu_profile.self_cpu_ns;});
    uint64_t total=0;for(auto* m:methods)total+=m->cpu_profile.self_cpu_ns;
    for(auto* m:methods)std::cout<<"PROFILE "<<VMS_CL(g_classes)[m->class_id].name<<'.'<<m->name<<m->desc<<" calls="<<m->cpu_profile.calls<<" self_cpu_ns="<<m->cpu_profile.self_cpu_ns<<'\n';
    std::cout<<"PROFILE_TOTAL self_cpu_ns="<<total<<" method_clocks_perturb_execution=1 compiled_regions_disabled=1\n";
}
int main(int argc,char** argv){
    check(argc>=5,"romfs engine jar scenario [frames] [trials]");
    VMS_CL(g_classpath)={argv[1]};VMS_DIAG(g_log_draw)=false;VMS_EXEC(g_slice_ms)=4;VMS_EXEC(g_speed_cap)=0;
    VMS_NATIVE(g_native_jit).configure(std::string(argv[2])=="jit");
    check(std::string(argv[2])!="jit"||VMS_NATIVE(g_native_jit).available,"requested host JIT available");
    std::vector<uint8_t> bytes;std::string error;
    check(read_whole(argv[3],bytes)&&unzip(bytes,VMS_CL(g_jar_files),error),"original JAR loads");
    std::cout<<"INPUT jar_sha256="<<rms_jar_identity(bytes.data(),bytes.size())<<'\n';
    const std::string scenario=argv[4];const bool profile=scenario=="profile"||scenario=="profile-battle";
    VMS_RS(g_screen_w)=240;VMS_RS(g_screen_h)=320;VMS_RS(g_fb).assign(240*320*3,0);
    const int common=ensure_class("CWA2DAPI/CWACommon");
    invoke(common,"setScreen","(SS)V",{Value::of_i(240),Value::of_i(320)});
    const int gfxcls=ensure_class("javax/microedition/lcdui/Graphics"),gfx=alloc_obj(gfxcls);root(gfx);
    invoke(gfxcls,"<init>","()V",{Value::of_ref(gfx)});
    const int uicls=ensure_class("CWAUI/CWAUIManager");
    const int ui=invoke(uicls,"getInstance","()LCWAUI/CWAUIManager;",{}).ref;root(ui);
    // These are the unchanged resource initializers called by GameManager.init.
    invoke(ensure_class("CWA2DAPI/cwabase2d/CWAImageManager"),"init","(I)V",{Value::of_i(50000)});
    invoke(ensure_class("CWA2DAPI/cwabase2d/CWASpDataManager"),"init","(I)V",{Value::of_i(1000)});
    invoke(ensure_class("CWA2DAPI/cwabase2d/CWADataManager"),"init","()V",{});
    const int path=make_string("/data/ui/battle.ui");root(path);
    invoke(uicls,"show","(Ljava/lang/String;ILCWAUI/CWAUICommandListener;)V",{Value::of_ref(ui),Value::of_ref(path),Value::of_i(257),Value::of_ref(0)});
    check(field(ui,"curControl","LCWAUI/CWAUIControl;").ref!=0,"original battle UI loaded");
    if(scenario=="battle"||scenario=="profile-battle") {
        const int gameuicls=ensure_class("game/GameUI"),petcls=ensure_class("game/GamePet");
        const int gameui=invoke(gameuicls,"getInstance","()Lgame/GameUI;",{}).ref;root(gameui);
        int pets[2];for(int i=0;i<2;++i){pets[i]=alloc_obj(petcls);root(pets[i]);invoke(petcls,"<init>","()V",{Value::of_ref(pets[i])});
            // Constructed valid battle actors; all properties/text are computed
            // by the original initializer from its unmodified database.
            invoke(petcls,"init","(IISBSB)V",{Value::of_ref(pets[i]),Value::of_i(i),Value::of_i(5+i),Value::of_i(0),Value::of_i(0),Value::of_i(1),Value::of_i(0)});
        }
        invoke(gameuicls,"setMyBattleUI","(Lgame/GamePet;ZI)Z",{Value::of_ref(gameui),Value::of_ref(pets[0]),Value::of_i(0),Value::of_i(11)});
        invoke(gameuicls,"setEnemyBattleUI","(Lgame/GamePet;Z)Z",{Value::of_ref(gameui),Value::of_ref(pets[1]),Value::of_i(0)});
        invoke(gameuicls,"initBattleSelect","()V",{Value::of_ref(gameui)});
    }
    const unsigned frames=argc>5?std::atoi(argv[5]):2,trials=argc>6?std::atoi(argv[6]):1;
    auto draw=[&](){invoke(gfxcls,"setClip","(IIII)V",{Value::of_ref(gfx),Value::of_i(0),Value::of_i(0),Value::of_i(240),Value::of_i(320)});
        ++VMS_RS(g_paint_depth);invoke(uicls,"draw","(Ljavax/microedition/lcdui/Graphics;)V",{Value::of_ref(ui),Value::of_ref(gfx)});--VMS_RS(g_paint_depth);};
    draw();gc_collect("ui-probe-setup");
    VMS_EXEC(g_execution_profile).enabled=profile;for(auto& c:VMS_CL(g_classes))for(auto& m:c.methods)m.cpu_profile={};
    for(unsigned trial=0;trial<trials;++trial){
        const uint64_t fast=VMS_EXEC(g_fast_ops),slow=VMS_EXEC(g_slow_ops),jit=VMS_NATIVE(g_native_jit).stats.ops,entries=g_jit_region_stats.entries,gfxjit=g_jitr_gfx_ok;
        VMS_RS(g_drawacc)={};VMS_RS(g_drawacc).on=true;VMS_RS(g_graphics_profile).reset(false);
        std::fill(VMS_RS(g_fb).begin(),VMS_RS(g_fb).end(),uint8_t(0));
        const auto start=std::chrono::steady_clock::now();
        for(unsigned f=0;f<frames;++f){draw();gc_collect("ui-probe-frame");}
        const double ms=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();
        std::cout<<"UI trial="<<trial<<" scenario="<<scenario<<" frames="<<frames<<" pixel_digest="<<digest(VMS_RS(g_fb))<<" wall_ms="<<ms<<" fast="<<VMS_EXEC(g_fast_ops)-fast<<" slow="<<VMS_EXEC(g_slow_ops)-slow<<" jitops="<<VMS_NATIVE(g_native_jit).stats.ops-jit<<" region_entries="<<g_jit_region_stats.entries-entries<<" gfx_jit_calls="<<g_jitr_gfx_ok-gfxjit<<" lines="<<VMS_RS(g_drawacc).lines<<" images="<<VMS_RS(g_drawacc).images<<" profile="<<profile<<'\n';
    }
    if(profile)profile_report();
    check(g_gc_sp.violations==0,"GC only at valid safepoints");check(jit236::active_code_calls()==0,"no live JIT activation");
    VMS_NATIVE(g_native_jit).clear();jit_region_reset();
    std::cout<<"PASS original battle UI replay checks="<<checks<<" original_game_assets=1 whole_ui_draw=1 selected_input_ui=1 natural_battle=0 switch_fps_claim=0\n";
}
