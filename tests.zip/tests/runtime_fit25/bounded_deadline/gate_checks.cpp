#include "poll_gate.h"
#include <cassert>
#include <iostream>
#include <limits>

int main() {
    // Whole original method shape; CP labels are independent of a game/class.
    const std::vector<uint8_t> code={0x1e,0xb8,0,3,0x61,0x3f,0x1e,0xb8,0,3,
                                   0x94,0x9e,0,9,0xb8,0,2,0xa7,0xff,0xf5,0xb1};
    auto clock=[](int cp){return cp==3;};auto yield=[](int cp){return cp==2;};
    auto match=[&](const std::vector<uint8_t>& bytes){return recognize_bounded_deadline_helper(bytes,clock,yield);};
    assert(match(code));
    for(size_t n=0;n<code.size();++n)assert(!match(std::vector<uint8_t>(code.begin(),code.begin()+n)));
    auto extra=code;extra.push_back(0x00);assert(!match(extra));
    for(size_t n=0;n<code.size();++n){auto changed=code;changed[n]^=0x01;assert(!match(changed));}
    assert(!recognize_bounded_deadline_helper(code,[](int){return false;},yield));
    assert(!recognize_bounded_deadline_helper(code,clock,[](int){return false;}));

    NativeDeadlineEvidence e;
    for(int delay:{-1,0,1,2,120,121}) {
        e.record_bounded_delay(1,delay,1000,7,10,1.0);
        const bool eligible=delay>=2&&delay<=120;
        assert(e.owns_bounded_delay(1,1000+delay,7,10,1.0,1001)==eligible);
        assert(!e.owns(1,0,1000,7,11,1.0)); // Never substitute for the older paint-after-anchor proof.
    }
    e.record_bounded_delay(1,80,1000,7,10,1.0);
    assert(e.owns_bounded_delay(1,1080,7,10,1.0,1000));
    assert(!e.owns_bounded_delay(0,1080,7,10,1.0,1001));
    assert(!e.owns_bounded_delay(2,1080,7,10,1.0,1001));
    assert(!e.owns_bounded_delay(1,1081,7,10,1.0,1001));
    assert(!e.owns_bounded_delay(1,1080,8,10,1.0,1001));
    assert(!e.owns_bounded_delay(1,1080,7,9,1.0,1001));
    assert(!e.owns_bounded_delay(1,1080,7,11,1.0,1001));
    assert(!e.owns_bounded_delay(1,1080,7,10,2.0,1001));
    assert(!e.owns_bounded_delay(1,1080,7,10,1.0,999));
    e.last_ms=1005;
    assert(!e.owns_bounded_delay(1,1080,7,10,1.0,1004));
    assert(e.owns_bounded_delay(1,1080,7,10,1.0,1005));
    e.reset();assert(!e.owns_bounded_delay(1,1080,7,10,1.0,1005));
    e.record_bounded_delay(1,2,INT64_MAX-1,7,10,1.0);assert(!e.activation);
    e.record_bounded_delay(1,2,-1,7,10,1.0);assert(!e.activation);
    e.record_bounded_delay(1,80,1000,7,0,1.0);assert(!e.activation);
    e.record_bounded_delay(0,80,1000,7,10,1.0);assert(!e.activation);
    e.record_bounded_delay(1,80,1000,0,10,1.0);assert(!e.activation);
    e.record_bounded_delay(1,80,1000,7,10,std::numeric_limits<double>::quiet_NaN());assert(!e.activation);
    e.record_bounded_delay(1,80,1000,7,10,0.0);assert(!e.activation);
    e.record_bounded_delay(1,80,1000,7,10,0.5);assert(!e.activation);
    e.record(1,0,1000,7,10,1.0);assert(e.owns(1,0,1000,7,11,1.0));
    assert(!e.owns_bounded_delay(1,1080,7,10,1.0,1001));
    PollGateState poll;
    for(int i=0;i<4;++i)poll.observe_deadline(&e,7,1000,1080,1001,true);
    for(double scale:{1.0,2.0,4.8,16.0})assert(poll.wait_us(1001,scale,false)>0&&poll.wait_us(1001,scale,false)<=500);
    assert(poll.wait_us(1080,1.0,false)==0);
    assert(poll.wait_us(1001,0.5,false)==0);
    std::cout<<"PASS exact whole-method certificate, 1/2/120/121 boundaries, provenance, overflow/rollback and legacy isolation\n";
}
