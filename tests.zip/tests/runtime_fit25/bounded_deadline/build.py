#!/usr/bin/env python3
"""Build a real VM around controlled external clock and OS sleep boundaries."""
import argparse, difflib, hashlib, json, subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
p = argparse.ArgumentParser()
p.add_argument('--source', type=Path, required=True)
p.add_argument('--output', type=Path, required=True)
p.add_argument('--jar', type=Path, required=True)
p.add_argument('--opt', choices=['0','1','2'], default='0', help='Host C/C++ optimization level (default: 0).')
a = p.parse_args()
source, out, jar = a.source.resolve(), a.output.resolve(), a.jar.resolve()
(out/'adapter/runtime').mkdir(parents=True, exist_ok=True)
(out/'classes').mkdir(exist_ok=True)
(out/'build-config.json').write_text(json.dumps({'opt':a.opt,'runtime_architecture':'host'},indent=2)+'\n')

def replace_function(text, signature, body):
    at=text.index(signature); begin=text.index('{',at); depth=1; end=begin+1
    while depth:
        depth += (text[end]=='{') - (text[end]=='}'); end+=1
    return text[:begin+1]+'\n'+body+'\n'+text[end-1:]

identities = {str(path):hashlib.sha256(path.read_bytes()).hexdigest()
              for base in [source/'src', source/'third_party', source/'romfs/classes']
              for path in base.rglob('*') if path.is_file()}
identities.update({str(path):hashlib.sha256(path.read_bytes()).hexdigest()
                   for path in HERE.iterdir() if path.suffix in ('.py','.cpp','.java','.md')})
identities[str(jar)]=hashlib.sha256(jar.read_bytes()).hexdigest()
diffs=[]
for relative in ['j2mevm.cpp','threading.h','runtime/interpreter.inc']:
    original=(source/'src'/relative).read_text()
    adapted=original.replace('std::this_thread::sleep_for(', 'fit24_clock::poll_sleep_for(' if relative=='runtime/interpreter.inc' else 'fit24_clock::sleep_for(')
    if relative=='j2mevm.cpp':
        for signature,body in [('static int64_t paint_clock_us()', 'return fit24_clock::read();'),
                               ('static int64_t monotonic_ms()', 'return fit24_clock::read()/1000;'),
                               ('static int64_t now_ms()', 'return fit24_clock::wall_read()/1000;')]:
            adapted=replace_function(adapted,signature,'    '+body)
    if relative=='runtime/interpreter.inc':
        marker='                push(Value::of_l(now));\n                return;\n            }\n            if (mm->native)'
        assert marker in adapted
        note='                fit24_clock::note_clock(VMS_CL(g_classes)[fr.method->class_id].name, fr.method->name, fr.method->desc, fr.op_pc, fr.locals.empty()?0:fr.locals[0].l, fr.stack.size()==1&&fr.stack.back().is_long?fr.stack.back().l:0, now);\n'
        adapted=adapted.replace(marker,note+marker)
        marker='P7_SCOPE(Idle);fit24_clock::poll_sleep_for(std::chrono::microseconds(requested));'
        assert marker in adapted
        adapted=adapted.replace(marker,'fit24_clock::note_nap(now,VMS_EXEC(g_game_clock).scale,evidence.poll.deadline_ms,requested); '+marker)
    (out/'adapter'/relative).write_text(adapted)
    diffs.extend(difflib.unified_diff(original.splitlines(True),adapted.splitlines(True),fromfile=str(source/'src'/relative),tofile='test-only/'+relative))
(out/'test-only-adapter.diff').write_text(''.join(diffs))
(out/'source-sha256.json').write_text(json.dumps(identities,indent=2)+'\n')
commands=[
    ['java','-XX:-UsePerfData','-m','jdk.compiler/com.sun.tools.javac.Main','-source','8','-target','8','-bootclasspath',str(source/'romfs/classes'),'-classpath',str(source/'romfs/classes')+':'+str(jar),'-d',str(out/'classes'),str(HERE/'AbsoluteDeadlineFixture.java')],
    ['gcc','-O'+a.opt,'-c',str(source/'src/puff.c'),'-o',str(out/'puff.o')],
    ['g++','-O'+a.opt,'-g0','-std=c++17','-fno-exceptions','-ffunction-sections','-fdata-sections','-DJ2ME_TEST_VM="'+str(out/'adapter/j2mevm.cpp')+'"','-I'+str(out/'adapter'),'-I'+str(source/'src'),'-I'+str(source/'src/runtime'),str(HERE/'runtime.cpp'),str(out/'puff.o'),'-Wl,--gc-sections','-pthread','-ldl','-o',str(out/'runtime')],
]
records=[]
for i,command in enumerate(commands):
    result=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=300)
    (out/f'build-{i}.log').write_bytes(result.stdout)
    records.append(dict(command=command,returncode=result.returncode))
    (out/'build-commands.json').write_text(json.dumps(records,indent=2)+'\n')
    print('BUILD',i,'returncode',result.returncode,flush=True)
    if result.returncode: raise SystemExit(result.stdout.decode(errors='replace')[-8000:])
changed=[path for path,digest in identities.items() if hashlib.sha256(Path(path).read_bytes()).hexdigest()!=digest]
(out/'source-changes.json').write_text(json.dumps(changed)+'\n')
if changed: raise SystemExit('Source changed during build: '+repr(changed))
print('PASS original game and VM input hashes unchanged',flush=True)
