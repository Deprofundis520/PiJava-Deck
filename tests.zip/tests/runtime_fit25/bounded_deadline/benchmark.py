#!/usr/bin/env python3
"""Small paired real-host CPU measurement; all code and waits are original VM paths."""
import argparse, json, os, statistics, subprocess
from pathlib import Path
p=argparse.ArgumentParser()
p.add_argument('--baseline',type=Path,required=True)
p.add_argument('--candidate',type=Path,required=True)
p.add_argument('--library',type=Path,required=True)
p.add_argument('--jar',type=Path,required=True)
p.add_argument('--output',type=Path,required=True)
a=p.parse_args();out=a.output.resolve();out.mkdir(parents=True,exist_ok=True)
records=[]
for cap,scale in [(0,1.0),(30,4.6),(60,4.8)]:
    for pair in range(4):
        for name in (['baseline','candidate'] if pair%2==0 else ['candidate','baseline']):
            build=getattr(a,name).resolve()
            command=[str(build/'runtime'),str(build/'classes'),str(a.library.resolve()),str(a.jar.resolve()),'0',str(cap),'80','4','0',str(1 if name=='candidate' else -1)]
            environment=dict(os.environ,FIT25_REAL_CLOCK='1',FIT25_CLOCK_SCALE=str(scale))
            result=subprocess.run(command,env=environment,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=30)
            raw=result.stdout.decode(errors='replace');(out/f'cap{cap}-pair{pair}-{name}.log').write_text(raw)
            if result.returncode:raise SystemExit(raw[-12000:])
            line=next(line for line in raw.splitlines() if line.startswith('RESULT '))
            values=dict(part.split('=',1) for part in line.split()[1:])
            metrics={key:float(value) if '.' in value else int(value) for key,value in values.items()}
            assert metrics['scale']==scale and metrics['updates']==metrics['completed']==4
            record=dict(name=name,cap=cap,scale=scale,pair=pair,command=command,environment={'FIT25_REAL_CLOCK':'1','FIT25_CLOCK_SCALE':str(scale)},metrics=metrics)
            records.append(record);(out/'results.json').write_text(json.dumps(records,indent=2)+'\n')
            print('MEASURE',cap,scale,pair,name,'cpu_ns',metrics['cpu_ns'],'wall_us',metrics['host_us'],'waits',metrics['poll_waits'],flush=True)
summary=[]
for cap,scale in [(0,1.0),(30,4.6),(60,4.8)]:
    cpu_ratios=[];rows=[]
    for pair in range(4):
        values={r['name']:r['metrics'] for r in records if r['cap']==cap and r['pair']==pair}
        before,after=values['baseline'],values['candidate']
        assert (before['pixels'],before['updates'],before['completed'],before['paints'])==(after['pixels'],after['updates'],after['completed'],after['paints'])
        assert after['poll_waits']>0 and before['poll_waits']==0
        cpu_ratios.append(after['cpu_ns']/before['cpu_ns'])
        rows.append(dict(pair=pair,cpu_ratio=cpu_ratios[-1],
                         baseline_cpu_percent=before['cpu_ns']/before['host_us']/10,
                         candidate_cpu_percent=after['cpu_ns']/after['host_us']/10,
                         baseline_poll_calls=before['poll_calls'],candidate_poll_calls=after['poll_calls'],
                         baseline_java_elapsed=before['java_elapsed'],candidate_java_elapsed=after['java_elapsed']))
    summary.append(dict(cap=cap,scale=scale,pairs=rows,median_cpu_ratio=statistics.median(cpu_ratios),all_cpu_lower=all(value<1 for value in cpu_ratios)))
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print('PASS paired CPU observations with equal original updates/paints/final pixels',flush=True)
