import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Graphics;

/** Test callers only. Mode zero executes the supplied, unmodified g.a(J)V. */
public class AbsoluteDeadlineFixture extends Canvas implements Runnable {
    static int mode, limit, completed, updates, paints, effects, peers;
    static long delay, elapsed;
    static final Object lock = new Object();
    public static void start(int selected, long requested, int count) {
        mode = selected; delay = requested; limit = count;
        completed = updates = paints = effects = peers = 0; elapsed = 0;
        AbsoluteDeadlineFixture canvas = new AbsoluteDeadlineFixture();
        Display.getDisplay(null).setCurrent(canvas);
        new Thread(canvas).start();
        if (mode == 8) new Thread(new Runnable() {
            public void run() { while (completed < limit) { ++peers; Thread.yield(); } }
        }).start();
    }
    protected void paint(Graphics graphics) {
        ++paints; graphics.setColor(updates); graphics.fillRect(0, 0, 8, 8);
    }
    static void pure(long amount) {
        amount += System.currentTimeMillis();
        while (amount > System.currentTimeMillis()) Thread.yield();
    }
    static void sideEffect(long amount) {
        amount += System.currentTimeMillis();
        while (amount > System.currentTimeMillis()) { ++effects; Thread.yield(); }
    }
    static synchronized void lockedMethod(long amount) {
        amount += System.currentTimeMillis();
        while (amount > System.currentTimeMillis()) Thread.yield();
    }
    static void handled(long amount) {
        try {
            amount += System.currentTimeMillis();
            while (amount > System.currentTimeMillis()) Thread.yield();
        } catch (RuntimeException error) { ++effects; }
    }
    static void unknown(long target) {
        while (target > System.currentTimeMillis()) Thread.yield();
    }
    public void run() {
        while (completed < limit) {
            ++updates;
            if (mode != 10) { repaint(); serviceRepaints(); }
            // Let the ordinary host turn present before exercising a 2ms
            // helper. The original helper itself remains untouched.
            if (mode == 16) { try { Thread.sleep(1); } catch (InterruptedException error) { ++effects; } }
            long began = System.currentTimeMillis();
            if (mode == 1) pure(delay);
            else if (mode == 2) sideEffect(delay);
            else if (mode == 3) lockedMethod(delay);
            else if (mode == 4) handled(delay);
            else if (mode == 5) unknown(began + delay);
            else if (mode == 6) { try { Thread.sleep(0); } catch (InterruptedException error) { ++effects; } }
            else if (mode == 7) Thread.yield();
            else if (mode == 9) { synchronized (lock) { g.a(delay); } }
            else g.a(delay);
            elapsed += System.currentTimeMillis() - began;
            ++completed;
        }
    }
}
