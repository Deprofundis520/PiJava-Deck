#!/usr/bin/env python3
"""Assert real-VM absolute-deadline behavior and preserve every command/output."""
import argparse, json, os, subprocess, sys
from pathlib import Path
p=argparse.ArgumentParser()
p.add_argument('--build',type=Path,required=True)
p.add_argument('--source',type=Path,required=True)
p.add_argument('--jar',type=Path,required=True)
p.add_argument('--output',type=Path,required=True)
p.add_argument('--baseline',action='store_true')
p.add_argument('--opt',choices=['0','1','2'],help='Rebuild first at this optimization level; omission uses the existing build (builder default: 0).')
p.add_argument('--cross-root',type=Path,help='Also compile/run the pure certificate unit under AArch64/QEMU; VM scenarios remain on the host.')
a=p.parse_args();out=a.output.resolve();out.mkdir(parents=True,exist_ok=True)
here=Path(__file__).resolve().parent
if a.opt is not None or not (a.build/'runtime').exists():
    subprocess.run([sys.executable,str(here/'build.py'),'--source',str(a.source.resolve()),'--output',str(a.build.resolve()),'--jar',str(a.jar.resolve()),'--opt',a.opt or '0'],check=True)
base=[str(a.build.resolve()/'runtime'),str(a.build.resolve()/'classes'),str(a.source.resolve()/'romfs/classes'),str(a.jar.resolve())]
cases=[]
for cap in [0,30,60]:cases.append((f'original-cap{cap}',0,cap,80,4,0,1))
if not a.baseline:
    cases.append(('generic-pure',1,0,80,2,0,1))
    for delay in [-1,0,1,2,120,121,9223372036854775807]:
        cases.append((f'boundary-{delay}',0,0,delay,2,0,int(2<delay<=120)))
    cases.append(('boundary-2-after-present',16,0,2,4,0,1))
    for mode,name in [(2,'side-effect'),(3,'synchronized'),(4,'handler'),(5,'unknown-deadline'),(6,'sleep-zero'),(7,'yield'),(8,'runnable-peer'),(9,'held-monitor'),(10,'no-owned-paint')]:
        cases.append((name,mode,0,80,2,0,0))
    for mode,name in [(11,'pause'),(12,'resume'),(13,'restore-midloop'),(14,'mode-change'),(15,'wall-clock-rollback')]:
        cases.append((name,mode,0,80,1,0,-1))
    cases.append(('oversleep-1500',0,60,80,4,1500,1))
    for cap in [0,30,60]:
        for scale in [0.5,4.6,4.8,16.0]:
            cases.append((f'scale-{scale}-cap{cap}',0,cap,80,4,0,int(scale>=1),scale))
records=[];bad=[]
for case in cases:
    name,mode,cap,delay,cycles,late,require=case[:7]
    environment=dict(os.environ)
    if len(case)>7:environment['FIT25_CLOCK_SCALE']=str(case[7])
    command=base+list(map(str,[mode,cap,delay,cycles,late,require]))
    result=subprocess.run(command,env=environment,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=90)
    raw=result.stdout.decode(errors='replace');(out/(name+'.log')).write_text(raw)
    result_line=next((line for line in raw.splitlines() if line.startswith('RESULT ')),None)
    record=dict(name=name,command=command,returncode=result.returncode)
    if len(case)>7:record['environment']={'FIT25_CLOCK_SCALE':str(case[7])}
    if result_line:
        values=dict(item.split('=',1) for item in result_line.split()[1:])
        record['metrics']={key:float(value) if '.' in value else int(value) for key,value in values.items()}
    record['failures']=[line for line in raw.splitlines() if line.startswith('FAIL ')]
    expected=(result.returncode==1 and record.get('metrics',{}).get('failures')==1 and record.get('metrics',{}).get('poll_waits')==0
              and record['failures']==['FAIL eligible original absolute deadline yields bounded OS naps','FAIL original absolute deadline VM checks']) if a.baseline else result.returncode==0
    if not a.baseline and name=='boundary-2':expected=expected and record.get('metrics',{}).get('gate_reads',0)>0
    record['expected_outcome']=expected
    if not expected:bad.append(name)
    records.append(record);(out/'results.json').write_text(json.dumps(records,indent=2)+'\n')
    print(('EXPECTED_RED' if a.baseline else 'CHECK'),name,'returncode',result.returncode,'ok',expected,flush=True)
if bad:raise SystemExit('Unexpected outcomes: '+', '.join(bad))
unit_records=[]
if not a.baseline:
    config=a.build/'build-config.json'
    opt=a.opt or (json.loads(config.read_text())['opt'] if config.exists() else '0')
    targets=[('host',['g++'],[],None)]
    if a.cross_root:
        cross=a.cross_root.resolve();environment=dict(os.environ,LD_LIBRARY_PATH=str(cross/'usr/lib/x86_64-linux-gnu'))
        targets.append(('aarch64',[str(cross/'usr/bin/aarch64-linux-gnu-g++'),'--sysroot='+str(cross)],
                        [str(cross/'usr/bin/qemu-aarch64'),'-L',str(cross/'usr/aarch64-linux-gnu')],environment))
    for arch,compiler,prefix,environment in targets:
        binary=out/('gate-checks-'+arch)
        commands=[compiler+['-O'+opt,'-std=c++17','-I'+str(a.source.resolve()/'src'),str(here/'gate_checks.cpp'),'-o',str(binary)],prefix+[str(binary)]]
        for index,command in enumerate(commands):
            result=subprocess.run(command,env=environment,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=90)
            (out/f'gate-{arch}-{index}.log').write_bytes(result.stdout)
            unit_records.append(dict(architecture=arch,command=command,returncode=result.returncode))
            (out/'unit-commands.json').write_text(json.dumps(unit_records,indent=2)+'\n')
            if result.returncode:raise SystemExit(result.stdout.decode(errors='replace'))
        print('PASS pure certificate unit',arch,'O'+opt,flush=True)
    (out/'coverage.json').write_text(json.dumps({'runtime_architectures':['host'],'runtime_scenarios':len(records),
         'unit_architectures':[target[0] for target in targets],'optimization':opt,
         'aarch64_vm_scenarios_executed':False},indent=2)+'\n')
print(('PASS baseline RED reproduced' if a.baseline else 'PASS candidate behavior checks'),len(records),flush=True)
