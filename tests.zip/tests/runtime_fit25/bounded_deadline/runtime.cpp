#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <string>
#include <thread>
#include <vector>

namespace fit24_clock {
int64_t us=1000000, tick_us=1, late_us=0, wall_offset_us=0;
bool real=false;
uint64_t sleeps=0, reads=0;
int64_t requested_us=0, actual_us=0, max_requested_us=0;
int64_t poll_requested_us=0,poll_actual_us=0,poll_max_request_us=0;
struct Gate {int64_t request=0,anchor=0,target=0,last=0;bool ready=false,unchanged=true;};
std::vector<Gate> gates;
struct Nap {int64_t now=0,deadline=0,request=0;double scale=0;};
std::vector<Nap> naps;
void note_nap(int64_t now,double scale,int64_t deadline,int64_t request){naps.push_back({now,deadline,request,scale});}
int64_t real_us() {return std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::steady_clock::now().time_since_epoch()).count();}
int64_t read() {++reads;if(real)return real_us();const auto value=us;us+=tick_us;return value;}
int64_t wall_read() {return read()+wall_offset_us;}
template<class Rep,class Period> void sleep_for(std::chrono::duration<Rep,Period> duration) {
    const auto requested=std::chrono::duration_cast<std::chrono::microseconds>(duration).count();
    if(requested<=0)return;
    ++sleeps;requested_us+=requested;max_requested_us=std::max(max_requested_us,requested);
    if(real){const auto start=real_us();std::this_thread::sleep_for(duration);actual_us+=real_us()-start;}
    else {actual_us+=requested+late_us;us+=requested+late_us;}
}
template<class Rep,class Period> void poll_sleep_for(std::chrono::duration<Rep,Period> duration) {
    const auto requested=std::chrono::duration_cast<std::chrono::microseconds>(duration).count();
    const auto before=actual_us;sleep_for(duration);poll_actual_us+=actual_us-before;
    poll_requested_us+=requested;poll_max_request_us=std::max(poll_max_request_us,requested);
}
void note_clock(const std::string& cls,const std::string& method,const std::string& desc,int pc,int64_t local,int64_t stacked,int64_t now) {
    if(desc!="(J)V"||!((cls=="g"&&method=="a")||(cls=="AbsoluteDeadlineFixture"&&method=="pure")))return;
    if(pc==1)gates.push_back({local,now,int64_t(uint64_t(stacked)+uint64_t(now)),0,false});
    else if(pc==7&&!gates.empty()) {auto& gate=gates.back();gate.last=now;gate.unchanged=gate.unchanged&&local==gate.target;if(now>=local)gate.ready=true;}
}
}

#define main emulator_main
#include J2ME_TEST_VM
#undef main
#include "host_menu_settings.h"
#include "host_speed.h"
static host_menu::Settings g_menu_settings;
static std::string instant_state_path(const std::string&) {return "unused-fit25-deadline.state";}
#include "instant_state.inc"
static int failures=0, checks=0;
static void check(bool ok,const char* why){++checks;if(!ok){++failures;std::cerr<<"FAIL "<<why<<'\n';}}
static Value field(int cls,const char* name,const char* desc="I") {
    auto* found=find_field(cls,name,desc);if(!found){std::cerr<<"missing "<<name<<'\n';std::exit(2);}
    return VMS_CL(g_classes)[found->owner].statics[found->slot];
}
int main(int argc,char** argv) {
    if(argc!=10){std::cerr<<"classes library jar mode cap delay cycles late_us require_nap\n";return 2;}
    const int mode=std::atoi(argv[4]),cap=std::atoi(argv[5]),cycles=std::atoi(argv[7]);
    const int64_t delay=std::atoll(argv[6]);fit24_clock::late_us=std::atoll(argv[8]);
    const int require=std::atoi(argv[9]);fit24_clock::real=std::getenv("FIT25_REAL_CLOCK")!=nullptr;
    VMS_CL(g_classpath)={argv[1],argv[2]};VMS_DIAG(g_log_draw)=false;
    VMS_PLAT(g_boot_ms)=now_ms();VMS_EXEC(g_speed_cap)=cap;speed_sync_clock();
    if(const char* scale=std::getenv("FIT25_CLOCK_SCALE")) {
        // A clock input, not a VM policy change. A deliberately unsupported
        // rate below 1 checks conservative refusal without changing the clock.
        VMS_EXEC(g_game_clock).rate(paint_clock_us(),1.0);
        VMS_EXEC(g_game_clock).scale=std::atof(scale);VMS_EXEC(g_game_clock_inherited)=true;
    }
    VMS_RS(g_fb).assign(size_t(VMS_RS(g_screen_w))*VMS_RS(g_screen_h)*3,0);
    VMS_EXEC(g_midlet_state)=MidletState::Active;
    std::vector<uint8_t> bytes;std::string error;
    check(read_whole(argv[3],bytes)&&unzip(bytes,VMS_CL(g_jar_files),error),"supplied original jar loads");
    const int cls=ensure_class("AbsoluteDeadlineFixture");
    run(find_method(cls,"start","(IJI)V",false),{Value::of_i(mode),Value::of_l(delay),Value::of_i(cycles)});
    const auto cpu_start=j2me_cpu_clock::now_ns();const auto began=fit24_clock::read();
    bool lifecycle=false;uint64_t waits_at_reset=0;int completed_at_reset=-1;
    int turns=0;
    while(field(cls,"completed").i<cycles&&turns++<5000000&&fit24_clock::read()-began<30000000) {
        host_lifecycle_poll242();
        sched_game_work(true,[]{},[](int64_t ms){fit24_clock::sleep_for(std::chrono::milliseconds(ms));});
        sched_present_turn(true,false,true,3,[]{});
        if(mode>=11&&mode<=15&&!lifecycle)for(auto& context:VMS_EXEC(g_threads)) {
            if(context.frames.empty())continue;
            auto& frame=context.frames.back();
            if(VMS_CL(g_classes)[frame.method->class_id].name!="g"||frame.method->name!="a"||frame.method->desc!="(J)V"||frame.pc<6)continue;
            lifecycle=true;completed_at_reset=field(cls,"completed").i;waits_at_reset=VMS_EXEC(g_poll_waits);
            if(mode==11){speed_pause_clock(true);check(context.native_deadline.activation==0,"pause clears anchor evidence");speed_pause_clock(false);}
            if(mode==12){speed_pause_clock(false);check(context.native_deadline.activation==0,"resume clears anchor evidence");}
            if(mode==13){const auto saved=sav_thread(context);VMS_EXEC(g_save_clock).ms=fit24_clock::read()/1000;VMS_EXEC(g_save_clock).us=fit24_clock::read();check(apply_thread(context,saved,""),"restore accepts suspended original helper");check(context.native_deadline.activation==0&&context.frames.back().native_deadline_activation==0,"restore has no host anchor or frame provenance");}
            if(mode==14){VMS_EXEC(g_speed_cap)=cap==30?60:30;speed_sync_clock();check(context.native_deadline.activation==0,"mode transition clears anchor evidence");}
            if(mode==15){fit24_clock::wall_offset_us-=100000;}
            break;
        }
    }
    const auto ended=fit24_clock::read();const auto cpu_ns=j2me_cpu_clock::now_ns()-cpu_start;
    check(field(cls,"completed").i==cycles,"every Java wait and update returns");
    check(field(cls,"updates").i==cycles,"no Java updates are skipped or duplicated");
    if(mode!=10)check(std::abs(field(cls,"paints").i-cycles)<=1,"original paint/update count preserved");
    if(mode==8)check(field(cls,"peers").i>0,"runnable Java peer executes");
    if(mode>=11&&mode<=15){check(lifecycle,"lifecycle exercised inside original helper");check(completed_at_reset==0,"reset occurs before first wait returns");check(VMS_EXEC(g_poll_waits)==waits_at_reset,"reset/rollback prevents further naps in the anchorless activation");}
    if(require>0)check(VMS_EXEC(g_poll_waits)>0,"eligible original absolute deadline yields bounded OS naps");
    if(require==0)check(VMS_EXEC(g_poll_waits)==0,"unproven or unsafe wait does not nap");
    check(fit24_clock::poll_max_request_us<=500,"every cooperative poll nap is bounded to 500us");
    for(const auto& nap:fit24_clock::naps)
        check(nap.scale>=1.0&&std::isfinite(nap.scale)&&nap.deadline>nap.now&&nap.request>0&&
              double(nap.request)<=double(nap.deadline-nap.now)*1000.0/nap.scale-1000.0+0.001,
              "host nap conversion preserves remaining scaled Java time and original 1ms host margin");
    if(mode==0||mode==1||mode>=8)for(const auto& gate:fit24_clock::gates){
        check(gate.unchanged&&gate.ready&&gate.last>=gate.target,"Java helper reaches its unchanged original absolute deadline");
        if(delay>=0&&delay<=120)check(gate.target-gate.anchor==delay,"author delay is neither scaled nor shortened");
    }
    for(const auto& c:VMS_CL(g_classes))for(const auto& method:c.methods)
        if((c.name=="g"&&method.name=="a"&&method.desc=="(J)V")||(c.name=="AbsoluteDeadlineFixture"&&method.name=="pure"))
            check(method.time_gates.empty(),"absolute helper does not certify a paced group or suppress JIT");
    uint64_t pixels=14695981039346656037ull;for(auto byte:VMS_RS(g_fb))pixels=(pixels^byte)*1099511628211ull;
    std::cout<<"RESULT mode="<<mode<<" cap="<<cap<<" delay="<<delay<<" cycles="<<cycles
             <<" real="<<fit24_clock::real<<" host_us="<<ended-began<<" cpu_ns="<<cpu_ns
             <<" completed="<<field(cls,"completed").i<<" updates="<<field(cls,"updates").i<<" paints="<<field(cls,"paints").i
             <<" pixels="<<pixels
             <<" java_elapsed="<<field(cls,"elapsed","J").l<<" effects="<<field(cls,"effects").i<<" peer_updates="<<field(cls,"peers").i
             <<" os_sleeps="<<fit24_clock::sleeps<<" requested_us="<<fit24_clock::requested_us<<" actual_us="<<fit24_clock::actual_us
             <<" max_request_us="<<fit24_clock::max_requested_us<<" poll_calls="<<VMS_EXEC(g_poll_calls)<<" gate_reads="<<VMS_EXEC(g_poll_gate_reads)
             <<" poll_requested_us="<<fit24_clock::poll_requested_us<<" poll_actual_us="<<fit24_clock::poll_actual_us<<" poll_max_request_us="<<fit24_clock::poll_max_request_us
             <<" poll_waits="<<VMS_EXEC(g_poll_waits)<<" poll_wait_us="<<VMS_EXEC(g_poll_wait_us)
             <<" fast_ops="<<VMS_EXEC(g_fast_ops)<<" slow_ops="<<VMS_EXEC(g_slow_ops)<<" scale="<<VMS_EXEC(g_game_clock).scale
             <<" gates="<<fit24_clock::gates.size()<<" checks="<<checks<<" failures="<<failures<<'\n';
    for(size_t n=0;n<fit24_clock::gates.size();++n){const auto& g=fit24_clock::gates[n];std::cout<<"GATE n="<<n<<" request="<<g.request<<" anchor="<<g.anchor<<" target="<<g.target<<" returned="<<g.last<<" ready="<<g.ready<<'\n';}
    std::cout<<(failures?"FAIL":"PASS")<<" original absolute deadline VM checks\n";
    return failures?1:0;
}
