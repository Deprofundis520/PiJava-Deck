#!/usr/bin/env python3
"""Structural negative tests for the NSP verifier; no console keys required."""
import hashlib
import importlib.util
import struct
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
target = ROOT / 'tools/verify_nsp.py'
if not target.is_file():
    raise SystemExit('FAIL: installable NSP verification is not implemented')
spec = importlib.util.spec_from_file_location('verify_nsp', target)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def container(names, payloads):
    strings = b''
    entries = b''
    offset = 0
    for name, data in zip(names, payloads):
        entries += struct.pack('<QQII', offset, len(data), len(strings), 0)
        strings += name.encode() + b'\0'
        offset += len(data)
    return b'PFS0' + struct.pack('<III', len(names), len(strings), 0) + entries + strings + b''.join(payloads)


with tempfile.TemporaryDirectory(prefix='pijava-nsp-checks-') as directory:
    directory = Path(directory)
    data = [b'program', b'control', b'meta']
    names = [hashlib.sha256(b).hexdigest()[:32] + ('.cnmt.nca' if i == 2 else '.nca') for i, b in enumerate(data)]
    good = container(names, data)
    package = directory / 'test.nsp'
    package.write_bytes(good)
    result = module.read_pfs0(package)
    assert len(result) == 3 and [r['name'] for r in result] == names
    cases = {
        'renamed_nro': b'\0' * 16 + b'NRO0' + b'\0' * 500,
        'truncated_table': good[:30],
        'truncated_payload': good[:-1],
        'path_traversal': container(['../' + names[0], names[1], names[2]], data),
        'duplicate_name': container([names[0], names[0], names[2]], data),
        'wrong_content_hash': container(names, [b'Program', data[1], data[2]]),
        'exefs_only': container(['main', 'main.npdm'], [b'NSO0', b'META']),
    }
    for label, raw in cases.items():
        package.write_bytes(raw)
        try:
            module.read_pfs0(package)
        except (ValueError, AssertionError):
            continue
        raise AssertionError('accepted invalid NSP: ' + label)
    print('PASS NSP structural checks valid=1 negative=' + str(len(cases)))
