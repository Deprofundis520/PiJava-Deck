#include <map>
#include <vector>
#include <cstdint>
#include <sstream>
static std::map<std::pair<const void*,int>, std::pair<uint64_t,uint64_t>> region_exits;
static void jitr_exit_hook(const void* m,int pc,int done,int,int32_t*,unsigned,const std::vector<int16_t>&,const std::vector<uint8_t>&){auto& n=region_exits[{m,pc}];++n.first;n.second+=done;}
#define J2ME_JITR_EXITS 1
#define main emulator_main
#include PROBE_VM
#undef main
#include PROBE_MENU
#include PROBE_SPEED
static host_menu::Settings g_menu_settings;
static std::string scene_snapshot;
static std::string instant_state_path(const std::string&) { return scene_snapshot; }
#include PROBE_SAVE
static Value fget(int ref,const char* name,const char* desc){if(ref<=0)return {};auto* f=find_field(VMS_HEAP(g_heap)[ref].cls,name,desc);return f?VMS_HEAP(g_heap)[ref].fields[f->slot]:Value{};}
static Value sget(const char* cls,const char* name,const char* desc){int cid=-1;for(size_t i=0;i<VMS_CL(g_classes).size();++i)if(VMS_CL(g_classes)[i].name==cls)cid=int(i);if(cid<0)return {};auto* f=find_field(cid,name,desc);return f?VMS_CL(g_classes)[f->owner].statics[f->slot]:Value{};}
static void report(){
  std::vector<std::pair<uint64_t,std::string>> rows;
  for(auto& c:VMS_CL(g_classes))for(auto& m:c.methods){if(m.read_leaf_calls)std::cout<<"READLEAF "<<c.name<<'.'<<m.name<<m.desc<<" calls="<<m.read_leaf_calls<<" fallback="<<m.read_leaf_fallbacks<<'\n';if(m.cpu_profile.calls||m.cpu_profile.self_cpu_ns)rows.push_back({m.cpu_profile.self_cpu_ns,c.name+'.'+m.name+m.desc+" calls="+std::to_string(m.cpu_profile.calls)});}
  std::sort(rows.rbegin(),rows.rend());for(auto& p:rows)std::cout<<"PROFILE self_ns="<<p.first<<" method="<<p.second<<'\n';
  rows.clear();for(auto& p:region_exits){auto* m=static_cast<const Method*>(p.first.first);rows.push_back({p.second.first,VMS_CL(g_classes)[m->class_id].name+'.'+m->name+m->desc+" pc="+std::to_string(p.first.second)+" ops="+std::to_string(p.second.second)});}std::sort(rows.rbegin(),rows.rend());for(size_t i=0;i<std::min(size_t(60),rows.size());++i)std::cout<<"REGION exits="<<rows[i].first<<" method="<<rows[i].second<<'\n';
}
int main(int argc,char** argv){
  if(argc!=7){std::cerr<<"runtime jar output-prefix seconds cap keys\n";return 2;}
  const std::string prefix=argv[3];const int seconds=std::atoi(argv[4]);
  setenv("J2ME_RMS_DIR",(prefix+"-rms").c_str(),1);VMS_CL(g_classpath)={argv[1]};VMS_PLAT(g_boot_ms)=now_ms();VMS_DIAG(g_log_draw)=false;VMS_EXEC(g_slice_ms)=14;VMS_EXEC(g_speed_cap)=std::atoi(argv[5]);
  log_open((prefix+".log").c_str(),true);configure_runtime_diagnostics();
  std::vector<uint8_t> bytes;std::string err;if(!read_whole(argv[2],bytes)||!unzip(bytes,VMS_CL(g_jar_files),err))return 3;
  load_props();auto midlet=manifest_midlet();for(char& c:midlet)if(c=='.')c='/';VMS_RS(g_fb).assign(size_t(VMS_RS(g_screen_w))*VMS_RS(g_screen_h)*3,0);launch_class(midlet,rms_jar_identity(bytes.data(),bytes.size()));
  std::vector<std::pair<int,int>> keys;std::istringstream input(argv[6]);std::string item;while(std::getline(input,item,',')){auto c=item.find(':');if(c!=std::string::npos)keys.emplace_back(std::atoi(item.substr(0,c).c_str()),std::atoi(item.substr(c+1).c_str()));}
  const int64_t begin=paint_clock_us();int held=0,mask=0,last_sec=-1;int64_t release=0;size_t key=0;
  while(paint_clock_us()-begin<int64_t(seconds)*1000000){
    int64_t now=paint_clock_us(),ms=(now-begin)/1000;
    if(held&&now>=release){VMS_PLAT(g_key_states)&=~mask;dispatch_key(held,true);held=mask=0;}
    if(!held&&key<keys.size()&&ms>=keys[key].first){held=keys[key++].second;int action=game_key_action(held);mask=action>0&&action<31?1<<action:0;VMS_PLAT(g_key_states)|=mask;dispatch_key(held,false);release=paint_clock_us()+100000;}
    host_lifecycle_poll242();sched_game_work(false,[]{},[](int64_t ms){std::this_thread::sleep_for(std::chrono::milliseconds(ms));});sched_present_turn(true,false,false,3,[]{});
    int sec=int((paint_clock_us()-begin)/1000000);if(sec!=last_sec){last_sec=sec;write_png(prefix+"-"+std::to_string(sec)+".png",VMS_RS(g_fb),VMS_RS(g_screen_w),VMS_RS(g_screen_h));int world=sget("g","a","Lm;").ref;std::cout<<"SCENE seconds="<<sec<<" world="<<world<<" class="<<(world>0?VMS_CL(g_classes)[VMS_HEAP(g_heap)[world].cls].name:"-")<<" actors="<<fget(world,"f","I").i<<" other="<<fget(world,"g","I").i<<" frames="<<VMS_RS(g_game_frames)<<" heap="<<VMS_HEAP(g_heap).size()<<std::endl;}
  }
  if(held)dispatch_key(held,true);scene_snapshot=prefix+".j2s";std::cout<<"SNAPSHOT saved="<<sheet_save_instant_state(argv[2])<<" path="<<scene_snapshot<<std::endl;report();lifecycle_destroy();jit_region_reset();VMS_NATIVE(g_native_jit).clear();p7::pool().shutdown();log_shutdown();std::cout.flush();std::cerr.flush();std::_Exit(0);
}
