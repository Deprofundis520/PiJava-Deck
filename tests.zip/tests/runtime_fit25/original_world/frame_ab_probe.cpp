#include <map>
#include <cstdint>
#include <vector>
#ifdef FRAME_PROFILE_EXITS
static bool capture_exits=false;
static std::map<std::pair<const void*,int>,uint64_t> region_exits;
static void jitr_exit_hook(const void* m,int pc,int,int,int32_t*,unsigned,const std::vector<int16_t>&,const std::vector<uint8_t>&){if(capture_exits)++region_exits[{m,pc}];}
#define J2ME_JITR_EXITS 1
#endif
#define main emulator_main
#include PROBE_VM
#undef main
#include PROBE_MENU
#include PROBE_SPEED
static host_menu::Settings g_menu_settings;
static std::string scene_snapshot;
static std::string instant_state_path(const std::string&) { return scene_snapshot; }
#include PROBE_SAVE
static unsigned checks=0;
static void check(bool ok,const char* why){++checks;if(!ok){std::cerr<<"FAIL "<<why<<'\n';std::exit(1);}}
static Value sget(const char* cls,const char* name,const char* desc){auto* f=find_field(ensure_class(cls),name,desc);check(f&&f->is_static,"scene static exists");return VMS_CL(g_classes)[f->owner].statics[f->slot];}
static Value fget(int ref,const char* name,const char* desc){auto* f=find_field(VMS_HEAP(g_heap)[ref].cls,name,desc);check(f&&!f->is_static,"scene field exists");return VMS_HEAP(g_heap)[ref].fields[f->slot];}
static uint64_t hash(const std::vector<uint8_t>& a){uint64_t h=14695981039346656037ull;for(auto x:a)h=(h^x)*1099511628211ull;return h;}
static void profile(){std::vector<std::pair<uint64_t,std::string>> rows;for(auto& c:VMS_CL(g_classes))for(auto& m:c.methods)if(m.cpu_profile.calls||m.cpu_profile.self_cpu_ns)rows.push_back({m.cpu_profile.self_cpu_ns,c.name+'.'+m.name+m.desc+" calls="+std::to_string(m.cpu_profile.calls)});std::sort(rows.rbegin(),rows.rend());for(auto& p:rows)std::cout<<"PROFILE self_ns="<<p.first<<" method="<<p.second<<'\n';}
int main(int argc,char** argv){
  check(argc==7,"runtime jar snapshot output-prefix frames trials");
  const std::string prefix=argv[4];const unsigned frames=std::atoi(argv[5]),trials=std::atoi(argv[6]);
  check(frames>0&&trials>0&&trials%4==0,"positive ABBA trial counts");
  VMS_CL(g_classpath)={argv[1]};VMS_PLAT(g_boot_ms)=now_ms();log_open((prefix+".log").c_str(),true);configure_runtime_diagnostics();VMS_DIAG(g_log_draw)=false;VMS_EXEC(g_slice_ms)=100000;VMS_EXEC(g_speed_cap)=0;
  std::vector<uint8_t> bytes;std::string err;check(read_whole(argv[2],bytes)&&unzip(bytes,VMS_CL(g_jar_files),err),"original jar loads");load_props();scene_snapshot=argv[3];
  const auto identity=rms_jar_identity(bytes.data(),bytes.size());
  for(int trial=-2;trial<int(trials);++trial){
    // One binary contains the exact old/new fast-batch bodies. Select only at
    // a stopped VM boundary, then restore the identical original saved state.
    immortal_ab_use_new=trial<0?trial==-1:(trial%4==1||trial%4==2);
    check(restore_instant_state(argv[2],identity),"same natural scene restores");
    const int world=sget("g","a","Lm;").ref,draw=sget("y","a","Lb;").ref;check(world>0&&draw>0,"natural world and graphics exist");
    const int gfx=fget(draw,"a","Ljavax/microedition/lcdui/Graphics;").ref;const int target=VMS_RS(g_gfx_target).at(gfx);check(target>0,"original offscreen target exists");
    auto* paint=find_method(VMS_HEAP(g_heap)[world].cls,"a","(Lb;)V",true);check(paint,"original full world paint exists");const std::vector<Value> args{Value::of_ref(world),Value::of_ref(draw)};
    auto run_frame=[&](){run(paint,args);check(!VMS_EXEC(g_thrown)&&!current_context().unhandled,"full world paint returns");};
    speed_sync_clock();VMS_EXEC(g_game_clock_inherited)=true;VMS_EXEC(g_game_clock).start(paint_clock_us(),946684800000LL);VMS_EXEC(g_game_clock).paused=true;
    const auto saved_threads=VMS_EXEC(g_threads);VMS_EXEC(g_threads).clear();VMS_EXEC(g_thread_live)=false;
    for(const auto& t:saved_threads)for(const auto& f:t.frames){for(const auto& v:f.locals)if(v.ref>0)VMS_CL(g_classes)[ensure_class("java/lang/Object")].statics.push_back(v);for(const auto& v:f.stack)if(v.ref>0)VMS_CL(g_classes)[ensure_class("java/lang/Object")].statics.push_back(v);}
    // Remove snapshot-loading temporaries once outside measured work. Frames
    // thereafter use the unchanged production Paint safepoint thresholds.
    gc_collect("frame-reset");VMS_HEAP(g_alloc_since)=0;
    for(unsigned i=0;i<128;++i){VMS_EXEC(g_game_clock).game_us=946684800000000LL+int64_t(i)*16667;run_frame();gc_safepoint(GcPoint::Paint);}
    if(trial<0)continue;
    if(trial==0)std::cout<<"SCENE world="<<world<<" class="<<VMS_CL(g_classes)[VMS_HEAP(g_heap)[world].cls].name<<" actors="<<fget(world,"f","I").i<<" visible="<<fget(world,"g","I").i<<" natural_constructors=1 full_renderer=1 scheduler_excluded=1 production_gc_thresholds=1 desktop_not_switch=1\n";
    VMS_RS(g_drawacc)={};VMS_RS(g_drawacc).on=true;VMS_RS(g_graphics_profile).reset(true);
    const auto fast=VMS_EXEC(g_fast_ops),slow=VMS_EXEC(g_slow_ops),jit=VMS_NATIVE(g_native_jit).stats.ops,entries=g_jit_region_stats.entries,gc=VMS_HEAP(g_gc_cycles);
    const auto cpu=j2me_cpu_clock::now_ns(),begin=paint_clock_us();
    for(unsigned i=0;i<frames;++i){VMS_EXEC(g_game_clock).game_us=946684800000000LL+int64_t(128+i)*16667;run_frame();gc_safepoint(GcPoint::Paint);}
    const auto cpu_ns=j2me_cpu_clock::now_ns()-cpu,wall_us=paint_clock_us()-begin;auto g=VMS_RS(g_graphics_profile).take_global();
    std::cout<<"FRAME trial="<<trial<<" variant="<<(immortal_ab_use_new?"new":"old")<<" frames="<<frames<<" cpu_ns="<<cpu_ns<<" wall_us="<<wall_us<<" pixels="<<hash(VMS_HEAP(g_heap)[target].pixels)<<" fast="<<VMS_EXEC(g_fast_ops)-fast<<" slow="<<VMS_EXEC(g_slow_ops)-slow<<" jit="<<VMS_NATIVE(g_native_jit).stats.ops-jit<<" entries="<<g_jit_region_stats.entries-entries<<" gfx="<<g.native_calls<<" lines="<<VMS_RS(g_drawacc).lines<<" images="<<VMS_RS(g_drawacc).images<<" clips="<<VMS_RS(g_drawacc).clips<<" gc="<<VMS_HEAP(g_gc_cycles)-gc<<'\n';
    check(g_gc_sp.violations==0&&jit236::active_code_calls()==0,"safepoints and code calls preserved");
    if(trial+1==int(trials))write_png(prefix+".png",VMS_HEAP(g_heap)[target].pixels,VMS_HEAP(g_heap)[target].width,VMS_HEAP(g_heap)[target].height);
  }
  std::cout<<"PASS frame-AB checks="<<checks<<'\n';jit_region_reset();VMS_NATIVE(g_native_jit).clear();p7::pool().shutdown();log_shutdown();std::cout.flush();std::cerr.flush();std::_Exit(0);
}
