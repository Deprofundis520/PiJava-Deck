#!/usr/bin/env python3
import argparse, hashlib, json, subprocess, time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--probe',type=Path);p.add_argument('--output',type=Path,required=True);p.add_argument('--optimization',choices=['O0','O1','O2'],default='O1');a=p.parse_args()
root=Path(__file__).resolve().parent;source=a.source.resolve();out=a.output.resolve();out.mkdir(parents=True,exist_ok=True);probe=(a.probe or root/'scene_probe.cpp').resolve()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
inputs={str(f):sha(f) for n in ['src','third_party','romfs/classes'] for f in (source/n).rglob('*') if f.is_file()};inputs[str(probe)]=sha(probe)
(out/'input-sha256.json').write_text(json.dumps(inputs,indent=2)+'\n')
commands=[['gcc','-'+a.optimization,'-g0','-c',str(source/'src/puff.c'),'-o',str(out/'puff.o')],['g++','-'+a.optimization,'-g0','-std=c++17','-fno-exceptions','-ffunction-sections','-fdata-sections','-DPROBE_VM="'+str(source/'src/j2mevm.cpp')+'"','-DPROBE_MENU="'+str(source/'src/host_menu.h')+'"','-DPROBE_SPEED="'+str(source/'src/host_speed.h')+'"','-DPROBE_SAVE="'+str(source/'src/instant_state.inc')+'"',str(probe),str(out/'puff.o'),'-Wl,--gc-sections','-pthread','-ldl','-o',str(out/'probe')]]
records=[]
for i,command in enumerate(commands):
    begin=time.monotonic()
    with (out/f'build-{i}.log').open('wb') as log:r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=300)
    records.append({'command':command,'returncode':r.returncode,'seconds':time.monotonic()-begin});(out/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print('build',i,r.returncode,round(records[-1]['seconds'],2),flush=True)
    if r.returncode:raise SystemExit((out/f'build-{i}.log').read_text()[-10000:])
(out/'input-changes.json').write_text(json.dumps([f for f,d in inputs.items() if sha(Path(f))!=d])+'\n')
