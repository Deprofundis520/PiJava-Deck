#!/usr/bin/env python3
"""Reproducible, test-only exact-body fast dispatch A/B adapter."""
import argparse, difflib, hashlib, json, shutil, subprocess, sys
from pathlib import Path

here = Path(__file__).resolve().parent
p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--baseline', type=Path, required=True)
p.add_argument('--candidate', type=Path, required=True)
p.add_argument('--source', type=Path, required=True)
p.add_argument('--output', type=Path, required=True)
p.add_argument('--optimization', choices=['O1', 'O2'], default='O1')
a = p.parse_args()
base, candidate, source, out = [x.resolve() for x in (a.baseline, a.candidate, a.source, a.output)]
for name in ('src', 'third_party', 'romfs/classes'):
    shutil.copytree(base/name, source/name, dirs_exist_ok=True)
old = (base/'src/interpreter_fast.inc').read_text()
new = (candidate/'src/interpreter_fast.inc').read_text()
start = 'template<bool JitReentry = false>\nstatic int execute_fast_batch('
end = '#include "read_leaf.inc"'
def parts(text):
    i, j = text.index(start), text.index(end)
    return text[:i], text[i:j], text[j:]
op, ob, os = parts(old)
np, nb, ns = parts(new)
forward = 'static bool execute_read_leaf(Method* m,const Value* args,int count,unsigned budget,Value& result,unsigned& executed);\n'
assert np == op + forward and os == ns
def renamed(body, name):
    needle = 'static int execute_fast_batch('
    assert body.count(needle) == 1
    return body.replace(needle, 'static int '+name+'(', 1)
old_body, new_body = renamed(ob, 'immortal_ab_fast_old'), renamed(nb, 'immortal_ab_fast_new')
dispatch = '''// Test-only selector; absent from every production candidate.
static bool immortal_ab_use_new=false;
template<bool JitReentry = false>
static int execute_fast_batch(Frame& fr,int budget) {
    return immortal_ab_use_new?immortal_ab_fast_new<JitReentry>(fr,budget):immortal_ab_fast_old<JitReentry>(fr,budget);
}
'''
adapted = np+old_body+new_body+dispatch+os
(source/'src/interpreter_fast.inc').write_text(adapted)
def sha(text): return hashlib.sha256(text.encode()).hexdigest()
manifest = {
    'baseline': str(base), 'candidate': str(candidate),
    'old_source_sha256': sha(old), 'new_source_sha256': sha(new),
    'old_body_sha256': sha(ob), 'new_body_sha256': sha(nb),
    'adapter_sha256': sha(adapted),
    'old_body_normalized_equals_original': old_body.replace('immortal_ab_fast_old','execute_fast_batch') == ob,
    'new_body_normalized_equals_candidate': new_body.replace('immortal_ab_fast_new','execute_fast_batch') == nb,
    'outside_body_differences': 'candidate forward declaration; exact renamed old/new template bodies; shared test-only selector; unchanged read_leaf include',
    'frame_input': 'same natural snapshot restored before each trial, same 128 warm frames, production GC threshold safepoints, ABBA order',
    'timing_scope': 'original full world renderer with natural actors/assets; scheduler, update, scripted external overlay, display/audio excluded',
    'no_switch_performance_claim': True,
}
out.mkdir(parents=True, exist_ok=True)
(out/'adapter.json').write_text(json.dumps(manifest, indent=2)+'\n')
(out/'adapter.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True), adapted.splitlines(True), fromfile='baseline/src/interpreter_fast.inc', tofile='ab-source/src/interpreter_fast.inc')))
subprocess.run([sys.executable, here/'build_probe.py', '--source', source, '--probe', here/'frame_ab_probe.cpp', '--output', out, '--optimization', a.optimization], check=True)
