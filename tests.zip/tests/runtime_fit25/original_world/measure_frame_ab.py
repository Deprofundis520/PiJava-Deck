#!/usr/bin/env python3
"""Sequential exact-body same-process A/B, preserving every observation."""
import argparse, hashlib, json, os, statistics, subprocess, time
from pathlib import Path

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--binary', type=Path, required=True)
p.add_argument('--runtime', type=Path, required=True)
p.add_argument('--jar', type=Path, required=True)
p.add_argument('--snapshot', type=Path, required=True)
p.add_argument('--output', type=Path, required=True)
p.add_argument('--frames', type=int, default=256)
p.add_argument('--trials', type=int, default=32)
a = p.parse_args()
assert a.frames > 0 and a.trials > 0 and a.trials % 4 == 0
out = a.output.resolve();out.mkdir(parents=True, exist_ok=True)
cpu = min(os.sched_getaffinity(0));os.sched_setaffinity(0, {cpu})
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
identity = {'binary': str(a.binary.resolve()), 'binary_sha256': sha(a.binary),
            'jar_sha256': sha(a.jar), 'snapshot_sha256': sha(a.snapshot),
            'cpu': cpu, 'frames': a.frames, 'trials': a.trials,
            'method': 'same-process exact-body ABBA; restore snapshot and 128 warm frames before every trial',
            'all_samples_retained': True, 'no_switch_performance_claim': True}
(out/'identity.json').write_text(json.dumps(identity, indent=2)+'\n')
assert int(os.environ.get('J2ME_GC_STRESS', '0')) == 0
summaries = {}
for engine, enabled in [('jit', '1'), ('fast', '0')]:
    prefix = out/engine
    cmd = [str(a.binary.resolve()), str(a.runtime.resolve()), str(a.jar.resolve()),
           str(a.snapshot.resolve()), str(prefix), str(a.frames), str(a.trials)]
    env = os.environ.copy();env['J2ME_JIT'] = enabled
    begin = time.monotonic()
    with prefix.with_suffix('.txt').open('wb') as f:
        r = subprocess.run(cmd, env=env, stdout=f, stderr=subprocess.STDOUT, timeout=300)
    record = {'command': cmd, 'J2ME_JIT': enabled, 'returncode': r.returncode,
              'seconds': time.monotonic()-begin}
    prefix.with_suffix('.command.json').write_text(json.dumps(record, indent=2)+'\n')
    assert r.returncode == 0, prefix.with_suffix('.txt').read_text()[-8000:]
    rows = []
    for line in prefix.with_suffix('.txt').read_text().splitlines():
        if not line.startswith('FRAME '): continue
        row = {}
        for pair in line.split()[1:]:
            k, v = pair.split('=', 1);row[k] = v if k == 'variant' else int(v)
        row['ops'] = row['fast']+row['slow']+row['jit'];rows.append(row)
    assert len(rows) == a.trials
    invariants = {k: sorted({r[k] for r in rows}) for k in
                  ['frames', 'pixels', 'gfx', 'lines', 'images', 'clips', 'ops', 'gc']}
    assert all(len(v) == 1 for v in invariants.values()), invariants
    assert all((r['jit'] == 0) == (engine == 'fast') for r in rows)
    ratios = []
    for i in range(0, len(rows), 4):
        block = rows[i:i+4]
        assert [r['variant'] for r in block] == ['old', 'new', 'new', 'old']
        ratios.append((block[1]['cpu_ns']+block[2]['cpu_ns']) /
                      (block[0]['cpu_ns']+block[3]['cpu_ns']))
    summary = {'engine': engine, 'invariants': invariants, 'cpu_ratios': ratios,
               'median': statistics.median(ratios), 'min': min(ratios), 'max': max(ratios),
               'candidate_faster_blocks': sum(r < 1 for r in ratios),
               'all_samples_retained': True, 'no_switch_performance_claim': True}
    prefix.with_suffix('.rows.json').write_text(json.dumps(rows, indent=2)+'\n')
    prefix.with_suffix('.summary.json').write_text(json.dumps(summary, indent=2)+'\n')
    summaries[engine] = summary;print(json.dumps(summary), flush=True)
(out/'summary.json').write_text(json.dumps(summaries, indent=2)+'\n')
