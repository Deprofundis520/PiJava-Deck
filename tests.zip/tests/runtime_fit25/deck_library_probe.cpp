#define main emulator_main
#include PROBE_VM
#undef main
#include PROBE_HOST_MENU
#include PROBE_HOST_SPEED
static host_menu::Settings g_menu_settings;
static std::string instant_state_path(const std::string&){return "unused-library-state";}
#include PROBE_STATE
static void check(bool b,const char* why){if(!b){std::cerr<<"FAIL "<<why<<"\n";std::exit(1);}}
static Value call(const char* name,const char* desc="()V"){int cls=ensure_class("DeckLibraryChecks");Method*m=find_method(cls,name,desc,false);check(m,"fixture method");Value v=run_event_callback(m,{});check(!VMS_EXEC(g_thrown)&&!current_context().unhandled,"Java callback");return v;}
int main(int argc,char**argv){check(argc==3,"args");VMS_CL(g_classpath)={argv[1],argv[2]};log_open("deck-library-probe.log",true);VMS_RS(g_fb).assign(240*320*3,0);VMS_EXEC(g_midlet_state)=MidletState::Active;
call("setup");int cls=ensure_class("DeckLibraryChecks");auto* app=find_field(cls,"app","LDeckLibraryChecks$App;");VMS_EXEC(g_midlet)=VMS_CL(g_classes)[cls].statics[app->slot].ref;
host_events();call("selectWidget");dispatch_key(49,false);dispatch_key(49,true);repaint_current();call("selectText");call("edit");call("verify");
deck_phone::active=deck_phone::Standard;check(call("fire","()I").i==8,"legacy phone key");deck_phone::active=deck_phone::Motorola;check(call("fire","()I").i==-20,"Motorola key");deck_phone::active=deck_phone::NokiaKeyboard;check(call("fire","()I").i==-5,"Nokia keyboard key");
SavState saved,decoded;std::string bytes;check(capture_state(saved,"deck-library.jar")&&encode_state(saved,bytes)&&decode_state(bytes,decoded)&&apply_state(decoded),"Form/CustomItem snapshot roundtrip");call("verify");
log_shutdown();std::cout<<"PASS real VM: library methods, buffered stream, CustomItem paint/traversal/raw keys, Form focus and Chinese edit notification, phone profiles, new-layout J2S5 roundtrip\n";}
