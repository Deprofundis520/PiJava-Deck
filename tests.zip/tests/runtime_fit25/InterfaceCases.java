import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Graphics;

interface InterfaceRead {
    int get();
    Object value();
    Object self();
    int constant(int unused);
    void noop();
    int synchronizedGet();
    int effect();
}
class InterfaceCell implements InterfaceRead {
    int number = 7;
    Object data = new Object();
    public int get() { return number; }
    public Object value() { return data; }
    public Object self() { return this; }
    public int constant(int unused) { return 1234; }
    public void noop() {}
    public synchronized int synchronizedGet() { return number; }
    public int effect() { InterfaceCases.calls++; return number; }
}
class InterfaceInherited extends InterfaceCell { int number = 99; }
class InterfaceOverride extends InterfaceCell {
    public int get() { InterfaceCases.calls++; return 43; }
}
class InterfaceOther extends InterfaceCell { public int get() { return -17; } }

class InterfaceCases extends Canvas implements Runnable {
    static InterfaceRead base, inherited, overridden, other;
    static int calls, completed, observed;
    static Thread worker;
    protected void paint(Graphics g) {}
    public void run() { observed = base.synchronizedGet(); completed++; }
    static void setup() {
        base = new InterfaceCell(); inherited = new InterfaceInherited();
        overridden = new InterfaceOverride(); other = new InterfaceOther();
        calls = completed = observed = 0;
    }
    static int once(InterfaceRead x) { return x.get(); }
    static Object reference(InterfaceRead x) { return x.value(); }
    static Object identity(InterfaceRead x) { return x.self(); }
    static int constant(InterfaceRead x, int n) { return x.constant(n); }
    static void empty(InterfaceRead x) { x.noop(); }
    static int synchronizedRead(InterfaceRead x) { return x.synchronizedGet(); }
    static int withEffect(InterfaceRead x) { return x.effect(); }
    static int sum(InterfaceRead x, int n) {
        int total = 0;
        for (int i = 0; i < n; i++) total += x.get();
        return total;
    }
    static int nullCatch() {
        try { return once(null); }
        catch (NullPointerException e) { return 77; }
    }
    static int polymorphic(int n) {
        int total = 0;
        for (int i = 0; i < n; i++) total += once((i & 1) == 0 ? base : other);
        return total;
    }
    static void startReader() {
        worker = new Thread(new InterfaceCases()); worker.start();
    }
}
