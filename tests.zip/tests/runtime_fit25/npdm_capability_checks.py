#!/usr/bin/env python3
"""Check serialized NPDM compatibility and required PiJava JIT/thread capabilities.

Use --config with --npdmtool to serialize the source, or --npdm for an extracted
package's main.npdm. No console keys or third-party Python modules are required.
"""
import argparse
import json
from pathlib import Path
import struct
import subprocess
import tempfile


def require(condition, message):
    if not condition:
        raise ValueError(message)


def verify_npdm(data):
    require(len(data) >= 0x80 and data[:4] == b'META', 'invalid META header')
    require(data[0x0c] & 0x0f == 3, '64-bit application address space changed')
    require(data[0x0e:0x10] == bytes([44, 0]), 'main priority/core changed')
    aci, aci_size, acid, acid_size = struct.unpack_from('<IIII', data, 0x70)
    tables = []
    for start, size, magic_at, field_at, magic in [
            (aci, aci_size, 0, 0x30, b'ACI0'),
            (acid, acid_size, 0x200, 0x230, b'ACID')]:
        require(start >= 0x80 and size >= field_at + 8 and start + size <= len(data),
                'truncated NPDM access-control section')
        require(data[start + magic_at:start + magic_at + 4] == magic, 'bad access-control magic')
        offset, length = struct.unpack_from('<II', data, start + field_at)
        require(offset >= field_at + 8 and length > 0 and length % 4 == 0 and
                offset + length <= size, 'invalid kernel-capability extent')
        tables.append(struct.unpack_from('<' + 'I' * (length // 4), data, start + offset))
    require(tables[0] == tables[1], 'ACI0 permissions differ from ACID bounds')
    caps = tables[0]
    cores = [c for c in caps if c & 0x0f == 0x07]
    debug = [c for c in caps if c & 0x1ffff == 0xffff]
    require(len(cores) == len(debug) == 1, 'missing or duplicate core/debug capability')
    core, flags = cores[0], debug[0]
    require(flags >> 19 == 0, 'pre-19 kernel reserved debug bits are set')
    require(bin((flags >> 17) & 7).count('1') <= 1, 'modern debug flags are not exclusive')
    require(flags == 0x2ffff, 'expected common allow_debug-only capability')
    require(((core >> 16) & 255, (core >> 24) & 255) == (0, 2), 'required cores 0-2 changed')
    require(((core >> 10) & 63, (core >> 4) & 63) == (28, 59), 'required priorities 28-59 changed')
    syscalls = {24 * (c >> 29) + bit for c in caps if c & 31 == 15
                for bit in range(24) if (c >> (5 + bit)) & 1}
    require({0x4b, 0x4c} <= syscalls, 'required CodeMemory JIT syscalls missing')
    require({0x08, 0x09, 0x0b, 0x0e, 0x0f} <= syscalls, 'required thread syscalls missing')
    return dict(passed=True, debug_capability=hex(flags), cores=[0, 2], priorities=[28, 59],
                pre19_reserved_clear=True, modern_debug_exclusive=True,
                code_memory_and_threads=True, aci_acid_equal=True, physical_switch_tested=False)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument('--config', type=Path)
    source.add_argument('--npdm', type=Path)
    parser.add_argument('--npdmtool', type=Path)
    args = parser.parse_args()
    if args.config:
        if not args.npdmtool:
            parser.error('--config requires --npdmtool')
        with tempfile.TemporaryDirectory(prefix='pijava-npdm-check-') as directory:
            target = Path(directory) / 'main.npdm'
            subprocess.run([str(args.npdmtool.resolve()), str(args.config.resolve()), str(target)], check=True)
            result = verify_npdm(target.read_bytes())
    else:
        result = verify_npdm(args.npdm.read_bytes())
    print('PASS NPDM capabilities ' + json.dumps(result, sort_keys=True))


if __name__ == '__main__':
    main()
