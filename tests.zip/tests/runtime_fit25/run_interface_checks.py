#!/usr/bin/env python3
"""Compile and execute real generic interface calls against the selected VM.

The baseline option records the expected missing-admission failure on Fit24.
Optional AArch64 execution uses QEMU only for correctness, never host timing.
"""
import argparse, hashlib, json, os, subprocess, time
from pathlib import Path

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    here=Path(__file__).resolve().parent
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--cross-root',type=Path);p.add_argument('--baseline',action='store_true')
    p.add_argument('--arch',choices=['x64','a64','both'],default='x64');p.add_argument('--opt',choices=['0','1','2'],default='1')
    a=p.parse_args();source=a.source.resolve();out=a.output.resolve();out.mkdir(parents=True,exist_ok=True)
    files=[f for s in ('src','third_party','romfs/classes') for f in sorted((source/s).rglob('*')) if f.is_file()]+[here/n for n in ('InterfaceCases.java','interface_vm_checks.cpp','run_interface_checks.py')]
    inputs={str(f):sha(f) for f in files};(out/'input-sha256.json').write_text(json.dumps(inputs,indent=2)+'\n');records=[];binaries={}
    def run(label,cmd,env=None,want=0):
        cmd=list(map(str,cmd));start=time.monotonic();r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=300,cwd=source,env=env)
        (out/(label+'.log')).write_bytes(r.stdout);records.append(dict(label=label,command=cmd,returncode=r.returncode,expected_returncode=want,seconds=time.monotonic()-start))
        (out/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(label,'returncode',r.returncode,'expected',want,flush=True)
        if r.returncode!=want:raise SystemExit(r.stdout.decode(errors='replace')[-8000:])
        return r.stdout.decode(errors='replace')
    classes=out/'classes';classes.mkdir(exist_ok=True)
    run('javac',['java','-m','jdk.compiler/com.sun.tools.javac.Main','-source','8','-target','8','-bootclasspath',source/'romfs/classes','-classpath',source/'romfs/classes','-d',classes,here/'InterfaceCases.java'])
    arches=[]
    if a.arch in ('x64','both'):arches.append(('x64',['gcc'],['g++'],[],os.environ.copy()))
    if a.arch in ('a64','both'):
        if not a.cross_root:p.error('--cross-root required for AArch64')
        cross=a.cross_root.resolve();env=os.environ.copy();env['LD_LIBRARY_PATH']=str(cross/'usr/lib/x86_64-linux-gnu')
        arches.append(('a64',[cross/'usr/bin/aarch64-linux-gnu-gcc','--sysroot='+str(cross)],[cross/'usr/bin/aarch64-linux-gnu-g++','--sysroot='+str(cross)],[cross/'usr/bin/qemu-aarch64','-L',cross/'usr/aarch64-linux-gnu'],env))
    for name,cc,cxx,qemu,env in arches:
        archout=out/name;archout.mkdir(exist_ok=True);puff=archout/'puff.o';binary=archout/'interface-vm-checks'
        run(name+'-puff',cc+['-O'+a.opt,'-g0','-c',source/'src/puff.c','-o',puff],env)
        defs=['-D'+k+'="'+str(source/v)+'"' for k,v in {'PROBE_VM':'src/j2mevm.cpp','PROBE_HOST_MENU':'src/host_menu.h','PROBE_HOST_SPEED':'src/host_speed.h','PROBE_STATE':'src/instant_state.inc'}.items()]
        run(name+'-vm',cxx+['-O'+a.opt,'-g0','-std=c++17','-fno-exceptions','-ffunction-sections','-fdata-sections']+defs+[here/'interface_vm_checks.cpp',puff,'-Wl,--gc-sections','-pthread','-ldl','-o',binary],env)
        binaries[str(binary)]=sha(binary)
        for engine in ('fast','jit'):
            for mode in ('semantics','state'):
                run(name+'-'+engine+'-'+mode,qemu+[binary,classes,source/'romfs/classes',engine,mode],env)
        text=run(name+'-jit-admission',qemu+[binary,classes,source/'romfs/classes','jit','admission'],env,1 if a.baseline else 0)
        if a.baseline and 'resolved monomorphic interface getter enters existing guarded JIT path' not in text:raise SystemExit('Wrong RED failure')
    changed=[f for f,h in inputs.items() if sha(Path(f))!=h];(out/'input-changes.json').write_text(json.dumps(changed)+'\n');assert not changed,changed
    (out/'binary-sha256.json').write_text(json.dumps(binaries,indent=2)+'\n')
    (out/'summary.json').write_text(json.dumps(dict(passed=True,baseline_expected_red=a.baseline,architectures=[r[0] for r in arches],commands=records,inputs_unchanged=True,scope='host/QEMU correctness; no physical Switch FPS'),indent=2)+'\n')
if __name__=='__main__':main()
