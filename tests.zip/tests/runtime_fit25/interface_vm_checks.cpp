// Actual interface calls and native-machine-code budget/class-guard checks.
// A missing interface IC must fail admission; wrong decode lengths, virtual
// targets, budgets or roots must fail the independent behavior assertions.
#define main emulator_main
#include PROBE_VM
#undef main
#include PROBE_HOST_MENU
#include PROBE_HOST_SPEED
static host_menu::Settings g_menu_settings;
static std::string instant_state_path(const std::string&) { return "unused-interface-state"; }
#include PROBE_STATE

static unsigned checks=0;
static void check(bool ok,const char* why){++checks;if(!ok){std::cerr<<"FAIL interface "<<why<<'\n';std::exit(1);}}
static Method* method(const char* name,const char* desc){auto* m=find_method(ensure_class("InterfaceCases"),name,desc,false);check(m,"fixture method exists");return m;}
static Value invoke(const char* name,const char* desc="()V",std::vector<Value> args={}){auto value=run(method(name,desc),args);check(!VMS_EXEC(g_thrown)&&!current_context().unhandled,"fixture returns normally");return value;}
static Value& stat(const char* name,const char* desc){auto* f=find_field(ensure_class("InterfaceCases"),name,desc);check(f&&f->is_static,"fixture static exists");return VMS_CL(g_classes)[f->owner].statics[f->slot];}
static Value& field(int ref,const char* name,const char* desc){auto* f=find_field(VMS_HEAP(g_heap)[ref].cls,name,desc);check(f&&!f->is_static,"fixture instance field exists");return VMS_HEAP(g_heap)[ref].fields[f->slot];}
static int receiver(const char* name){return stat(name,"LInterfaceRead;").ref;}
static int interface_pc(const Method* m){for(size_t pc=0;pc<m->code.size();){if(m->code[pc]==185)return int(pc);const int len=jvm_op_length(m->code,pc);check(len>0,"bytecode decoding progresses");pc+=size_t(len);}check(false,"fixture has invokeinterface");return -1;}
static uint64_t ops(){return VMS_EXEC(g_fast_ops)+VMS_EXEC(g_slow_ops)+VMS_NATIVE(g_native_jit).stats.ops;}

static void semantics(){
    invoke("setup");const int base=receiver("base"),inherited=receiver("inherited"),other=receiver("other"),over=receiver("overridden");
    for(int repeat=0;repeat<3;++repeat)for(int ref:{base,inherited,other,over,base}){
        const int want=ref==other?-3400:ref==over?8600:1400;
        const auto before=ops();const int got=invoke("sum","(LInterfaceRead;I)I",{Value::of_ref(ref),Value::of_i(200)}).i;
        check(got==want,"warm interface loop preserves inherited/overridden receiver behavior");
        if(ref==base||ref==inherited)check(ops()-before==2609,"200 getter loop uses hand-counted 13n+9 original ops");
    }
    check(stat("calls","I").i==600,"side-effecting override executes exactly once per original call");
    check(invoke("nullCatch","()I").i==77,"warm null interface receiver follows Java exception path");
    check(invoke("polymorphic","(I)I",{Value::of_i(200)}).i==-1000,"alternating receiver classes retain dynamic dispatch");
    check(invoke("reference","(LInterfaceRead;)Ljava/lang/Object;",{Value::of_ref(base)}).ref==field(base,"data","Ljava/lang/Object;").ref,"interface getter preserves reference identity");
    check(invoke("identity","(LInterfaceRead;)Ljava/lang/Object;",{Value::of_ref(base)}).ref==base,"interface self return preserves receiver identity");
    check(invoke("constant","(LInterfaceRead;I)I",{Value::of_ref(base),Value::of_i(INT_MIN)}).i==1234,"ignored argument and constant return remain intact");
    invoke("empty","(LInterfaceRead;)V",{Value::of_ref(base)});
    const auto original_calls=stat("calls","I").i;check(invoke("withEffect","(LInterfaceRead;)I",{Value::of_ref(base)}).i==7&&stat("calls","I").i==original_calls+1,"nontrivial interface method keeps its visible side effect");
    // Synchronized interface callees are never part of a pure inline sequence.
    check(monitor_enter(base)&&monitor_enter(base),"main context acquires receiver monitor twice");invoke("startReader");check(pump_one_thread(),"worker reaches its real synchronized interface call");
    auto* worker=thread_context(stat("worker","Ljava/lang/Thread;").ref);check(worker&&worker->state==ThreadState::Blocked&&worker->monitor==base,"interface callee blocks on existing monitor owner");
    check(stat("completed","I").i==0,"blocked interface read has not completed");
    field(base,"number","I")=Value::of_i(81);monitor_exit(base);check(!pump_one_thread(),"recursive monitor remains owned");monitor_exit(base);
    for(int i=0;i<20&&VMS_EXEC(g_thread_live);++i)pump_one_thread();
    check(!VMS_EXEC(g_thread_live)&&stat("completed","I").i==1&&stat("observed","I").i==81,"resumed synchronized read observes owner mutation exactly once");field(base,"number","I")=Value::of_i(7);
    auto& r=r4::state;const auto saved_profile=r.cfg.profile;
    for(const char* profile:{"reference-v1","optimized-v1"}){
        r.cfg.profile=profile;r.remaining=1000000;r.worker_phase=false;r.opcodes=0;r.active=true;
        const int got=run(method("sum","(LInterfaceRead;I)I"),{Value::of_ref(base),Value::of_i(200)}).i;r.active=false;
        check(got==1400&&r.opcodes==2609&&r.remaining==997391,"reference and optimized deterministic modes preserve independent original fuel");
        std::cout<<"INTERFACE_R4 profile="<<profile<<" opcodes="<<r.opcodes<<" expected=2609\n";
    }r.cfg.profile=saved_profile;
    gc_collect("interface-roots");check(invoke("reference","(LInterfaceRead;)Ljava/lang/Object;",{Value::of_ref(base)}).ref==field(base,"data","Ljava/lang/Object;").ref,"reference returned through compiled stack survives legal GC via ordinary Java owner");
    std::cout<<"INTERFACE_SEMANTICS class_guard_null_polymorphism_inheritance_effects_monitor_gc_exact_fuel=1\n";
}

static void compiled_contract(){
    invoke("setup");const int base=receiver("base"),other=receiver("other");
    for(int i=0;i<40;++i)check(invoke("once","(LInterfaceRead;)I",{Value::of_ref(base)}).i==7,"real invocation warms resolved target");
    Method* once=method("once","(LInterfaceRead;)I");const int pc=interface_pc(once);
    check(pc==1&&once->code.size()==7,"independent once fixture has five-byte interface instruction at BCI 1");
    std::vector<jitr::IcSite> sites(once->code.size());sites[pc]=jitr_ic_for(once,pc);
    check(sites[pc].kind==jitr::IC_GET,"resolved monomorphic interface getter enters existing guarded JIT path"); // Fit24 RED.
    check(sites[pc].cost==4&&sites[pc].argc==0,"interface getter charges invoke plus three original callee bytecodes");
    jitr::Spec spec;spec.code=once->code.data();spec.size=once->code.size();spec.entry=pc;spec.entry_depth=1;spec.max_locals=once->max_locals;spec.max_stack=once->max_stack;spec.ic=&sites;
    jitr::Region region;check(jitr::build(spec,region),"resolved interface call builds from nonempty operand stack");
    const jitr::Helpers helpers{jitr_h_getfield,jitr_h_aload,jitr_h_alen,jitr_h_icget,jitr_h_icchk,jitr_h_cast,jitr_h_inst,jitr_h_icgfx,jitr_h_iastore,jitr_h_getstatic};
    const uint32_t id=jit236::next_install_id();jit236::Executable exe;check(exe.install(jitr::emit_host(region,helpers,id),id),"interface contract machine code installs");
    unsigned cases=0;
    for(int ref:{base,other,0})for(unsigned budget:{0u,1u,2u,3u,4u,5u}){
        std::vector<int32_t> slots(2+2*(spec.max_locals+spec.max_stack+1),0);slots[0]=-7;slots[1]=int32_t(id);slots[3]=ref;slots[3+2*spec.max_locals]=ref;
        const auto before=slots;uint64_t result;{jit236::CodeCall call;result=reinterpret_cast<jitr::Fn>(exe.fn)(slots.data(),budget);}
        const bool executed=ref==base&&budget>=4;
        check(uint32_t(result)==unsigned(executed?6:1)&&unsigned(result>>32)==unsigned(executed?4:0),"budget/class/null exit charges nothing and retains exact original invocation BCI");
        if(executed)check(slots[2+2*spec.max_locals]==7&&slots[3+2*spec.max_locals]==0&&slots[0]==1,"five-byte interface fallthrough and integer result are exact");
        else for(size_t i=2;i<slots.size();++i)check(slots[i]==before[i],"bailout preserves live locals and operands");
        ++cases;
    }
    // Resolving a different concrete receiver cannot authorize stale code.
    check(invoke("once","(LInterfaceRead;)I",{Value::of_ref(other)}).i==-17,"class miss reexecutes original virtual resolution");
    check(invoke("once","(LInterfaceRead;)I",{Value::of_ref(base)}).i==7,"previous receiver remains correct after polymorphic miss");
    for(const char* name:{"synchronizedRead","withEffect"}){
        invoke(name,"(LInterfaceRead;)I",{Value::of_ref(base)});auto* m=method(name,"(LInterfaceRead;)I");check(jitr_ic_for(m,interface_pc(m)).kind==jitr::IC_NONE,"synchronized or side-effecting callee cannot be inlined");
    }
    // Both argument removal and reference/void returns cross the new five-byte
    // interface boundary. Expected PCs/costs come from the compiled fixture.
    struct Shape {const char* name;const char* desc;int pc,next,depth,cost,kind;};
    const Shape shapes[]={
        {"reference","(LInterfaceRead;)Ljava/lang/Object;",1,6,1,4,jitr::IC_GET},
        {"identity","(LInterfaceRead;)Ljava/lang/Object;",1,6,1,3,jitr::IC_SELF},
        {"constant","(LInterfaceRead;I)I",2,7,2,3,jitr::IC_CONST},
        {"empty","(LInterfaceRead;)V",1,6,1,2,jitr::IC_VOID}};
    for(const auto& shape:shapes){
        std::vector<Value> args{Value::of_ref(base)};if(shape.depth==2)args.push_back(Value::of_i(INT_MIN));
        for(int i=0;i<40;++i)invoke(shape.name,shape.desc,args);
        auto* m=method(shape.name,shape.desc);check(interface_pc(m)==shape.pc,"argument fixture has independent expected invocation BCI");
        std::vector<jitr::IcSite> ic(m->code.size());ic[shape.pc]=jitr_ic_for(m,shape.pc);
        check(ic[shape.pc].kind==shape.kind&&ic[shape.pc].cost==shape.cost,"reference self constant and void interface targets preserve existing exact IC cost");
        jitr::Spec s;s.code=m->code.data();s.size=m->code.size();s.entry=shape.pc;s.entry_depth=shape.depth;s.max_locals=m->max_locals;s.max_stack=m->max_stack;s.ic=&ic;
        jitr::Region body;check(jitr::build(s,body),"typed interface call builds");
        const auto install=jit236::next_install_id();jit236::Executable code;check(code.install(jitr::emit_host(body,helpers,install),install),"typed interface contract installs");
        for(unsigned budget:{unsigned(shape.cost-1),unsigned(shape.cost)}){
            std::vector<int32_t> slots(2+2*(s.max_locals+s.max_stack+1),0);slots[1]=int32_t(install);slots[3+2*s.max_locals]=base;
            if(shape.depth==2)slots[2+2*(s.max_locals+1)]=INT_MIN;
            uint64_t result;{jit236::CodeCall active;result=reinterpret_cast<jitr::Fn>(code.fn)(slots.data(),budget);}
            const bool executed=budget==unsigned(shape.cost);
            check(uint32_t(result)==unsigned(executed?shape.next:shape.pc)&&unsigned(result>>32)==unsigned(executed?shape.cost:0),"typed interface call retains exact before/after budget boundary");
            if(executed&&shape.kind!=jitr::IC_VOID){const int wanted_ref=shape.kind==jitr::IC_SELF?base:shape.kind==jitr::IC_GET?field(base,"data","Ljava/lang/Object;").ref:0;
                check(slots[2+2*s.max_locals]==(shape.kind==jitr::IC_CONST?1234:0)&&slots[3+2*s.max_locals]==wanted_ref,"typed interface result preserves reference or integer value");}
        }
    }
    // The ordinary region compiler, beyond the direct contract above, must
    // actually install an interface IC at a hot loop site.
    invoke("sum","(LInterfaceRead;I)I",{Value::of_ref(base),Value::of_i(1000)});
    auto* sum=method("sum","(LInterfaceRead;I)I");const int sumpc=interface_pc(sum);bool installed=false;
    for(const auto& item:g_jit_regions[sum].at){const auto& entry=item.second;if(entry.runs&&size_t(sumpc)<entry.ic_kind.size()&&entry.ic_kind[sumpc]==jitr::IC_GET)installed=true;}
    check(installed,"normal hot-loop compilation reaches and executes interface IC metadata");
    // Invalid operand bytes are never accepted solely because the target cache
    // contains a previously valid receiver/method resolution.
    Method malformed=*once;malformed.code[4]=0;
    check(jitr_ic_for(&malformed,1).kind==jitr::IC_NONE,"zero interface count cannot authorize cached target");
    malformed=*once;malformed.code[5]=1;
    check(jitr_ic_for(&malformed,1).kind==jitr::IC_NONE,"nonzero reserved operand cannot authorize cached target");
    // A truncated interface encoding must not read its reserved/count operands.
    const uint8_t short_code[]={185,0,1};spec.code=short_code;spec.size=3;spec.entry=0;std::vector<jitr::IcSite> short_sites(3);short_sites[0]=sites[pc];spec.ic=&short_sites;
    check(!jitr::build(spec,region),"truncated five-byte instruction rejected before machine code emission");
    std::cout<<"INTERFACE_COMPILED cases="<<cases<<" original_call_pc=1 fallthrough_pc=6 exact_cost=4\n";
}

static void snapshot(){
    invoke("setup");const int base=receiver("base");
    for(int i=0;i<4;++i)check(invoke("sum","(LInterfaceRead;I)I",{Value::of_ref(base),Value::of_i(200)}).i==1400,"warm compiled interface before capture");
    const int cls=ensure_class("InterfaceCases");VMS_RS(g_current)=alloc_obj(cls);run(find_method(cls,"<init>","()V",false),{Value::of_ref(VMS_RS(g_current))});
    VMS_EXEC(g_midlet)=alloc_obj(ensure_class("java/lang/Object"));VMS_EXEC(g_midlet_state)=MidletState::Active;
    SavState saved,decoded;std::string bytes;check(capture_state(saved,"interface-fixture.jar")&&encode_state(saved,bytes),"legal snapshot captures ordinary Java object/stack state");
    check(bytes.substr(0,4)=="J2S5"&&decode_state(bytes,decoded)&&apply_state(decoded),"existing J2S5 format restores with JIT caches invalidated");
    const int restored=receiver("base");check(invoke("sum","(LInterfaceRead;I)I",{Value::of_ref(restored),Value::of_i(200)}).i==1400,"interface getter rewarms correctly after restore");
    std::cout<<"INTERFACE_STATE snapshot_restore_rewarm=1\n";
}

int main(int argc,char** argv){
    check(argc==5,"classes romfs engine mode");VMS_CL(g_classpath)={argv[1],argv[2]};VMS_DIAG(g_log_draw)=false;VMS_EXEC(g_slice_ms)=4;VMS_EXEC(g_speed_cap)=0;
    VMS_RS(g_fb).assign(240*320*3,0);VMS_NATIVE(g_native_jit).configure(std::string(argv[3])=="jit");
    check(std::string(argv[3])!="jit"||VMS_NATIVE(g_native_jit).available,"requested host JIT available");
    const std::string mode=argv[4];if(mode=="semantics")semantics();else if(mode=="admission")compiled_contract();else if(mode=="state")snapshot();else check(false,"known mode");
    check(g_gc_sp.violations==0,"no GC safepoint violation");check(jit236::active_code_calls()==0,"no live JIT call on teardown");
    VMS_NATIVE(g_native_jit).clear();jit_region_reset();std::cout<<"PASS interface checks="<<checks<<'\n';
}
