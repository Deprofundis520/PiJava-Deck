#!/usr/bin/env python3
"""Check unchanged original populated battle UI work against a selected VM.

The original JAR is an external, read-only test input and is never bundled or
rewritten. This is a correctness replay with selected actor inputs, not a
natural full-battle or physical Switch performance measurement.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time


EXPECTED_JAR_SHA256 = 'efe69d4ba2339926db0290b822035cb79be526077a28918ed2954267a8acd828'
EXPECTED_PIXEL_DIGEST = 3708250636282913805
FRAMES = 8
TRIALS = 2


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def check_trials(output, jar_sha256):
    """Validate every warm and subsequent trial; no trial is discarded."""
    lines = output.splitlines()
    if 'INPUT jar_sha256=' + jar_sha256 not in lines:
        raise ValueError('probe did not report the unchanged external JAR identity')
    trials = []
    for line in lines:
        if not line.startswith('UI '):
            continue
        row = dict(item.split('=', 1) for item in line.split()[1:])
        expected = (len(trials), 'battle', FRAMES, EXPECTED_PIXEL_DIGEST,
                    1320 * FRAMES, 134 * FRAMES, 244631 * FRAMES, '0')
        observed = (int(row['trial']), row['scenario'], int(row['frames']),
                    int(row['pixel_digest']), int(row['lines']), int(row['images']),
                    sum(int(row[key]) for key in ('fast', 'slow', 'jitops')),
                    row['profile'])
        if observed != expected:
            raise ValueError('original UI work mismatch: ' + repr(observed) +
                             ' expected ' + repr(expected))
        trials.append(row)
    if len(trials) != TRIALS:
        raise ValueError('expected exactly two complete UI trials')
    if not any(line.startswith('PASS original battle UI replay checks=') and
               'original_game_assets=1 whole_ui_draw=1 selected_input_ui=1 natural_battle=0 switch_fps_claim=0' in line
               for line in lines):
        raise ValueError('probe did not complete its GC and JIT-lifetime checks')
    return trials


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--pet-jar', type=Path, required=True)
    parser.add_argument('--opt', choices=('1', '2'), default='1')
    parser.add_argument('--cross-root', type=Path)
    parser.add_argument('--arch', choices=('x64', 'a64', 'both'), default='x64')
    args = parser.parse_args()
    if args.arch in ('a64', 'both') and args.cross_root is None:
        parser.error('--cross-root is required for AArch64 correctness execution')
    here = Path(__file__).resolve().parent
    source, out, jar = args.source.resolve(), args.output.resolve(), args.pet_jar.resolve()
    for required in (source / 'src/j2mevm.cpp', source / 'src/puff.c',
                     here / 'pet_ui_probe.cpp', jar):
        if not required.is_file():
            parser.error('required input is missing: ' + str(required))
    for directory in ('third_party', 'romfs/classes'):
        if not (source / directory).is_dir():
            parser.error('required source directory is missing: ' + str(source / directory))
    jar_sha256 = sha(jar)
    if jar_sha256 != EXPECTED_JAR_SHA256:
        parser.error('external JAR SHA-256 differs from the original replay input: ' + jar_sha256)
    out.mkdir(parents=True, exist_ok=True)
    files = [path for directory in ('src', 'third_party', 'romfs/classes')
             for path in sorted((source / directory).rglob('*')) if path.is_file()]
    files += [here / 'pet_ui_probe.cpp', Path(__file__).resolve(), jar]
    inputs = {str(path): sha(path) for path in files}
    (out / 'input-sha256.json').write_text(json.dumps(inputs, indent=2) + '\n')
    commands, binaries, runs = [], {}, []

    def run(label, command, env):
        command = list(map(str, command))
        start = time.monotonic()
        result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                cwd=source, env=env, timeout=300)
        (out / (label + '.log')).write_bytes(result.stdout)
        commands.append(dict(label=label, command=command, returncode=result.returncode,
                             seconds=time.monotonic()-start))
        (out / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
        print(label, 'returncode', result.returncode, flush=True)
        if result.returncode != 0:
            raise SystemExit(result.stdout.decode(errors='replace')[-8000:])
        return result.stdout.decode(errors='replace')

    arches = []
    if args.arch in ('x64', 'both'):
        arches.append(('x64', ['gcc'], ['g++'], [], os.environ.copy()))
    if args.arch in ('a64', 'both'):
        cross = args.cross_root.resolve()
        env = os.environ.copy()
        env['LD_LIBRARY_PATH'] = str(cross / 'usr/lib/x86_64-linux-gnu')
        arches.append(('a64',
                       [cross / 'usr/bin/aarch64-linux-gnu-gcc', '--sysroot=' + str(cross)],
                       [cross / 'usr/bin/aarch64-linux-gnu-g++', '--sysroot=' + str(cross)],
                       [cross / 'usr/bin/qemu-aarch64', '-L', cross / 'usr/aarch64-linux-gnu'], env))
    for name, cc, cxx, qemu, env in arches:
        archout = out / name
        archout.mkdir(exist_ok=True)
        puff, binary = archout / 'puff.o', archout / 'pet-ui-checks'
        run(name + '-puff', cc + ['-O' + args.opt, '-g0', '-c', source / 'src/puff.c', '-o', puff], env)
        define = '-DPROBE_VM="' + str(source / 'src/j2mevm.cpp') + '"'
        run(name + '-vm', cxx + ['-O' + args.opt, '-g0', '-std=c++17', '-fno-exceptions',
                                 '-ffunction-sections', '-fdata-sections', define,
                                 here / 'pet_ui_probe.cpp', puff, '-Wl,--gc-sections',
                                 '-pthread', '-ldl', '-o', binary], env)
        binaries[str(binary)] = sha(binary)
        (out / 'binary-sha256.json').write_text(json.dumps(binaries, indent=2) + '\n')
        for engine in ('fast', 'jit'):
            output = run(name + '-' + engine,
                         qemu + [binary, source / 'romfs/classes', engine, jar,
                                 'battle', str(FRAMES), str(TRIALS)], env)
            runs.append(dict(architecture=name, engine=engine,
                             trials=check_trials(output, jar_sha256)))
            (out / 'runs.json').write_text(json.dumps(runs, indent=2) + '\n')
    changed = [name for name, expected in inputs.items() if sha(Path(name)) != expected]
    (out / 'input-changes.json').write_text(json.dumps(changed, indent=2) + '\n')
    if changed:
        raise SystemExit('inputs changed during correctness checks: ' + repr(changed))
    summary = dict(passed=True, optimization='-O' + args.opt,
                   architectures=[row[0] for row in arches],
                   frames_per_trial=FRAMES, trials_per_engine=TRIALS,
                   engines=['fast', 'jit'], external_jar_sha256=jar_sha256,
                   expected_pixel_digest=EXPECTED_PIXEL_DIGEST,
                   expected_per_draw=dict(lines=1320, images=134, original_operations=244631),
                   inputs_unchanged=True, commands=commands, runs=runs,
                   scope='original populated UI correctness with selected actors and explicit GC per draw; no natural full-battle or physical Switch FPS claim')
    (out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print('PASS original populated UI correctness:', ','.join(summary['architectures']), flush=True)


if __name__ == '__main__':
    main()
