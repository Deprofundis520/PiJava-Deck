#define main emulator_main
#include "../src/j2mevm.cpp"
#undef main

static void check(bool ok,const char* label) {
    if(!ok){std::cerr<<"FAIL Samsung LCDLight "<<label<<"\n";std::exit(1);}
}
int main(int argc,char** argv) {
    configure_runtime_diagnostics();
    VMS_CL(g_classpath)={"build/samsung-lcdlight-classes","romfs/classes"};
    VMS_DIAG(g_log_draw)=false;
    std::vector<uint8_t> bytes;
    check(read_whole("romfs/classes/com/samsung/util/LCDLight.class",bytes),"API class is bundled");
    const int cls=ensure_class("com/samsung/util/LCDLight");
    Method* on=find_method(cls,"on","(I)V",false);
    Method* off=find_method(cls,"off","()V",false);
    Method* supported=find_method(cls,"isSupported","()Z",false);
    check(on&&off&&supported,"standard method descriptors resolve");
    VMS_RS(g_fb).assign(12,73);
    const auto original=VMS_RS(g_fb);
    const int width=VMS_RS(g_screen_w),height=VMS_RS(g_screen_h);
    auto support=[&](){Value value=run(supported,{});check(!VMS_EXEC(g_thrown),"isSupported returns normally");return value.i;};
    check(support()==1,"emulated API reports support");
    for(int duration:{10000,1,0,-1,2147483647,(-2147483647-1)}) {
        run(on,{Value::of_i(duration)});
        check(!VMS_EXEC(g_thrown),"on accepts duration without Java error");
        check(support()==1,"on does not change support");
        run(off,{});run(off,{});
        check(!VMS_EXEC(g_thrown)&&support()==1,"off is repeatable without changing support");
    }
    check(VMS_RS(g_fb)==original&&VMS_RS(g_screen_w)==width&&VMS_RS(g_screen_h)==height,
          "backlight requests preserve rendered display");
    if(argc>1&&std::string(argv[1])=="fixture") {
        const int fixture=ensure_class("SamsungLcdLightChecks");
        Method* method=find_method(fixture,"run","()I",false);
        check(method,"Java invocation fixture resolves");
        const Value value=run(method,{});
        check(!VMS_EXEC(g_thrown)&&value.i==10000,"repeated Java invokestatic calls complete");
    }
    std::cout<<"PASS Samsung LCDLight signatures, support, repeated duration/off calls, display unchanged\n";
    p7::pool().shutdown();
}
