#!/usr/bin/env python3
"""Real unmodified Xianni JAR overlap contract; x64 and optional qemu A64.

Only generated diagnostic copies use the finite libnx boundary. No production
sources, Java bytecode, HotThreshold or overlap policy constants are changed.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess
import time


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--jar', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--cross-root', type=Path)
    args = parser.parse_args()
    source = Path(__file__).resolve().parents[2]
    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=True)
    jar = args.jar.resolve()
    if sha(jar) != '0ecdc696a3bb5fd03921640b9e4ce24164963c641120abf3b4ec578f05fab85d':
        raise SystemExit('Wrong original Xianni JAR SHA-256')
    text = (source / 'src/j2mevm.cpp').read_text()
    needle = '#include "native_jit236.h"'
    stale = "jit236::fault_stale()=(f[0]=='1');"
    if text.count(needle) != 1 or text.count(stale) != 1:
        raise SystemExit('Unexpected diagnostic boundary shape')
    if os.environ.get('J2ME_JIT_FAULT_STALE'):
        raise SystemExit('Stale injection is unsupported by this Switch-boundary contract')
    hybrid = text.replace(needle, '#define __SWITCH__ 1\n' + needle + '\n#undef __SWITCH__')
    hybrid = hybrid.replace(stale, 'if(f[0]==\'1\')die("hybrid boundary disallows stale injection");')
    vm = out / 'j2mevm-finite-jit.cpp'
    vm.write_text(hybrid)
    inputs = [jar, source / 'src/j2mevm.cpp', source / 'src/native_jit236.h',
              source / 'src/jit_code_pool.h', source / 'src/jit_region.h',
              source / 'src/runtime/native_jit.inc', source / 'src/runtime/interpreter.inc',
              source / 'src/interpreter_fast.inc', source / 'src/array_storage.h',
              source / 'src/primitive_buffer_pool.h', source / 'tests/runtime_fit13/jit_mock/switch.h',
              source / 'tests/runtime_fit20/real_jar_overlap_checks.cpp', Path(__file__), vm]
    before = {str(path): sha(path) for path in inputs}
    (out / 'source-sha256.txt').write_text(''.join(digest + '  ' + path + '\n' for path, digest in before.items()))
    results = []

    def run(label, command, env=None, binary=None):
        command = list(map(str, command))
        print(label + ': ' + shlex.join(command), flush=True)
        start = time.monotonic()
        result = subprocess.run(command, cwd=source, env=env, stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT, timeout=300)
        log = out / (label + '.log')
        log.write_bytes(result.stdout)
        record = dict(label=label, command=command, signedrc=result.returncode,
                      seconds=round(time.monotonic() - start, 3), log_sha256=sha(log))
        if binary:
            record['binary_sha256'] = sha(binary)
        results.append(record)
        (out / 'commands-and-results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2) + '\n')
        print(result.stdout.decode(errors='replace'), end='', flush=True)
        print(label + '_signedrc=' + str(result.returncode), flush=True)
        if result.returncode:
            raise SystemExit(result.returncode)

    arches = [('x64', ['gcc'], ['g++'], [], None)]
    if args.cross_root:
        cross = args.cross_root.resolve()
        env = os.environ.copy()
        env['LD_LIBRARY_PATH'] = str(cross / 'usr/lib/x86_64-linux-gnu')
        sysroot = '--sysroot=' + str(cross)
        arches.append(('a64', [cross / 'usr/bin/aarch64-linux-gnu-gcc', sysroot],
                       [cross / 'usr/bin/aarch64-linux-gnu-g++', sysroot],
                       [cross / 'usr/bin/qemu-aarch64', '-L', cross / 'usr/aarch64-linux-gnu'], env))
    for arch, cc, cxx, emulator, env in arches:
        puff = out / ('puff-' + arch + '.o')
        exe = out / ('real-jar-overlap-' + arch)
        run('build-puff-' + arch, cc + ['-O1', '-c', source / 'src/puff.c', '-o', puff], env)
        run('build-real-jar-overlap-' + arch, cxx + ['-O0', '-g0', '-std=c++17', '-fno-exceptions',
            '-ffunction-sections', '-fdata-sections', '-I' + str(source / 'src'),
            '-I' + str(source / 'tests/runtime_fit13/jit_mock'), '-DJ2ME_TEST_VM="' + str(vm) + '"',
            source / 'tests/runtime_fit20/real_jar_overlap_checks.cpp', puff,
            '-Wl,--gc-sections', '-pthread', '-ldl', '-o', exe], env)
        run('real-jar-overlap-' + arch, emulator + [exe, jar, source / 'romfs/classes'], env, exe)
    after = {str(path): sha(path) for path in inputs}
    if before != after:
        raise SystemExit('Input/source identity changed during this contract run')
    (out / 'input-identity-verified.json').write_text(json.dumps(dict(all_inputs_unchanged=True,
        original_jar_sha256=sha(jar), execution_architectures=[x[0] for x in arches]), indent=2) + '\n')


if __name__ == '__main__':
    main()
