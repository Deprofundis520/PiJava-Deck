// Real alloc_array + real GC. Host timing is not Switch timing or game FPS.
#include <cstdlib>
#include <new>
#include <cstdint>
namespace host_alloc {
static bool measured = false;
static uint64_t calls = 0, bytes = 0, payload36_calls = 0, payload608_calls = 0, payload64_calls = 0, payload1024_calls = 0, payload48_calls = 0;
static void account(size_t n) {
    if (measured) { ++calls; bytes += n; if (n == 36) ++payload36_calls; if (n == 608) ++payload608_calls; if (n == 64) ++payload64_calls; if (n == 1024) ++payload1024_calls; if (n == 48) ++payload48_calls; }
}
}
void* operator new(size_t n) {
    if (void* p = std::malloc(n ? n : 1)) { host_alloc::account(n); return p; }
    std::abort();
}
void* operator new[](size_t n) { return ::operator new(n); }
void operator delete(void* p) noexcept { std::free(p); }
void operator delete[](void* p) noexcept { std::free(p); }
void operator delete(void* p, size_t) noexcept { std::free(p); }
void operator delete[](void* p, size_t) noexcept { std::free(p); }
#ifndef J2ME_TEST_VM
#define J2ME_TEST_VM "../../src/j2mevm.cpp"
#endif
#define main emulator_main
#include J2ME_TEST_VM
#undef main

static void require(bool ok, const char* why) {
    if (!ok) { std::cerr << "FAIL array-allocation-bench " << why << '\n'; std::exit(1); }
}
static uint64_t checksum = 0;
static void allocation(unsigned n, unsigned length = 9) {
    const int r = alloc_array("[I", length);
    auto& a = VMS_HEAP(g_heap)[r].elems;
    require(a.size() == length && a.get(0).i == 0 && a.get(length - 1).i == 0, "new primitive array boundary zeroes");
    // Dirty both boundaries so later reuse must clear actual former contents.
    a.set(0, Value::of_i(int(n + 1))); a.set(length - 1, Value::of_i(-int(n + 1)));
    checksum += uint32_t(a.get(0).i);
    // No reference escapes this function, so subsequent collections are safe.
}
static void workload(const std::string& scenario) {
    if (scenario == "help117") {
        // 117 * 608 = 71136 payload bytes/draw observed on the static help page.
        // Homogeneous payload proxy; not the real glyph length distribution.
        for (unsigned draw = 0; draw < 660; ++draw) {
            for (unsigned n = 0; n < 117; ++n) allocation(draw * 117 + n, 152);
            gc_safepoint(GcPoint::Paint); // production threshold, only at draw boundary
        }
    } else {
        // burst is a no-intermediate-safepoint control, not a claim about the
        // game's worker: cooperative run() may return with Java frames alive.
        unsigned batch = scenario == "burst76800" ? 76800 : scenario == "batch512" ? 512 : 256;
        for (unsigned n = 0; n < 76800; ++n) {
            allocation(n);
            if ((n + 1) % batch == 0) {
                if (scenario == "normal256") gc_safepoint(GcPoint::Paint);
                else gc_collect("bench-batch");
            }
        }
    }
    if (VMS_HEAP(g_alloc_since)) gc_collect("bench-final");
}
static int inspect_jar(const char* jar, const char* classes) {
    VMS_CL(g_classpath).push_back(classes);
    std::vector<uint8_t> bytes; std::string error;
    require(read_whole(jar, bytes) && unzip(bytes, VMS_CL(g_jar_files), error), "JAR read/unzip");
    const int cid = ensure_class("al");
    const auto& c = VMS_CL(g_classes)[cid];
    for (const auto& m : c.methods) {
        if (m.name != "a") continue;
        std::cout << "METHOD " << c.name << '.' << m.name << m.desc << " flags=" << m.flags
            << " locals=" << m.max_locals << " stack=" << m.max_stack << " code_bytes=" << m.code.size() << '\n';
        for (size_t pc = 0; pc < m.code.size();) {
            const int op = m.code[pc], len = jvm_op_length(m.code, pc);
            require(len > 0, "real al bytecode decoding");
            std::cout << "BC pc=" << pc << " op=" << op;
            for (int i = 1; i < len; ++i) std::cout << ' ' << unsigned(m.code[pc + i]);
            if (op >= 178 && op <= 185) {
                std::string owner, name, desc;
                resolve_member(c, (m.code[pc + 1] << 8) | m.code[pc + 2], owner, name, desc);
                std::cout << " member=" << owner << '.' << name << desc;
            }
            std::cout << '\n'; pc += len;
        }
    }
    return 0; // class parsing only; no initialization, native call or method execution
}
int main(int argc, char** argv) {
    require(argc >= 2, "scenario required");
    const std::string scenario = argv[1];
    if (scenario == "inspect-jar") { require(argc == 4, "inspect-jar JAR classes"); return inspect_jar(argv[2], argv[3]); }
    require(scenario == "normal256" || scenario == "batch256" || scenario == "batch512" || scenario == "help117" || scenario == "burst76800", "known scenario");
    require(!std::getenv("J2ME_GC_STRESS"), "unset J2ME_GC_STRESS for production threshold");
    const unsigned repeats = argc > 2 ? unsigned(std::atoi(argv[2])) : 7;
    const unsigned workload_repeats = argc > 3 ? unsigned(std::atoi(argv[3])) : 1;
    require(workload_repeats > 0 && workload_repeats <= 100, "bounded positive workload repeats");
    VMS_DIAG(g_log_draw) = false;
    Class c; c.name = "ArrayBenchRoot"; c.init_state = 2; c.statics.resize(1);
    VMS_CL(g_classes).push_back(std::move(c));
    const int sentinel = alloc_array("[I", 9);
    VMS_HEAP(g_heap)[sentinel].elems.set(4, Value::of_i(0x13579));
    VMS_CL(g_classes)[0].statics[0] = Value::of_ref(sentinel);
    const uint32_t generation = VMS_HEAP(g_heap)[sentinel].generation;
    gc_collect("bench-setup");
    for (unsigned trial = 0; trial <= repeats; ++trial) {
        const uint64_t cycles = VMS_HEAP(g_gc_cycles), gens = resver::g_stats.generations;
        const uint64_t safepoints = g_gc_sp.collections[1];
        checksum = 0; host_alloc::calls = host_alloc::bytes = host_alloc::payload36_calls = host_alloc::payload608_calls = host_alloc::payload64_calls = host_alloc::payload1024_calls = host_alloc::payload48_calls = 0;
        host_alloc::measured = true;
        const auto start = std::chrono::steady_clock::now();
        for (unsigned pass = 0; pass < workload_repeats; ++pass) workload(scenario);
        const double ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - start).count();
        host_alloc::measured = false;
        require(VMS_HEAP(g_array_payload_live) == 36, "all unrooted payload reclaimed");
        require(VMS_HEAP(g_heap)[sentinel].is_array && VMS_HEAP(g_heap)[sentinel].generation == generation &&
            VMS_HEAP(g_heap)[sentinel].elems.get(4).i == 0x13579, "static root unchanged by all sweeps");
        require(g_gc_sp.violations == 0, "legal safepoints");
        const uint64_t count_per_workload = scenario == "help117" ? 660 * 117 : 76800;
        const uint64_t count = count_per_workload * workload_repeats;
        require(checksum == workload_repeats * count_per_workload * (count_per_workload + 1) / 2, "allocation workload checksum");
        require(resver::g_stats.generations - gens == count, "every dead handle swept once");
        std::cout << "{\"scenario\":\"" << scenario << "\",\"trial\":" << trial
            << ",\"warmup\":" << (trial == 0 ? "true" : "false") << ",\"allocations\":" << count
            << ",\"workload_repeats\":" << workload_repeats
            << ",\"draws\":" << (scenario == "help117" ? 660 * workload_repeats : 0)
            << ",\"elements\":" << (scenario == "help117" ? 152 : 9) << ",\"bytes_each\":" << (scenario == "help117" ? 608 : 36) << ",\"total_alloc_sweep_ms\":" << ms
            << ",\"host_new_calls\":" << host_alloc::calls << ",\"host_new_bytes\":" << host_alloc::bytes
            << ",\"host_new_36B_calls\":" << host_alloc::payload36_calls
            << ",\"host_new_608B_calls\":" << host_alloc::payload608_calls
            << ",\"host_new_64B_calls\":" << host_alloc::payload64_calls
            << ",\"host_new_1024B_calls\":" << host_alloc::payload1024_calls
            << ",\"host_new_48B_calls\":" << host_alloc::payload48_calls
            << ",\"gc_cycles\":" << VMS_HEAP(g_gc_cycles) - cycles
            << ",\"paint_gc_collections\":" << g_gc_sp.collections[1] - safepoints
            << ",\"swept_generations\":" << resver::g_stats.generations - gens
            << ",\"heap_slots\":" << VMS_HEAP(g_heap).size() << ",\"free_slots\":" << VMS_HEAP(g_free).size()
            << ",\"live_payload_bytes\":" << VMS_HEAP(g_array_payload_live)
            << ",\"checksum\":" << checksum << ",\"host_not_switch\":true,\"game_execution\":false}\n";
    }
}
