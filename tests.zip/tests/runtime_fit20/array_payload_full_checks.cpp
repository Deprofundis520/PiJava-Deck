#define J2ME_TEST_ARRAY_POOL_ENABLED 1
#include "array_payload_checks.cpp"
