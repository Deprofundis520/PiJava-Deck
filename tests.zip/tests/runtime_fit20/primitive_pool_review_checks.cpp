#include "../../src/optimization_config.h"
#include "../../src/runtime/value.h"
#include "../../src/array_storage.h"
#include <algorithm>
#include <cassert>
#include <cstdio>
#include <random>
#include <type_traits>

// Independent review checks: the GC/Java integration is covered by
// array_payload_checks.cpp; this exercises storage ownership and pool edges.
int main() {
    static_assert(!std::is_copy_constructible<PrimitiveBufferPool>::value, "pool ownership must not copy");
    PrimitiveBufferPool pool, other;
    for (size_t n=1;n<=4096;++n) {
        std::vector<uint8_t> donor(n,0xa5), out;
        pool.release(donor);
        assert(donor.empty() && donor.capacity()==0);
        pool.acquire(out,n);
        assert(out.empty() && out.capacity()>=n);
        out.resize(n,0);
        assert(std::all_of(out.begin(),out.end(),[](uint8_t v){return v==0;}));
        pool.release(out);
        assert(pool.retained_bytes()<=pool.byte_budget());
        pool.clear();
    }
    // Byte budget and fixed slot metadata independently bind retained storage.
    for (int i=0;i<100;++i) {std::vector<uint8_t> v(4096);pool.release(v);}
    assert(pool.retained_bytes()==pool.Budget && pool.returns==64 && pool.discarded==36);
    pool.clear();
    for (int i=0;i<600;++i) {std::vector<uint8_t> v(1);pool.release(v);}
    assert(pool.returns==pool.Slots && pool.discarded==600-pool.Slots);
    assert(pool.retained_bytes()==pool.Slots);
    assert(other.retained_bytes()==0 && other.hits==0);
    pool.clear();

    // Exhaust every bitmap bit, including 0/63 and summary words 0/63.
    // An exact-class request hits; one byte above that class cannot use it.
    for(size_t b=0;b<4096;++b) {
        const size_t capacity=b+1;
        std::vector<uint8_t> donor(capacity,0xa5),out;
        auto* owned=donor.data();pool.release(donor);
        pool.acquire(out,capacity);
        assert(pool.hits==1 && out.data()==owned && out.capacity()==capacity);
        pool.release(out);
        pool.acquire(out,capacity+1);
        assert(pool.hits==1 && pool.misses==1 && out.capacity()>=capacity+1);
        assert(pool.retained_bytes()==capacity);
        pool.clear();
    }
    // The request's first bitmap word contains only a masked-out low bit.
    // The summary must select the next word, at either bit 0 or bit 63.
    for(size_t word=0;word<63;++word) {
        for(size_t offset:{size_t(1),size_t(64)}) {
            const size_t low=word*64+1,high=(word+1)*64+offset;
            std::vector<uint8_t> lower(low),upper(high),out;
            auto* expected=upper.data();pool.release(lower);pool.release(upper);
            pool.acquire(out,low+1);
            assert(pool.hits==1 && pool.misses==0 && out.data()==expected);
            assert(pool.retained_bytes()==low);
            pool.clear();
        }
    }
    // Summary top bit 63 can be reached from word 0; removal must clear it.
    {std::vector<uint8_t> low(1),high(4096),out;auto* expected=high.data();
     pool.release(low);pool.release(high);pool.acquire(out,2);
     assert(pool.hits==1 && out.data()==expected && pool.retained_bytes()==1);
     std::vector<uint8_t> another;pool.acquire(another,2);assert(pool.misses==1);
     pool.clear();}
    // Word 63 with no adequate bit must miss without shifting by 64.
    {std::vector<uint8_t> low(4033),out;pool.release(low);pool.acquire(out,4096);
     assert(pool.hits==0 && pool.misses==1 && pool.retained_bytes()==4033);pool.clear();}
    // Lowest adequate bucket wins within a word and across summary words;
    // removing one bucket must retain its still-nonempty word's summary bit.
    for(size_t n:{size_t(1),size_t(63),size_t(64),size_t(65),size_t(127),size_t(128),size_t(129),size_t(4095),size_t(4096)}) {
        std::vector<uint8_t> donor(n);pool.release(donor);
    }
    const size_t requests[][2]={{2,63},{1,1},{64,64},{66,127},{65,65},{128,128},{129,129},{4096,4096},{130,4095}};
    for(const auto& request:requests) {
        std::vector<uint8_t> out;pool.acquire(out,request[0]);
        assert(out.capacity()==request[1]);
    }
    assert(pool.hits==9 && pool.misses==0 && pool.retained_bytes()==0);
    pool.clear();
    // Same-bin linked lists and the int16 slot/free-list indices stay valid
    // through all 512 slots, complete depletion and a second full refill.
    for(int cycle=0;cycle<2;++cycle) {
        std::vector<std::vector<uint8_t>> owned(pool.Slots);
        for(size_t i=0;i<pool.Slots;++i){std::vector<uint8_t> donor(36);pool.release(donor);}
        const auto before=pool.hits;
        for(auto& v:owned)pool.acquire(v,36);
        assert(pool.hits==before+pool.Slots && pool.retained_bytes()==0);
        for(size_t i=0;i<owned.size();++i)for(size_t j=0;j<i;++j)assert(owned[i].data()!=owned[j].data());
    }
    pool.clear();

    const char* kinds[]={"[B","[Z","[C","[S","[I","[F","[J","[D"};
    for(const char* kind:kinds) {
        ArrayStorage source;
        assert(source.reset(kind,17,&pool));
        auto dirty=Value::of_i(-1);dirty.l=-1;
        for(size_t i=0;i<source.size();++i)source.set(i,dirty);
        const auto before=source.layout_version();
        ArrayStorage snapshot=source;
        const auto snapshot_ptr=snapshot.raw_payload();
        source.recycle_dead_primitive(pool);
        // Recycling transfers ownership only; snapshots retain their own bytes.
        assert(snapshot.raw_payload()==snapshot_ptr && snapshot.payload_bytes()>0);
        ArrayStorage fresh;
        assert(fresh.reset(kind,17,&pool));
        assert(fresh.layout_version()>before && fresh.content_version()==fresh.layout_version());
        assert(fresh.raw_payload()!=snapshot_ptr);
        assert(std::all_of(fresh.raw_payload(),fresh.raw_payload()+fresh.payload_bytes(),[](uint8_t v){return v==0;}));
        fresh.set(0,Value::of_l(123));
        assert(fresh.content_version()>fresh.layout_version());
        ArrayStorage moved=std::move(fresh);
        assert(moved.payload_bytes()==snapshot.payload_bytes());
        auto stamp=moved.content_version();
        assert(!moved.reset("[V",4,&pool) && moved.content_version()==stamp);
        moved.recycle_dead_primitive(pool);
    }
    pool.clear();
    for(const char* kind:{"[Ljava/lang/Object;","[[I","[[[B"}) {
        ArrayStorage refs;assert(refs.reset(kind,20,&pool));
        refs.set(0,Value::of_ref(19));refs.recycle_dead_primitive(pool);
        assert(refs.get(0).ref==19 && pool.returns==0 && pool.misses==0);
    }
    ArrayStorage large;assert(large.reset("[B",4097,&pool));large.recycle_dead_primitive(pool);
    assert(pool.retained_bytes()==0 && pool.discarded==1);

    // Mixed bins, non-powers of two, exhausted budgets and repeated clear.
    std::mt19937 rng(0x20dead);
    std::vector<std::vector<uint8_t>> live(80);
    for(int step=0;step<100000;++step) {
        auto& v=live[rng()%live.size()];
        if(v.capacity()) {pool.release(v);std::vector<uint8_t>().swap(v);}
        else {
            size_t n=rng()%5000;
            pool.acquire(v,n);
            assert(v.empty() && v.capacity()>=n);
            v.resize(n,0);
            for(const auto& peer:live)if(&peer!=&v && peer.capacity())assert(peer.data()!=v.data());
            std::fill(v.begin(),v.end(),0xa5);
        }
        assert(pool.retained_bytes()<=pool.Budget);
        if(step%997==0)pool.clear();
    }
    pool.clear();
    assert(pool.retained_bytes()==0 && pool.hits==0 && pool.returns==0 && pool.peak_bytes==0);
    std::printf("PASS independent primitive pool review: sizes=1..4096 randomized_ops=100000 fixed_slots=%zu byte_budget=%zu metadata_object_bytes=%zu\n",pool.Slots,pool.Budget,sizeof(pool));
}
