// Real VM admission, emitter, executable pages and interpreter differential.
#ifndef J2ME_TEST_VM
#define J2ME_TEST_VM "../../src/j2mevm.cpp"
#endif
#define main emulator_main
#include J2ME_TEST_VM
#undef main
static void check(bool ok,const char* why){if(!ok){std::cerr<<"FAIL jit-overlap "<<why<<'\n';std::exit(1);}}
static Method fixture(std::vector<uint8_t> code,unsigned locals=1,unsigned stack=4){Method m;m.class_id=0;m.name="overlap";m.desc="()V";m.flags=8;m.max_locals=locals;m.max_stack=stack;m.code=std::move(code);m.quick.resize(m.code.size());return m;}
static Method linear(unsigned count=24){std::vector<uint8_t> code;for(unsigned k=0;k<count;++k)code.insert(code.end(),{132,0,1});code.push_back(177);return fixture(std::move(code));}
static Frame frame(Method& m,int pc=0,std::vector<Value> stack={}){Frame f;f.method=&m;f.pc=pc;f.op_pc=-1;f.locals.assign(m.max_locals,Value::of_i(0));f.stack=std::move(stack);return f;}
static int warm(Method& m,int pc=0,std::vector<Value> stack={}){int done=0;for(unsigned k=0;k<JitRegionHot+16;++k){auto f=frame(m,pc,stack);done=jit_region_try(f,256);}return done;}
static void reset(){jit_region_reset();VMS_NATIVE(g_native_jit).clear();}
static void setup(){VMS_DIAG(g_log_draw)=false;Class c;c.name="OverlapFixture";c.init_state=2;c.statics={Value::of_i(7)};VMS_CL(g_classes).clear();VMS_CL(g_classes).push_back(std::move(c));VMS_NATIVE(g_native_jit).configure(true);check(VMS_NATIVE(g_native_jit).available,"native host available");}

static std::vector<jit236::Executable> pressure_fillers;
static void release_pressure(){pressure_fillers.clear();while(!jit236::code_quarantine().empty())jit236::release_oldest_quarantine();}
static void add_pressure(){
 check(pressure_fillers.empty(),"pressure fillers have one owner");
 const uint8_t code[]={26,4,96,172};const std::string desc="(I)I";jit236::Spec spec{code,sizeof code,&desc,8,1,2,false,false,nullptr};jit236::Program program;check(jit236::verify(spec,program),"pressure filler really verifies");
 pressure_fillers.resize(4);for(auto& e:pressure_fillers){auto id=jit236::next_install_id();auto bytes=jit236::emit_host(program,id);check(!bytes.empty(),"pressure filler emits valid native body");bytes.resize(262144,0);check(e.install(bytes,id,jit236::InstallMode::Normal),"ordinary 256KiB pressure filler installs");}
 check(jit236::code_pool_stats().used_bytes>=1024*1024,"four real ordinary arenas provide live pressure");
}
static void low_pressure(){
 release_pressure();check(jit236::code_pool_stats().used_bytes<1024*1024,"low pressure fixture has less than one MiB live code");auto m=linear();warm(m);check(warm(m,12)==20&&g_jit_regions[&m].at[12].state==1,"low live-code pressure keeps ordinary suffix admission");
 const auto owner=g_jit_regions[&m].at[0].exe.id,suffix=g_jit_regions[&m].at[12].exe.id;add_pressure();auto f=frame(m);check(jit_region_try(f,256)==24&&g_jit_regions[&m].at[0].exe.id==owner,"pressure increase leaves installed owner unchanged");f=frame(m,12);check(jit_region_try(f,256)==20&&g_jit_regions[&m].at[12].exe.id==suffix,"pressure increase leaves already-installed suffix unchanged");reset();
 std::cout<<"PASS low pressure admits suffix and pressure increase preserves installed code\n";
}
static void pressure_drop(){
 auto m=linear();warm(m);warm(m,12);check(g_jit_regions[&m].at[12].state==0,"real one-MiB pressure initially defers suffix");const auto owner=g_jit_regions[&m].at[0].exe.id;release_pressure();check(jit236::code_pool_stats().used_bytes<1024*1024,"released ordinary fillers and quarantine leave low live pressure");auto f=frame(m,12);check(jit_region_try(f,256)==20&&g_jit_regions[&m].at[12].state==1,"cached deferral reopens immediately when pressure falls");check(g_jit_regions[&m].at[0].exe.id==owner,"pressure drop never replaces existing owner");
#ifndef J2ME_OVERLAP_BASELINE
 check(g_jit_region_stats.overlap_reopened==1,"pressure drop is one cache reopening");
#endif
 reset();add_pressure();std::cout<<"PASS cached deferral reopens below one-MiB live-code threshold\n";
}
static void redundant(bool baseline){auto m=linear();check(warm(m)==24,"owner executes arithmetic");auto& rm=g_jit_regions[&m];const auto bytes=g_jit_region_stats.bytes;const auto id=rm.at[0].exe.id;warm(m,12);std::cout<<"ADMISSION baseline="<<baseline<<" owner_id="<<id<<" before_bytes="<<bytes<<" after_bytes="<<g_jit_region_stats.bytes<<" installed="<<g_jit_region_stats.compiled<<'\n';if(baseline)check(rm.at[12].state==1&&g_jit_region_stats.bytes>bytes,"baseline really installs duplicate suffix page");else check(rm.at[12].state==0&&!rm.at[12].exe.fn&&g_jit_region_stats.bytes==bytes,"covered suffix must remain soft deferred without another page");check(rm.at[0].exe.id==id&&rm.at[0].state==1,"owner executable unchanged");
#ifndef J2ME_OVERLAP_BASELINE
 check(g_jit_region_stats.overlap_deferred==1&&g_jit_region_stats.overlap_hits==16&&g_jit_region_stats.overlap_reopened==0,"initial deferral and cached-hit diagnostics count actual paths");
#endif
 reset();}

static void compare(const Frame& a,const Frame& b){
 check(a.pc==b.pc&&a.op_pc==b.op_pc&&a.locals.size()==b.locals.size()&&a.stack.size()==b.stack.size(),"exact interpreter PC/op-PC and stack depth");
 for(unsigned k=0;k<a.locals.size();++k)check(a.locals[k].i==b.locals[k].i&&a.locals[k].ref==b.locals[k].ref&&a.locals[k].l==b.locals[k].l,"exact interpreter locals");
 for(unsigned k=0;k<a.stack.size();++k)check(a.stack[k].i==b.stack[k].i&&a.stack[k].ref==b.stack[k].ref,"exact interpreter stack operands");
}
static void rotation(){
 auto m=linear();warm(m);const auto id=g_jit_regions[&m].at[0].exe.id;const auto bytes=g_jit_region_stats.bytes;
 const unsigned budgets[]={0,1,2,3,8,32,256};
 for(unsigned n=0;n<10000;++n){auto owner=frame(m);check(jit_region_try(owner,256)==24,"owner continues real progress");int pc=3*int(1+n%23);auto f=frame(m,pc),ref=f;int expected=execute_fast_batch(ref,budgets[n%7]);int actual=jit_region_try(f,budgets[n%7]);check(actual==0,"all covered rotation entries stay deferred");compare(f,frame(m,pc));actual=execute_fast_batch(f,budgets[n%7]);check(actual==expected,"deferred fallback uses exact bytecode budget");compare(f,ref);check(!jitr_skipped(f)||f.pc==72,"soft deferral never installs method skip bits");}
 check(g_jit_region_stats.bytes==bytes&&g_jit_region_stats.compiled==1&&g_jit_regions[&m].at[0].exe.id==id,"10000 rotating nonheaders do not grow executable pages");
 for(int pc=3;pc<72;pc+=3){auto& rm=g_jit_regions[&m];check(!rm.dead[pc]&&rm.at[pc].state==0&&!rm.at[pc].exe.fn,"no covered PC becomes permanent dead or owns code");auto f=frame(m,pc);check(!jitr_skipped(f),"no covered entry skip bit");}
 std::cout<<"PASS rotation rounds=10000 nonheaders=23 before_bytes="<<bytes<<" after_bytes="<<g_jit_region_stats.bytes<<" compiled="<<g_jit_region_stats.compiled<<'\n';reset();
}
static void owner_changes(){
 // Let the existing real 256-run low-throughput policy retire the owner.
 {auto m=linear();warm(m);warm(m,12);auto& rm=g_jit_regions[&m];check(rm.at[12].state==0,"suffix starts deferred");while(rm.at[0].state==1){auto f=frame(m);jit_region_try(f,1);}check(rm.dead[0]&&!rm.at[0].exe.fn,"real owner retirement closes executable");auto f=frame(m,12);check(jit_region_try(f,256)==20&&rm.at[12].state==1,"owner retirement immediately reopens suffix");
#ifndef J2ME_OVERLAP_BASELINE
 check(g_jit_region_stats.overlap_reopened==1,"owner retirement reports exactly one reopened candidate");
#endif
 reset();}
 // Progress belongs to one install ID, never merely an executable address.
 {auto m=linear();warm(m);warm(m,12);auto& rm=g_jit_regions[&m];++rm.at[0].exe.id;auto f=frame(m,12);check(jit_region_try(f,256)==20&&rm.at[12].state==1,"changed owner ID cannot inherit old healthy evidence");reset();}
 {auto m=linear();warm(m);warm(m,12);auto& rm=g_jit_regions[&m];++rm.at[0].exe.id;auto f=frame(m);check(!jit_region_try(f,256)&&rm.at[0].fresh_page,"real stale ID releases owner and requests Fresh page");f=frame(m,12);check(jit_region_try(f,256)==20&&rm.at[12].state==1,"stale owner invalidates deferral immediately");reset();}
 {auto m=linear();warm(m);warm(m,12);VMS_NATIVE(g_native_jit).clear();check(warm(m,12)==20&&g_jit_region_stats.compiled==1&&g_jit_regions[&m].at[12].state==1,"epoch reset forgets old owner and admission cache");reset();}
 // Install suffix first, then covering owner: installed entries and both recovery paths remain untouched.
 {auto m=linear();warm(m,12);warm(m);auto& rm=g_jit_regions[&m];auto id=rm.at[12].exe.id;auto f=frame(m,12);check(jit_region_try(f,256)==20&&rm.at[12].exe.id==id,"existing suffix still executes own unchanged code");rm.at[12].stale=true;f=frame(m,12);check(jit_region_try(f,256)==20&&rm.at[12].exe.id!=id,"stale QuickSite recovery cannot be overlap deferred");id=rm.at[12].exe.id;++rm.at[12].exe.id;f=frame(m,12);check(!jit_region_try(f,256)&&rm.at[12].fresh_page,"suffix stale fault enters Fresh recovery");f=frame(m,12);check(jit_region_try(f,256)==20&&rm.at[12].state==1&&!rm.at[12].fresh_page&&rm.at[12].exe.id!=id,"Fresh suffix reinstalls despite healthy covering owner");reset();}
 std::cout<<"PASS owner retirement, install ID, stale/Fresh and epoch invalidation\n";
}
static void noncoverage(){
 // The owner stops at an unresolved getstatic. Its depth there is valid, but that is a K_EXIT.
 {auto m=linear(12);m.code.pop_back();int pc=m.code.size();m.code.insert(m.code.end(),{178,0,1,87,132,0,1,177});m.quick.resize(m.code.size());check(warm(m)==12,"owner exits before unresolved static");check(g_jit_regions[&m].at[0].depth[pc]==0,"K_EXIT really has nonnegative depth");m.quick[pc].kind=1;m.quick[pc].a=0;m.quick[pc].b=0;check(warm(m,pc)==3&&g_jit_regions[&m].at[pc].state==1,"K_EXIT is never actual compiled coverage");reset();}
 {auto m=linear();warm(m);check(warm(m,12,{Value::of_i(91)})==20&&g_jit_regions[&m].at[12].state==1,"different stack depth remains eligible");auto f=frame(m,12,{Value::of_i(91)});check(jit_region_try(f,256)==20&&f.stack.size()==1&&f.stack[0].i==91,"depth-mismatched installed candidate keeps operands");reset();}
 // No owner may assemble its coverage from separate regions.
 {auto m=linear();warm(m,36);warm(m,12);check(g_jit_regions[&m].at[36].state==1&&g_jit_regions[&m].at[12].state==1,"owner covering only suffix subset cannot defer larger candidate");reset();}
 // Both healthy owners together cover the diamond; no one install covers it all.
 {auto m=linear(12);m.max_locals=2;m.code.pop_back();m.code.insert(m.code.end(),{27,153,0,10,178,0,1,87,167,0,43,178,0,1,87});for(unsigned n=0;n<12;++n)m.code.insert(m.code.end(),{132,0,1});m.code.insert(m.code.end(),{132,0,1,177});m.quick.resize(m.code.size());m.quick[40].kind=1;m.quick[40].a=0;m.quick[40].b=0;check(warm(m)==14,"diamond owner stops at unresolved left arm");m.quick[47].kind=1;m.quick[47].a=0;m.quick[47].b=0;check(warm(m,47)==15,"second healthy owner covers left arm");check(warm(m,36)>0&&g_jit_regions[&m].at[36].state==1,"candidate cannot union coverage from two healthy owners");reset();}
 // New owner must establish actual multi-op progress first.
 {auto m=linear();for(unsigned k=0;k<JitRegionHot;++k){auto f=frame(m);jit_region_try(f,256);}check(g_jit_regions[&m].at[0].runs==1,"new owner only ran once");check(warm(m,12)==20&&g_jit_regions[&m].at[12].state==1,"unproven new install cannot defer another candidate");reset();}
 std::cout<<"PASS K_EXIT, same-depth, whole-owner and proven-progress admission checks\n";
}
static void guard_exit(){
 for(bool at_entry:{false,true}){
 auto m=linear(at_entry?0:12);m.code.pop_back();const int guard=m.code.size();m.code.insert(m.code.end(),{178,0,1,87});const int suffix=m.code.size();for(unsigned n=0;n<12;++n)m.code.insert(m.code.end(),{132,0,1});m.code.push_back(177);m.quick.resize(m.code.size());m.quick[guard].kind=1;m.quick[guard].a=0;m.quick[guard].b=0;
 VMS_CL(g_classes)[0].init_state=2;warm(m);warm(m,suffix);auto& rm=g_jit_regions[&m];check(rm.at[suffix].state==0,"healthy helper owner initially covers suffix");VMS_CL(g_classes)[0].init_state=0;auto f=frame(m);check(jit_region_try(f,256)==(at_entry?0:12)&&f.pc==guard,"real static helper bails at compiled op");VMS_CL(g_classes)[0].init_state=2;f=frame(m,suffix);check(jit_region_try(f,256)==12&&rm.at[suffix].state==1,"guard/zero bailout cancels owner's structural coverage");reset();}
 // A local representation guard is also a failed attempt to enter the owner.
 {auto m=linear(24);m.max_locals=2;for(unsigned n=0;n<12;++n)m.code[3*n+1]=1;warm(m);warm(m,36);auto& rm=g_jit_regions[&m];check(rm.at[36].state==0,"local-guard suffix initially deferred");auto f=frame(m);f.locals[1]=Value::of_l(5);check(!jit_region_try(f,256),"owner really rejects nonplain stored local");f=frame(m,36);check(jit_region_try(f,256)==12&&rm.at[36].state==1,"owner pre-entry local guard reopens unaffected suffix");reset();}
 std::cout<<"PASS actual helper, local and zero bailout reopen deferred entries\n";
}

static int warm_frame(const Frame& seed);
static void ic_budget(){
 auto& cp=VMS_CL(g_classes)[0].cp;cp.resize(7);cp[1].tag=10;cp[1].a=2;cp[1].b=3;cp[2].tag=7;cp[2].a=4;cp[3].tag=12;cp[3].a=5;cp[3].b=6;cp[4].tag=cp[5].tag=cp[6].tag=1;cp[4].utf="OverlapFixture";cp[5].utf="constant";cp[6].utf="()I";
 auto callee=fixture({4,172},1,1);callee.flags=0;callee.name="constant";callee.desc="()I";VMS_CL(g_classes)[0].methods.push_back(std::move(callee));
 if(VMS_HEAP(g_heap).empty())VMS_HEAP(g_heap).push_back(Obj{});Obj obj;obj.cls=0;VMS_HEAP(g_heap).push_back(std::move(obj));const int receiver=VMS_HEAP(g_heap).size()-1;
 for(bool at_entry:{true,false}){
 auto m=linear(at_entry?0:12);m.max_locals=2;m.code.pop_back();if(!at_entry)m.code.push_back(43);int ic=m.code.size();m.code.insert(m.code.end(),{182,0,1,87});int suffix=m.code.size();for(unsigned n=0;n<24;++n)m.code.insert(m.code.end(),{132,0,1});m.code.push_back(177);m.quick.resize(m.code.size());auto& q=m.quick[ic];q.kind=4;q.vclass=0;q.va=0;q.vb=0;q.argc=0;
 auto seed=frame(m);seed.locals[1]=Value::of_ref(receiver);if(at_entry)seed.stack={Value::of_ref(receiver)};check(warm_frame(seed)>0,"actual monomorphic constant IC owner executes");auto tail=seed;tail.pc=suffix;tail.stack.clear();check(warm_frame(tail)==0,"IC owner initially defers covered suffix");
 for(unsigned remaining:{1u,2u}){auto f=seed;const int prefix=at_entry?0:13;check(jit_region_try(f,prefix+remaining)==prefix&&f.pc==ic&&f.stack.size()==1&&f.stack[0].ref==receiver,"IC insufficient budget exits before atomic callee with exact stack");f=tail;check(!jit_region_try(f,256)&&g_jit_regions[&m].at[suffix].state==0,"ordinary IC budget exit preserves healthy overlap owner");}
 const auto sites=g_jit_region_t3.ic_sites;for(unsigned n=0;n<10000;++n){auto f=tail;check(!jit_region_try(f,256),"cached IC owner still defers suffix");}check(g_jit_region_t3.ic_sites==sites,"10000 cached deferrals do not repeat region/IC builds");
 auto bad=seed;if(at_entry)bad.stack[0]=Value::of_ref(0);else bad.locals[1]=Value::of_ref(0);check(jit_region_try(bad,256)==(at_entry?0:13),"actual IC receiver guard bails");auto f=tail;check(jit_region_try(f,256)==24&&g_jit_regions[&m].at[suffix].state==1,"IC guard failure still reopens suffix immediately");reset();
 }
 VMS_CL(g_classes)[0].methods.clear();std::cout<<"PASS IC cost budgets at entry/middle preserve owner; actual IC guard releases it\n";
}
static void loop_headers(){
 {auto m=fixture({132,0,1,132,0,1,132,0,1,26,16,30,161,255,250,177});warm(m);warm(m,6);check(g_jit_regions[&m].at[6].state==1,"backward conditional header inside outer region stays eligible");reset();}
 for(unsigned op:{170u,171u}){
 std::vector<uint8_t> code={132,0,1,132,0,1,3,uint8_t(op)};
 auto put=[&](int32_t v){for(int n=3;n>=0;--n)code.push_back(uint8_t(uint32_t(v)>>(n*8)));};
 put(-4);if(op==170){put(0);put(0);put(-1);}else{put(1);put(0);put(-1);}auto m=fixture(std::move(code));warm(m);warm(m,3);warm(m,6);check(g_jit_regions[&m].at[3].state==1&&g_jit_regions[&m].at[6].state==1,"backward switch default and case destinations stay eligible");reset();}
 for(unsigned op:{168u,200u,201u}){auto m=linear(12);m.code.pop_back();int pc=m.code.size();int offset=6-pc;if(op==168)m.code.insert(m.code.end(),{uint8_t(op),uint8_t(uint16_t(offset)>>8),uint8_t(offset)});else m.code.insert(m.code.end(),{uint8_t(op),uint8_t(uint32_t(offset)>>24),uint8_t(uint32_t(offset)>>16),uint8_t(uint32_t(offset)>>8),uint8_t(offset)});m.quick.resize(m.code.size());warm(m);warm(m,6);check(g_jit_regions[&m].at[6].state==1,"backward jsr/goto_w/jsr_w destination stays eligible");reset();}
 std::cout<<"PASS conditional, tableswitch, lookupswitch and wide backward headers\n";
}
static int warm_frame(const Frame& seed){int done=0;for(unsigned n=0;n<JitRegionHot+16;++n){auto f=seed;done=jit_region_try(f,256);}return done;}
static void effects(){
 if(VMS_HEAP(g_heap).empty())VMS_HEAP(g_heap).push_back(Obj{});const int array=alloc_array("[I",8);
 std::vector<uint8_t> code;for(unsigned k=0;k<8;++k)code.insert(code.end(),{42,16,uint8_t(k),27,4,96,79});code.push_back(177);auto m=fixture(std::move(code),2,4);
 auto seed=frame(m);seed.locals={Value::of_ref(array),Value::of_i(0x123456)};check(warm_frame(seed)==48,"side-effect owner stores all eight pixels");auto suffix=seed;suffix.pc=24;suffix.stack={Value::of_ref(array),Value::of_i(3)};check(warm_frame(suffix)==0&&g_jit_regions[&m].at[24].state==0,"stackful side-effect suffix is soft deferred");
 auto clear=[&](){for(unsigned k=0;k<8;++k)VMS_HEAP(g_heap)[array].elems.set(k,Value::of_i(0));};
 for(unsigned budget:{0u,1u,2u,3u,4u,8u,31u,128u})for(auto initial:{seed,suffix}){
 clear();auto reference=initial;auto before=resver::g_stats.array_content;int expected=execute_fast_batch(reference,budget);auto writes=resver::g_stats.array_content-before;std::vector<int> pixels;for(unsigned k=0;k<8;++k)pixels.push_back(VMS_HEAP(g_heap)[array].elems.get(k).i);
 clear();auto actual=initial;before=resver::g_stats.array_content;int done=jit_region_try(actual,budget);if(!done)done=execute_fast_batch(actual,budget);check(done==expected,"exact operation budget with stores and live stack");compare(actual,reference);check(resver::g_stats.array_content-before==writes,"same write barrier count");for(unsigned k=0;k<8;++k)check(VMS_HEAP(g_heap)[array].elems.get(k).i==pixels[k],"identical side effects once");}
 std::cout<<"PASS exact interpreter budgets/PC/locals/stack and primitive side effects\n";reset();
}

static void resource_bench(bool baseline){
 auto m=linear();warm(m);auto start=std::chrono::steady_clock::now();uint64_t ops=0,checksum=0;
 for(unsigned n=0;n<10000;++n){auto owner=frame(m);ops+=jit_region_try(owner,256);int pc=3*int(1+n%23);auto f=frame(m,pc);int done=jit_region_try(f,256);if(!done)done=execute_fast_batch(f,256);check(done==24-pc/3&&f.pc==72,"resource comparison preserves exact suffix ops and PC");ops+=done;checksum+=f.locals[0].i;}
 double ms=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();
 if(baseline)check(g_jit_region_stats.bytes>4096&&g_jit_region_stats.compiled==24,"baseline rotation installs redundant pages");else check(g_jit_region_stats.bytes==4096&&g_jit_region_stats.compiled==1,"covered rotation remains one installed page");
 std::cout<<"BENCH synthetic_overlap baseline="<<baseline<<" rounds=10000 compiled="<<g_jit_region_stats.compiled<<" resident="<<g_jit_region_stats.resident<<" executable_bytes="<<g_jit_region_stats.bytes<<" ops="<<ops<<" checksum="<<checksum<<" elapsed_ms="<<ms<<" game_fps_claim=0\n";reset();
}
int main(int argc,char** argv){setup();bool baseline=argc>1&&std::string(argv[1])=="baseline";if(!baseline)low_pressure();else add_pressure();redundant(baseline);resource_bench(baseline);if(!baseline){pressure_drop();rotation();owner_changes();noncoverage();guard_exit();ic_budget();loop_headers();effects();}std::cout<<"PASS jit_overlap host="<<jit236::architecture()<<" baseline="<<baseline<<'\n';release_pressure();}
