#!/usr/bin/env python3
"""Compare already built identical-harness binaries; never compiles while timing.

Alternate baseline/candidate process order per scenario, with one warm-up and
seven measured trials per process. A single pass is retained in full.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import statistics
import subprocess


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline', type=Path, required=True)
    parser.add_argument('--candidate', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--workload-repeats', type=int, default=1)
    args = parser.parse_args()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    binaries = {'baseline': args.baseline.resolve(), 'candidate': args.candidate.resolve()}
    env = os.environ.copy()
    env.pop('J2ME_GC_STRESS', None)
    provenance = {'scope': 'real VM native host timing; not Switch timing/game FPS',
                  'ordering': 'alternate baseline/candidate order per scenario, seven trials after one warm-up in each process, one pass',
                  'workload_repeats': args.workload_repeats,
                  'commands': [], 'binaries': {name: {'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()} for name, path in binaries.items()}}
    summary = []
    for case, scenario in enumerate(['normal256', 'batch256', 'batch512', 'help117', 'burst76800']):
        results = {}
        order = ['baseline', 'candidate'] if case % 2 == 0 else ['candidate', 'baseline']
        for name in order:
            command = [str(binaries[name]), scenario, '7', str(args.workload_repeats)]
            proc = subprocess.run(command, capture_output=True, env=env, timeout=60)
            (output / f'{scenario}-{name}.stdout').write_bytes(proc.stdout)
            (output / f'{scenario}-{name}.stderr').write_bytes(proc.stderr)
            provenance['commands'].append({'argv': command, 'returncode': proc.returncode})
            if proc.returncode:
                raise SystemExit(f'{name} {scenario}: {proc.stderr.decode(errors="replace")}')
            samples = [json.loads(line) for line in proc.stdout.splitlines()]
            samples = [row for row in samples if not row['warmup']]
            assert len(samples) == 7
            results[name] = {'median_ms': statistics.median(row['total_alloc_sweep_ms'] for row in samples),
                             'min_ms': min(row['total_alloc_sweep_ms'] for row in samples),
                             'max_ms': max(row['total_alloc_sweep_ms'] for row in samples),
                             'samples': samples}
        a, b = results['baseline'], results['candidate']
        # Allocation semantics/GC schedules must be identical despite host reuse.
        for key in ['workload_repeats', 'allocations', 'draws', 'elements', 'bytes_each', 'gc_cycles', 'paint_gc_collections',
                    'swept_generations', 'heap_slots', 'free_slots', 'live_payload_bytes', 'checksum']:
            assert len({row[key] for result in results.values() for row in result['samples']}) == 1, (scenario, key)
        summary.append({'scenario': scenario, 'baseline': a, 'candidate': b,
                        'candidate_time_change_percent': (b['median_ms'] / a['median_ms'] - 1) * 100,
                        'candidate_new_call_change_percent': (b['samples'][0]['host_new_calls'] / a['samples'][0]['host_new_calls'] - 1) * 100,
                        'candidate_new_bytes_change_percent': (b['samples'][0]['host_new_bytes'] / a['samples'][0]['host_new_bytes'] - 1) * 100})
    (output / 'comparison.json').write_text(json.dumps(summary, indent=2) + '\n')
    (output / 'provenance.json').write_text(json.dumps(provenance, indent=2) + '\n')
    print(json.dumps([{k: v for k, v in row.items() if k not in ['baseline', 'candidate']} |
                      {name + '_median_ms': row[name]['median_ms'] for name in ['baseline', 'candidate']} for row in summary], indent=2))


if __name__ == '__main__':
    main()
