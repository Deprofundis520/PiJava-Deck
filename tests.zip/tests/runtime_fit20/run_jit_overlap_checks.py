#!/usr/bin/env python3
"""Run real VM overlap admission on host and optionally qemu A64; preserve signed status."""
import argparse
import hashlib
import os
import re
from pathlib import Path
import shlex
import subprocess
import zipfile

def read_baseline_runtime(path):
    data=path.read_bytes()
    if hashlib.sha256(data).hexdigest()!='1219b6ce06c1f6b52f3625480a50260ea48e119e4caabca25f864b0ceac895f0':
        raise SystemExit('Wrong original Fit19 source ZIP SHA-256')
    with zipfile.ZipFile(path) as archive:
        names=[name for name in archive.namelist() if name=='src/runtime/native_jit.inc' or name.endswith('/src/runtime/native_jit.inc')]
        if len(names)!=1: raise SystemExit('Expected exactly one src/runtime/native_jit.inc in original Fit19 ZIP')
        return archive.read(names[0])

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--output',type=Path,required=True)
p.add_argument('--cross-root',type=Path)
p.add_argument('--baseline',action='store_true')
p.add_argument('--baseline-source-zip',type=Path,help='Original Fit19 source ZIP with pinned SHA-256; required with --baseline')
p.add_argument('--opt',choices=['O0','O2'],default='O0')
a=p.parse_args()
if a.baseline and a.baseline_source_zip is None: p.error('--baseline requires --baseline-source-zip')
source=Path(__file__).resolve().parents[2];out=a.output.resolve();out.mkdir(parents=True,exist_ok=True)
def run(label,argv,env=None):
    argv=list(map(str,argv));print(label+': '+shlex.join(argv),flush=True)
    r=subprocess.run(argv,cwd=source,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=300)
    (out/(label+'.log')).write_bytes(r.stdout);print(r.stdout.decode(errors='replace'),end='',flush=True);print(label+'_signedrc='+str(r.returncode),flush=True)
    if r.returncode: raise SystemExit(r.returncode)
vm=source/'src/j2mevm.cpp'
if a.baseline:
    original=read_baseline_runtime(a.baseline_source_zip.resolve())
    inc=out/'baseline-native-jit.inc';inc.write_text(original.decode().replace('#include "../jit_region.h"','#include "'+str(source/'src/jit_region.h')+'"'))
    # Current diagnostic fields are absent in the historical runtime include.
    # Keep baseline VM behavior identical; omit only its unused window log line.
    baseline_vm=(source/'src/j2mevm.cpp').read_text().replace('#include "runtime/native_jit.inc"','#include "'+str(inc)+'"')
    baseline_vm,count=re.subn(r'    log_line\("JITREGION schema=1 .*?g_jit_region_stats\.stale_fatal\)\);',
                             '    log_line("JITREGION baseline_overlap=1");',baseline_vm,count=1,flags=re.S)
    if count!=1: raise SystemExit('Expected exactly one region window diagnostic')
    vm=out/'baseline-vm.cpp';vm.write_text(baseline_vm)
arches=[('x64',['gcc'],['g++'],[],None)]
if a.cross_root:
    cross=a.cross_root.resolve();env=os.environ.copy();env['LD_LIBRARY_PATH']=str(cross/'usr/lib/x86_64-linux-gnu');sysroot='--sysroot='+str(cross)
    arches.append(('a64',[cross/'usr/bin/aarch64-linux-gnu-gcc',sysroot],[cross/'usr/bin/aarch64-linux-gnu-g++',sysroot],[cross/'usr/bin/qemu-aarch64','-L',cross/'usr/aarch64-linux-gnu'],env))
for arch,cc,cxx,qemu,env in arches:
    puff=out/('puff-'+arch+'.o');exe=out/('jit-overlap-'+arch)
    run('build-puff-'+arch,cc+['-O1','-c',source/'src/puff.c','-o',puff],env)
    run('build-overlap-'+arch,cxx+(['-DJ2ME_OVERLAP_BASELINE=1'] if a.baseline else [])+['-'+a.opt,'-g0','-std=c++17','-fno-exceptions','-ffunction-sections','-fdata-sections','-I'+str(source/'src'),'-DJ2ME_TEST_VM="'+str(vm)+'"',source/'tests/runtime_fit20/jit_overlap_checks.cpp',puff,'-Wl,--gc-sections','-pthread','-ldl','-o',exe],env)
    run('overlap-'+arch,qemu+[exe]+(['baseline'] if a.baseline else []),env)
