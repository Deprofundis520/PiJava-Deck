#!/usr/bin/env python3
"""Build a real VM allocation/GC short benchmark from an explicit source tree.

No source changes, mock allocation counters, QEMU timing or game FPS claims.
The test's global operator new measures actual C++ new requests (not malloc).
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import statistics
import subprocess
import time


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--label', default='baseline-fit19')
    parser.add_argument('--opts', nargs='+', choices=['O1', 'O2'], default=['O1', 'O2'])
    parser.add_argument('--repeats', type=int, default=7)
    parser.add_argument('--jar', type=Path)
    parser.add_argument('--build-only', action='store_true')
    args = parser.parse_args()
    source, output = args.source.resolve(), args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    harness = Path(__file__).resolve().with_name('array_allocation_bench.cpp')
    env = os.environ.copy()
    env.pop('J2ME_GC_STRESS', None)
    provenance = {'source': str(source), 'label': args.label, 'harness': str(harness),
                  'host': platform.uname()._asdict(), 'scope': 'native desktop real VM alloc_array+gc_collect; not Switch timing or game FPS',
                  'help_proxy': '660 draws x 117 int[152]; 71136 payload bytes/draw; homogeneous proxy, not real glyph lengths',
                  'new_counter': 'Global operator new/new[] real requests, including GC and logging; 36B/608B size buckets (also 64B/1024B in trial rows) are observational, not a mocked savings estimate',
                  'timing': 'One warm-up + repeated trials in each scenario process. Complete allocation/check/two boundary writes and final GC included; startup/build/output excluded',
                  'commands': [], 'sha256': {str(harness): digest(harness), str(Path(__file__).resolve()): digest(Path(__file__).resolve())}}
    for path in sorted((source / 'src').rglob('*')):
        if path.is_file(): provenance['sha256'][str(path)] = digest(path)
    if args.jar:
        provenance['jar'] = str(args.jar.resolve())
        provenance['sha256'][str(args.jar.resolve())] = digest(args.jar)
    def run(label, command, timeout=240):
        command = list(map(str, command))
        started = time.time()
        proc = subprocess.run(command, cwd=source, env=env, capture_output=True, timeout=timeout)
        (output / (label + '.stdout')).write_bytes(proc.stdout)
        (output / (label + '.stderr')).write_bytes(proc.stderr)
        provenance['commands'].append({'label': label, 'argv': command, 'returncode': proc.returncode, 'wall_seconds': time.time() - started})
        (output / 'provenance.json').write_text(json.dumps(provenance, indent=2) + '\n')
        if proc.returncode: raise SystemExit(f'{label} failed: {proc.stderr.decode(errors="replace")}')
        return proc.stdout.decode()
    summary = []
    for opt in args.opts:
        puff = output / ('puff-' + opt + '.o')
        run('build-puff-' + opt, ['gcc', '-' + opt, '-c', source / 'src/puff.c', '-o', puff])
        exe = output / ('array-allocation-' + opt)
        run('build-vm-' + opt, ['g++', '-' + opt, '-g0', '-std=c++17', '-fno-exceptions',
            '-ffunction-sections', '-fdata-sections', '-DJ2ME_TEST_VM="' + str(source / 'src/j2mevm.cpp') + '"',
            harness, puff, '-Wl,--gc-sections', '-pthread', '-ldl', '-o', exe])
        provenance['sha256'][str(exe)] = digest(exe)
        (output / 'provenance.json').write_text(json.dumps(provenance, indent=2) + '\n')
        if args.build_only:
            continue
        for scenario in ['normal256', 'batch256', 'batch512', 'help117', 'burst76800']:
            stdout = run(scenario + '-' + opt, [exe, scenario, args.repeats])
            rows = [json.loads(line) for line in stdout.splitlines()]
            samples = [row for row in rows if not row['warmup']]
            summary.append({'label': args.label, 'opt': opt, 'scenario': scenario,
                'median_ms': statistics.median(row['total_alloc_sweep_ms'] for row in samples),
                'min_ms': min(row['total_alloc_sweep_ms'] for row in samples),
                'max_ms': max(row['total_alloc_sweep_ms'] for row in samples),
                'samples': samples})
        if args.jar and opt == args.opts[0]:
            run('real-jar-al-bytecode', [exe, 'inspect-jar', args.jar.resolve(), source / 'romfs/classes'])
    if args.build_only:
        return
    (output / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps([{k: v for k, v in row.items() if k != 'samples'} for row in summary], indent=2))


if __name__ == '__main__':
    main()
