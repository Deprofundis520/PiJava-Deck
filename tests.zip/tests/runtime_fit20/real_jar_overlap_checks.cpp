// Actual unmodified Xianni v.a bytecode through the production VM/JIT glue.
// Deliberately resolved QuickSites/classes and constructed glyph state;
// finite libnx mock, never a natural game warm-up or FPS benchmark.
#ifndef J2ME_TEST_VM
#error "Build with the real-JAR overlap runner's isolated hybrid VM"
#endif
#define main emulator_main
#include J2ME_TEST_VM
#undef main

static void check(bool ok,const char* why){if(!ok){std::cerr<<"FAIL real-jar-overlap "<<why<<" pool_used="<<jit236::code_pool_stats().used_bytes<<" objects="<<fit13_mock::live<<'\n';std::exit(1);}}
static void same_frame(const Frame& a,const Frame& b){
 check(a.pc==b.pc&&a.op_pc==b.op_pc&&a.locals.size()==b.locals.size()&&a.stack.size()==b.stack.size(),"exact PC/op-PC and stack/local depth");
 auto value=[](const Value& x,const Value& y){return x.i==y.i&&x.ref==y.ref&&x.l==y.l&&x.is_long==y.is_long;};
 for(unsigned i=0;i<a.locals.size();++i)check(value(a.locals[i],b.locals[i]),"exact local values");
 for(unsigned i=0;i<a.stack.size();++i)check(value(a.stack[i],b.stack[i]),"exact live stack values");
}
static std::vector<jit236::Executable> pressure(){
 const uint8_t bc[]={26,4,96,172};const std::string desc="(I)I";jit236::Spec spec{bc,sizeof bc,&desc,8,1,2,false,false,nullptr};
 jit236::Program program;check(jit236::verify(spec,program),"pressure leaf verifies");std::vector<jit236::Executable> out(4);
 for(auto& e:out){auto id=jit236::next_install_id();auto bytes=jit236::emit_host(program,id);check(!bytes.empty(),"pressure leaf emits");bytes.resize(262144,0);check(e.install(bytes,id),"ordinary 256KiB pressure slice installs");}
 return out;
}
struct Snapshot {Frame frame;std::vector<int32_t> pixels;};
int main(int argc,char** argv){
 check(argc==3,"original JAR and classpath arguments");VMS_DIAG(g_log_draw)=false;
 VMS_CL(g_classpath).push_back(argv[2]);std::vector<uint8_t> bytes;std::string error;
 check(read_whole(argv[1],bytes)&&unzip(bytes,VMS_CL(g_jar_files),error),"original JAR unzip");
 const int cls=ensure_class("v");unsigned mi=0;bool found=false;
 for(;mi<VMS_CL(g_classes)[cls].methods.size();++mi){auto& m=VMS_CL(g_classes)[cls].methods[mi];if(m.name=="a"&&m.desc=="(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;III)V"){found=true;break;}}
 check(found,"actual v.a(Graphics,String,III)V method");
 // Do not hold Class references across ensure_class: loading may reallocate.
 auto raw=VMS_CL(g_classes)[cls].methods[mi].code;
 for(size_t pc=0;pc<raw.size();){int op=raw[pc];int len=jvm_op_length(raw,pc);check(len>0,"bytecode decoding");
  if(op==178||op==180){std::string owner,name,desc;resolve_member(VMS_CL(g_classes)[cls],(raw[pc+1]<<8)|raw[pc+2],owner,name,desc);
   int cid=ensure_class(owner);auto* f=find_field(cid,name,desc);check(f!=nullptr,"real field resolves");
   auto& m=VMS_CL(g_classes)[cls].methods[mi];if(m.quick.empty())m.quick.resize(m.code.size());m.quick[pc].kind=1;m.quick[pc].a=f->owner;m.quick[pc].b=f->slot;
   std::cout<<"RESOLVE pc="<<pc<<" op="<<op<<" field="<<owner<<'.'<<name<<':'<<desc<<" cls="<<f->owner<<" slot="<<f->slot<<'\n';}
  std::cout<<"BC pc="<<pc<<" op="<<op;for(int k=1;k<len;++k)std::cout<<' '<<int(raw[pc+k]);std::cout<<'\n';pc+=len;}
 for(auto& c:VMS_CL(g_classes))c.init_state=2;
 auto& m=VMS_CL(g_classes)[cls].methods[mi];
 std::cout<<"METHOD code="<<m.code.size()<<" locals="<<m.max_locals<<" stack="<<m.max_stack<<" flags="<<m.flags<<'\n';
 // Safe, deliberately constructed 8x8 one-character glyph; no Graphics call.
 if(VMS_HEAP(g_heap).empty())VMS_HEAP(g_heap).push_back(Obj{});
 const int bits=alloc_array("[B",8),pixels=alloc_array("[I",64);
 for(unsigned i=0;i<8;++i)VMS_HEAP(g_heap)[bits].elems.set(i,Value::of_i(255));
 auto setstatic=[&](const char* name,const char* desc,Value value){auto* f=find_field(cls,name,desc);check(f&&f->is_static,"actual game static slot");VMS_CL(g_classes)[f->owner].statics[f->slot]=value;};
 setstatic("a","B",Value::of_i(8));setstatic("b","B",Value::of_i(1));setstatic("e","[B",Value::of_ref(bits));setstatic("g","[I",Value::of_ref(pixels));
 auto state=[&](){Frame f;f.method=&m;f.pc=108;f.op_pc=-1;f.locals.resize(m.max_locals);for(auto p:std::vector<std::pair<int,int>>{{5,0},{6,7},{7,7},{8,8},{9,0},{11,1},{12,8},{13,0},{14,65},{15,0x123456}})f.locals[p.first]=Value::of_i(p.second);return f;};
 auto resetpixels=[&](){for(unsigned i=0;i<64;++i)VMS_HEAP(g_heap)[pixels].elems.set(i,Value::of_i(0));};

 auto readpixels=[&](){std::vector<int32_t> out(64);for(unsigned i=0;i<64;++i)out[i]=VMS_HEAP(g_heap)[pixels].elems.get(i).i;return out;};
 auto restorepixels=[&](const std::vector<int32_t>& data){check(data.size()==64,"pixel snapshot shape");for(unsigned i=0;i<64;++i)VMS_HEAP(g_heap)[pixels].elems.set(i,Value::of_i(data[i]));};
 // Entry states come from the real interpreter, including the live operand
 // stack at arithmetic/branch/array-load PCs and a preceding pixel write at174.
 std::unordered_map<int,Snapshot> seeds;resetpixels();auto trace=state();
 const std::vector<int> entries={110,127,140,151,174};
 for(unsigned n=0;n<1000&&seeds.size()<entries.size();++n){
  if(std::find(entries.begin(),entries.end(),trace.pc)!=entries.end()&&!seeds.count(trace.pc))seeds.emplace(trace.pc,Snapshot{trace,readpixels()});
  if(seeds.size()<entries.size())check(execute_fast_batch(trace,1)==1,"real single-op trace progresses to all logged PCs");
 }
 check(seeds.size()==entries.size(),"all logged interior states traced");
 fit13_mock::limit=10;std::string why;check(jit_region_self_test(why),"actual Dedicated selftest executes");
 auto fillers=pressure();check(jit236::code_pool_stats().used_bytes==JitOverlapPressureBytes,"four whole ordinary arenas establish exact one-MiB pressure");
 auto& engine=VMS_NATIVE(g_native_jit);engine.enabled=engine.available=true;
 for(unsigned n=0;n<JitRegionHot+8;++n){resetpixels();auto f=state();int done=jit_region_try(f,10000);if(n>=JitRegionHot-1)check(done==2526&&f.pc==211,"loop-header owner really installs and fully executes");}
 auto& rm=g_jit_regions[&m];check(rm.loop_headers[108]&&rm.at[108].state==1&&jitr_overlap_healthy(rm.at[108]),"actual108 is admitted loop header with proven healthy progress");
 const auto owner_id=rm.at[108].exe.id;const auto owner_fn=rm.at[108].exe.fn;const size_t owner_size=rm.at[108].exe.size;
 const auto* owner_address=reinterpret_cast<const uint8_t*>(owner_fn);const std::vector<uint8_t> immutable_owner(owner_address,owner_address+owner_size);
 const auto region_bytes=g_jit_region_stats.bytes;const auto compiled=g_jit_region_stats.compiled;const auto slices=jit236::code_pool_stats().slices;const auto used=jit236::code_pool_stats().used_bytes;const auto creates=fit13_mock::creates;
 auto owner_unchanged=[&](){const auto& e=rm.at[108];check(e.state==1&&e.exe.id==owner_id&&e.exe.fn==owner_fn&&e.exe.size==owner_size&&std::equal(immutable_owner.begin(),immutable_owner.end(),owner_address),"existing owner ID/address/native bytes unchanged");};
 std::cout<<"OWNER entry=108 header=1 id="<<owner_id<<" runs="<<rm.at[108].overlap_runs<<" ops="<<rm.at[108].overlap_ops<<" code_page_bytes="<<owner_size<<" live_bytes="<<used<<" objects="<<fit13_mock::live<<'\n';
 for(int pc:entries){
  const auto& seed=seeds.at(pc);check(!rm.loop_headers[pc],"logged interior PC is a nonheader in real method");
  for(unsigned n=0;n<JitRegionHot+1000;++n){restorepixels(seed.pixels);auto f=seed.frame;check(jit_region_try(f,10000)==0,"covered hot interior entry returns to interpreter");same_frame(f,seed.frame);check(readpixels()==seed.pixels,"deferred entry performs no pixel writes");}
  const auto& candidate=rm.at[pc];check(candidate.state==0&&!candidate.exe.fn&&candidate.overlap_owner==108&&candidate.overlap_id==owner_id&&!rm.dead[pc]&&!jitr_skipped(seed.frame),"soft cache names actual owner without code/permanent skip");
  check(g_jit_region_stats.bytes==region_bytes&&g_jit_region_stats.compiled==compiled&&jit236::code_pool_stats().slices==slices&&jit236::code_pool_stats().used_bytes==used&&fit13_mock::creates==creates,"1064 attempts per PC allocate no new executable code/resources");owner_unchanged();
  std::cout<<"DEFER pc="<<pc<<" depth="<<seed.frame.stack.size()<<" header=0 attempts="<<JitRegionHot+1000<<" owner="<<candidate.overlap_owner<<" native_pages_delta=0\n";
  for(unsigned budget:{0u,1u,2u,3u,8u,32u,128u,1024u,10000u}){
   restorepixels(seed.pixels);auto ref=seed.frame;int expected=execute_fast_batch(ref,budget);auto expected_pixels=readpixels();
   restorepixels(seed.pixels);auto f=seed.frame;int done=jit_region_try(f,budget);check(done==0,"covered candidate continues fallback at every budget");done=execute_fast_batch(f,budget);check(done==expected,"fallback exact operation budget");same_frame(f,ref);check(readpixels()==expected_pixels,"fallback exact pixels including prior traced writes");
   std::cout<<"DIFFERENTIAL pc="<<pc<<" budget="<<budget<<" ops="<<done<<" exit="<<f.pc<<" last="<<f.op_pc<<'\n';
  }
 }
 check(g_jit_region_stats.overlap_deferred==entries.size()&&g_jit_region_stats.overlap_hits>=entries.size()*1000,"all actual candidates initially defer and reuse cached decisions");owner_unchanged();
 fillers.clear();while(!jit236::code_quarantine().empty())jit236::release_oldest_quarantine();check(jit236::code_pool_stats().used_bytes<JitOverlapPressureBytes,"actual ordinary slice retirement lowers live pressure");
 for(int pc:entries){
  const auto& seed=seeds.at(pc);restorepixels(seed.pixels);auto ref=seed.frame;int expected=execute_fast_batch(ref,10000);auto expected_pixels=readpixels();
  restorepixels(seed.pixels);auto f=seed.frame;int actual=jit_region_try(f,10000);check(actual==expected&&rm.at[pc].state==1&&rm.at[pc].exe.fn,"pressure drop immediately reopens original deferred candidate for install/execution");same_frame(f,ref);check(readpixels()==expected_pixels,"reopened compiled pixels match real interpreter");owner_unchanged();
  std::cout<<"REOPEN pc="<<pc<<" installed=1 ops="<<actual<<" exit="<<f.pc<<" code_page_bytes="<<rm.at[pc].exe.size<<'\n';
 }
 check(g_jit_region_stats.overlap_reopened==entries.size()&&g_jit_region_stats.compiled==compiled+entries.size(),"each cached candidate reopens once after real pressure release");
 check(fit13_mock::peak<=10,"finite native object ceiling respected");
 std::cout<<"SUMMARY deferred="<<g_jit_region_stats.overlap_deferred<<" cached_hits="<<g_jit_region_stats.overlap_hits<<" reopened="<<g_jit_region_stats.overlap_reopened<<" owner_immutable=1 peak_objects="<<fit13_mock::peak<<'\n';
 jit_region_reset();engine.clear();while(!jit236::code_quarantine().empty())jit236::release_oldest_quarantine();jit236::dedicated_blocks().clear();check(!fit13_mock::live&&!jit236::code_pool_stats().slices,"all native resources close");
 std::cout<<"PASS real_jar_overlap host="<<jit236::architecture()<<" real_JAR_bytecode=1 finite_libnx_mock=1 resolved_quicksites_fixture=1 natural_game_warmup=0 game_fps_claim=0\n";
}
