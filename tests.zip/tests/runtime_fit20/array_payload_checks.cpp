#include <cstdlib>
#include <new>
#include <cstdio>
static bool count_host_allocations=false;
static size_t host_allocations=0;
void* operator new(size_t n) { if(count_host_allocations)++host_allocations; if(void* p=std::malloc(n?n:1))return p;std::abort(); }
void* operator new[](size_t n){return ::operator new(n);}
void operator delete(void* p) noexcept {std::free(p);}
void operator delete[](void* p) noexcept {std::free(p);}
void operator delete(void* p,size_t) noexcept {std::free(p);}
void operator delete[](void* p,size_t) noexcept {std::free(p);}
#ifndef J2ME_TEST_VM
#define J2ME_TEST_VM "../../src/j2mevm.cpp"
#endif
#define main emulator_main
#include J2ME_TEST_VM
#undef main
static void check(bool ok,const char* why){if(!ok){std::fprintf(stderr,"FAIL array payload: %s host_allocations=%zu\n",why,host_allocations);std::exit(1);}}
static void batch(){
    for(int i=0;i<256;++i){int ref=alloc_array("[I",9);check(VMS_HEAP(g_heap)[ref].elems.get(0).i==0,"recycled payload starts at zero");VMS_HEAP(g_heap)[ref].elems.set(0,Value::of_i(i+1));}
    gc_collect("payload-batch");
    check(VMS_HEAP(g_array_payload_live)==0,"dead payloads excluded from live bytes");
}
int main(){
    VMS_DIAG(g_log_draw)=false;
    batch(); batch(); // Warm heap slots, mark scratch and payload capacity.
    host_allocations=0;count_host_allocations=true;
    for(int i=0;i<10;++i)batch();
    count_host_allocations=false;
    std::printf("actual_host_allocations=%zu arrays=2560\n",host_allocations);
    check(host_allocations<512,"repeated dead primitive payloads avoid per-array host allocation");
#ifdef J2ME_TEST_ARRAY_POOL_ENABLED
    auto& pool=VMS_HEAP(g_primitive_buffers);
    check(pool.hits>=2560 && pool.retained_bytes()<=pool.byte_budget(),"bounded reuse counters match executed VM allocations");
    const int live=alloc_array("[I",9);VMS_HEAP(g_heap)[live].elems.set(0,Value::of_i(123));VMS_RS(g_current)=live;
    const auto key=resver::g_epoch; const auto gen=VMS_HEAP(g_heap)[live].generation;
    gc_collect("payload-live-root");
    const int other=alloc_array("[I",9);
    check(other!=live && VMS_HEAP(g_heap)[other].elems.get(0).i==0,"new array does not alias live Java array");
    VMS_HEAP(g_heap)[other].elems.set(0,Value::of_i(456));
    check(VMS_HEAP(g_heap)[live].elems.get(0).i==123 && VMS_HEAP(g_heap)[live].generation==gen && resver::g_epoch==key,"live contents identity and epoch unchanged");
    VMS_RS(g_current)=0;gc_collect("payload-release");pool.clear();
    const auto returns=pool.returns;
    alloc_array("[Ljava/lang/Object;",9);alloc_array("[I",1025);gc_collect("payload-excluded");
    check(pool.returns==returns && pool.retained_bytes()==0,"reference and oversized payloads not retained");
    for(const char* desc:{"[B","[Z","[C","[S","[I","[F","[J","[D"}){
        const int a=alloc_array(desc,9);VMS_HEAP(g_heap)[a].elems.set(0,Value::of_i(-1));gc_collect("payload-type-reuse");
        const int b=alloc_array(desc,9);auto v=VMS_HEAP(g_heap)[b].elems.get(0);
        check(v.ref==0 && v.i==0 && v.l==0,"all primitive types clear old payload bits");gc_collect("payload-type-done");
    }
    pool.clear();check(pool.retained_bytes()==0,"explicit launch/restore cache reset releases capacity");
#endif
    std::puts("PASS primitive payload reuse actual_VM=1 Java_identity_preserved=1");
}
