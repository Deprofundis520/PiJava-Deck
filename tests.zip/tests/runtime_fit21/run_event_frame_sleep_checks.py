#!/usr/bin/env python3
"""Build and execute the focused production-VM event wait regression."""
import argparse
import json
from pathlib import Path
import subprocess

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--jar', type=Path)
parser.add_argument('--sanitize', action='store_true')
args = parser.parse_args()
source = Path(__file__).resolve().parents[2]
out = args.output.resolve()
out.mkdir(parents=True, exist_ok=True)
records = []

def run(label, command):
    command = list(map(str, command))
    result = subprocess.run(command, cwd=source, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=300)
    (out / (label + '.log')).write_bytes(result.stdout)
    records.append(dict(label=label, command=command, returncode=result.returncode))
    (out / 'commands.json').write_text(json.dumps(records, indent=2) + '\n')
    print(label + ' returncode=' + str(result.returncode), flush=True)
    if label.startswith('run-') and not result.returncode:
        print('\n'.join(line for line in result.stdout.decode(errors='replace').splitlines()
                        if line.startswith(('CASE ', 'GUARD ', 'EventFrameSleep '))) + '\n', end='', flush=True)
    elif result.returncode:
        print(result.stdout.decode(errors='replace')[-10000:], end='', flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)

flags = ['-O1', '-g0']
if args.sanitize:
    flags += ['-fsanitize=undefined', '-fno-sanitize-recover=all']
puff = out / 'puff.o'
binary = out / 'event-frame-sleep'
run('build-puff', ['gcc', *flags, '-c', source / 'src/puff.c', '-o', puff])
run('build-event', ['g++', *flags, '-std=c++17', '-fno-exceptions', '-ffunction-sections', '-fdata-sections',
    source / 'tests/runtime_fit21/event_frame_sleep_checks.cpp', puff, '-Wl,--gc-sections', '-pthread', '-ldl', '-o', binary])
run('run-generic', [binary])
if args.jar:
    run('run-original', [binary, args.jar.resolve()])
