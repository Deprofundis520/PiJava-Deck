// Reproduces loss of compiled loop execution after covered budget exits.
// The result and bytecode accounting are independent of wall-clock timing.
#ifndef J2ME_TEST_VM
#define J2ME_TEST_VM "../../src/j2mevm.cpp"
#endif
#define main emulator_main
#include J2ME_TEST_VM
#undef main

static void check(bool ok, const char* why) {
    if (!ok) { std::cerr << "FAIL loop-reentry " << why << '\n'; std::exit(1); }
}
static std::vector<jit236::Executable> pressure() {
    const uint8_t bc[] = {26,4,96,172}; const std::string desc = "(I)I";
    const jit236::Spec spec{bc,sizeof bc,&desc,8,1,2,false,false,nullptr};
    jit236::Program program; check(jit236::verify(spec,program),"pressure leaf verifies");
    std::vector<jit236::Executable> out(4);
    for (auto& e : out) {
        const auto id = jit236::next_install_id(); auto bytes = jit236::emit_host(program,id);
        bytes.resize(262144,0); check(e.install(bytes,id),"pressure code installs");
    }
    return out;
}
static Frame state(Method& m, int count) {
    Frame f; f.method=&m; f.pc=4; f.op_pc=-1;
    f.locals={Value::of_i(count),Value::of_i(0),Value::of_i(0)}; return f;
}
#ifndef J2ME_FIT21_BASELINE
static void same_frame(const Frame& a,const Frame& b) {
    check(a.pc==b.pc&&a.op_pc==b.op_pc&&a.locals.size()==b.locals.size()&&a.stack.size()==b.stack.size(),"exact PC, last PC and frame shape");
    auto same=[](const Value& x,const Value& y){return x.i==y.i&&x.ref==y.ref&&x.l==y.l&&x.is_long==y.is_long;};
    for(size_t i=0;i<a.locals.size();++i)check(same(a.locals[i],b.locals[i]),"exact locals");
    for(size_t i=0;i<a.stack.size();++i)check(same(a.stack[i],b.stack[i]),"exact live operand stack");
}
static void boundary_checks(Method& m) {
    // A split batch must be exactly the same Java prefix at every budget,
    // including nonempty-stack budget exits and the branch opcode itself.
    for(int budget=0;budget<=128;++budget) {
        auto reference=state(m,10000),candidate=reference;
        check(execute_fast_batch(reference,budget)==budget,"reference has this many loop operations");
        int done=0;
        while(done<budget) {
            const int n=execute_fast_batch<true>(candidate,budget-done);
            check(n>0&&n<=budget-done,"handoff always makes bounded progress"); done+=n;
        }
        same_frame(candidate,reference);
    }
    auto start=state(m,10000),end=start;
    check(execute_fast_batch<true>(end,0)==0,"zero budget does nothing");same_frame(start,end);
    end=start;check(execute_fast_batch<true>(end,100)==9&&end.pc==4&&end.op_pc==16,"taken goto is charged before loop handoff");
    end=state(m,0);check(execute_fast_batch<true>(end,100)==4&&end.pc==20&&end.stack.back().i==0,"untaken backedge follows the ordinary exit");
    // Conditional backward branch, one int left live at the target.
    Method conditional;conditional.class_id=0;conditional.max_locals=1;conditional.max_stack=2;
    conditional.code={132,0,255,26,154,255,252,87,177};conditional.quick.resize(conditional.code.size());
    Frame a;a.method=&conditional;a.locals={Value::of_i(3)};a.stack={Value::of_i(77)};a.op_pc=-1;
    Frame b=a;check(execute_fast_batch<true>(b,100)==3&&b.pc==0&&b.op_pc==4,"conditional backward branch is a boundary");
    check(execute_fast_batch(a,3)==3,"reference conditional prefix");same_frame(a,b);
    // A failed array store exits with all operands untouched. Earlier writes
    // occur once even when several backedge handoffs precede the exception.
    if(VMS_HEAP(g_heap).empty())VMS_HEAP(g_heap).push_back(Obj{});
    const int array=alloc_array("[I",4);
    Method store;store.class_id=0;store.max_locals=3;store.max_stack=3;
    store.code={3,61,28,27,162,0,13,42,28,28,79,132,2,1,167,255,244,177};store.quick.resize(store.code.size());
    auto stores=[&](){Frame f;f.method=&store;f.op_pc=-1;f.locals={Value::of_ref(array),Value::of_i(6),Value::of_i(0)};return f;};
    auto reference=stores();const int expected=execute_fast_batch(reference,1000);
    check(reference.pc==10&&reference.stack.size()==3&&reference.stack[1].i==4,"reference stops before out-of-bounds iastore");
    for(size_t i=0;i<4;++i){check(VMS_HEAP(g_heap)[array].elems.get(i).i==int(i),"literal expected array prefix");VMS_HEAP(g_heap)[array].elems.set(i,Value::of_i(-1));}
    auto candidate=stores();int done=0;
    for(unsigned calls=0;calls<20;++calls){const int n=execute_fast_batch<true>(candidate,1000-done);done+=n;if(!n)break;}
    check(done==expected,"array prefix keeps exact opcode count");same_frame(candidate,reference);
    for(size_t i=0;i<4;++i)check(VMS_HEAP(g_heap)[array].elems.get(i).i==int(i),"array writes preserved across handoffs");
    // Retired/banned headers must not keep forcing batch boundaries. An engine
    // epoch reset must discard the negative decision just as normal dispatch.
    jitr_mark_skip(&m,4);end=state(m,10000);
    const auto handoffs=g_jit_region_stats.backedge_handoffs;
    check(execute_fast_batch<true>(end,128)==128&&g_jit_region_stats.backedge_handoffs==handoffs,"skipped loop stays uninterrupted");
    VMS_NATIVE(g_native_jit).clear();end=state(m,10000);
    check(execute_fast_batch<true>(end,100)==9,"new engine epoch discards old skip decision");
    std::cout<<"PASS loop-reentry exact budgets, stacks, writes, exceptions, skip and epoch\n";
}
static void disabled_profile_checks(Method& m) {
    jit_region_reset();VMS_NATIVE(g_native_jit).configure(false);
    check(run(&m,{Value::of_i(10000)}).i==49995000,"JIT-disabled result");
    check(g_jit_region_stats.ops==0&&g_jit_region_stats.backedge_handoffs==0,"JIT-disabled keeps original fast path");
    VMS_NATIVE(g_native_jit).configure(true);jit_region_reset();
    check(run_impl<true>(&m,{Value::of_i(10000)}).i==49995000,"method-profile result");
    check(g_jit_region_stats.ops==0&&g_jit_region_stats.backedge_handoffs==0,"method-profile keeps original fast path");
    std::cout<<"PASS loop-reentry disabled and method-profile isolation\n";
}
static void representation_checks() {
    // Both classfile shapes pass an independent Java verifier. A live long
    // operand and a merged local used only in an untaken int-store arm are
    // valid Java, but are not representable by the current integer region.
    // They must retain batched interpretation rather than dispatch once per
    // iteration forever. A changed input must still permit future JIT use.
    for(bool live_stack:{true,false}) {
        jit_region_reset();VMS_NATIVE(g_native_jit).clear();
        Method m;m.class_id=0;m.name=live_stack?"liveLongStack":"mergedLongLocal";
        m.desc=live_stack?"(I)J":"(IZ)I";m.flags=8;m.max_locals=live_stack?1:4;m.max_stack=3;
        m.code=live_stack?std::vector<uint8_t>{10,132,0,255,26,154,255,252,173}:
            std::vector<uint8_t>{10,65,27,153,0,5,3,61,132,0,255,26,154,255,246,4,172};
        m.quick.resize(m.code.size());
        const auto fast0=VMS_EXEC(g_fast_ops),slow0=VMS_EXEC(g_slow_ops),jit0=g_jit_region_stats.ops;
        const auto handoffs0=g_jit_region_stats.backedge_handoffs;
        const int count=100000;
        auto result=run(&m,live_stack?std::vector<Value>{Value::of_i(count)}:
            std::vector<Value>{Value::of_i(count),Value::of_i(0)});
        const auto ops=VMS_EXEC(g_fast_ops)-fast0+VMS_EXEC(g_slow_ops)-slow0+g_jit_region_stats.ops-jit0;
        const auto handoffs=g_jit_region_stats.backedge_handoffs-handoffs0;
        check(live_stack?(result.is_long&&result.l==1):result.i==1,"representation fallback literal result");
        check(ops==uint64_t(count)*(live_stack?3:5)+(live_stack?2:4),"representation fallback exact bytecodes");
        std::cout<<"REPRESENTATION case="<<(live_stack?"stack":"local")<<" iterations="<<count<<" handoffs="<<handoffs<<" ops="<<ops<<'\n';
        check(handoffs*16<uint64_t(count),"unrepresentable loops must not hand off once per iteration");
        if(!live_stack) {
            const auto before=g_jit_region_stats.ops;
            result=run(&m,{Value::of_i(count),Value::of_i(1)});
            check(result.i==1&&g_jit_region_stats.ops-before>uint64_t(count)*3,
                  "changed local representation must re-admit JIT without an epoch reset");
        }
        jit_region_reset();
    }
    std::cout<<"PASS loop-reentry transient representation fallback and re-admission\n";
}
static void helper_bail_checks() {
    // A real, resolved long getstatic repeatedly fails the integer helper
    // after twelve productive operations. The old short-region retirement
    // threshold does not cover this case; ordinary batching must remain.
    jit_region_reset();VMS_NATIVE(g_native_jit).clear();
    Class cls;cls.name="LongHelperFixture";cls.init_state=2;
    const int cid=int(VMS_CL(g_classes).size());
    Field field;field.owner=cid;field.name="longField";field.desc="J";field.slot=0;field.is_static=true;
    cls.fields.push_back(field);cls.statics={Value::of_l(1)};cls.cp.resize(7);
    cls.cp[1].tag=9;cls.cp[1].a=2;cls.cp[1].b=3;cls.cp[2].tag=7;cls.cp[2].a=4;
    cls.cp[3].tag=12;cls.cp[3].a=5;cls.cp[3].b=6;
    cls.cp[4].tag=cls.cp[5].tag=cls.cp[6].tag=1;
    cls.cp[4].utf=cls.name;cls.cp[5].utf=field.name;cls.cp[6].utf=field.desc;
    VMS_CL(g_classes).push_back(std::move(cls));
    Method m;m.class_id=cid;m.name="persistentLongStaticHelper";m.desc="(II)I";
    m.flags=8;m.max_locals=2;m.max_stack=2;
    for(int k=0;k<12;++k)m.code.insert(m.code.end(),{132,1,1});
    m.code.insert(m.code.end(),{178,0,1,88,132,0,255,26,154,255,212,27,172});
    m.quick.resize(m.code.size());m.quick[36].kind=1;m.quick[36].a=cid;m.quick[36].b=0;
    const int count=10000;
    for(unsigned trial=0;trial<JitRegionHot+8;++trial) {
        Frame f;f.method=&m;f.locals={Value::of_i(count),Value::of_i(0)};
        const int done=jit_region_try(f,1024);
        if(trial>=JitRegionHot-1)check(done==12&&f.pc==36,"real compiled prefix reaches the failing long helper");
    }
    check(g_jit_regions[&m].at[0].state==1&&g_jit_regions[&m].at[0].overlap_bailed,
          "persistent helper region is installed and known to bail");
    const auto fast0=VMS_EXEC(g_fast_ops),slow0=VMS_EXEC(g_slow_ops),jit0=g_jit_region_stats.ops;
    check(run(&m,{Value::of_i(count),Value::of_i(0)}).i==12*count,"helper fallback literal result");
    check(VMS_EXEC(g_fast_ops)-fast0+VMS_EXEC(g_slow_ops)-slow0+g_jit_region_stats.ops-jit0==uint64_t(count)*17+2,
          "helper fallback exact bytecodes");
    check(g_jit_region_stats.backedge_handoffs==0,"rejected helper keeps ordinary batching");
    std::cout<<"PASS loop-reentry persistent helper bailout keeps ordinary batching\n";
    jit_region_reset();
}
#endif
int main(int argc, char** argv) {
    VMS_DIAG(g_log_draw)=false;
    VMS_CL(g_classpath)={"romfs/classes"};
    Class c; c.name="LoopReentryFixture"; c.init_state=2;
    VMS_CL(g_classes).push_back(std::move(c));
    Method m; m.class_id=0; m.name="sum"; m.desc="(I)I";
    m.flags=8; m.max_locals=3; m.max_stack=2;
    // sum(0..n-1), literal loop header at BCI4, nine bytecodes/iteration.
    m.code={3,60,3,61,28,26,162,0,13,27,28,96,60,132,2,1,167,255,244,27,172};
    m.quick.resize(m.code.size());
    VMS_NATIVE(g_native_jit).configure(true);
    check(VMS_NATIVE(g_native_jit).enabled&&VMS_NATIVE(g_native_jit).available,"host JIT available");
    auto fillers=pressure();
    for (unsigned n=0;n<JitRegionHot+8;++n) {
        auto f=state(m,10000); const int done=jit_region_try(f,1024);
        if(n>=JitRegionHot-1)check(done==1024,"healthy owner consumes full original budget");
    }
    check(g_jit_regions[&m].loop_headers[4]&&jitr_overlap_healthy(g_jit_regions[&m].at[4]),"compiled true loop header is healthy");
    // Warm naturally through the real run() dispatcher. Pressure lets the
    // existing overlap policy defer suffixes rather than install duplicates.
    for(unsigned n=0;n<12;++n)check(run(&m,{Value::of_i(10000)}).i==49995000,"literal Java sum during warmup");
    const auto region_before=g_jit_region_stats.ops;
    const auto fast_before=VMS_EXEC(g_fast_ops);
    const auto slow_before=VMS_EXEC(g_slow_ops);
    const auto result=run(&m,{Value::of_i(10000)});
    const auto region=g_jit_region_stats.ops-region_before;
    const auto fast=VMS_EXEC(g_fast_ops)-fast_before;
    const auto slow=VMS_EXEC(g_slow_ops)-slow_before;
    std::cout<<"MEASURE sum="<<result.i<<" region_ops="<<region<<" fast_ops="<<fast
             <<" slow_ops="<<slow<<" total="<<region+fast+slow
             <<" overlap_hits="<<g_jit_region_stats.overlap_hits<<'\n';
    check(result.i==49995000,"literal Java sum preserved");
    check(region+fast+slow==90009,"exact original bytecode count including return");
    if(argc==1||std::string(argv[1])!="characterize")
        check(region*10>9*(region+fast),"covered loop must promptly reenter compiled header");
#ifndef J2ME_FIT21_BASELINE
    boundary_checks(m);
    disabled_profile_checks(m);
    representation_checks();
    helper_bail_checks();
#endif
    jit_region_reset(); VMS_NATIVE(g_native_jit).clear();
    std::cout<<"PASS loop-reentry runtime and arithmetic\n";
}
