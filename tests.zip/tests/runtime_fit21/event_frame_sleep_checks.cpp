#define main emulator_main
#ifndef J2ME_TEST_VM
#define J2ME_TEST_VM "../../src/j2mevm.cpp"
#endif
#include J2ME_TEST_VM
#undef main
#include <iostream>

// Generic, distributable bytecode fixture. An optional supplied JAR exercises
// the unchanged original controller loop and forwarding wrapper as well.
static int checks=0;
static void check(bool ok,const char* message) {
    ++checks;if(!ok){std::cerr<<"FAIL EventFrameSleep "<<message<<'\n';std::exit(1);}
}
static int utf(Class& c,const std::string& value) {
    CpEntry e;e.tag=1;e.utf=value;c.cp.push_back(e);return int(c.cp.size())-1;
}
static int member(Class& c,int tag,const std::string& owner,const std::string& name,const std::string& desc) {
    const int cn=utf(c,owner),fn=utf(c,name),fd=utf(c,desc);
    CpEntry cl;cl.tag=7;cl.a=cn;c.cp.push_back(cl);const int ci=int(c.cp.size())-1;
    CpEntry nt;nt.tag=12;nt.a=fn;nt.b=fd;c.cp.push_back(nt);const int ni=int(c.cp.size())-1;
    CpEntry ref;ref.tag=uint8_t(tag);ref.a=ci;ref.b=ni;c.cp.push_back(ref);return int(c.cp.size())-1;
}
static void patch_cp(std::vector<uint8_t>& code,int at,int cp) {code[at+1]=uint8_t(cp>>8);code[at+2]=uint8_t(cp);}
static Method method(int owner,const char* name,const char* desc,std::vector<uint8_t> code,int locals=4,int flags=1) {
    Method m;m.class_id=owner;m.name=name;m.desc=desc;m.code=std::move(code);m.max_locals=locals;m.max_stack=8;m.flags=flags;
    m.quick.resize(m.code.size());return m;
}
struct Fixture {int owner=-1,controller=0,canvas=0,flag_slot=-1,extra_slot=-1;Method* loop=nullptr;Method* bridge=nullptr;};
static Fixture fixture(bool supplied) {
    Fixture f;
    const int object=ensure_class("java/lang/Object"),canvas_class=ensure_class("javax/microedition/lcdui/game/GameCanvas");
    f.canvas=alloc_obj(canvas_class);
    run(find_method(canvas_class,"<init>","(Z)V",false),{Value::of_ref(f.canvas),Value::of_i(0)});
    const int parent=supplied?ensure_class("b"):object;
    f.owner=int(VMS_CL(g_classes).size());Class c;c.name=supplied?"EventFrameOriginalProbe":"EventFrameGenericProbe";
    c.super_id=parent;c.init_state=2;c.instance_fields=VMS_CL(g_classes)[parent].instance_fields;c.cp.push_back({});
    if(!supplied) {
        Field flag;flag.owner=f.owner;flag.name="event";flag.desc="Z";flag.slot=c.instance_fields++;c.fields.push_back(flag);
        Field extra;extra.owner=f.owner;extra.name="extraPeriod";extra.desc="I";extra.slot=c.instance_fields++;c.fields.push_back(extra);
    }
    Field canvas;canvas.owner=f.owner;canvas.name="canvas";canvas.desc="Ljavax/microedition/lcdui/game/GameCanvas;";canvas.slot=0;canvas.is_static=true;
    c.fields.push_back(canvas);c.statics.push_back(Value::of_ref(f.canvas));
    const int draw_field=member(c,9,c.name,canvas.name,canvas.desc);
    const int draw=member(c,10,"javax/microedition/lcdui/game/GameCanvas","flushGraphics","()V");
    std::vector<uint8_t> work={0xb2,0,0,0xb6,0,0,0x03,0xac};patch_cp(work,0,draw_field);patch_cp(work,3,draw);
    c.methods.push_back(method(f.owner,supplied?"a":"enter","()V",{0xb1}));
    c.methods.push_back(method(f.owner,supplied?"b":"leave","()V",{0xb1}));
    c.methods.push_back(method(f.owner,supplied?"c":"work","()Z",work));
    if(!supplied) {
        const int enter=member(c,10,c.name,"enter","()V"),leave=member(c,10,c.name,"leave","()V"),call_work=member(c,10,c.name,"work","()Z");
        const int flag=member(c,9,c.name,"event","Z"),extra=member(c,9,c.name,"extraPeriod","I");
        const int clock=member(c,10,"java/lang/System","currentTimeMillis","()J");
        const int maximum=member(c,10,"java/lang/Math","max","(JJ)J"),forward=member(c,10,c.name,"positiveSleep","(J)V");
        CpEntry floor;floor.tag=5;floor.l=5;c.cp.push_back(floor);const int floor_cp=int(c.cp.size())-1;c.cp.push_back({});
        std::vector<uint8_t> loop={0x2a,0xb6,0,0,0xb8,0,0,0x40,0x2a,0xb6,0,0,0x9a,0,47,
            0x03,0x3e,0x2a,0xb4,0,0,0x99,0,13,0x2a,0xb4,0,0,0x3e,0x2a,0x03,0xb5,0,0,
            0x14,0,0,0x1d,0x10,83,0x60,0x85,0xb8,0,0,0x1f,0x65,0x65,0xb8,0,0,0x5c,0x40,0xb8,0,0,0xa7,0xff,0xcc,
            0x2a,0xb6,0,0,0xb1};
        for(auto pair:std::vector<std::pair<int,int>>{{1,enter},{4,clock},{9,call_work},{18,flag},{25,extra},{31,flag},{34,floor_cp},{42,clock},{48,maximum},{53,forward},{60,leave}})patch_cp(loop,pair.first,pair.second);
        c.methods.push_back(method(f.owner,"loop","()V",loop));
        const int sleep=member(c,10,"java/lang/Thread","sleep","(J)V");
        std::vector<uint8_t> bridge={0x1e,0x09,0x94,0x9d,0,4,0xb1,0x1e,0xb8,0,0,0xb1};patch_cp(bridge,8,sleep);
        c.methods.push_back(method(f.owner,"positiveSleep","(J)V",bridge,2,9));
    }
    const std::string name=c.name;VMS_CL(g_classes).push_back(std::move(c));VMS_CL(g_class_index)[name]=f.owner;
    f.controller=alloc_obj(f.owner);
    if(supplied)run(find_method(parent,"<init>","(I)V",false),{Value::of_ref(f.controller),Value::of_i(0)});
    f.flag_slot=find_field(parent==object?f.owner:parent,supplied?"f":"event","Z")->slot;
    f.extra_slot=find_field(parent==object?f.owner:parent,supplied?"i":"extraPeriod","I")->slot;
    f.loop=find_method(supplied?parent:f.owner,supplied?"d":"loop","()V",false);
    f.bridge=find_method(supplied?ensure_class("cx"):f.owner,supplied?"a":"positiveSleep","(J)V",false);
    return f;
}
static void prepare(Fixture& f,int cap,bool event) {
    VMS_EXEC(g_running_thread)=nullptr;speed_reset_learning();
    for(auto& t:VMS_EXEC(g_threads))diag_sleep_cancel(t,runtime_cause::CancelReason::Reset);
    VMS_EXEC(g_threads).clear();VMS_EXEC(g_thread_live)=false;VMS_EXEC(g_active_stack)=nullptr;
    VMS_EXEC(g_midlet_state)=MidletState::Active;VMS_PLAT(g_host_paused)=false;VMS_PLAT(g_host_frozen236)=false;
    VMS_EXEC(g_notify_destroyed)=VMS_EXEC(g_notify_paused)=false;
    VMS_EXEC(g_speed_cap)=cap;speed_sync_clock();speed_reset_learning();VMS_EXEC(g_speed_next_us)=0;
    VMS_EXEC(g_game_clock).rate(paint_clock_us(),1.0);VMS_EXEC(g_game_clock).pause(paint_clock_us(),false);
    VMS_RS(g_current)=VMS_RS(g_shown)=f.canvas;VMS_RS(g_repaint)=false;VMS_RS(g_paint_depth)=0;
    VMS_HEAP(g_heap)[f.controller].fields[f.flag_slot]=Value::of_i(event);
    VMS_HEAP(g_heap)[f.controller].fields[f.extra_slot]=Value::of_i(83);
    VMS_EXEC(g_threads).emplace_back();auto& t=VMS_EXEC(g_threads).back();VMS_EXEC(g_running_thread)=&t;
    current_thread_ref();VMS_EXEC(g_yield)=false;VMS_EXEC(g_slice_ms)=100;
}
static void resume(Fixture& f,bool first=false) {
    VMS_EXEC(g_yield)=false;VMS_EXEC(g_resume_request)=true;
    run(first?f.loop:nullptr,first?std::vector<Value>{Value::of_ref(f.controller)}:std::vector<Value>{});
}
static runtime_cause::SleepRequest sleep_record(JavaThreadContext& t) {
    diag_sleep_cancel(t,runtime_cause::CancelReason::Manual);
    const auto& logs=g_device_diag.sleeps;
    check(logs.completions!=0,"production sleep diagnostics recorded");
    return logs.history[size_t((logs.completions-1)%logs.history.size())].request;
}
static void runtime_case(Fixture& f,int cap,bool event,int delayed_work_ms=0) {
    prepare(f,cap,event);auto& t=current_context();const auto before=paint_clock_us();
    for(int turn=0;turn<8&&t.state==ThreadState::Runnable;++turn) {
        // A real cooperative drawing boundary lets us model elapsed work or
        // scheduler delay without faking either Java clock sample.
        if(turn==1&&delayed_work_ms)std::this_thread::sleep_for(std::chrono::milliseconds(delayed_work_ms));
        resume(f,turn==0);
    }
    check(t.state==ThreadState::Sleeping,"exact loop reaches native sleep");
    check(t.frames.size()==2&&t.frames.back().method==f.bridge,"real bridge remains on cooperative Java stack");
    const int64_t requested=as_long(t.frames.back().locals[0]);
    if(!delayed_work_ms)check((requested>120)==event,"original Java request retains the event multiplier");
    else if(delayed_work_ms>=166)check(requested==5,"original max floor remains five milliseconds");
    else if(delayed_work_ms>=46)check(requested>5&&requested<=120,"event remainder crosses ordinary sleep boundary after elapsed work");
    else check(requested>120&&requested<166,"event remainder subtracts actual elapsed work");
    check(!VMS_HEAP(g_heap)[f.controller].fields[f.flag_slot].i,"Java consumes its own event flag");
    check(VMS_HEAP(g_heap)[f.controller].fields[f.extra_slot].i==83,"Java period field stays unchanged");
    check(t.owned_draws==1,"actual GameCanvas flush earns one completed drawing");
    if(cap) {
        check(t.wake_us>0&&t.sleep_paced,"certified event receives an owned cap deadline");
        const int64_t budget=(event?2:1)*speed_period_us();
        if(delayed_work_ms*1000>budget)check(t.wake_us>=paint_clock_us()&&t.wake_us<=paint_clock_us()+1500,
              "overdue event keeps a one-millisecond cooperative sleep");
        else check(t.wake_us>=before+budget-3000&&t.wake_us<=before+budget+3000,
              "absolute cap deadline includes elapsed work and preserves one/two frames");
    } else {
        check(t.wake_us==0&&!t.sleep_paced,"native mode retains original Java wait");
        check(t.wake>=monotonic_ms()+requested-2,"native deadline retains full requested duration");
    }
    check(t.frame_due_us==0,"one sleep consumes or discards its drawing credit");
    check(VMS_EXEC(g_game_clock).scale==1.0,"Java clock remains unscaled");
    const auto log=sleep_record(t);
    check(log.requested_ms==requested,"diagnostics keep original Java request");
    check((log.route==runtime_cause::Route::EventFrame)==(cap&&event),"production diagnostic route distinguishes the certified event");
    check(!t.event_frame_sleep.active&&!t.event_frame_sleep.complete,"certificate consumed once");
    std::cout<<"CASE cap="<<cap<<" event="<<event<<" delayed_work_ms="<<delayed_work_ms<<" request_ms="<<requested<<" scheduled_us="<<(t.wake_us?t.wake_us-before:0)<<" route="<<runtime_cause::route_name(log.route)<<'\n';
}
static void begin_drawn_event(Fixture& f) {
    prepare(f,60,true);resume(f,true);auto& t=current_context();
    check(t.state==ThreadState::Runnable&&t.owned_draws==1&&t.frames.size()==2,"fixture stops at real completed-draw yield");
    check(t.event_frame_sleep.active&&!t.event_frame_sleep.complete,"start clock captured before work returns");
}
static void reject_after_draw(Fixture& f,const char* label,const std::function<void(JavaThreadContext&)>& change) {
    begin_drawn_event(f);auto& t=current_context();change(t);
    for(int turn=0;turn<8;++turn){resume(f);if(t.state==ThreadState::Sleeping)break;}
    check(t.state==ThreadState::Sleeping,"guard fixture reaches native sleep");
    const auto log=sleep_record(t);
    check(log.requested_ms>120,"guard fixture still asks for a long event remainder");
    check(t.wake_us==0&&!t.sleep_paced&&log.effective_ms==log.requested_ms,"invalid event proof retains original long wait");
    check(log.route==runtime_cause::Route::LongUnpaced&&!t.event_frame_sleep.active,"invalid event uses original outside-range route");
    std::cout<<"GUARD "<<label<<" PASS\n";
}
static void runtime_guards(Fixture& f) {
    reject_after_draw(f,"missing owner",[](JavaThreadContext&){VMS_EXEC(g_speed_budget_owner)=nullptr;});
    reject_after_draw(f,"foreign owner",[](JavaThreadContext&){VMS_EXEC(g_speed_budget_owner)=&VMS_EXEC(g_main_thread);});
    reject_after_draw(f,"spent draw credit",[](JavaThreadContext& t){t.frame_due_us=0;});
    reject_after_draw(f,"different activation",[](JavaThreadContext& t){++t.frames.front().event_frame_cycle;});
    reject_after_draw(f,"wrong depth",[](JavaThreadContext& t){++t.event_frame_sleep.depth;});
    reject_after_draw(f,"changed anchor",[](JavaThreadContext& t){auto& v=t.frames.front().locals[1];v=Value::of_l(as_long(v)-1);});
    reject_after_draw(f,"wrong extra period",[&](JavaThreadContext&){VMS_HEAP(g_heap)[f.controller].fields[f.extra_slot]=Value::of_i(84);});
    reject_after_draw(f,"heap epoch",[](JavaThreadContext&){resver::bump_epoch();});
    reject_after_draw(f,"controller generation",[&](JavaThreadContext&){++VMS_HEAP(g_heap)[f.controller].generation;});
    reject_after_draw(f,"canvas generation",[&](JavaThreadContext&){++VMS_HEAP(g_heap)[f.canvas].generation;});
    reject_after_draw(f,"hidden canvas",[](JavaThreadContext&){VMS_RS(g_shown)=0;});
    reject_after_draw(f,"host pause",[](JavaThreadContext&){VMS_PLAT(g_host_paused)=true;});
    reject_after_draw(f,"host freeze",[](JavaThreadContext&){VMS_PLAT(g_host_frozen236)=true;});
    reject_after_draw(f,"lifecycle pause",[](JavaThreadContext&){VMS_EXEC(g_midlet_state)=MidletState::Paused;});
    reject_after_draw(f,"notify pause",[](JavaThreadContext&){VMS_EXEC(g_notify_paused)=true;});
    reject_after_draw(f,"notify destroy",[](JavaThreadContext&){VMS_EXEC(g_notify_destroyed)=true;});
    reject_after_draw(f,"scaled clock",[](JavaThreadContext&){VMS_EXEC(g_game_clock).rate(paint_clock_us(),1.5);});
    reject_after_draw(f,"paused game clock",[](JavaThreadContext&){VMS_EXEC(g_game_clock).pause(paint_clock_us(),true);});
    reject_after_draw(f,"timer queue wait",[](JavaThreadContext& t){t.timer.queue_wait=true;});
    reject_after_draw(f,"verified clock gate",[](JavaThreadContext& t){t.auto_fps.verified_gate_seen=true;});
    reject_after_draw(f,"wrong thread state",[](JavaThreadContext& t){t.state=ThreadState::Blocked;});
    reject_after_draw(f,"stale real anchor",[](JavaThreadContext& t){t.event_frame_sleep.start_us-=240001;});
    reject_after_draw(f,"mode change",[](JavaThreadContext&){VMS_EXEC(g_speed_cap)=30;});
    reject_after_draw(f,"native mode change",[](JavaThreadContext&){VMS_EXEC(g_speed_cap)=0;});
    reject_after_draw(f,"pause/resume reset",[](JavaThreadContext& t){speed_pause_clock(true);speed_pause_clock(false);check(!t.event_frame_sleep.active,"pause drops event evidence");});
    reject_after_draw(f,"explicit learning reset",[](JavaThreadContext& t){speed_reset_learning();check(!t.event_frame_sleep.active,"learning reset drops event evidence");});
    reject_after_draw(f,"frame unwind",[](JavaThreadContext& t){release_frame_monitor(t.frames.front());check(!t.event_frame_sleep.active,"unwind cancels the matching method");});
    reject_after_draw(f,"two actual draws",[&](JavaThreadContext& t){
        const int cls=ensure_class("javax/microedition/lcdui/game/GameCanvas");
        run(find_method(cls,"flushGraphics","()V",false),{Value::of_ref(f.canvas)});
        check(t.owned_draws==2,"second actual flush really occurred");
    });
    reject_after_draw(f,"real Display switch",[&](JavaThreadContext& t){
        const int cls=ensure_class("javax/microedition/lcdui/Display"),display=alloc_obj(cls);
        const int next=alloc_obj(ensure_class("javax/microedition/lcdui/game/GameCanvas"));
        run(find_method(cls,"setCurrent0","(Ljavax/microedition/lcdui/Displayable;ILjavax/microedition/lcdui/Displayable;)V",false),
            {Value::of_ref(display),Value::of_ref(next),Value::of_i(-1),Value::of_ref(0)});
        check(!t.event_frame_sleep.active,"Display invalidates pending event evidence");
    });
    // Real Java Thread.yield is not a completed frame; unrelated sleeps cannot
    // carry a partial certificate through a blocking native operation.
    reject_after_draw(f,"unrelated Thread.yield",[](JavaThreadContext& t){
        const int cls=ensure_class("java/lang/Thread");Frame call;call.method=find_method(cls,"yield","()V",false);
        VMS_EXEC(g_can_suspend)=true;thread_native(call.method,call);VMS_EXEC(g_can_suspend)=false;
        check(!t.event_frame_sleep.active,"yield cancels partial event evidence");
    });
    begin_drawn_event(f);auto& ending=current_context();finish_thread(ending);
    check(!ending.event_frame_sleep.active&&ending.frames.empty(),"thread termination resets event evidence");
    std::cout<<"GUARD termination PASS\n";
}
static void direct_long_waits(Fixture& f) {
    Method* sleep=find_method(ensure_class("java/lang/Thread"),"sleep","(J)V",false);
    for(int cap:{0,30,60})for(bool drawn:{false,true})for(int request:{147,148,149,150,151,152,153,166,500}) {
        prepare(f,cap,false);auto& t=current_context();VMS_EXEC(g_can_suspend)=true;
        if(drawn)speed_note_paint(paint_clock_us(),&t);
        Frame call;call.method=sleep;call.locals={Value::of_l(request)};
        const auto before=monotonic_ms();thread_native(sleep,call);const auto after=monotonic_ms();VMS_EXEC(g_can_suspend)=false;
        check(t.state==ThreadState::Sleeping&&t.wake_us==0&&!t.sleep_paced,"direct long sleep does not acquire event pacing");
        check(t.wake>=before+request&&t.wake<=after+request,"direct long sleep retains exact Java duration");
    }
    std::cout<<"GUARD direct native long waits (54 combinations) PASS\n";
}
static void structural_checks(Fixture& f) {
    const auto& cls=VMS_CL(g_classes)[f.loop->class_id];Frame frame;frame.method=f.loop;frame.locals={Value::of_ref(f.controller)};
    auto recognize=[&](const std::vector<uint8_t>& code,int start=4) {
        return recognize_event_frame_sleep(code,start,jvm_op_length,
            [&](int cp){return event_frame_member(cls,cp,"java/lang/System","currentTimeMillis","()J");},
            [&](int cp){return event_frame_member(cls,cp,nullptr,nullptr,"()Z");},
            [&](int cp,bool extra){return event_frame_field(frame,cp,extra)!=nullptr;},
            [&](int cp){return event_frame_member(cls,cp,"java/lang/Math","max","(JJ)J");},
            [&](int cp){return event_frame_member(cls,cp,nullptr,nullptr,"(J)V");},
            [&](int cp,bool wide)->int64_t{return cp>0&&size_t(cp)<cls.cp.size()&&cls.cp[cp].tag==(wide?5:3)?(wide?cls.cp[cp].l:cls.cp[cp].a):0;});
    };
    const auto original=f.loop->code;const auto p=recognize(original);
    check(p.valid()&&p.start==4&&p.end==42&&p.bridge==53&&p.period_ms==83&&p.floor_ms==5,"exact loop bytecode recognized");
    check(p.anchor==1&&p.extra==3&&p.request==1,"reused anchor/request slot is tracked exactly");
    for(size_t n=0;n<=59;++n)check(!recognize({original.begin(),original.begin()+n}).valid(),"truncated loop certificate rejected");
    check(!recognize(original,5).valid(),"operand byte cannot be a clock entry");
    for(auto replacement:std::vector<std::pair<int,int>>{{7,0x41},{15,0x04},{23,12},{30,0x04},{37,0x1c},{39,7},{39,121},
        {40,0x64},{41,0x88},{45,0x20},{46,0x61},{47,0x61},{51,0x59},{52,0x3f},{58,0xcd}}) {
        auto bad=original;bad[size_t(replacement.first)]=uint8_t(replacement.second);
        check(!recognize(bad).valid(),"foreign local, arithmetic, branch, reset or period rejected");
    }
    for(auto use:std::vector<std::pair<int,int>>{{4,48},{9,53},{18,25},{25,18},{31,25},{42,48},{48,4},{53,9}}) {
        auto bad=original;bad[size_t(use.first+1)]=original[size_t(use.second+1)];bad[size_t(use.first+2)]=original[size_t(use.second+2)];
        check(!recognize(bad).valid(),"wrong field or call signature rejected");
    }
    auto bad=original;bad[1]=0xa7;bad[2]=0;bad[3]=41;
    check(!recognize(bad).valid(),"outside entry into end-clock block rejected");
    bad=original;bad.insert(bad.end(),{0xa7,0xff,0xea});
    check(!recognize(bad).valid(),"unreachable foreign branch into loop rejected conservatively");
    bad=original;bad[0]=0xc4;check(!recognize(bad).valid(),"wide/unsupported control flow rejected");
    bad=original;bad[16]=bad[28]=0x3c;bad[37]=0x1b;
    check(!recognize(bad).valid(),"extra cannot alias either word of the long anchor");
    for(int period:{8,120}){bad=original;bad[39]=uint8_t(period);check(recognize(bad).valid(),"bounded period endpoint recognized structurally");}
    const int floor_cp=(int(original[35])<<8)|original[36];auto& entry=VMS_CL(g_classes)[f.loop->class_id].cp[size_t(floor_cp)];const auto floor=entry.l;
    for(int floor_bad:{0,8}){entry.l=floor_bad;check(!recognize(original).valid(),"unbounded/zero floor rejected");}entry.l=floor;
    for(bool extra:{false,true}) {
        auto* field=const_cast<Field*>(event_frame_field(frame,extra?p.extra_field:p.flag_field,extra));const auto flags=field->flags;
        field->flags|=0x0040;check(!recognize(original).valid(),"volatile event fields cannot become pacing evidence");field->flags=flags;
    }
    auto bridge_copy=[&]() {Method m;m.class_id=f.bridge->class_id;m.name=f.bridge->name;m.desc=f.bridge->desc;
        m.flags=f.bridge->flags;m.max_locals=f.bridge->max_locals;m.code=f.bridge->code;m.handlers=f.bridge->handlers;return m;};
    {auto m=bridge_copy();check(event_frame_bridge_pc(m)==8,"actual positive wrapper and handler validate");}
    for(size_t n=0;n<f.bridge->code.size();++n){auto m=bridge_copy();m.code.resize(n);check(event_frame_bridge_pc(m)<0,"truncated wrapper or live handler rejected");}
    for(auto replacement:std::vector<std::pair<int,int>>{{0,0x1f},{1,0x0a},{3,0x9c},{5,5},{6,0x00},{7,0x1f},{8,0xb6},{11,0x00}}) {
        auto m=bridge_copy();m.code[size_t(replacement.first)]=uint8_t(replacement.second);check(event_frame_bridge_pc(m)<0,"nonexact positive bridge rejected");
    }
    {auto m=bridge_copy();m.flags&=~8;check(event_frame_bridge_pc(m)<0,"instance bridge rejected");}
    {auto m=bridge_copy();m.flags|=32;check(event_frame_bridge_pc(m)<0,"synchronized bridge rejected");}
    {auto m=bridge_copy();m.native=true;check(event_frame_bridge_pc(m)<0,"native bridge rejected");}
    {auto m=bridge_copy();m.handlers.push_back({0,6,7,0});check(event_frame_bridge_pc(m)<0,"extra handler entering positive branch rejected");}
    // Cache resolution itself, including handler edges, is a production path.
    for(int variant=0;variant<5;++variant) {
        prepare(f,60,true);Method m=method(f.loop->class_id,"cacheProbe","()V",original);
        if(variant==1)m.flags|=8;
        if(variant==2)m.flags|=32;
        if(variant==3)m.handlers.push_back({4,59,59,0});
        if(variant==4)m.handlers.push_back({60,63,34,0});
        std::vector<Frame> stack(1);auto& fr=stack[0];fr.method=&m;fr.op_pc=4;fr.pc=7;fr.locals.resize(4);fr.locals[0]=Value::of_ref(f.controller);
        VMS_EXEC(g_active_stack)=&stack;VMS_EXEC(g_can_suspend)=true;
        speed_event_frame_clock(fr,game_current_ms(),m.quick[4]);
        check(current_context().event_frame_sleep.active==(variant==0),"production cache rejects static/locked/handler entry variants");
        current_context().event_frame_sleep.cancel();VMS_EXEC(g_active_stack)=nullptr;VMS_EXEC(g_can_suspend)=false;
    }
    std::cout<<"GUARD structural boundaries, fields, arithmetic, branches, handlers and bridge PASS\n";
}
static void timer_guard(Fixture& f) {
    prepare(f,60,true);auto& t=current_context();
    const int queue_class=ensure_class("java/util/TimerQueue"),task_class=ensure_class("java/util/TimerTask");
    const int queue=alloc_obj(queue_class),task=alloc_obj(task_class);
    for(const char* name:{"period","scheduledTime"}){
        auto* field=find_field(task_class,name,"J");check(field!=nullptr,"TimerTask fixture field exists");
        VMS_HEAP(g_heap)[task].fields[size_t(field->slot)]=Value::of_l(83);
    }
    Frame q;q.method=find_method(queue_class,"run","()V",false);q.locals={Value::of_ref(queue)};
    Frame r;r.method=find_method(task_class,"run","()V",false);r.locals={Value::of_ref(task)};
    check(q.method&&r.method,"real Timer callback frames resolve");t.frames.push_back(std::move(q));t.frames.push_back(std::move(r));
    for(int turn=0;turn<8&&t.state==ThreadState::Runnable;++turn)resume(f,turn==0);
    const auto log=sleep_record(t);
    check(t.state==ThreadState::Sleeping&&t.owned_draws==1,"Timer callback fixture executes a real drawing");
    check(t.wake_us==0&&log.effective_ms==log.requested_ms&&log.route==runtime_cause::Route::LongUnpaced,
          "drawn Timer callback still retains original long event sleep");
    std::cout<<"GUARD real Timer callback chain PASS\n";
}
static void prep_and_one_use(Fixture& f) {
    prepare(f,60,true);auto& t=current_context();const int period=speed_period_us();
    for(int n=0;n<4;++n){t.frame_prep.arm(f.canvas,period,f.bridge,8);t.frame_prep.woke(1000000);t.frame_prep.before_draw(f.canvas,period,1004000);}
    check(t.frame_prep.lead_us(period)==4500,"preparation lead fixture trained");
    resume(f,true);const auto anchor=t.event_frame_sleep.start_us;
    for(int n=0;n<8&&t.state==ThreadState::Runnable;++n)resume(f);
    check(t.wake_us==anchor+2*period,"event deadline does not subtract preparation lead twice");
    sleep_record(t);
    t.state=ThreadState::Runnable;VMS_EXEC(g_can_suspend)=true;VMS_EXEC(g_active_stack)=&t.frames;
    Frame call;call.method=find_method(ensure_class("java/lang/Thread"),"sleep","(J)V",false);call.locals={Value::of_l(166)};
    thread_native(call.method,call);VMS_EXEC(g_can_suspend)=false;VMS_EXEC(g_active_stack)=nullptr;
    const auto log=sleep_record(t);
    check(t.wake_us==0&&log.effective_ms==166&&log.route==runtime_cause::Route::LongUnpaced,"second sleep cannot reuse spent event evidence");
    std::cout<<"GUARD preparation lead and one-use certificate PASS\n";
}
int main(int argc,char** argv) {
    std::cout<<std::unitbuf;VMS_CL(g_classpath)={"romfs/classes"};VMS_DIAG(g_log_draw)=false;
    VMS_RS(g_screen_w)=VMS_RS(g_screen_h)=8;VMS_RS(g_fb).assign(8*8*3,0);
    const bool supplied=argc>1;
    if(supplied){std::vector<uint8_t> jar;std::string error;check(read_whole(argv[1],jar)&&unzip(jar,VMS_CL(g_jar_files),error),"optional JAR loads");}
    auto f=fixture(supplied);
    const auto loop_bytes=f.loop->code,bridge_bytes=f.bridge->code;
    for(int cap:{0,30,60})for(bool event:{false,true})runtime_case(f,cap,event);
    for(int cap:{30,60})for(int delayed_work_ms:{20,50,170})runtime_case(f,cap,true,delayed_work_ms);
    runtime_guards(f);direct_long_waits(f);structural_checks(f);timer_guard(f);prep_and_one_use(f);
    check(f.loop->code==loop_bytes&&f.bridge->code==bridge_bytes,"original loop and wrapper bytecode remain unchanged");
    VMS_EXEC(g_running_thread)=nullptr;speed_reset_learning();VMS_EXEC(g_threads).clear();
    std::cout<<"EventFrameSleep checks="<<checks<<" supplied="<<supplied<<" PASS\n";
}
