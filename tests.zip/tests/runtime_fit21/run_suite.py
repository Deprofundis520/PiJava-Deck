import ast,concurrent.futures,datetime,hashlib,json,os,pathlib,subprocess,sys,tempfile,time
import argparse
parser=argparse.ArgumentParser(description='Compile the tools/test.py suite in parallel, then run every original check serially.')
parser.add_argument('--source',type=pathlib.Path,default=pathlib.Path(__file__).resolve().parents[2])
parser.add_argument('--output',type=pathlib.Path,required=True)
parser.add_argument('--workers',type=int,choices=(1,2,3,4),default=3)
a=parser.parse_args()
root=a.source.resolve();out=a.output.resolve();out.mkdir(parents=True,exist_ok=True)
def source_identity():
    files=sorted(p for base in ['src','romfs/classes','tests'] for p in (root/base).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
    files += [root/'tools/test.py',root/'tools/build.py']
    return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
initial_identity=source_identity()
(out/'source-identity.json').write_text(json.dumps(initial_identity,indent=2)+'\n')
sys.path.insert(0,str(root/'tools'));import build
records=[]
def run(label,argv,timeout=300):
    start=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic()
    p=subprocess.run([str(x) for x in argv],cwd=root,capture_output=True,text=True,timeout=timeout)
    row=dict(label=label,argv=[str(x) for x in argv],cwd=str(root),utc=start,signedrc=p.returncode,seconds=time.monotonic()-t,stdout=p.stdout,stderr=p.stderr)
    (out/(label+'.json')).write_text(json.dumps(row,ensure_ascii=False,indent=2))
    print(label,'rc',p.returncode,flush=True);return row
def required(label,argv):
    r=run(label,argv);records.append(r)
    if r['signedrc']:raise SystemExit(label+' failed; inspect evidence')
build.BUILD.mkdir(exist_ok=True);classes=build.BUILD/'test-classes';classes.mkdir(exist_ok=True)
required('java-tests',build.java_compiler(None)+['-source','8','-target','8','-bootclasspath',root/'romfs/classes','-classpath',root/'romfs/classes','-encoding','UTF-8','-d',classes]+sorted((root/'tests/java').glob('*.java'))+[root/'tests/runtime_fit22/EventPaintChecks.java'])
puff=build.BUILD/'test-puff.o';required('puff',['gcc','-O2','-c',root/'src/puff.c','-o',puff])
required('runtime-compile',['g++','-O2','-std=c++17','-fno-exceptions','-I'+str(root/'src'),root/'tests/runtime_checks.cpp',puff,'-o',build.BUILD/'runtime_checks'])
tree=ast.parse((root/'tools/test.py').read_text());loops=[n for n in tree.body if isinstance(n,ast.For) and isinstance(n.iter,ast.List)]
java=ast.literal_eval(loops[0].iter);cpp=ast.literal_eval(loops[1].iter)
def compile_case(case):
    name,source,link=case
    row=run('compile-'+name,['g++','-O2','-std=c++17','-fno-exceptions','-I'+str(root/'tests/mock_switch'),root/'tests'/source]+([puff] if link else [])+(['-Wl,--wrap=statvfs'] if name=='Compat217Checks' else [])+['-o',build.BUILD/name])
    binary=build.BUILD/name
    if row['signedrc']==0 and not binary.stat().st_mode & 0o100:
        binary.chmod(binary.stat().st_mode|0o100);row['restored_owner_execute']=True
        (out/('compile-'+name+'.json')).write_text(json.dumps(row,ensure_ascii=False,indent=2))
    return row
with concurrent.futures.ThreadPoolExecutor(max_workers=a.workers) as pool:
    for r in pool.map(compile_case,cpp):records.append(r)
if any(x['signedrc'] for x in records):raise SystemExit('compile failed')
results=[]
for name in java:
    r=run('run-'+name,[build.BUILD/'runtime_checks',name],30);ok=r['signedrc']==0
    if name=='ThrowableChecks':ok &= all(x in r['stderr'] for x in ['JAVA java.lang.Exception: 标准输出中文标记','JAVA java.lang.Exception: 默认错误中文标记','ThrowableChecks.systemStreams'])
    results.append(dict(test=name,passed=bool(ok),record=r))
for name,source,link in cpp:
    with tempfile.TemporaryDirectory(prefix='fit21-check-') as temp:
        args=[classes] if name=='InstantStateChecks' else [classes,root/'romfs/classes',temp] if name=='Compat217Checks' else []
        r=run('run-'+name,[build.BUILD/name]+args,90 if name=='PollGateChecks' else 45)
        results.append(dict(test=name,passed=r['signedrc']==0,record=r))
unchanged=initial_identity==source_identity()
summary=dict(version=build.VERSION,compile_workers=a.workers,runtime_execution='serial_after_all_compiles',source_unchanged=unchanged,results=results)
(out/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
print('TOTAL',len(results),'PASS',sum(x['passed'] for x in results),flush=True)
sys.exit(0 if unchanged and all(x['passed'] for x in results) else 1)
