#!/usr/bin/env python3
"""Execute the real VM loop regression on host and optional AArch64/QEMU."""
import argparse
import json
import os
from pathlib import Path
import subprocess

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--output',type=Path,required=True)
parser.add_argument('--baseline-root',type=Path,help='Extracted original Fit20 tree; regression is expected to fail')
parser.add_argument('--cross-root',type=Path)
parser.add_argument('--sanitize',action='store_true')
args=parser.parse_args()
source=Path(__file__).resolve().parents[2]
runtime=(args.baseline_root or source).resolve()
out=args.output.resolve();out.mkdir(parents=True,exist_ok=True)
records=[]
def run(label,command,env=None):
    command=list(map(str,command))
    result=subprocess.run(command,cwd=source,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=300)
    (out/(label+'.log')).write_bytes(result.stdout)
    records.append(dict(label=label,command=command,returncode=result.returncode))
    (out/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
    print(label+' returncode='+str(result.returncode),flush=True)
    if result.returncode:
        print(result.stdout.decode(errors='replace')[-6000:]);raise SystemExit(result.returncode)
    if label.startswith('run-'):print(result.stdout.decode(errors='replace'),end='')
architectures=[('host',['gcc'],['g++'],[],None)]
if args.cross_root:
    cross=args.cross_root.resolve();env=os.environ.copy();env['LD_LIBRARY_PATH']=str(cross/'usr/lib/x86_64-linux-gnu')
    architectures.append(('a64',[cross/'usr/bin/aarch64-linux-gnu-gcc','--sysroot='+str(cross)],
        [cross/'usr/bin/aarch64-linux-gnu-g++','--sysroot='+str(cross)],
        [cross/'usr/bin/qemu-aarch64','-L',cross/'usr/aarch64-linux-gnu'],env))
for name,cc,cxx,prefix,env in architectures:
    flags=['-O1','-g0']
    if args.sanitize:flags+=['-fsanitize=undefined','-fno-sanitize-recover=all']
    puff=out/('puff-'+name+'.o');binary=out/('loop-reentry-'+name)
    run('build-puff-'+name,cc+flags+['-c',runtime/'src/puff.c','-o',puff],env)
    run('build-loop-'+name,cxx+flags+['-std=c++17','-fno-exceptions','-ffunction-sections','-fdata-sections',
        '-DJ2ME_TEST_VM="'+str(runtime/'src/j2mevm.cpp')+'"']+
        (['-DJ2ME_FIT21_BASELINE=1'] if args.baseline_root else [])+
        [source/'tests/runtime_fit21/loop_reentry_checks.cpp',puff,'-Wl,--gc-sections','-pthread','-ldl','-o',binary],env)
    run('run-'+name,prefix+[binary],env)
