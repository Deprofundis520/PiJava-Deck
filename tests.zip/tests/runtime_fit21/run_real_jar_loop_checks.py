#!/usr/bin/env python3
"""Run original external JAR pixel loops through the production VM.

No JAR/font assets are copied. Inputs and initialized frame state are constructed;
the generated diagnostic VM only stops before the final graphics/image API and
optionally counts exits. Host timings are observations, never Switch FPS gates.
"""
import argparse
import hashlib
import json
import resource
import statistics
import subprocess
import time
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def build(source, out):
    out.mkdir(parents=True, exist_ok=True)
    interpreter = (source / 'src/runtime/interpreter.inc').read_text()
    needle = '    while (!st->empty() && !(use_thread && VMS_EXEC(g_yield))) {'
    assert interpreter.count(needle) == 1, 'Unexpected interpreter dispatch boundary'
    interpreter = interpreter.replace(needle, needle + '\n        if (st->back().method==analysis_method && st->back().pc==analysis_stop_pc) {analysis_stopped=true;break;}\n        if(analysis_profile)++analysis_dispatch;')
    needle = '        uint8_t op = code[fr.pc++]; P61_OP(fr.method, fr.op_pc, op | 0x100u);'
    assert interpreter.count(needle) == 1, 'Unexpected slow-op boundary'
    interpreter = interpreter.replace(needle, needle + '\n        if(analysis_profile && fr.method==analysis_method)++analysis_slow[fr.op_pc];')
    for name in ['interpreter_fast.inc', 'flag_spin236.h']:
        interpreter = interpreter.replace('#include "../' + name + '"', '#include "' + name + '"')
    diagnostic_interpreter = out / 'interpreter-probe.inc'
    diagnostic_interpreter.write_text(interpreter)
    vm = (source / 'src/j2mevm.cpp').read_text()
    needle = '#include "runtime/interpreter.inc"'
    assert vm.count(needle) == 1, 'Unexpected interpreter include boundary'
    diagnostic_vm = out / 'j2mevm-probe.cpp'
    diagnostic_vm.write_text(vm.replace(needle, '#include "' + str(diagnostic_interpreter) + '"'))
    puff, binary = out / 'puff.o', out / 'real-jar-loop-checks'
    commands = [
        ['gcc', '-O2', '-c', str(source / 'src/puff.c'), '-o', str(puff)],
        ['g++', '-O2', '-g0', '-std=c++17', '-fno-exceptions', '-ffunction-sections', '-fdata-sections',
         '-I' + str(source / 'src'), '-DJ2ME_TEST_VM="' + str(diagnostic_vm) + '"',
         str(HERE / 'real_jar_loop_checks.cpp'), str(puff), '-Wl,--gc-sections', '-pthread', '-ldl', '-o', str(binary)],
    ]
    for i, command in enumerate(commands):
        result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=300)
        (out / ('build-' + str(i) + '.log')).write_bytes(result.stdout)
        if result.returncode:
            raise SystemExit(result.stdout.decode(errors='replace'))
    return binary, commands


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, default=ROOT)
    parser.add_argument('--baseline-source', type=Path)
    parser.add_argument('--output', type=Path, default=ROOT / 'build/fit21-real-jar-loops')
    parser.add_argument('--xianni-jar', type=Path, required=True)
    parser.add_argument('--shanhai-jar', type=Path, required=True)
    parser.add_argument('--repeats', type=int, default=5)
    parser.add_argument('--build-only', action='store_true')
    args = parser.parse_args()
    if not 0 <= args.repeats <= 20:
        parser.error('--repeats must be 0..20')
    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=True)
    jars = {'glyph': args.xianni_jar.resolve(), 'shop': args.shanhai_jar.resolve()}
    sources = {'candidate': args.source.resolve()}
    if args.baseline_source:
        sources = {'baseline': args.baseline_source.resolve(), **sources}
    identities = {str(path): sha(path) for path in jars.values()}
    for source in sources.values():
        for name in ['j2mevm.cpp', 'interpreter_fast.inc', 'runtime/interpreter.inc', 'runtime/native_jit.inc', 'jit_region.h', 'array_storage.h', 'primitive_buffer_pool.h']:
            path = source / 'src' / name
            identities[str(path)] = sha(path)
    binaries, build_commands = {}, {}
    for label, source in sources.items():
        print('Building', label, source, flush=True)
        binaries[label], build_commands[label] = build(source, out / label)
    (out / 'inputs-and-build.json').write_text(json.dumps(dict(sha256=identities, commands=build_commands, binaries={label: sha(path) for label, path in binaries.items()}), indent=2) + '\n')
    if args.build_only:
        return
    records = []
    for scenario, jar in jars.items():
        for index, mode in enumerate(['jit-pressure', 'jit', 'fast']):
            order = list(sources) if index % 2 == 0 else list(reversed(sources))
            for label in order:
                command = [str(binaries[label]), scenario, str(jar), str(sources[label] / 'romfs/classes'), mode, str(args.repeats)]
                before = resource.getrusage(resource.RUSAGE_CHILDREN)
                start = time.monotonic()
                result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=120)
                after = resource.getrusage(resource.RUSAGE_CHILDREN)
                log = out / label / (scenario + '-' + mode + '.log')
                log.write_text(result.stdout)
                if result.returncode or 'PASS original_bytecode=1' not in result.stdout:
                    raise SystemExit('Failed ' + str(log) + '\n' + result.stdout[-6000:])
                trials = []
                for line in result.stdout.splitlines():
                    if line.startswith('RUN '):
                        values = dict(word.split('=', 1) for word in line.split()[2:])
                        trials.append({key: float(value) if key == 'ms' else int(value) for key, value in values.items()})
                assert trials, 'Missing workload output'
                warm = [row['ms'] for row in trials if row['trial'] > 0]
                record = dict(version=label, scenario=scenario, mode=mode, command=command, log=str(log), rows=trials,
                              elapsed_ms=(time.monotonic() - start) * 1000,
                              process_cpu_ms=((after.ru_utime + after.ru_stime) - (before.ru_utime + before.ru_stime)) * 1000,
                              warm_median_ms=statistics.median(warm) if warm else None)
                records.append(record)
                (out / 'results.json').write_text(json.dumps(records, indent=2) + '\n')
                print(label, scenario, mode, 'cold_ms', trials[0]['ms'], 'warm_median_ms', record['warm_median_ms'], flush=True)
    for scenario in jars:
        rows = [row for record in records if record['scenario'] == scenario for row in record['rows']]
        assert len({row['checksum'] for row in rows}) == 1, scenario + ' pixel checksum mismatch'
        totals = {row['fast'] + row['slow'] + row['jitops'] + row['leafops'] for row in rows}
        assert len(totals) == 1, scenario + ' complete-tier opcode mismatch: ' + str(totals)
        print('PASS', scenario, 'exact pixel checksum and bytecodes', next(iter(totals)), flush=True)
    assert all(sha(Path(path)) == digest for path, digest in identities.items()), 'Inputs changed during the run'


if __name__ == '__main__':
    main()
