// Diagnostic harness: original game bytecode, constructed inputs, production VM.
// The generated VM adds only a stop-before-API hook and optional exit counters.
#include <cstdint>
#include <map>
#include <vector>
#include <string>
static const void* analysis_method = nullptr;
static int analysis_stop_pc = -1;
static bool analysis_stopped = false, analysis_profile = false;
static uint64_t analysis_dispatch = 0;
static std::map<int,uint64_t> analysis_exits, analysis_slow;
static void jitr_exit_hook(const void* m,int pc,int done,int budget,int32_t*,unsigned,const std::vector<int16_t>&,const std::vector<uint8_t>&) {
    (void)done;(void)budget;if(analysis_profile && m==analysis_method)++analysis_exits[pc];
}
#define J2ME_JITR_EXITS 1
#define main emulator_main
#include J2ME_TEST_VM
#undef main
static void check(bool x,const char* why){if(!x){std::cerr<<"FAIL "<<why<<'\n';std::exit(1);}}
static Method* method(int cls,const char* name,const char* desc){for(auto& m:VMS_CL(g_classes)[cls].methods)if(m.name==name&&m.desc==desc)return &m;check(false,"method exists");return nullptr;}
static void setstatic(int cls,const char* name,const char* desc,Value value){auto* f=find_field(cls,name,desc);check(f,"static field exists");VMS_CL(g_classes)[f->owner].statics[f->slot]=value;}
static void resolve_statics(int cls) {
    const size_t count=VMS_CL(g_classes)[cls].methods.size();
    for(size_t mi=0;mi<count;++mi){auto code=VMS_CL(g_classes)[cls].methods[mi].code;
        for(size_t pc=0;pc<code.size();){int op=code[pc],len=jvm_op_length(code,pc);check(len>0,"valid bytecode");
            if(op==178||op==179){std::string owner,name,desc;resolve_member(VMS_CL(g_classes)[cls],(code[pc+1]<<8)|code[pc+2],owner,name,desc);int cid=ensure_class(owner);auto* field=find_field(cid,name,desc);check(field,"field resolves");
                auto& m=VMS_CL(g_classes)[cls].methods[mi];m.quick.resize(m.code.size());m.quick[pc].kind=1;m.quick[pc].a=field->owner;m.quick[pc].b=field->slot;}
            pc+=len;}}
}
static void execute(Frame seed,int stop) {
    analysis_method=seed.method;analysis_stop_pc=stop;analysis_stopped=false;
    auto& ctx=current_context();ctx.frames.clear();ctx.frames.push_back(std::move(seed));
    for(unsigned slices=0;!analysis_stopped;++slices){check(slices<100000,"bounded progress");VMS_EXEC(g_yield)=false;VMS_EXEC(g_resume_request)=true;run(nullptr,{});check(!ctx.frames.empty(),"stop before return/API");
        if(!analysis_stopped)gc_safepoint(GcPoint::Threads);}
    check(ctx.frames.back().pc==stop,"exact stop PC");
}
static uint64_t pixels(int ref){uint64_t h=1469598103934665603ull;for(size_t i=0;i<VMS_HEAP(g_heap)[ref].elems.size();++i){h^=uint32_t(VMS_HEAP(g_heap)[ref].elems.get(i).i);h*=1099511628211ull;}return h;}
static std::vector<jit236::Executable> pressure(){
    const uint8_t bc[]={26,4,96,172};const std::string desc="(I)I";jit236::Spec spec{bc,sizeof bc,&desc,8,1,2,false,false,nullptr};jit236::Program p;check(jit236::verify(spec,p),"pressure leaf verifies");std::vector<jit236::Executable> out(4);
    for(auto& e:out){auto id=jit236::next_install_id();auto b=jit236::emit_host(p,id);check(!b.empty(),"pressure emission");b.resize(262144,0);check(e.install(b,id),"ordinary pressure install");}return out;
}
static void print_profile(){std::cout<<"EXITS";for(auto p:analysis_exits)std::cout<<' '<<p.first<<':'<<p.second;std::cout<<"\nSLOW";for(auto p:analysis_slow)std::cout<<' '<<p.first<<':'<<p.second;std::cout<<'\n';}
int main(int argc,char** argv){
    check(argc>=5,"scenario jar classes mode [repeats]");std::string scenario=argv[1];bool jit=std::string(argv[4])!="fast";unsigned repeats=argc>5?std::atoi(argv[5]):5;
    VMS_DIAG(g_log_draw)=false;VMS_EXEC(g_slice_ms)=4;VMS_CL(g_classpath).push_back(argv[3]);std::vector<uint8_t> bytes;std::string error;check(read_whole(argv[2],bytes)&&unzip(bytes,VMS_CL(g_jar_files),error),"JAR load");
    int cls=ensure_class(scenario=="glyph"?"v":"al");ensure_class("java/lang/String");resolve_statics(cls);for(auto& c:VMS_CL(g_classes))c.init_state=2;
    VMS_NATIVE(g_native_jit).configure(jit);check(!jit||VMS_NATIVE(g_native_jit).available,"host JIT available");std::vector<jit236::Executable> fillers;if(std::string(argv[4])=="jit-pressure")fillers=pressure();
    // Resumable production execution belongs to a scheduler worker, whose
    // frame stack remains a GC root after RunScope returns at a slice boundary.
    VMS_EXEC(g_threads).emplace_back();auto& worker=VMS_EXEC(g_threads).back();worker.state=ThreadState::Runnable;worker.begun=true;VMS_EXEC(g_running_thread)=&worker;
    if(scenario=="glyph"){
        const auto* font=jar_lookup("/bin/font.bin");check(font&&font->size()>3,"original bitmap font asset");int height=(*font)[0],count=((*font)[1]<<8)|(*font)[2],base=3+2*count;check(base<int(font->size()),"font structure");
        int codes=alloc_array("[S",count),bits=alloc_array("[B",font->size()-base);for(int i=0;i<count;++i)VMS_HEAP(g_heap)[codes].elems.set(i,Value::of_i(int16_t(((*font)[3+2*i]<<8)|(*font)[4+2*i])));for(size_t i=base;i<font->size();++i)VMS_HEAP(g_heap)[bits].elems.set(i-base,Value::of_i(int8_t((*font)[i])));
        setstatic(cls,"a","B",Value::of_i(height));setstatic(cls,"b","B",Value::of_i(((height-1)>>3)+1));setstatic(cls,"d","[S",Value::of_ref(codes));setstatic(cls,"e","[B",Value::of_ref(bits));
        std::vector<int> strings;for(int i=0;i<117;++i){std::string s;int cp=uint16_t(VMS_HEAP(g_heap)[codes].elems.get(size_t(count/2+i)%count).i);utf8_append(s,cp);strings.push_back(make_string(s));}
        for(int s:strings)VMS_CL(g_classes)[cls].statics.push_back(Value::of_ref(s)); // fixture roots outside safepoint scopes
        Method* m=method(cls,"a","(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;III)V");
        for(unsigned trial=0;trial<=repeats;++trial){uint64_t checksum=0;const auto fast0=VMS_EXEC(g_fast_ops),slow0=VMS_EXEC(g_slow_ops),jit0=g_jit_region_stats.ops,leaf0=VMS_NATIVE(g_native_jit).stats.ops-jit0;const auto begin=std::chrono::steady_clock::now();
            for(unsigned draw=0;draw<20;++draw){for(int str:strings){Frame f;f.method=m;f.locals.resize(m->max_locals);f.entry_checked=true;f.locals[1]=Value::of_ref(str);f.locals[4]=Value::of_i(0x7391ab);execute(std::move(f),211);auto* field=find_field(cls,"g","[I");int pix=VMS_CL(g_classes)[field->owner].statics[field->slot].ref;checksum=(checksum*1099511628211ull)^pixels(pix);}
                current_context().frames.clear();gc_safepoint(GcPoint::Paint);}
            double ms=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-begin).count();std::cout<<"RUN glyph trial="<<trial<<" jit="<<jit<<" draws=20 glyphs=2340 height="<<height<<" checksum="<<checksum<<" ms="<<ms<<" fast="<<(VMS_EXEC(g_fast_ops)-fast0)<<" slow="<<(VMS_EXEC(g_slow_ops)-slow0)<<" jitops="<<(g_jit_region_stats.ops-jit0)<<" leafops="<<(VMS_NATIVE(g_native_jit).stats.ops-g_jit_region_stats.ops-leaf0)<<" regions="<<g_jit_region_stats.resident<<" bytes="<<g_jit_region_stats.bytes<<" deferred="<<g_jit_region_stats.overlap_deferred<<" hits="<<g_jit_region_stats.overlap_hits<<'\n';}
        analysis_profile=true;Frame f;f.method=m;f.locals.resize(m->max_locals);f.entry_checked=true;f.locals[1]=Value::of_ref(strings[0]);f.locals[4]=Value::of_i(0x7391ab);execute(std::move(f),211);print_profile();
    }else{
        check(scenario=="shop","known scenario");Method* m=method(cls,"a","(Ljavax/microedition/lcdui/Graphics;II)V");const unsigned width=240,height=320,count=width*height;int pix=alloc_array("[I",count);VMS_CL(g_classes)[cls].statics.push_back(Value::of_ref(pix));
        auto seed=[&](){Frame f;f.method=m;f.pc=213;f.entry_checked=true;f.locals.resize(m->max_locals);f.locals[2]=f.locals[5]=Value::of_ref(pix);f.locals[3]=f.locals[6]=Value::of_i(width);f.locals[4]=f.locals[7]=Value::of_i(height);return f;};
        for(unsigned trial=0;trial<=repeats;++trial){for(unsigned i=0;i<count;++i)VMS_HEAP(g_heap)[pix].elems.set(i,Value::of_i(int32_t(0xff000000u|((i*0x3591u)&0xffffff))));const auto fast0=VMS_EXEC(g_fast_ops),slow0=VMS_EXEC(g_slow_ops),jit0=g_jit_region_stats.ops,leaf0=VMS_NATIVE(g_native_jit).stats.ops-jit0,gc0=VMS_HEAP(g_gc_cycles);const auto begin=std::chrono::steady_clock::now();execute(seed(),845);double ms=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-begin).count();std::cout<<"RUN shop trial="<<trial<<" jit="<<jit<<" pixels="<<count<<" checksum="<<pixels(pix)<<" ms="<<ms<<" fast="<<(VMS_EXEC(g_fast_ops)-fast0)<<" slow="<<(VMS_EXEC(g_slow_ops)-slow0)<<" jitops="<<(g_jit_region_stats.ops-jit0)<<" gc="<<(VMS_HEAP(g_gc_cycles)-gc0)<<" leafops="<<(VMS_NATIVE(g_native_jit).stats.ops-g_jit_region_stats.ops-leaf0)<<" regions="<<g_jit_region_stats.resident<<" bytes="<<g_jit_region_stats.bytes<<" deferred="<<g_jit_region_stats.overlap_deferred<<" hits="<<g_jit_region_stats.overlap_hits<<'\n';}
        analysis_profile=true;for(unsigned i=0;i<count;++i)VMS_HEAP(g_heap)[pix].elems.set(i,Value::of_i(-1));execute(seed(),845);print_profile();
    }
    check(g_gc_sp.violations==0,"legal safepoints");current_context().frames.clear();jit_region_reset();VMS_NATIVE(g_native_jit).clear();fillers.clear();std::cout<<"PASS original_bytecode=1 constructed_inputs=1 natural_scene=0 desktop_not_switch=1\n";
}
