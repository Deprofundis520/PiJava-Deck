#!/usr/bin/env python3
"""Build and run real Java event/worker/repaint scheduling regressions.

Use --source to run the same assertions against an immutable baseline. A
baseline failure is reported as a failure, with its complete captured log.
Compilation and test timeouts bound the test process, never the VM behavior.
"""
import argparse
import hashlib
import json
import subprocess
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    here = Path(__file__).resolve().parent
    parser.add_argument("--source", type=Path, default=here.parents[1])
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--mode", type=int)
    parser.add_argument("--build-only", action="store_true")
    args = parser.parse_args()
    source, output = args.source.resolve(), args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    classes = output / "classes"
    classes.mkdir(exist_ok=True)
    api = source / "romfs/classes"
    binary = output / "event-paint-checks"
    puff = output / "puff.o"
    records = []

    def run(label, command, timeout):
        command = list(map(str, command))
        try:
            result = subprocess.run(command, cwd=output, stdout=subprocess.PIPE,
                                    stderr=subprocess.STDOUT, timeout=timeout)
            content, code = result.stdout, result.returncode
        except subprocess.TimeoutExpired as error:
            content, code = error.stdout or b"", 124
        (output / (label + ".log")).write_bytes(content)
        records.append({"label": label, "command": command,
                        "returncode": code, "external_timeout_seconds": timeout})
        (output / "commands.json").write_text(json.dumps(records, indent=2) + "\n")
        print(label, "returncode=" + str(code), flush=True)
        if code:
            print(content.decode(errors="replace")[-8000:])
            raise SystemExit(code)
        if label == "run":
            for line in content.decode(errors="replace").splitlines():
                if line.startswith(("PASS", "FAIL")):
                    print(line)

    identities = {}
    for path in (source / "src/j2mevm.cpp", source / "src/threading.h",
                 source / "src/exec_context.h", source / "src/runtime/interpreter.inc",
                 source / "src/continuation.inc", source / "src/instant_state.inc",
                 here / "EventPaintChecks.java", here / "event_paint_checks.cpp"):
        identities[str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
    (output / "inputs.json").write_text(json.dumps(identities, indent=2) + "\n")
    run("java", ["java", "-m", "jdk.compiler/com.sun.tools.javac.Main", "-source", "8",
                 "-target", "8", "-bootclasspath", api, "-classpath", api, "-d", classes,
                 here / "EventPaintChecks.java"], 60)
    run("puff", ["gcc", "-O1", "-c", source / "src/puff.c", "-o", puff], 60)
    run("build", ["g++", "-O1", "-g0", "-std=c++17", "-fno-exceptions",
                  "-ffunction-sections", "-fdata-sections",
                  '-DJ2ME_TEST_VM="' + str(source / "src/j2mevm.cpp") + '"',
                  '-DJ2ME_TEST_STATE="' + str(source / "src/instant_state.inc") + '"',
                  here / "event_paint_checks.cpp", puff, "-Wl,--gc-sections",
                  "-pthread", "-ldl", "-o", binary], 300)
    if not args.build_only:
        command = [binary, classes, api]
        if args.mode is not None:
            command.append(str(args.mode))
        run("run", command, 30)


if __name__ == "__main__":
    main()
