#include "../../src/runtime/library_index.h"
#include <iostream>
#include <string>
#include <vector>
using namespace j2me_runtime;
static unsigned checks=0;
static void check(bool yes,const char* why){++checks;if(!yes){std::cerr<<"FAIL "<<why<<'\n';std::exit(1);}}
int main(){
    LibraryIndex index;uint64_t version=1,epoch=0;size_t last=SIZE_MAX;
    std::vector<std::string> text={"alpha","beta","alpha","",std::string("\0embedded",9)};
    // Deliberately equal hashes for distinct texts: content equality must decide
    // both insertion and lookup, including the first duplicate dense position.
    auto key=[](std::string_view s){return ScalarKey{17,ScalarKey::string_kind,s};};
    auto read=[&](size_t i,ScalarKey& k){if(i>=text.size())return false;k=key(text[i]);return true;};
    auto find=[&](std::string_view s){return index.find(7,text.size(),version,last,epoch,key(s),read);};
    check(find("alpha")==0,"first equal duplicate wins with hash collision");
    check(find("beta")==1&&find("")==3&&find("missing")==-1,"colliding unequal values stay distinct");
    check(find(std::string_view("\0embedded",9))==4,"embedded NUL participates in exact equality");
    const auto hits=index.stats().hits;check(find("alpha")==0&&index.stats().hits>hits,"fresh String index hit");
    text.push_back("gamma");++version;last=text.size()-1;check(find("gamma")==5,"append with collisions");
    text.erase(text.begin());++version;last=SIZE_MAX;check(find("alpha")==1&&find("beta")==0,"remove rebuilds dense positions");
    text[1]="delta";++epoch;check(find("alpha")==-1&&find("delta")==1,"mutated text epoch rebuilds hashes");
    auto custom=[&](size_t i,ScalarKey& k){if(i==1)return false;return read(i,k);};
    ++version;check(index.find(7,text.size(),version,SIZE_MAX,epoch,key("beta"),custom)==LibraryIndex::fallback,"a custom stored key rejects whole table");
    check(index.find(7,text.size(),version,SIZE_MAX,epoch,key("beta"),custom)==LibraryIndex::fallback,"custom rejection retained only for same version");
    ++version;check(find("beta")==0,"valid revision restores eligibility");
    // Slots stay sixteen bytes. Even a table of maximum-length String keys
    // retains positions and hashes only, never copies the key payloads.
    std::vector<std::string> many(16384);
    for(size_t i=0;i<many.size();++i)many[i]=std::to_string(i)+std::string(1000,'x');
    auto manykey=[&](size_t i){return ScalarKey{uint64_t(i),ScalarKey::string_kind,many[i]};};
    auto manyread=[&](size_t i,ScalarKey& k){if(i>=many.size())return false;k=manykey(i);return true;};
    for(int id=10;id<100;++id){check(index.find(id,many.size(),1,SIZE_MAX,0,manykey(111),manyread)==111,"bounded table eviction keeps String results");check(index.retained_bytes()<=index.byte_budget(),"slot allocation budget enforced");}
    check(index.retained_bytes()==index.byte_budget(),"maximum retained slots consume the existing two MiB budget");
    index.sweep([](int){return false;});check(index.retained_bytes()==0,"weak sweep releases all String index slots");
    check(index.find(7,LibraryIndex::max_keys+1,1,SIZE_MAX,0,key("alpha"),read)==LibraryIndex::fallback,"oversized table falls back");
    check(index.find(7,0,1,SIZE_MAX,0,key("alpha"),read)==-1,"empty table is absent");
    index.clear();check(index.retained_bytes()==0,"reset leaves no retained key payload");
    std::cout<<"PASS StringIndexCore checks="<<checks<<" collisions=forced bounded_slots=1\n";
}
