#!/usr/bin/env python3
"""Build/run the actual VM String-key library regression with optional baseline."""
import argparse,json,subprocess
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--source',type=Path);p.add_argument('--sanitize',action='store_true');p.add_argument('--build-only',action='store_true');a=p.parse_args()
here=Path(__file__).resolve().parent;root=here.parents[1];src=(a.source or root).resolve();out=a.output.resolve();out.mkdir(parents=True,exist_ok=True);classes=out/'classes';classes.mkdir(exist_ok=True)
flags=['-O1' if a.sanitize else '-O0','-g0']+(['-fsanitize=undefined','-fno-sanitize-recover=all'] if a.sanitize else [])
commands=[['java','-m','jdk.compiler/com.sun.tools.javac.Main','-source','8','-target','8','-bootclasspath',str(src/'romfs/classes'),'-classpath',str(src/'romfs/classes'),'-d',str(classes),str(root/'tests/java/StringIndexChecks.java')],['gcc',*flags,'-c',str(src/'src/puff.c'),'-o',str(out/'puff.o')],['g++',*flags,'-std=c++17','-fno-exceptions','-ffunction-sections','-fdata-sections','-DJ2ME_TEST_VM="'+str(src/'src/j2mevm.cpp')+'"','-DJ2ME_TEST_STATE="'+str(src/'src/instant_state.inc')+'"',str(here/'string_index_vm_checks.cpp'),str(out/'puff.o'),'-Wl,--gc-sections','-pthread','-ldl','-o',str(out/'string-index-vm')]]
if not a.build_only:commands += [[str(out/'string-index-vm'),str(classes),str(src/'romfs/classes'),mode] for mode in ['fast','jit']]
records=[]
for i,cmd in enumerate(commands):
 r=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=300);(out/f'step-{i}.log').write_bytes(r.stdout);records.append({'command':cmd,'returncode':r.returncode});(out/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print('step',i,'returncode',r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.stdout.decode(errors='replace')[-6000:])
 if i>=3:print(r.stdout.decode(errors='replace'),end='')
