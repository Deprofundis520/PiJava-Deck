import java.util.Vector;
import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Graphics;

/** Verifies the event callback / worker paint boundary with real Java threads. */
public final class EventPaintChecks extends Canvas {
    static EventPaintChecks self;
    static Canvas hidden;
    static final class HiddenSurface extends Canvas {
        protected void paint(Graphics graphics) {
            if (mode == 15 && armed != 0) {
                Display.getDisplay(null).setCurrent(self); self.repaint();
                new Thread(new Producer()).start(); sleep();
                require(returned == 0, "visible pending service returned during unrelated paint");
                require(producerDone == 1, "unrelated paint starved producer"); otherPaints++; return;
            }
            if (mode != 13 || armed == 0 || otherPaints != 0) return;
            try { waitingWorker.join(100); }
            catch (InterruptedException exception) { throw new RuntimeException("unexpected interrupt"); }
            require(returned == 1, "obsolete receiver blocked inside unrelated paint"); otherPaints++;
        }
    }
    public static final class StateMidlet extends javax.microedition.midlet.MIDlet {
        protected void startApp() {}
        protected void pauseApp() {}
        protected void destroyApp(boolean unconditional) {}
    }
    public static javax.microedition.midlet.MIDlet stateMidlet() { return new StateMidlet(); }
    static Vector shared;
    static int mode, armed, keyActive, keyDone, paints, started, returned;
    static int producerDone, expectedToken, seenToken, exceptions, ownReturned, paintActive, otherPaints;
    static Thread eventThread, painterThread, waitingWorker;
    static volatile boolean busy;
    static void require(boolean value, String why) {
        if (!value) throw new RuntimeException(why);
    }
    protected void paint(Graphics graphics) {
        if (armed == 0 || ownReturned != 0 || (mode != 1 && mode != 3 && returned != 0)) return;
        if (mode == 3) while (busy) {}
        if (mode == 0 || mode == 2 || mode == 4 || mode == 5 || mode == 15) {
            require(keyActive == 0 && keyDone == 1, "worker paint reentered active event");
            require(Thread.currentThread() == painterThread, "worker paint lost Java thread identity");
        } else if (mode == 1 || mode == 3 || mode == 9 || mode == 11 || mode == 14) {
            require(keyActive == 1, "same-event service was deferred");
            require(Thread.currentThread() == eventThread, "same-event service changed Java identity");
        } else if (mode == 12) {
            require(keyActive == 0 && keyDone == 1, "host paint reentered event");
            require(Thread.currentThread() == eventThread, "host paint changed Java identity");
        }
        if (mode != 3 && mode != 6 && mode != 7 && mode != 8 && mode != 10)
            require(shared.size() == 1, "shared collection content changed");
        paints++; seenToken = expectedToken;
        graphics.setColor(expectedToken); graphics.fillRect(0, 0, 3, 3);
        if (mode == 11 || mode == 12 || mode == 14) {
            paintActive = 1;
            if (mode == 14) Display.getDisplay(null).setCurrent(hidden);
            new Thread(new Producer()).start(); sleep();
            require(returned == 0, "pending service returned while paint was active");
            require(producerDone == 1, "paint wait starved ordinary producer");
            paintActive = 0;
        }
    }
    static final class Painter implements Runnable {
        public void run() {
            painterThread = Thread.currentThread(); started++;
            final Canvas receiver = mode == 6 ? hidden : self;
            final int token = expectedToken;
            if (mode != 7) receiver.repaint();
            receiver.serviceRepaints();
            require(receiver == (mode == 6 ? hidden : self) && token == expectedToken, "retry lost receiver or locals");
            if (mode != 6 && mode != 7 && mode != 10 && mode != 13) require(paints >= 1 && seenToken == expectedToken,
                    "service returned before paint completion");
            require(paintActive == 0, "service returned inside active paint");
            require(Thread.currentThread() == painterThread, "retry changed worker identity");
            returned++;
        }
    }
    static final class Producer implements Runnable {
        public void run() { producerDone++; busy = false; }
    }
    static void sleep() {
        try { Thread.sleep(20); }
        catch (InterruptedException exception) { throw new RuntimeException("unexpected interrupt"); }
    }
    static void body() {
        eventThread = Thread.currentThread(); keyActive = 1;
        if (mode == 1 || mode == 3) {
            if (mode == 3) new Thread(new Producer()).start();
            synchronized (shared) {
                self.repaint(); self.serviceRepaints();
                require(paints == 1 && seenToken == expectedToken, "own synchronous paint incomplete");
                require(Thread.holdsLock(shared), "own service lost reentrant monitor");
                ownReturned++;
            }
        } else if (mode == 9 || mode == 10 || mode == 11 || mode == 13 || mode == 14) {
            Thread worker = new Thread(new Painter()); worker.start(); sleep();
            waitingWorker = worker;
            require(started == 1 && returned == 0 && paints == 0, "worker was not deferred");
            if (mode != 10 && mode != 13) {
                self.serviceRepaints();
                require(paints == 1 && seenToken == expectedToken, "event did not consume pending paint");
            } else {
                Display.getDisplay(null).setCurrent(hidden);
                if (mode == 13) hidden.serviceRepaints();
            }
            try { worker.join(100); } catch (InterruptedException exception) { throw new RuntimeException("unexpected interrupt"); }
            require(returned == 1, "obsolete paint wait blocked worker join");
            ownReturned++;
        } else if (mode == 6 || mode == 7 || mode == 8) {
            new Thread(new Painter()).start(); sleep();
            require(returned == 1, mode == 7 ? "empty request blocked" : "non-event worker failed");
        } else {
            try {
                synchronized (shared) {
                    synchronized (shared) {
                        new Thread(new Painter()).start();
                        if (mode == 2) new Thread(new Producer()).start();
                        sleep();
                        require(started == 1 && returned == 0 && paints == 0,
                                "worker paint crossed event boundary");
                        require(Thread.holdsLock(shared), "event monitor lost while waiting");
                        if (mode == 2) require(producerDone == 1, "ordinary producer starved");
                        if (mode == 5) throw new RuntimeException("fixture release");
                    }
                    require(Thread.holdsLock(shared), "nested monitor depth lost");
                }
            } catch (RuntimeException exception) {
                if (mode != 5 || !"fixture release".equals(exception.getMessage())) throw exception;
                exceptions++;
            }
        }
        if (mode == 15) Display.getDisplay(null).setCurrent(hidden);
        keyActive = 0; keyDone++;
    }
    protected void keyPressed(int code) {
        require(code == 53, "key operand lost"); body();
    }
    static final class SerialEvent implements Runnable {
        public void run() { body(); }
    }
    public static int setup(int which) {
        mode = which; armed = 0; self = new EventPaintChecks(); hidden = new HiddenSurface();
        shared = new Vector(); shared.addElement(new Object());
        Display.getDisplay(null).setCurrent(self); return 1;
    }
    public static int arm(int token) {
        if (Display.getDisplay(null).getCurrent() != self) Display.getDisplay(null).setCurrent(self);
        armed = 1; expectedToken = token; busy = true;
        keyActive = keyDone = paints = started = returned = producerDone = seenToken = exceptions = ownReturned = paintActive = otherPaints = 0;
        eventThread = painterThread = waitingWorker = null;
        return 1;
    }
    public static int enqueue(int ignored) {
        Display.getDisplay(null).callSerially(new SerialEvent()); return 1;
    }
    public static int nonEvent(int ignored) {body(); return 1;}
    public static int verify(int ignored) {
        require(keyDone == 1 && keyActive == 0, "event did not finish");
        require(!Thread.holdsLock(shared), "event monitor leaked");
        if (mode == 1 || mode == 3) require(paints == 1 && returned == 0, "same-event completion count");
        else if (mode == 6 || mode == 7 || mode == 10 || mode == 13) require(started == 1 && returned == 1 && paints == 0, "unneeded service behavior");
        else require(started == 1 && returned == 1 && paints == 1, "deferred service completion count");
        if (mode == 2 || mode == 3 || mode == 11 || mode == 12 || mode == 14 || mode == 15) require(producerDone == 1, "producer did not complete");
        if (mode == 13 || mode == 15) require(otherPaints == 1, "unrelated paint did not complete");
        if (mode == 5) require(exceptions == 1, "exception lock cleanup path did not run");
        return 1;
    }
}
