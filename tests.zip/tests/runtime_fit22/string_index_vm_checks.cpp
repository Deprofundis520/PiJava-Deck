#define main emulator_main
#ifndef J2ME_TEST_VM
#define J2ME_TEST_VM "../../src/j2mevm.cpp"
#endif
#include J2ME_TEST_VM
#undef main
#include "../../src/host_menu.h"
#include "../../src/host_speed.h"
static host_menu::Settings g_menu_settings;
static std::string instant_state_path(const std::string&) {return "unused-string-index-state";}
#ifndef J2ME_TEST_STATE
#define J2ME_TEST_STATE "../../src/instant_state.inc"
#endif
#include J2ME_TEST_STATE
static unsigned checks=0;
static void check(bool yes,const char* why){++checks;if(!yes){std::cerr<<"FAIL "<<why<<'\n';std::exit(1);}}
static Value invoke(const char* name,const char* desc="()V"){
    auto* m=find_method(ensure_class("StringIndexChecks"),name,desc,false);check(m,"fixture method exists");auto v=run(m,{});check(!VMS_EXEC(g_thrown),"fixture returns without exception");return v;
}
static Value field(const char* name,const char* desc){auto* f=find_field(ensure_class("StringIndexChecks"),name,desc);check(f,"fixture field exists");return VMS_CL(g_classes)[f->owner].statics[f->slot];}
static bool native_find(int table,int key,int expected){
    Method* m=find_method(ensure_class("java/util/Hashtable"),"find","(Ljava/lang/Object;)I",false);
    Value args[2]={Value::of_ref(table),Value::of_ref(key)},out;bool accepted=library_intrinsic_dispatch(LibFind,m,args,out);
    if(accepted)check(out.i==expected,"native position matches dense reference");return accepted;
}
static int table_keys(int table){auto* f=find_field(VMS_HEAP(g_heap)[table].cls,"keys","[Ljava/lang/Object;");check(f,"keys field");return VMS_HEAP(g_heap)[table].fields[f->slot].ref;}
int main(int argc,char** argv){
    log_open((std::string(argc>1?argv[1]:"build/test-classes")+"/string-index-runtime.log").c_str(),true);
    VMS_CL(g_classpath)={argc>1?argv[1]:"build/test-classes",argc>2?argv[2]:"romfs/classes"};VMS_DIAG(g_log_draw)=false;
    VMS_NATIVE(g_native_jit).configure(argc>3&&std::string(argv[3])=="jit");
    invoke("setup");int table=field("saved","Ljava/util/Hashtable;").ref,key=field("savedKey","Ljava/lang/String;").ref;
    check(native_find(table,make_string("alpha"),0),"equal distinct String keys use the reviewed index"); // Fit21 RED: String admission absent.
    const auto first=VMS_NATIVE(g_library_indexes).stats();check(native_find(table,make_string("alpha"),0),"repeat String lookup accepted");
    check(VMS_NATIVE(g_library_indexes).stats().hits>first.hits,"repeat String lookup reuses derived index");
    check(native_find(table,make_string("absent"),-1),"String miss remains a miss");
    check(!native_find(table,0,-1),"null lookup falls back to original exception");
    check(!native_find(table,make_string(std::string(1025,'x')),-1),"unbounded query String follows Java path");
    int original_second=VMS_HEAP(g_heap)[table_keys(table)].elems.get(1).ref;
    VMS_HEAP(g_heap)[table_keys(table)].elems.set(1,Value::of_ref(make_string(std::string(1025,'x'))));
    check(!native_find(table,make_string("alpha"),0),"long stored String rejects even a short lookup");
    VMS_HEAP(g_heap)[table_keys(table)].elems.set(1,Value::of_ref(original_second));
    check(invoke("run","()I").i>14000,"randomized original Java table semantics and callbacks");
    check(VMS_NATIVE(g_library_indexes).retained_bytes()<=VMS_NATIVE(g_library_indexes).byte_budget(),"native cache stays within budget");
    // Private/native reinitialization is permitted by this VM's entry machinery;
    // invalidate derived String hashes even for that unusual existing behavior.
    invoke("setup");table=field("saved","Ljava/util/Hashtable;").ref;key=field("savedKey","Ljava/lang/String;").ref;
    check(native_find(table,make_string("alpha"),0),"mutable-path initial cache");
    int chars=alloc_array("[C",4);for(int i=0;i<4;++i)VMS_HEAP(g_heap)[chars].elems.set(i,Value::of_i("beta"[i]));
    int str=ensure_class("java/lang/String");auto* init=find_method(str,"initChars","([CII)V",false);check(init,"native initializer exists");
    auto epoch=VMS_NATIVE(g_index_key_epoch);run(init,{Value::of_ref(key),Value::of_ref(chars),Value::of_i(0),Value::of_i(4)});
    check(!VMS_EXEC(g_thrown)&&VMS_NATIVE(g_index_key_epoch)>epoch,"String native initializer invalidates existing index");
    check(native_find(table,make_string("alpha"),-1)&&native_find(table,make_string("beta"),0),"old and new values after String reinitialization");
    int bytes=alloc_array("[B",5);for(int i=0;i<5;++i)VMS_HEAP(g_heap)[bytes].elems.set(i,Value::of_i("gamma"[i]));
    auto* charset_init=find_method(str,"initBytesCharset","([BIILjava/lang/String;)V",false);check(charset_init,"charset initializer exists");
    epoch=VMS_NATIVE(g_index_key_epoch);run(charset_init,{Value::of_ref(key),Value::of_ref(bytes),Value::of_i(0),Value::of_i(5),Value::of_ref(make_string("UTF-8"))});
    check(!VMS_EXEC(g_thrown)&&VMS_NATIVE(g_index_key_epoch)>epoch,"String charset initializer invalidates index");
    check(native_find(table,make_string("beta"),-1)&&native_find(table,make_string("gamma"),0),"charset mutation reflected");
    auto* byte_init=find_method(str,"initBytes","([BII)V",false);check(byte_init,"byte initializer exists");
    VMS_HEAP(g_heap)[bytes].elems.set(0,Value::of_i('d'));epoch=VMS_NATIVE(g_index_key_epoch);
    run(byte_init,{Value::of_ref(key),Value::of_ref(bytes),Value::of_i(0),Value::of_i(5)});
    check(!VMS_EXEC(g_thrown)&&VMS_NATIVE(g_index_key_epoch)>epoch,"String byte initializer invalidates index");
    check(native_find(table,make_string("gamma"),-1)&&native_find(table,make_string("damma"),0),"byte mutation reflected");
    // Exact class-byte admission: modified String metadata cannot authorize any
    // native lookup, and restoring the reviewed class restores eligibility.
    std::vector<uint8_t> class_bytes;check(read_whole(std::string(argc>2?argv[2]:"romfs/classes")+"/java/lang/String.class",class_bytes),"read reviewed class");
    const auto trusted=VMS_CL(g_classes)[str].trusted_library;VMS_CL(g_classes)[str].trusted_library=0;class_bytes.back()^=1;bind_library_layout(str,class_bytes);
    check(!VMS_CL(g_classes)[str].trusted_library&&!native_find(table,make_string("damma"),0),"modified String class declines index");
    class_bytes.back()^=1;bind_library_layout(str,class_bytes);check(VMS_CL(g_classes)[str].trusted_library==trusted,"exact class rebind");
    // The deterministic meter must not skip a native String.equals that it
    // cannot charge exactly; caller remains on ordinary bytecodes.
    Method* find=find_method(ensure_class("java/util/Hashtable"),"find","(Ljava/lang/Object;)I",false);Value args[2]={Value::of_ref(table),Value::of_ref(make_string("damma"))},out;unsigned cost=0;
    check(!r4_shortcut_cost(find,args,2,4096,cost,out),"String comparison keeps deterministic uncertified fallback");
    invoke("setup");table=field("saved","Ljava/util/Hashtable;").ref;key=field("savedKey","Ljava/lang/String;").ref;
    check(native_find(table,make_string("alpha"),0),"index before GC");gc_collect("String index live fixture");
    check(gc_slot_live(key)&&native_find(table,make_string("alpha"),0),"live String table survives GC");
    int canvas=ensure_class("StringIndexCanvas");VMS_RS(g_current)=alloc_obj(canvas);run(find_method(canvas,"<init>","()V",false),{Value::of_ref(VMS_RS(g_current))});
    VMS_EXEC(g_midlet)=alloc_obj(ensure_class("java/lang/Object"));VMS_EXEC(g_midlet_state)=MidletState::Active;VMS_RS(g_fb).assign(240*320*3,0);
    SavState state,decoded;std::string encoded;check(capture_state(state,"string-index-fixture.jar")&&encode_state(state,encoded)&&encoded.substr(0,4)=="J2S5","unchanged J2S5 encode");
    check(decode_state(encoded,decoded)&&apply_state(decoded),"J2S5 restore accepted");
    check(VMS_NATIVE(g_library_indexes).retained_bytes()==0,"restore clears all derived index slots");
    check(invoke("verify","()I").i==1,"restored String table bytecode results");
    table=field("saved","Ljava/util/Hashtable;").ref;int array=table_keys(table);key=field("savedKey","Ljava/lang/String;").ref;
    check(native_find(table,make_string("alpha"),0),"restored table rebuilds index");
    invoke("drop");gc_collect("String index weak fixture");
    check(!gc_slot_live(array)&&!gc_slot_live(key)&&VMS_NATIVE(g_library_indexes).retained_bytes()==0,"weak index does not retain Java table or keys");
    check(g_gc_sp.violations==0,"legal GC safepoints");j2melog::shutdown();std::cout<<"PASS StringIndexVM checks="<<checks<<" randomized_java=6000 mutations=3 restore=J2S5\n";
}
