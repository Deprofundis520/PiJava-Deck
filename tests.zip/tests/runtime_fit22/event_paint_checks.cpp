// The event-delivery thread may not be suspended under a foreign worker's
// synchronous paint; that worker retains the original invoke and operands.
#ifndef J2ME_TEST_VM
#define J2ME_TEST_VM "../../src/j2mevm.cpp"
#endif
#define main emulator_main
#include J2ME_TEST_VM
#undef main
#include "../../src/host_menu.h"
#include "../../src/host_speed.h"
static host_menu::Settings g_menu_settings;
static std::string instant_state_path(const std::string&) {return "unused-event-paint-state";}
#ifndef J2ME_TEST_STATE
#define J2ME_TEST_STATE "../../src/instant_state.inc"
#endif
#include J2ME_TEST_STATE
static int fixture;
static void check(bool ok,const char* why) {
    if(!ok){std::cerr<<"FAIL event-paint "<<why<<'\n';std::exit(1);}
}
static int field(const char* name) {
    const auto* f=find_field(fixture,name,"I");check(f&&f->is_static,"fixture field exists");
    return VMS_CL(g_classes)[f->owner].statics[f->slot].i;
}
static void invoke(const char* name,int value) {
    auto* method=find_method(fixture,name,"(I)I",false);check(method,"fixture method exists");
    check(run(method,{Value::of_i(value)}).i==1&&!VMS_EXEC(g_thrown),name);
}
int main(int argc,char** argv) {
    check(argc==1||argc==3||argc==4,"usage [classes api_classes [one-mode]]");std::cout<<std::unitbuf;
    const std::string classes=argc>1?argv[1]:"build/test-classes",api=argc>2?argv[2]:"romfs/classes";
    VMS_CL(g_classpath)={classes,api};VMS_DIAG(g_log_draw)=false;VMS_PLAT(g_boot_ms)=now_ms();
    log_open((classes+"/event-paint-vm.log").c_str(),true);
    fixture=ensure_class("EventPaintChecks");
    int cases=0;
    for(int cap:{0,30,60})for(int mode:{0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15}) {
        if(argc>3&&mode!=std::atoi(argv[3]))continue;
        stop_thread();VMS_EXEC(g_speed_cap)=cap;VMS_EXEC(g_midlet_state)=MidletState::Active;
        VMS_PLAT(g_host_paused)=false;VMS_RS(g_fb).assign(size_t(VMS_RS(g_screen_w))*VMS_RS(g_screen_h)*3,0);
        speed_sync_clock();invoke("setup",mode);host_events();VMS_RS(g_repaint)=false;VMS_RS(g_fb_dirty)=false;
        for(int token:{157,293}) {
            VMS_EXEC(g_speed_frame_open)=false;VMS_EXEC(g_speed_serial_serviced)=false;invoke("arm",token);
            std::cout<<"BEGIN event-paint cap="<<cap<<" mode="<<mode<<" token="<<token<<'\n';
            auto* old_thread=VMS_EXEC(g_running_thread);auto* old_stack=VMS_EXEC(g_active_stack);
            const auto turns_before=VMS_EXEC(g_runtime_profile).pending.worker_turns;
            if(mode==4){invoke("enqueue",0);host_events();}
            else if(mode==8)invoke("nonEvent",0);
            else dispatch_key(53,false);
            check(VMS_EXEC(g_running_thread)==old_thread&&VMS_EXEC(g_active_stack)==old_stack,
                  "callback preserved host Java context");
            check(field("keyDone")==1&&field("keyActive")==0,"callback completed");
            if(mode==0||mode==2||mode==5||mode==12||mode==15){
                check(field("paints")==0&&field("returned")==0,"foreign worker waits for callback");
                check(VMS_EXEC(g_runtime_profile).pending.worker_turns-turns_before<=4,"deferred worker does not busy-retry");
            }
            if(mode==12||mode==15){VMS_RS(g_repaint)=false;repaint_current();}
            for(int turn=0;turn<64&&VMS_EXEC(g_thread_live);++turn)advance_game_frame();
            check(!VMS_EXEC(g_thread_live),"worker completed");invoke("verify",0);
            check(VMS_EXEC(g_run_depth)==0&&VMS_EXEC(g_pump_depth)==0&&VMS_RS(g_paint_depth)==0,
                  "no native continuation left active");
            check(!VMS_EXEC(g_thrown)&&VMS_HEAP(g_root_stacks).empty(),"no exception or root stack residue");
            for(const auto& monitor:VMS_EXEC(g_monitors))check(!monitor.second.owner,"monitor owner released");
            if(mode!=4&&mode!=8)dispatch_key(53,true);
            ++cases;std::cout<<"PASS event-paint cap="<<cap<<" mode="<<mode<<" token="<<token
                <<" paints="<<field("paints")<<" service_returns="<<field("returned")<<'\n';
        }
    }
    if(argc<4) {
        stop_thread();VMS_EXEC(g_speed_cap)=0;VMS_EXEC(g_midlet_state)=MidletState::Active;
        VMS_PLAT(g_host_paused)=false;speed_sync_clock();invoke("setup",0);host_events();
        VMS_RS(g_repaint)=false;VMS_RS(g_fb_dirty)=false;invoke("arm",501);dispatch_key(53,false);
        check(field("started")==1&&field("returned")==0&&field("paints")==0,"reset has a pending worker service");
        stop_thread();check(!VMS_EXEC(g_thread_live)&&VMS_EXEC(g_threads).empty(),"reset removed pending worker");
        VMS_EXEC(g_midlet_state)=MidletState::Active;VMS_PLAT(g_host_paused)=false;
        invoke("setup",8);host_events();VMS_RS(g_repaint)=false;VMS_RS(g_fb_dirty)=false;
        invoke("arm",502);invoke("nonEvent",0);invoke("verify",0);
        std::cout<<"PASS event-paint reset_pending_worker=1 non_event_after_reset=1\n";
        stop_thread();VMS_EXEC(g_midlet_state)=MidletState::Active;VMS_PLAT(g_host_paused)=false;
        invoke("setup",0);host_events();VMS_RS(g_repaint)=false;VMS_RS(g_fb_dirty)=false;
        invoke("arm",503);dispatch_key(53,false);
        check(field("started")==1&&field("returned")==0&&field("paints")==0,"snapshot has a pending service");
        check(VMS_EXEC(g_threads).size()==1&&!VMS_EXEC(g_threads).front().frames.empty(),"snapshot worker retains Java frames");
        const auto& before=VMS_EXEC(g_threads).front().frames.back();
        const int invoke_pc=before.pc,invoke_op=before.op_pc,receiver=before.stack.back().ref;
        check(receiver==VMS_RS(g_current)&&invoke_pc==invoke_op,"snapshot retains invoke PC and receiver operand");
        auto* midlet=find_method(fixture,"stateMidlet","()Ljavax/microedition/midlet/MIDlet;",false);
        check(midlet,"snapshot fixture MIDlet exists");VMS_EXEC(g_midlet)=run(midlet,{}).ref;
        SavState saved,decoded;std::string bytes;
        check(capture_state(saved,"event-paint-fixture.jar")&&encode_state(saved,bytes)&&bytes.substr(0,4)=="J2S5",
              "pending invoke uses unchanged snapshot format");
        check(decode_state(bytes,decoded)&&apply_state(decoded),"pending invoke snapshot restores");
        fixture=ensure_class("EventPaintChecks");
        check(VMS_EXEC(g_threads).size()==1&&!VMS_EXEC(g_threads).front().frames.empty(),"restored worker retains Java frames");
        const auto& after=VMS_EXEC(g_threads).front().frames.back();
        check(after.pc==invoke_pc&&after.op_pc==invoke_op&&!after.stack.empty()&&after.stack.back().ref==receiver,
              "restore preserves pending invoke and receiver");
        for(int turn=0;turn<64&&VMS_EXEC(g_thread_live);++turn)advance_game_frame();
        check(!VMS_EXEC(g_thread_live),"restored pending worker completed");invoke("verify",0);
        std::cout<<"PASS event-paint snapshot_pending_invoke=1 format=J2S5 receiver_and_pc_preserved=1\n";
    }
    stop_thread();log_shutdown();std::cout<<"PASS event-paint cases="<<cases<<'\n';
}
