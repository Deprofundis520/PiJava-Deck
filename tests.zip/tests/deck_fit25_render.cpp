#include "font8x8_basic.h"
#include "platform/deck_ui.h"
#include <fstream>
void save(const char* dir,const char* name,const std::vector<uint32_t>& pixels){std::ofstream f(std::filesystem::path(dir)/(std::string(name)+".ppm"),std::ios::binary);f<<"P6\n1280 720\n255\n";for(auto c:pixels){char b[]={char(c),char(c>>8),char(c>>16)};f.write(b,3);}}
int main(int argc,char**argv){if(argc!=2)return 1;deck_ui::UI ui;ui.load_fonts();if(!ui.font.ready())return 2;
deck_game_options::Options o;o.rotation=1;o.alias="帝国时代 III";ui.settings_menu(9,60,false,"设置已保存",o,"Age of Empires III.jar");save(argv[1],"rotation-v312",ui.pixels);
deck_text::Editor e;e.begin(deck_text::Editor::Purpose::Rename,"帝国时代 III");ui.text_menu(e);save(argv[1],"text-v312",ui.pixels);
ui.menu({"帝国时代 III","3D QBlast.jar"},0,"读取到 2 个 JAR",60,false,0);save(argv[1],"library-v312",ui.pixels);
return 0;}
