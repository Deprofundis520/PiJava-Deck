#include "../src/logical_screen.h"
#include "../src/presentation/viewport.h"
#include "../src/presentation/gpu_filter.h"
#include <cassert>
#include <climits>
#include <cstdio>
int main(){
 using namespace logical_screen;
 for(auto size:{std::pair<int,int>{480,800},{800,480},{512,800},{800,512},{640,640},{16,800},{800,16}}){
  const int w=size.first,h=size.second;assert(valid(w,h));
  int pw=0,ph=0;assert(parse(std::to_string(w)+"x"+std::to_string(h),pw,ph)&&pw==w&&ph==h);
  auto v=j2me_present::game_viewport(w,h,true);assert(j2me_present::valid_viewport(v)&&(v.w==1280||v.h==720));
  std::vector<uint8_t> source(size_t(w)*h*3,113);auto before=source;
  for(int filter=1;filter<6;++filter){
   std::vector<uint32_t> packed;assert(j2me_present::gpu_filter::pack(source,w,h,display_filter::Filter(filter),packed,true));
   assert(packed.size()==4+size_t(w)*h&&packed.size()*4<=1638416u&&source==before);
  }
 }
 for(auto size:{std::pair<int,int>{800,513},{513,800},{800,800},{801,16},{16,801},{INT_MAX,INT_MAX},{0,800},{800,0},{-1,800},{15,800}}){
  int w=size.first,h=size.second,pw=92,ph=93;assert(!valid(w,h));
  assert(!parse(std::to_string(w)+"x"+std::to_string(h),pw,ph)&&pw==92&&ph==93);
  if(w>=16&&h>=16){
   assert(!j2me_present::valid_viewport(j2me_present::game_viewport(w,h,true)));
   std::vector<uint8_t> none;std::vector<uint32_t> out{17,29};
   assert(!j2me_present::gpu_filter::pack(none,w,h,display_filter::Filter::Crt,out,true));assert((out==std::vector<uint32_t>{17,29}));
  }
 }
 assert(j2me_present::gpu_filter::max_input_bytes==1638416u);
 // Every previously accepted source dimension must stay accepted.
 for(int w=16;w<=640;++w)for(int h=16;h<=640;++h)assert(valid(w,h));
 auto v=j2me_present::game_viewport(480,800,true);assert(v.x==424&&v.y==0&&v.w==432&&v.h==720);
 v=j2me_present::game_viewport(800,480,true);assert(v.x==40&&v.y==0&&v.w==1200&&v.h==720);
 std::puts("PASS capacity: new axes, exact area boundary, invalid/overflow rejection, old range preserved, GPU bytes unchanged");
}
