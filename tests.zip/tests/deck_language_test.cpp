#include "font8x8_basic.h"
#include "platform/deck_ui.h"
#include "platform/deck_navigation.h"
#include "platform/deck_memory_render.h"
#include <fstream>
#include <iostream>
static int checks=0;
static void check(bool x,const char*why){++checks;if(!x){std::cerr<<"FAIL "<<why<<'\n';std::exit(1);}}
static void image(deck_ui::UI&u,const std::string&p){std::ofstream f(p,std::ios::binary);f<<"P6\n1280 720\n255\n";for(auto c:u.pixels){char b[]={char(c),char(c>>8),char(c>>16)};f.write(b,3);}}
int main(int argc,char**argv){
 check(argc==2,"output folder");std::filesystem::path out=argv[1];std::filesystem::create_directories(out);
 deck_i18n::load(out/"language.cfg");check(deck_i18n::save(true),"English saved");deck_i18n::english=false;deck_i18n::load(out/"language.cfg");check(deck_i18n::english,"English persists");
 for(auto&e:deck_i18n::catalog){check(e.en[0]!=0,"nonempty English");check(deck_i18n::tr(e.zh)==e.en,"every catalog entry translates exactly");}
 check(deck_i18n::tr("保存即时存档")=="Save state","pause label");check(deck_i18n::tr("搜索完成：12 项；修改前请核对目标")=="Search complete: 12 matches. Check the target before editing","composed count");
 check(deck_i18n::tr(deck_i18n::raw("游戏/保存即时存档.jar"))=="游戏/保存即时存档.jar","user text protected");
 deck_ui::UI u;u.load_fonts();check(!u.font_bytes.empty(),"real font loaded");check(deck_i18n::tr("类型：32位整数")=="Type: 32-bit integer","composed short labels");for(bool en:{false,true}){
 deck_i18n::english=en;std::string prefix=(out/(en?"en-":"zh-")).string();
 u.menu({"游戏.jar","保存即时存档.jar"},0,"设置已保存",60,false,0);image(u,prefix+"library.ppm");
 u.game(nullptr,240,320,"60");u.pause_menu(7);image(u,prefix+"pause.ppm");
 u.settings_menu(10,60,true,"语言已保存",{},"游戏.jar","");image(u,prefix+"settings.ppm");
 deck_keymap::Editor map;u.keymap_menu(map,"按菜单键开始录入");image(u,prefix+"mapping.ppm");
 map.menu();u.keymap_menu(map,"");image(u,prefix+"capture.ppm");
 deck_text::Editor text;text.begin(deck_text::Editor::Purpose::Rename,"保存即时存档");u.text_menu(text);image(u,prefix+"text.ppm");
 text.begin(deck_text::Editor::Purpose::Memory,"9223372036854775807",20,2);text.title="修改目标数值";u.text_menu(text);image(u,prefix+"number.ppm");
 deck_games::Browser folders;folders.folder=std::filesystem::u8path("/home/deck/游戏");u.folder_menu(folders);image(u,prefix+"folders.ppm");
 u.skins_menu({},0,"请选择游戏");image(u,prefix+"skins.ppm");deck_custom_skin::Meta meta;meta.name="游戏皮肤";host_skin::Pixels pixels;u.skin_layout(meta,pixels,0,"");image(u,prefix+"viewport.ppm");
 deck_memory::Backend b{[]{return uint32_t(1);},[](const deck_memory::Target&,int64_t&n){n=9999;return true;},[](const deck_memory::Target&,int64_t){return true;},[](deck_memory::Type,std::vector<deck_memory::Span>&,std::string&){return true;},[](const deck_memory::Target&){return "game.Player.gold";}};
 deck_memory::Session memory(b);deck_memory::Panel panel;memory.candidates.push_back({{},100});memory.note="搜索完成：1 项；修改前请核对目标";deck_memory::render(u,memory,panel);image(u,prefix+"memory.ppm");
 }
 check(deck_i18n::save(false),"Chinese saved");deck_i18n::load(out/"language.cfg");check(!deck_i18n::english&&deck_i18n::tr("保存即时存档")=="保存即时存档","Chinese restored");
 deck_navigation::State n;n.input(deck_navigation::Input::Menu);n.input(deck_navigation::Input::Up);check(n.option==10&&n.input(deck_navigation::Input::Confirm)==deck_navigation::Effect::ValueNext,"controller language row");n.input(deck_navigation::Input::Down);check(n.option==0,"settings wraps 11 rows");
 std::cout<<"PASS language persistence, Chinese/English text, user data, controller settings and 22 screen renders; checks="<<checks<<'\n';
}
