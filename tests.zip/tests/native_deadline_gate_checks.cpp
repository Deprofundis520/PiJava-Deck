#include "../src/poll_gate.h"
#include <cassert>
#include <climits>
#include <iostream>

int main() {
    // `while (start + mutablePeriod > clock()) Thread.yield();`
    // lload_1, getstatic byte, i2l, ladd, clock, lcmp, ifle exit,
    // yield, goto lload_1, return. CPs are mock-independent labels.
    const std::vector<uint8_t> code={0x1f,0xb2,0,1,0x85,0x61,0xb8,0,3,
                                      0x94,0x9e,0,9,0xb8,0,2,0xa7,0xff,0xf0,0xb1};
    auto pure_static=[](int cp){return cp==1;};
    auto yield=[](int cp){return cp==2;};
    auto clock=[](int cp){return cp==3;};
    auto safe_flow=[](int,int){return true;};
    auto match=[&](const std::vector<uint8_t>& c){return recognize_native_deadline_gate(c,6,9,pure_static,yield,clock,safe_flow);};
    assert(match(code)==1);
    for(size_t n=0;n<code.size();++n) {
        std::vector<uint8_t> short_code(code.begin(),code.begin()+n);
        assert(match(short_code)<0);
    }
    auto reject=[&](int offset,uint8_t byte){auto altered=code;altered[offset]=byte;assert(match(altered)<0);};
    reject(0,0x1a); // int local is not a long anchor
    reject(4,0x00); // wrong conversion
    reject(5,0x65); // subtraction instead of addition
    reject(9,0x95); // wrong comparator
    reject(10,0x9d); // wrong branch meaning
    reject(12,0x06); // exit must be after the wait loop
    reject(13,0x84); // an increment/side effect in the wait path
    reject(15,0x04); // call other than Thread.yield
    reject(18,0xf1); // wrong backward target
    assert(recognize_native_deadline_gate(code,6,9,[](int){return false;},yield,clock,safe_flow)<0); // missing/volatile field
    assert(recognize_native_deadline_gate(code,6,9,pure_static,[](int){return false;},clock,safe_flow)<0);
    assert(recognize_native_deadline_gate(code,6,9,pure_static,yield,[](int){return false;},safe_flow)<0);
    assert(recognize_native_deadline_gate(code,6,9,pure_static,yield,clock,[](int,int){return false;})<0);
    auto length=[&](int p){const int op=code[size_t(p)];return op==0xb2||op==0xb8||op==0x9e||op==0xa7?3:1;};
    assert(native_deadline_flow_safe(code,0,19,false,length));
    assert(!native_deadline_flow_safe(code,0,19,true,length));
    assert(!native_deadline_flow_safe(code,2,19,false,length)); // operand byte, not an instruction start

    PollGateState state; const void* site=&state;
    for(int n=0;n<4;++n)assert(!state.observe_deadline(site,6,100,170,110+n,true));
    assert(state.reads==4 && state.wait_us(113,1.0,false)==500);
    // The static period is mutable. A new deadline starts fresh evidence even
    // when its anchor value and call-site remain the same.
    assert(!state.observe_deadline(site,6,100,120,114,true));
    assert(state.reads==1 && state.wait_us(114,1.0,false)==0);
    for(int n=0;n<3;++n)state.observe_deadline(site,6,100,120,115+n,true);
    assert(state.reads==4 && state.wait_us(117,1.0,false)==500);
    assert(state.observe_deadline(site,6,100,120,120,true));
    state.observe_deadline(site,6,100,230,110,true);assert(state.reads==0);
    state.observe_deadline(site,6,LLONG_MAX-2,-1,110,true);assert(state.reads==0);
    state.observe_deadline(site,6,100,170,110,false);assert(state.reads==0);
    assert(state.wait_us(110,1.0,false)==0);
    NativeDeadlineEvidence evidence;
    evidence.record(1,1,100,7,10,1.0);
    assert(!evidence.owns(1,1,100,7,10,1.0)); // no new completed paint
    assert(evidence.owns(1,1,100,7,11,1.0));
    assert(!evidence.owns(2,1,100,7,11,1.0)); // recursion/reentry
    assert(!evidence.owns(1,2,100,7,11,1.0));
    assert(!evidence.owns(1,1,101,7,11,1.0));
    assert(!evidence.owns(1,1,100,8,11,1.0)); // different Canvas
    assert(!evidence.owns(1,1,100,7,11,2.0)); // clock mode/rate changed
    evidence.record(2,1,100,7,11,1.0);
    assert(!evidence.owns(1,1,100,7,12,1.0));
    evidence.reset();assert(!evidence.owns(2,1,100,7,12,1.0));
    std::cout << "PASS native deadline recognition, pure loop and dynamic bounds\n";
}
