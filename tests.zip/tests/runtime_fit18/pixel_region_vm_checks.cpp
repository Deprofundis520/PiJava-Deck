// Generic arithmetic/static-read region contracts using the real VM and interpreter.
// No game JAR, native API substitution, allocation/GC or timing changes.
#ifndef J2ME_TEST_VM
#define J2ME_TEST_VM "../../src/j2mevm.cpp"
#endif
#define main emulator_main
#include J2ME_TEST_VM
#undef main
#include <climits>
#include <random>
static void check(bool ok,const char* why){if(!ok){std::cerr<<"FAIL pixel-region "<<why<<'\n';std::exit(1);}}
static Method fixture(std::vector<uint8_t> code,unsigned locals,unsigned stack){Method m;m.class_id=0;m.name="pixels";m.desc="()V";m.flags=8;
 m.max_locals=locals;m.max_stack=stack;m.code=std::move(code);m.quick.resize(m.code.size());return m;}
static Frame frame(Method& m,std::vector<Value> locals){Frame f;f.method=&m;f.locals=std::move(locals);return f;}
static void setup(){VMS_DIAG(g_log_draw)=false;VMS_CL(g_classes).clear();VMS_CL(g_class_index).clear();Class c;c.name="PixelFixture";c.init_state=2;
 c.statics={Value::of_i(42),Value::of_ref(0)};VMS_CL(g_classes).push_back(std::move(c));VMS_NATIVE(g_native_jit).configure(true);
 check(VMS_NATIVE(g_native_jit).enabled&&VMS_NATIVE(g_native_jit).available,"host JIT available");}
static void static_case(){
 auto m=fixture({178,0,1,59,26,4,96,59,177},1,2);m.quick[0].kind=1;m.quick[0].a=0;m.quick[0].b=0;
 Frame f;int done=0;for(unsigned n=0;n<JitRegionHot;++n){f=frame(m,{Value::of_i(-1)});done=jit_region_try(f,100);}
 check(done==6&&f.pc==8&&f.locals[0].i==43,"resolved initialized getstatic must execute through region");
 VMS_CL(g_classes)[0].statics[0]=Value::of_i(98);f=frame(m,{Value::of_i(-1)});check(jit_region_try(f,100)==6&&f.locals[0].i==99,"compiled getstatic must read current value on every invocation");
 for(int state:{0,1,3}){VMS_CL(g_classes)[0].init_state=state;f=frame(m,{Value::of_i(-1)});check(jit_region_try(f,100)==0&&f.pc==0&&f.locals[0].i==-1&&f.stack.empty(),"uninitialized/in-progress/erroneous class must bail before getstatic");}
 VMS_CL(g_classes)[0].init_state=2;VMS_CL(g_classes)[0].statics[0]=Value::of_l(123);f=frame(m,{Value::of_i(-1)});check(jit_region_try(f,100)==0&&f.pc==0,"long static must stay interpreted");
 VMS_CL(g_classes)[0].statics[0]=Value::of_i(42);
 for(unsigned budget=0;budget<=8;++budget){Frame ref=frame(m,{Value::of_i(-1)});ref.op_pc=-1;const int expected=execute_fast_batch(ref,budget);f=frame(m,{Value::of_i(-1)});f.op_pc=-1;
  check(jit_region_try(f,budget)==expected&&f.pc==ref.pc&&f.op_pc==ref.op_pc&&f.locals[0].i==ref.locals[0].i&&f.stack.size()==ref.stack.size(),"getstatic interpreter differential budgets/PC/locals");
  for(unsigned k=0;k<f.stack.size();++k)check(f.stack[k].i==ref.stack[k].i&&f.stack[k].ref==ref.stack[k].ref,"getstatic interpreter differential live stack");}
 auto saved=VMS_CL(g_classes)[0].statics;VMS_CL(g_classes)[0].statics.clear();f=frame(m,{Value::of_i(-1)});check(jit_region_try(f,100)==0&&f.pc==0,"static slot bounds rechecked at execution");VMS_CL(g_classes)[0].statics=saved;
 VMS_CL(g_classes)[0].statics[1]=Value::of_i(6);m.quick[0].b=1;VMS_NATIVE(g_native_jit).clear();
 for(unsigned n=0;n<JitRegionHot;++n){f=frame(m,{Value::of_i(-1)});done=jit_region_try(f,100);}
 check(done==6&&f.locals[0].i==7,"engine epoch must discard old resolved static slot");jit_region_reset();
 // Static reference reads remain roots in Class.statics; no compiled safepoint or raw pointer caching.
 const int array=alloc_array("[I",4);VMS_CL(g_classes)[0].statics[1]=Value::of_ref(array);m=fixture({178,0,1,75,177},1,1);m.quick[0].kind=1;m.quick[0].a=0;m.quick[0].b=1;
 for(unsigned n=0;n<JitRegionHot;++n){f=frame(m,{Value::of_ref(0)});done=jit_region_try(f,100);}
 check(done==2&&f.locals[0].ref==array,"getstatic must preserve reference half");gc_collect("pixel-static-root");f=frame(m,{Value::of_ref(0)});
 check(jit_region_try(f,100)==2&&f.locals[0].ref==array&&VMS_HEAP(g_heap)[array].is_array,"static array remains GC root across region invocations");jit_region_reset();
 m=fixture({178,0,1,75,177},1,1);for(unsigned n=0;n<JitRegionHot;++n){f=frame(m,{Value::of_ref(0)});done=jit_region_try(f,100);}
 check(done==0&&f.pc==0,"unresolved static reads stay interpreted");jit_region_reset();
 std::cout<<"PASS getstatic current values and initialization/long bail guards\n";
}
static void differential(Method& m, const std::vector<Value>& values, unsigned entry=0, std::vector<Value> stack={}) {
 jitr::Spec spec;spec.code=m.code.data();spec.size=m.code.size();spec.entry=entry;spec.max_locals=m.max_locals;spec.max_stack=m.max_stack;spec.entry_depth=stack.size();
 jitr::Region region;check(jitr::build(spec,region),"arithmetic region builds");bool arithmetic=false;for(const auto& n:region.ins)if((n.op==108||n.op==112)&&n.kind==jitr::K_OP)arithmetic=true;check(arithmetic,"arithmetic is compiled rather than an exit");
 const auto id=jit236::next_install_id();jit236::Executable exe;auto code=jitr::emit_host(region,{},id);check(!code.empty()&&exe.install(code,id),"arithmetic code installs");
 for(unsigned budget=0;budget<=6;++budget){
  Frame reference=frame(m,values);reference.pc=entry;reference.stack=stack;reference.op_pc=-1;
  const int expected=execute_fast_batch(reference,budget);
  std::vector<int32_t> slots(2+2*(m.max_locals+m.max_stack+1),0x12345);slots[0]=-1;slots[1]=id;
  for(unsigned k=0;k<values.size();++k){slots[2+2*k]=values[k].i;slots[3+2*k]=values[k].ref;}
  for(unsigned k=0;k<stack.size();++k){slots[2+2*(m.max_locals+k)]=stack[k].i;slots[3+2*(m.max_locals+k)]=stack[k].ref;}
  auto rc=reinterpret_cast<jitr::Fn>(exe.fn)(slots.data(),budget);
  check(uint32_t(rc)==unsigned(reference.pc)&&uint32_t(rc>>32)==unsigned(expected),"compiled/interpreter exit PC and exact budget count");
  check(slots[0]==reference.op_pc,"compiled/interpreter last executed PC");
  for(unsigned k=0;k<values.size();++k)check(slots[2+2*k]==reference.locals[k].i&&slots[3+2*k]==reference.locals[k].ref,"compiled/interpreter locals");
  check(region.depth[reference.pc]==int(reference.stack.size()),"compiled/interpreter stack depth");
  for(unsigned k=0;k<reference.stack.size();++k)check(slots[2+2*(m.max_locals+k)]==reference.stack[k].i&&slots[3+2*(m.max_locals+k)]==reference.stack[k].ref,"compiled/interpreter live operands, including zero-divisor bail");
 }
}
static void division_case(){
 for(int op:{108,112}){
 auto m=fixture({26,27,uint8_t(op),61,177},3,2);Frame f;int done=0;
 for(unsigned n=0;n<JitRegionHot;++n){f=frame(m,{Value::of_i(17),Value::of_i(5),Value::of_i(-99)});done=jit_region_try(f,100);}
 check(done==4&&f.pc==4&&f.locals[2].i==(op==108?3:2),"idiv/irem must stay compiled");jit_region_reset();
 const int32_t edges[]={INT32_MIN,INT32_MIN+1,-65536,-17,-1,0,1,3,5,17,65536,INT32_MAX};
 for(int32_t a:edges)for(int32_t b:edges)differential(m,{Value::of_i(a),Value::of_i(b),Value::of_i(-99)});
 std::mt19937 rng(0x18d1);for(unsigned n=0;n<128;++n)differential(m,{Value::of_i(int32_t(rng())),Value::of_i(int32_t(rng())),Value::of_i(-99)});
 // Entry directly at arithmetic with an existing operand stack, including zero and MIN/-1.
 for(int32_t b:{0,-1,3})differential(m,{Value::of_i(INT32_MIN),Value::of_i(b),Value::of_i(-99)},2,{Value::of_i(INT32_MIN),Value::of_i(b)});
 }
 std::cout<<"PASS idiv/irem compiled arithmetic\n";
}
static void benchmark_case(){
 const unsigned count=16384,repeats=64;const int bits=alloc_array("[B",count),pixels=alloc_array("[I",count);
 for(unsigned k=0;k<count;++k)VMS_HEAP(g_heap)[bits].elems.set(k,Value::of_i(k&1));
 VMS_CL(g_classes)[0].statics={Value::of_i(0x123456),Value::of_ref(bits),Value::of_ref(pixels)};
 auto m=fixture({3,59,26,27,162,0,31,178,0,1,26,51,4,126,153,0,15,178,0,2,26,178,0,3,26,6,112,96,79,132,0,1,167,255,226,177},2,4);
 for(auto q:std::vector<std::pair<unsigned,int>>{{7,1},{17,2},{21,0}}){m.quick[q.first].kind=1;m.quick[q.first].a=0;m.quick[q.first].b=q.second;}
 // Warm only candidate collection, before measurement; no game names/hash matching.
 for(unsigned n=0;n<JitRegionHot;++n){auto f=frame(m,{Value::of_i(0),Value::of_i(count)});while(f.pc!=35){int done=jit_region_try(f,1024);if(!done)done=execute_fast_batch(f,1024);check(done>0,"warmup progress");}}
 uint64_t checksum[2]{},ops[2]{},entries[2]{};double elapsed[2]{};
 for(unsigned mode=0;mode<2;++mode){const auto start=std::chrono::steady_clock::now();
  for(unsigned n=0;n<repeats;++n){auto f=frame(m,{Value::of_i(0),Value::of_i(count)});
   while(f.pc!=35){int done=mode?jit_region_try(f,1024):0;if(!done)done=execute_fast_batch(f,1024);check(done>0,"bitmap benchmark makes progress");ops[mode]+=done;++entries[mode];}}
  elapsed[mode]=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();
  for(unsigned k=0;k<count;++k)checksum[mode]+=uint32_t(VMS_HEAP(g_heap)[pixels].elems.get(k).i);
 }
 check(checksum[0]==checksum[1]&&checksum[1]==uint64_t(8192)*0x123456+8191,"literal bitmap checksum must match compiled/interpreted writes");
 check(ops[0]==ops[1],"bitmap bytecode count unchanged");
 std::cout<<"BENCH desktop_synthetic_bitmap count="<<count<<" repeats="<<repeats<<" fast_ms="<<elapsed[0]<<" region_ms="<<elapsed[1]<<" fast_entries="<<entries[0]<<" region_entries="<<entries[1]<<" ops="<<ops[0]<<" checksum="<<checksum[0]<<" desktop_not_switch=1\n";jit_region_reset();
}
static void neighborhood_benchmark_case(){
 const unsigned count=16384,repeats=64;
 auto m=fixture({3,61,3,62,29,26,162,0,26,28,29,16,9,112,6,104,29,16,9,108,96,16,9,108,96,61,132,3,1,167,255,231,177},4,4);
 for(unsigned n=0;n<JitRegionHot;++n){auto f=frame(m,{Value::of_i(count),Value::of_i(0),Value::of_i(0),Value::of_i(0)});while(f.pc!=32){int done=jit_region_try(f,1024);if(!done)done=execute_fast_batch(f,1024);check(done>0,"neighborhood warmup progress");}}
 uint64_t ops[2]{},entries[2]{};double elapsed[2]{};
 for(unsigned mode=0;mode<2;++mode){const auto start=std::chrono::steady_clock::now();
  for(unsigned n=0;n<repeats;++n){auto f=frame(m,{Value::of_i(count),Value::of_i(0),Value::of_i(0),Value::of_i(0)});
   while(f.pc!=32){int done=mode?jit_region_try(f,1024):0;if(!done)done=execute_fast_batch(f,1024);check(done>0,"neighborhood benchmark progress");ops[mode]+=done;++entries[mode];}
   check(f.locals[2].i==1670660,"literal neighborhood arithmetic checksum");}
  elapsed[mode]=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();}
 check(ops[0]==ops[1],"neighborhood bytecode count unchanged");
 std::cout<<"BENCH desktop_synthetic_neighborhood count="<<count<<" repeats="<<repeats<<" fast_ms="<<elapsed[0]<<" region_ms="<<elapsed[1]<<" fast_entries="<<entries[0]<<" region_entries="<<entries[1]<<" ops="<<ops[0]<<" checksum=1670660 desktop_not_switch=1\n";jit_region_reset();
}
int main(int argc,char** argv){setup();std::string test=argc>1?argv[1]:"all";if(test=="static"||test=="all")static_case();if(test=="division"||test=="all")division_case();if(test=="bench")benchmark_case();if(test=="bench-neighborhood")neighborhood_benchmark_case();jit_region_reset();VMS_NATIVE(g_native_jit).clear();}
