import javax.microedition.midlet.MIDlet;
import javax.microedition.lcdui.*;
class DeckMemoryBase {public int inherited=100;}
public class DeckMemoryCases extends DeckMemoryBase {
    public static class App extends MIDlet {protected void startApp(){} protected void pauseApp(){} protected void destroyApp(boolean b){}}
    public static class View extends Canvas {protected void paint(Graphics g){}}
    public static App app;
    public static DeckMemoryCases player;
    public static int gems=3;
    public static final int CONSTANT=100;
    public final int fixed=100;
    public int gold=100;
    public byte ammo=5;
    public short potions=6;
    public long experience=9000000000L;
    public int[] bag={100,7,8};
    public byte[] bytes={-128,127,5};
    public short[] shorts={-32768,32767,6};
    public long[] longs={Long.MIN_VALUE,Long.MAX_VALUE,9000000000L};
    public static int[] large;
    public static void setup(){app=new App();player=new DeckMemoryCases();Display.getDisplay(app).setCurrent(new View());}
    public static void spend(){player.gold-=10;}
    public static int gold(){return player.gold;}
    public static int gems(){return gems;}
    public static int item(){return player.bag[0];}
    public static long experience(){return player.experience;}
    public static int ammo(){return player.ammo;}
    public static int potions(){return player.potions;}
    public static void many(){large=new int[100001];}
}
