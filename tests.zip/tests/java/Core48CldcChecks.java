import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.FilterInputStream;
import java.io.InputStream;
import java.util.Stack;

/** Consumer contracts run by PiJava, never by the host JVM. */
public final class Core48CldcChecks {
    private static int assertions;
    private static void check(boolean ok, String reason) {
        assertions++;
        if (!ok) throw new RuntimeException(reason);
    }
    private static byte[] bytes(int n) {
        byte[] b = new byte[n];
        for (int i = 0; i < n; i++) b[i] = (byte)i;
        return b;
    }
    private static final class Source extends InputStream {
        byte[] data; int pos; int chunk; int bulkCalls; int closes;
        boolean ready = true; boolean fail; boolean failClose;
        Source(int size, int chunk) { data = bytes(size); this.chunk = chunk; }
        public int read() throws IOException {
            if (fail) throw new IOException("source read");
            return pos == data.length ? -1 : data[pos++] & 255;
        }
        public int read(byte[] b, int off, int len) throws IOException {
            bulkCalls++;
            if (fail) throw new IOException("source read");
            if (pos == data.length) return -1;
            int n = data.length - pos;
            if (n > len) n = len;
            if (n > chunk) n = chunk;
            System.arraycopy(data, pos, b, off, n); pos += n; return n;
        }
        public int available() throws IOException {
            if (fail) throw new IOException("source available");
            return ready ? data.length - pos : 0;
        }
        public void close() throws IOException {
            closes++;
            if (failClose) throw new IOException("source close");
        }
    }
    public static int buffered() throws Exception {
        assertions = 0;
        Source source = new Source(260, 260);
        BufferedInputStream in = new BufferedInputStream(source, 4);
        check(in.markSupported(), "buffer supports mark");
        check(in.available() == 260, "available before fill");
        for (int i = 0; i < 4; i++) check(in.read() == i, "single reads preserve buffer bytes");
        check(source.bulkCalls == 1, "single reads actually buffered");
        check(in.read() == 4 && in.available() == 255, "refill boundary and available");
        byte[] dst = new byte[260];
        check(in.read(dst, 2, 255) == 255, "bulk drains buffer and underlying");
        for (int i = 0; i < 255; i++) check((dst[i + 2] & 255) == ((i + 5) & 255), "bulk unsigned data");
        check(dst[0] == 0 && dst[1] == 0 && dst[257] == 0, "bulk honors destination bounds");
        check(in.read() == -1 && in.read(dst) == -1, "EOF single and inherited array read");
        check(in.read(dst, dst.length, 0) == 0, "empty read at EOF");
        BufferedInputStream tail = new BufferedInputStream(new ByteArrayInputStream(bytes(3)), 2);
        check(tail.read(dst, 0, 8) == 3 && dst[0] == 0 && dst[2] == 2, "bulk past EOF returns positive tail");
        check(tail.read(dst, 0, 8) == -1, "bulk past EOF then EOF");
        check(in.skip(30) == 0 && in.available() == 0, "EOF skip and available");
        source = new Source(9, 2); in = new BufferedInputStream(source, 3);
        check(in.read(dst, 0, 8) == 8, "positive available combines short reads");
        check(in.read() == 8 && in.read() == -1, "short read tail");
        source = new Source(9, 2); source.ready = false; in = new BufferedInputStream(source, 3);
        check(in.read(dst, 0, 8) == 2, "zero available returns current short read");
        check(in.read() == 2, "zero available is not EOF");
        in = new BufferedInputStream(new ByteArrayInputStream(bytes(15)), 3);
        check(in.read() == 0, "skip setup");
        check(in.skip(-3) == 0 && in.skip(0) == 0, "nonpositive skip");
        check(in.skip(1) == 1 && in.read() == 2, "buffered skip");
        check(in.skip(5) == 5 && in.read() == 8, "underlying skip");
        try { in.reset(); check(false, "reset without mark"); } catch (IOException expected) { check(true, "unmarked reset rejected"); }
        in = new BufferedInputStream(new ByteArrayInputStream(bytes(20)), 2);
        in.mark(9);
        check(in.read(dst, 0, 9) == 9 && dst[0] == 0 && dst[8] == 8, "bulk mark survives growth through limit");
        in.reset(); check(in.read() == 0, "bulk grown mark resets");
        in = new BufferedInputStream(new ByteArrayInputStream(bytes(20)), 2);
        in.mark(9);
        for (int i = 0; i < 9; i++) check(in.read() == i, "mark survives buffer growth through limit");
        in.reset(); check(in.read() == 0, "grown mark resets");
        in.reset(); check(in.skip(6) > 0, "marked skip progresses");
        in.reset(); check(in.read() == 0, "skip preserves mark");
        in = new BufferedInputStream(new ByteArrayInputStream(bytes(20)), 4);
        check(in.read() == 0 && in.read() == 1, "compaction setup");
        in.mark(6);
        for (int i = 2; i < 8; i++) check(in.read() == i, "mark preserves compacted bytes");
        in.reset(); check(in.read() == 2, "compacted mark resets");
        in.mark(1);
        for (int i = 3; i < 15; i++) check(in.read() == i, "read beyond mark limit");
        try { in.reset(); check(false, "expired mark"); } catch (IOException expected) { check(true, "expired mark rejected after refill"); }
        in = new BufferedInputStream(new ByteArrayInputStream(bytes(5)));
        in.mark(5); check(in.read(dst, 0, 5) == 5, "default constructor and marked bulk");
        in.reset(); check(in.read() == 0, "marked bulk replay");
        try { new BufferedInputStream(in, 0); check(false, "zero buffer"); } catch (IllegalArgumentException expected) { check(true, "zero buffer rejected"); }
        try { new BufferedInputStream(in, -1); check(false, "negative buffer"); } catch (IllegalArgumentException expected) { check(true, "negative buffer rejected"); }
        try { in.read(null, 0, 0); check(false, "null destination"); } catch (NullPointerException expected) { check(true, "null destination rejected"); }
        int[] offsets = {-1, 0, dst.length + 1, 2, 2147483647};
        int[] lengths = {1, -1, 0, dst.length, 2147483647};
        for (int i = 0; i < offsets.length; i++) {
            try { in.read(dst, offsets[i], lengths[i]); check(false, "invalid read bounds"); }
            catch (IndexOutOfBoundsException expected) { check(true, "invalid read bounds rejected"); }
        }
        source = new Source(5, 5); in = new BufferedInputStream(source, 2);
        in.read(); in.mark(2); in.close(); in.close(); check(source.closes == 1, "close owns underlying exactly once");
        closed(in, dst);
        source = new Source(5, 5); source.failClose = true; in = new BufferedInputStream(source, 2);
        try { in.close(); check(false, "close error"); } catch (IOException expected) { check(expected.getMessage().equals("source close"), "close failure propagated"); }
        in.close(); check(source.closes == 1, "close failure leaves wrapper closed"); closed(in, dst);
        source = new Source(5, 5); source.fail = true; in = new BufferedInputStream(source, 2);
        try { in.read(); check(false, "read error"); } catch (IOException expected) { check(expected.getMessage().equals("source read"), "read failure propagated"); }
        try { in.available(); check(false, "available error"); } catch (IOException expected) { check(true, "available failure propagated"); }
        return assertions;
    }
    private static void closed(BufferedInputStream in, byte[] dst) throws Exception {
        try { in.read(); check(false, "closed single"); } catch (IOException expected) { check(true, "closed single rejected"); }
        try { in.read(dst, 0, 1); check(false, "closed bulk"); } catch (IOException expected) { check(true, "closed bulk rejected"); }
        try { in.read(dst, 0, 0); check(false, "closed empty"); } catch (IOException expected) { check(true, "closed empty rejected"); }
        try { in.skip(0); check(false, "closed skip"); } catch (IOException expected) { check(true, "closed skip rejected"); }
        try { in.available(); check(false, "closed available"); } catch (IOException expected) { check(true, "closed available rejected"); }
        try { in.reset(); check(false, "closed reset"); } catch (IOException expected) { check(true, "closed reset rejected"); }
    }
    public static int exception() {
        assertions = 0;
        check(new StringIndexOutOfBoundsException(-7).getMessage().equals("String index out of range: -7"), "negative index message");
        check(new StringIndexOutOfBoundsException(0).getMessage().equals("String index out of range: 0"), "zero index message");
        check(new StringIndexOutOfBoundsException(2147483647).getMessage().equals("String index out of range: 2147483647"), "maximum index message");
        check(new StringIndexOutOfBoundsException(-2147483648).getMessage().equals("String index out of range: -2147483648"), "minimum index message");
        check(new StringIndexOutOfBoundsException().getMessage() == null, "default message preserved");
        check(new StringIndexOutOfBoundsException("detail").getMessage().equals("detail"), "string message preserved");
        try { throw new StringIndexOutOfBoundsException(4); }
        catch (IndexOutOfBoundsException expected) { check(expected instanceof StringIndexOutOfBoundsException, "integer exception catches by superclass"); }
        return assertions;
    }
    private static final class Filter extends FilterInputStream {
        int calls;
        Filter(InputStream source) { super(source); }
        public int read(byte[] b, int off, int len) throws IOException {
            calls++;
            return super.read(b, off, len);
        }
        InputStream source() { return in; }
    }
    public static int filter() throws Exception {
        assertions = 0;
        ByteArrayInputStream source = new ByteArrayInputStream(bytes(9));
        Filter filter = new Filter(source);
        check(filter.source() == source, "filter protected underlying stream");
        check(filter.markSupported(), "filter forwards mark support");
        filter.mark(9);
        check(filter.read() == 0 && filter.available() == 8, "filter single and available delegate");
        byte[] dst = new byte[3];
        check(filter.read(dst) == 3 && dst[0] == 1 && dst[2] == 3, "filter inherited array read data");
        check(filter.calls == 1, "filter array read dispatches subclass override");
        filter.reset(); check(filter.read() == 0, "filter mark reset delegate");
        check(filter.skip(3) == 3 && filter.read() == 4, "filter skip delegate");
        Source owned = new Source(2, 2); filter = new Filter(owned); filter.close();
        check(owned.closes == 1, "filter closes underlying resource");
        FilterInputStream buffered = new BufferedInputStream(new ByteArrayInputStream(bytes(3)), 2);
        check(buffered instanceof BufferedInputStream && buffered.read() == 0, "buffered stream assignable to filter superclass");
        return assertions;
    }
    private static final class Equal {
        int value; Equal(int value) { this.value = value; }
        public boolean equals(Object other) { return other instanceof Equal && ((Equal)other).value == value; }
    }
    public static int stack() {
        assertions = 0;
        Stack stack = new Stack();
        check(stack.empty() && stack.search(null) == -1 && stack.search("missing") == -1, "empty searches");
        Equal first = new Equal(7); Equal second = new Equal(7);
        check(stack.push(first) == first, "push return identity");
        stack.push(null); stack.push(second); stack.push(null); stack.push("top");
        check(stack.search(new Equal(7)) == 3, "nearest equal duplicate top distance");
        check(stack.search(null) == 2, "nearest null duplicate top distance");
        check(stack.search("top") == 1 && stack.search("missing") == -1, "top and absent searches");
        check(stack.size() == 5 && stack.peek().equals("top"), "search does not mutate stack");
        check(stack.pop().equals("top") && stack.search(null) == 1, "search after pop");
        check(stack.pop() == null && stack.peek() == second && stack.search(first) == 1, "normal null pop and equals search");
        check(stack.pop() == second && stack.search(first) == 2, "search lower duplicate");
        check(stack.pop() == null && stack.pop() == first && stack.empty(), "normal LIFO identity preserved");
        return assertions;
    }
}
