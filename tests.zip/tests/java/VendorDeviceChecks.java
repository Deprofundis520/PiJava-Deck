public final class VendorDeviceChecks {
    public static int run() {
        new com.siemens.mp.game.Vibrator();
        new com.motorola.multimedia.Lighting();
        new mmpp.media.BackLight();
        if(mmpp.media.BackLight.numColors()!=0||mmpp.media.BackLight.getColor()!=0)return -1;
        int[] values={10000,1,0,-1,2147483647,(-2147483647-1)};
        for(int i=0;i<10000;i++) {
            int value=values[i%values.length];
            com.siemens.mp.game.Vibrator.startVibrator();
            com.siemens.mp.game.Vibrator.triggerVibrator(value);
            com.siemens.mp.game.Vibrator.stopVibrator();
            com.siemens.mp.game.Vibrator.stopVibrator();
            com.motorola.multimedia.Lighting.backlightOn();
            com.motorola.multimedia.Lighting.backlightOff();
            mmpp.media.BackLight.setColor(value);
            mmpp.media.BackLight.on(value);
            if(mmpp.media.BackLight.getColor()!=0||mmpp.media.BackLight.numColors()!=0)return -2;
            mmpp.media.BackLight.off();
            mmpp.media.BackLight.off();
        }
        return 10000;
    }
}
