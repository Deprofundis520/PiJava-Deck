import javax.microedition.lcdui.*;
import javax.microedition.midlet.*;
import java.io.*;
import java.util.*;
public class DeckLibraryChecks {
    public static class App extends MIDlet { protected void startApp(){} protected void pauseApp(){} protected void destroyApp(boolean b){} }
    public static class Widget extends CustomItem {
        public Widget(){super("widget");}
        protected int getMinContentWidth(){return 20;} protected int getMinContentHeight(){return 20;}
        protected int getPrefContentWidth(int h){return 100;} protected int getPrefContentHeight(int w){return 40;}
        protected void paint(Graphics g,int w,int h){paints++;g.setColor(0xff0000);g.fillRect(0,0,w,h);}
        protected boolean traverse(int d,int w,int h,int[] r){traverses++;return false;}
        protected void keyPressed(int k){pressed=k;} protected void keyReleased(int k){released=k;}
    }
    public static class C extends Canvas {protected void paint(Graphics g){} }
    public static App app;public static Form form;public static TextField text;public static Widget widget;public static C canvas;
    public static int paints,traverses,pressed,released,changes;
    static void check(boolean b){if(!b)throw new RuntimeException("library contract");}
    public static void setup() throws Exception {
        check(Double.toString(1.5).equals("1.5"));check(new StringIndexOutOfBoundsException(3).getMessage()!=null);
        Stack stack=new Stack();stack.push("a");stack.push("b");check(stack.search("a")==2&&stack.search("c")==-1);
        BufferedInputStream in=new BufferedInputStream(new ByteArrayInputStream(new byte[]{1,2,3,4}),2);
        check(in.read()==1);in.mark(4);check(in.read()==2&&in.read()==3);in.reset();check(in.read()==2);in.close();
        boolean closed=false;try{in.read();}catch(IOException e){closed=true;}check(closed);
        app=new App();form=new Form("Form");StringItem item=new StringItem("label","value",Item.BUTTON);
        item.setFont(Font.getDefaultFont());check(item.getAppearanceMode()==Item.BUTTON&&item.getFont()!=null);form.append(item);
        text=new TextField("name","old",16,TextField.ANY);form.append(text);widget=new Widget();form.append(widget);
        form.setItemStateListener(new ItemStateListener(){public void itemStateChanged(Item i){changes++;}});
        Display.getDisplay(app).setCurrent(form);canvas=new C();
    }
    public static void selectWidget(){Display.getDisplay(app).setCurrentItem(widget);}
    public static void selectText(){Display.getDisplay(app).setCurrentItem(text);}
    public static void edit(){text.setString("中文Ab");text.notifyStateChanged();}
    public static void verify(){check(text.getString().equals("中文Ab")&&changes==1&&pressed==49&&released==49&&paints>0&&traverses>0);}
    public static int fire(){return canvas.getKeyCode(Canvas.FIRE);}
}
