import java.util.Enumeration;
import javax.microedition.pim.*;

/** Executed by the actual emulator VM, compiled against an independent API snapshot. */
public final class OptionalPimChecks {
    private static void check(boolean ok, String reason) {
        if (!ok) throw new RuntimeException(reason);
    }
    public static int denied() {
        try { PIM.getInstance(); }
        catch (SecurityException expected) { return 1; }
        throw new RuntimeException("PIM must deny access without a backend");
    }
    // Matches the collection's optional address-book lookup: catch Exception and
    // continue with empty names. No fixture contact or PIM backend is substituted.
    public static int gameFallback() {
        String[] names = new String[0];
        ContactList list = null;
        try {
            PIM pim = PIM.getInstance();
            String[] lists = pim.listPIMLists(PIM.CONTACT_LIST);
            if (lists.length > 0) {
                list = (ContactList)pim.openPIMList(PIM.CONTACT_LIST, PIM.READ_ONLY, lists[0]);
                Enumeration items = list.items();
                if (items.hasMoreElements()) {
                    Contact contact = (Contact)items.nextElement();
                    names = new String[] { contact.getString(Contact.FORMATTED_NAME, 0) };
                }
                list.close();
            }
        } catch (Exception unavailable) {
            check(unavailable instanceof SecurityException, "expected unavailable capability denial");
            check(list == null, "no contact list was fabricated");
            check(names.length == 0, "game keeps its own empty fallback data");
            return 3;
        }
        throw new RuntimeException("game optional PIM branch must take its catch");
    }
    public static int exceptions() throws Exception {
        PIMException empty = new PIMException();
        check(empty.getMessage() == null, "default PIM exception message");
        check(empty.getReason() == 0, "default PIM exception reason");
        PIMException message = new PIMException("unavailable 中文");
        check(message.getMessage().equals("unavailable 中文"), "PIM exception message");
        check(message.getReason() == 0, "message PIM exception default reason");
        try { throw new PIMException("closed", PIMException.LIST_CLOSED); }
        catch (Exception e) {
            check(e instanceof PIMException, "checked exception inheritance");
            check(((PIMException)e).getReason() == PIMException.LIST_CLOSED, "explicit reason retained");
        }
        FieldEmptyException e = new FieldEmptyException("empty", Contact.TEL);
        FieldFullException f = new FieldFullException("full", Contact.NAME);
        UnsupportedFieldException u = new UnsupportedFieldException("unsupported", Contact.PHOTO);
        check(e.getField() == Contact.TEL && e.getMessage().equals("empty"), "empty field detail");
        check(f.getField() == Contact.NAME && f.getMessage().equals("full"), "full field detail");
        check(u.getField() == Contact.PHOTO && u.getMessage().equals("unsupported"), "unsupported field detail");
        check(new FieldEmptyException().getField() == 0 && new FieldEmptyException("x").getField() == 0, "empty defaults");
        check(new FieldFullException().getField() == 0 && new FieldFullException("x").getField() == 0, "full defaults");
        check(new UnsupportedFieldException().getField() == 0 && new UnsupportedFieldException("x").getField() == 0, "unsupported defaults");
        return 12;
    }
}
