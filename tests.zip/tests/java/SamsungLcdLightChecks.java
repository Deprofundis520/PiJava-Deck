import com.samsung.util.LCDLight;

public final class SamsungLcdLightChecks {
    public static int run() {
        for(int i=0;i<10000;i++) {
            // Magic Runes requests 10000 via this exact invokestatic descriptor.
            LCDLight.on(10000);
            if(!LCDLight.isSupported())return -1;
            LCDLight.off();
        }
        return 10000;
    }
}
