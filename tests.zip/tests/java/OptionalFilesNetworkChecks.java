import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.NoSuchElementException;
import javax.microedition.io.ConnectionNotFoundException;
import javax.microedition.io.Connector;
import javax.microedition.io.HttpsConnection;
import javax.microedition.io.DatagramConnection;
import javax.microedition.io.PushRegistry;
import javax.microedition.io.file.ConnectionClosedException;
import javax.microedition.io.file.FileConnection;
import javax.microedition.io.file.FileSystemListener;
import javax.microedition.io.file.FileSystemRegistry;
import javax.microedition.io.file.IllegalModeException;
import javax.microedition.rms.RecordStore;

/** Runs only inside the production interpreter; compile contracts are separate. */
public class OptionalFilesNetworkChecks {
    private static int checks;
    private static int events;
    private static void check(boolean ok) {
        if (!ok) throw new RuntimeException("optional files/network check " + checks);
        checks++;
    }
    private static class Listener implements FileSystemListener {
        public void rootChanged(int state, String name) { events++; }
    }
    public static int files() throws Exception {
        checks = 0;
        Enumeration roots = FileSystemRegistry.listRoots();
        check(roots != null && !roots.hasMoreElements());
        boolean exhausted = false;
        try { roots.nextElement(); } catch (NoSuchElementException e) { exhausted = true; }
        check(exhausted);
        check(!FileSystemRegistry.listRoots().hasMoreElements());
        boolean rejected = false;
        try { FileSystemRegistry.addFileSystemListener(null); } catch (NullPointerException e) { rejected = true; }
        check(rejected);
        rejected = false;
        try { FileSystemRegistry.removeFileSystemListener(null); } catch (NullPointerException e) { rejected = true; }
        check(rejected);
        Listener listener = new Listener();
        check(!FileSystemRegistry.removeFileSystemListener(listener));
        check(!FileSystemRegistry.addFileSystemListener(listener));
        check(!FileSystemRegistry.addFileSystemListener(listener));
        check(!FileSystemRegistry.listRoots().hasMoreElements() && events == 0);
        check(!FileSystemRegistry.removeFileSystemListener(listener));
        check(!FileSystemRegistry.removeFileSystemListener(listener));
        rejected = false;
        try { FileConnection file = (FileConnection) Connector.open("file:///root1/data.bin"); }
        catch (ConnectionNotFoundException e) { rejected = true; }
        check(rejected && events == 0);
        rejected = false;
        try { Connector.openOutputStream("file:///root1/data.bin"); }
        catch (IOException e) { rejected = true; }
        check(rejected);
        check("closed".equals(new ConnectionClosedException("closed").getMessage()));
        check(new ConnectionClosedException() instanceof RuntimeException);
        check("mode".equals(new IllegalModeException("mode").getMessage()));
        check(new IllegalModeException() instanceof RuntimeException);
        return checks;
    }
    public static int network() throws Exception {
        checks = 0;
        boolean rejected = false;
        try { HttpsConnection https = (HttpsConnection) Connector.open("https://example.invalid/"); }
        catch (IOException e) { rejected = true; }
        check(rejected);
        rejected = false;
        try { Connector.open("http://example.invalid/", Connector.READ); }
        catch (ConnectionNotFoundException e) { rejected = true; }
        check(rejected);
        rejected = false;
        try { Connector.openInputStream("https://example.invalid/"); }
        catch (ConnectionNotFoundException e) { rejected = true; }
        check(rejected);
        rejected = false;
        try { Connector.open("http://example.invalid/", 0); }
        catch (IllegalArgumentException e) { rejected = true; }
        check(rejected);
        rejected = false;
        try { Connector.open(null); } catch (IllegalArgumentException e) { rejected = true; }
        check(rejected);
        return checks;
    }
    public static int resourcesRms() throws Exception {
        checks = 0;
        InputStream resource = Connector.openInputStream("files-network.bin");
        check(resource.read() == 1 && resource.read() == 35 && resource.read() == -1);
        resource.close();
        RecordStore store = RecordStore.openRecordStore("OptionalFilesNet", true);
        int id = store.addRecord(new byte[] {7, 42}, 0, 2);
        store.closeRecordStore();
        store = RecordStore.openRecordStore("OptionalFilesNet", false);
        byte[] bytes = store.getRecord(id);
        check(bytes.length == 2 && bytes[0] == 7 && bytes[1] == 42);
        check(store.getNumRecords() == 1);
        store.closeRecordStore();
        RecordStore.deleteRecordStore("OptionalFilesNet");
        return checks;
    }
    public static int push() throws Exception {
        checks = 0;
        check(PushRegistry.listConnections(false).length == 0);
        check(PushRegistry.listConnections(true).length == 0);
        check(PushRegistry.getMIDlet("socket://:1234") == null);
        check(PushRegistry.getFilter("socket://:1234") == null);
        check(PushRegistry.getMIDlet(null) == null && PushRegistry.getFilter(null) == null);
        check(!PushRegistry.unregisterConnection(null));
        check(!PushRegistry.unregisterConnection("socket://:1234"));
        boolean rejected = false;
        try { PushRegistry.registerConnection("socket://:1234", "OptionalFilesNetworkChecks", "*"); }
        catch (ConnectionNotFoundException e) { rejected = true; }
        check(rejected);
        rejected = false;
        try { PushRegistry.registerAlarm("OptionalFilesNetworkChecks", 123456789L); }
        catch (ConnectionNotFoundException e) { rejected = true; }
        check(rejected);
        rejected = false;
        try { PushRegistry.registerAlarm("OptionalFilesNetworkChecks", 0); }
        catch (ConnectionNotFoundException e) { rejected = true; }
        check(rejected);
        rejected = false;
        try { PushRegistry.registerConnection(null, "OptionalFilesNetworkChecks", "*"); }
        catch (IllegalArgumentException e) { rejected = true; }
        check(rejected);
        rejected = false;
        try { PushRegistry.registerConnection("socket://:1234", "OptionalFilesNetworkChecks", null); }
        catch (IllegalArgumentException e) { rejected = true; }
        check(rejected);
        rejected = false;
        try { PushRegistry.registerConnection("invalid", "OptionalFilesNetworkChecks", "*"); }
        catch (IllegalArgumentException e) { rejected = true; }
        check(rejected);
        rejected = false;
        try { PushRegistry.registerConnection("socket://:1234", null, "*"); }
        catch (ClassNotFoundException e) { rejected = true; }
        check(rejected);
        rejected = false;
        try { PushRegistry.registerAlarm(null, 0); }
        catch (ClassNotFoundException e) { rejected = true; }
        check(rejected);
        rejected = false;
        try { PushRegistry.registerConnection("", "OptionalFilesNetworkChecks", "*"); }
        catch (IllegalArgumentException e) { rejected = true; }
        check(rejected);
        rejected = false;
        try { PushRegistry.registerConnection("socket://:1234", "OptionalFilesNetworkChecks", ""); }
        catch (IllegalArgumentException e) { rejected = true; }
        check(rejected);
        rejected = false;
        try { PushRegistry.registerAlarm("", 0); }
        catch (ClassNotFoundException e) { rejected = true; }
        check(rejected);
        rejected = false;
        try { PushRegistry.registerConnection("bad scheme://:1234", "OptionalFilesNetworkChecks", "*"); }
        catch (IllegalArgumentException e) { rejected = true; }
        check(rejected);
        rejected = false;
        try { PushRegistry.registerConnection("1socket://:1234", "OptionalFilesNetworkChecks", "*"); }
        catch (IllegalArgumentException e) { rejected = true; }
        check(rejected);
        check(PushRegistry.listConnections(false).length == 0 && !PushRegistry.unregisterConnection("socket://:1234"));
        return checks;
    }
    public static int datagram() throws Exception {
        checks = 0;
        boolean rejected = false;
        try { DatagramConnection d = (DatagramConnection) Connector.open("datagram://example.invalid:1234"); }
        catch (ConnectionNotFoundException e) { rejected = true; }
        check(rejected);
        return checks;
    }
}
