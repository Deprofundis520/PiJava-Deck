import javax.microedition.lcdui.*;
/** The same fixture is valid against Fit8 and the candidate frozen libraries. */
public final class Core48UiLegacyChecks {
 public static int setup(int strings) {
  Form form=new Form("legacy");
  if(strings!=0)form.append(new StringItem("label","unchanged default font"));
  else form.append(new TextField("number","12",8,TextField.NUMERIC));
  form.append(new Gauge("gauge",true,10,2));
  Display.getDisplay(null).setCurrent(form);return 1;
 }
}
