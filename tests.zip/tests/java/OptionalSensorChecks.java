import javax.microedition.sensor.*;

/** Game-style fixture executed only on the emulator VM. */
public final class OptionalSensorChecks implements SensorListener, DataAndErrorListener, ConditionListener {
    private static int callbacks;
    public void sensorAvailable(SensorInfo info) { callbacks++; }
    public void sensorUnavailable(SensorInfo info) { callbacks++; }
    public void dataReceived(SensorConnection sensor, Data[] data, boolean lost) { callbacks++; }
    public void errorReceived(SensorConnection sensor, int error, long time) { callbacks++; }
    public void conditionMet(SensorConnection sensor, Data data, Condition condition) { callbacks++; }
    private static void check(boolean value, String reason) {
        if (!value) throw new RuntimeException(reason);
    }
    public static int discovery() {
        check(SensorManager.findSensors(null, null).length == 0, "no devices");
        check(SensorManager.findSensors("acceleration", null).length == 0, "quantity lookup");
        check(SensorManager.findSensors(null, SensorInfo.CONTEXT_TYPE_USER).length == 0, "context lookup");
        check(SensorManager.findSensors("acceleration", SensorInfo.CONTEXT_TYPE_USER).length == 0, "game lookup");
        check(SensorManager.findSensors("sensor:acceleration").length == 0, "URL lookup");
        check(SensorManager.findSensors("sensor:acceleration;contextType=user;model=default;location=phone").length == 0, "qualified URL");
        check(SensorManager.findSensors("sensor:unknown").length == 0, "unknown quantity has no device");
        check(SensorManager.findSensors("sensor:acceleration;model=").length == 0, "empty model is valid selector");
        check(SensorManager.findSensors("sensor:acceleration;location=").length == 0, "empty location is valid selector");
        check(System.getProperty("microedition.sensor.version") == null, "hardware version remains unadvertised");
        return 8;
    }
    public static int gameFallback() throws Exception {
        Class.forName("javax.microedition.sensor.SensorManager");
        SensorInfo[] infos = SensorManager.findSensors("acceleration", "user");
        String sensorUrl = null;
        for (int i = 0; i < infos.length; i++) sensorUrl = infos[i].getUrl();
        check(infos.length == 0, "discovery yields empty array");
        check(sensorUrl == null, "game keeps button input fallback");
        check(callbacks == 0, "no values or events fabricated");
        return 3;
    }
    private static void invalidUrl(String url) {
        try { SensorManager.findSensors(url); }
        catch (IllegalArgumentException expected) { return; }
        throw new RuntimeException("invalid sensor URL accepted");
    }
    public static int validation() {
        int count = 0;
        try { SensorManager.findSensors((String)null); }
        catch (NullPointerException expected) { count++; }
        String[] invalid = { "", "acceleration", "sensor:", "sensor:acceleration:bad", "sensor:acceleration;contextType=bad", "sensor:acceleration;unknown=value", "sensor:acceleration;model", "sensor:acceleration?model=x" };
        for (int i = 0; i < invalid.length; i++) { invalidUrl(invalid[i]); count++; }
        invalidUrl("sensor:acceleration;");
        invalidUrl("sensor:acceleration;model=x;model=y");
        invalidUrl("sensor:acceleration;location=x;model=y");
        invalidUrl("sensor:acceleration;model=x-y");
        try { SensorManager.findSensors(null, "bad"); }
        catch (IllegalArgumentException expected) { count++; }
        try { SensorManager.findSensors("acceleration", "bad"); }
        catch (IllegalArgumentException expected) { count++; }
        check(SensorManager.findSensors("", null).length == 0, "empty quantity has no matching sensor");
        count++;
        return count;
    }
    public static int listeners() {
        int count = 0;
        OptionalSensorChecks listener = new OptionalSensorChecks();
        try { SensorManager.addSensorListener(null, "acceleration"); }
        catch (NullPointerException expected) { count++; }
        try { SensorManager.addSensorListener(listener, (String)null); }
        catch (NullPointerException expected) { count++; }
        try { SensorManager.addSensorListener(null, (SensorInfo)null); }
        catch (NullPointerException expected) { count++; }
        try { SensorManager.addSensorListener(listener, (SensorInfo)null); }
        catch (NullPointerException expected) { count++; }
        try { SensorManager.removeSensorListener(null); }
        catch (NullPointerException expected) { count++; }
        try { SensorManager.addSensorListener(listener, new ForeignSensorInfo()); }
        catch (IllegalArgumentException expected) { count++; }
        SensorManager.addSensorListener(listener, "acceleration");
        SensorManager.addSensorListener(listener, "acceleration");
        SensorManager.addSensorListener(listener, "unknown");
        SensorManager.removeSensorListener(listener);
        SensorManager.removeSensorListener(listener);
        check(callbacks == 0, "no registered device means no callbacks");
        return count; // Six required argument errors, no discovery notifications.
    }
    public static int values() {
        MeasurementRange range = new MeasurementRange(-10, 10, 0.5);
        check(range.getSmallestValue() == -10, "range minimum retained");
        check(range.getLargestValue() == 10, "range maximum retained");
        check(range.getResolution() == 0.5, "range resolution retained");
        check(new MeasurementRange(2, 2, 0).getResolution() == 0, "equal endpoints and zero resolution");
        int count = 4;
        try { new MeasurementRange(3, 2, 1); }
        catch (IllegalArgumentException expected) { count++; }
        try { new MeasurementRange(1, 2, -1); }
        catch (IllegalArgumentException expected) { count++; }
        check(Unit.getUnit("m/s^2").toString().equals("m/s^2"), "unit symbol retained");
        boolean nullRejected = false;
        boolean emptyRejected = false;
        try { Unit.getUnit(null); }
        catch (NullPointerException expected) { nullRejected = true; }
        try { Unit.getUnit(""); }
        catch (IllegalArgumentException expected) { emptyRejected = true; }
        check(nullRejected && emptyRejected, "null and empty unit symbols rejected");
        check(Unit.getUnit("m/s^2") == Unit.getUnit(new String("m/s^2")), "unit factory returns canonical instance by symbol content");
        check(Unit.getUnit("m") != Unit.getUnit("s"), "different symbols retain different units");
        return count + 1;
    }
    /** Foreign metadata is never an available platform device. */
    private static final class ForeignSensorInfo implements SensorInfo {
        public ChannelInfo[] getChannelInfos() { return new ChannelInfo[0]; }
        public int getConnectionType() { return CONN_EMBEDDED; }
        public String getContextType() { return CONTEXT_TYPE_USER; }
        public String getDescription() { return "foreign test metadata"; }
        public int getMaxBufferSize() { return 1; }
        public String getModel() { return "foreign"; }
        public Object getProperty(String name) { throw new IllegalArgumentException(); }
        public String[] getPropertyNames() { return new String[0]; }
        public String getQuantity() { return "acceleration"; }
        public String getUrl() { return "sensor:acceleration"; }
        public boolean isAvailabilityPushSupported() { return false; }
        public boolean isAvailable() { return false; }
        public boolean isConditionPushSupported() { return false; }
    }
}
