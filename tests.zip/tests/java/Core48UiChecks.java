import javax.microedition.lcdui.*;
public final class Core48UiChecks {
 static Display d; static Form form; static Probe probe,second; static StringItem string;
 public static int paints,shows,hides,sizes,traverses,outs,presses,releases,mode,paintWidth,paintHeight,clips;
 static void check(boolean b,String message){if(!b)throw new RuntimeException(message);}
 public static int focus(){
  d=Display.getDisplay(null); Form other=new Form("other"); d.setCurrent(other);
  boolean rejected=false;try{d.setCurrentItem(null);}catch(NullPointerException e){rejected=true;}check(rejected&&d.getCurrent()==other,"null current item atomic");
  StringItem loose=new StringItem(null,"loose");rejected=false;try{d.setCurrentItem(loose);}catch(IllegalStateException e){rejected=true;}check(rejected&&d.getCurrent()==other,"unowned item atomic");
  Gauge gauge=new Gauge(null,false,10,2);Alert alert=new Alert("alert");alert.setIndicator(gauge);rejected=false;try{d.setCurrentItem(gauge);}catch(IllegalStateException e){rejected=true;}check(rejected,"alert item rejected");
  form=new Form("focus");TextField first=new TextField(null,"",8,TextField.NUMERIC),last=new TextField(null,"",8,TextField.NUMERIC);form.append(first);for(int i=0;i<20;i++)form.append("filler");form.append(last);
  d.setCurrentItem(last);check(d.getCurrent()==form,"owner made current");form.keyPressed(49);check(first.getString().equals("")&&last.getString().equals("1"),"last item focus/input");
  Form detached=new Form("detach");detached.append(loose);detached.delete(0);rejected=false;try{d.setCurrentItem(loose);}catch(IllegalStateException e){rejected=true;}check(rejected,"deleted owner cleared");return 1;
 }
 public static int strings(){
  check(new StringItem(null,null).getAppearanceMode()==Item.PLAIN,"plain default");for(int i=0;i<3;i++)check(new StringItem(null,null,i).getAppearanceMode()==i,"legal appearance");
  boolean rejected=false;try{new StringItem(null,null,-1);}catch(IllegalArgumentException e){rejected=true;}check(rejected,"negative appearance");rejected=false;try{new StringItem(null,null,3);}catch(IllegalArgumentException e){rejected=true;}check(rejected,"bad appearance");
  string=new StringItem(null,"MMM",Item.BUTTON);Font f=Font.getFont(Font.FACE_SYSTEM,Font.STYLE_BOLD,Font.SIZE_LARGE);string.setFont(f);check(string.getFont()==f,"font identity");string.setFont(null);check(string.getFont()!=null&&string.getFont().getSize()==Font.SIZE_MEDIUM,"null default font");string.setFont(f);form=new Form("font");form.append(string);Display.getDisplay(null).setCurrent(form);return 1;
 }
 public static int custom(){
  d=Display.getDisplay(null);probe=new Probe("label");check(probe.getMinimumWidth()>=17&&probe.getMinimumHeight()>=13,"content minimum");check(probe.getPreferredWidth()>=70&&probe.getPreferredHeight()>=32,"preferred callbacks");
  probe.setPreferredSize(1,1);check(probe.getPreferredWidth()>=probe.getMinimumWidth()&&probe.getPreferredHeight()>=probe.getMinimumHeight(),"locked size clamps minimum");probe.setPreferredSize(-1,-1);
  check(probe.modes()==15,"honest traversal press/release capabilities");check(probe.getGameAction(53)==Canvas.FIRE&&probe.getGameAction(48)==0,"game key mapping");boolean rejected=false;try{probe.getGameAction(99999);}catch(IllegalArgumentException e){rejected=true;}check(rejected,"invalid key code");
  form=new Form("custom");form.append(probe);second=new Probe(null);form.append(second);d.setCurrentItem(probe);return 1;
 }
 public static int edgePaints,edgeShows,edgeHides,edgeHiddenPaints;
 public static int edge(){
  d=Display.getDisplay(null);form=new Form("edge");form.append(new Edge());
  for(int i=0;i<10;i++)form.append("ordinary");d.setCurrent(form);return 1;
 }
 public static void edgeScroll(){d.setCurrentItem(form.get(10));}
 static final class Edge extends CustomItem {
  boolean shown;Edge(){super(null);}
  protected int getMinContentWidth(){return 10;}protected int getMinContentHeight(){return 10;}
  protected int getPrefContentWidth(int h){return 10;}protected int getPrefContentHeight(int w){return 10;}
  protected void showNotify(){shown=true;edgeShows++;}protected void hideNotify(){shown=false;edgeHides++;}
  protected void paint(Graphics g,int w,int h){edgePaints++;if(!shown)edgeHiddenPaints++;g.setColor(0x37BC69);g.fillRect(0,0,w,h);}
 }
 public static void invalidateProbe(){probe.height=80;probe.resize();}
 public static void repaintProbe(){probe.refresh();}
 public static void focusSecond(){d.setCurrentItem(second);}
 public static void hide(){d.setCurrent(new Form("hidden"));}
 public static void remove(){form.delete(0);}
 public static void focusProbe(){d.setCurrentItem(probe);}
 public static void reparent(){form=new Form("parent2");form.append(probe);d.setCurrentItem(probe);}
 public static void replace(){form.set(0,new StringItem(null,"replacement"));}
 public static void clearReattach(){form.deleteAll();form.append(probe);d.setCurrentItem(probe);}
 public static void tall(){probe.height=600;probe.resize();}
 static final class Probe extends CustomItem {
  int height=32,step,lastWidth,lastHeight; Probe(String l){super(l);}
  protected int getMinContentWidth(){return 17;}protected int getMinContentHeight(){return 13;}
  protected int getPrefContentWidth(int h){return 70;}protected int getPrefContentHeight(int w){return height;}
  int modes(){return getInteractionModes();}void resize(){invalidate();}void refresh(){repaint(0,0,1,1);}
  protected void sizeChanged(int w,int h){sizes++;paintWidth=w;paintHeight=h;lastWidth=w;lastHeight=h;}
  protected void showNotify(){shows++;}protected void hideNotify(){hides++;}
  protected boolean traverse(int dir,int w,int h,int[] r){traverses++;if(dir==NONE){step=0;return true;}if(dir==Canvas.DOWN&&step++==0){r[1]=height>300?height-10:0;r[2]=10;r[3]=10;return true;}return false;}
  protected void traverseOut(){outs++;}
  protected void keyPressed(int code){presses++;refresh();}protected void keyReleased(int code){releases++;}
  protected void paint(Graphics g,int w,int h){paints++;check(w==lastWidth&&h==lastHeight,"size before paint");check(g.getTranslateX()==0&&g.getTranslateY()==0&&g.getColor()==0&&g.getStrokeStyle()==Graphics.SOLID,"fresh graphics context");clips=g.getClipWidth()*g.getClipHeight();g.setClip(-100,-100,w+200,h+200);g.setColor(0xD03070);g.fillRect(-100,-100,w+200,h+200);g.translate(15,25);g.setFont(Font.getFont(0,1,16));}
 }
}
