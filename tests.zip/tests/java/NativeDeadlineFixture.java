import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Graphics;

public class NativeDeadlineFixture extends Canvas implements Runnable {
    public static byte period = 70;
    public static volatile byte volatilePeriod = 70;
    public static int updates, paints, mode;
    public static boolean active;
    protected void paint(Graphics graphics) {
        paints++;
        graphics.setColor(updates);
        graphics.fillRect(0, 0, 8, 8);
    }
    public static void start(int selected) {
        updates = paints = 0; mode = selected; period = volatilePeriod = 70; active = true;
        NativeDeadlineFixture canvas = new NativeDeadlineFixture();
        Display.getDisplay(null).setCurrent(canvas);
        if (mode == 3) new Thread(new Peer()).start();
        new Thread(canvas).start();
    }
    public void run() {
        if (mode == 4) locked(); else loop();
    }
    private synchronized void locked() { loop(); }
    private void loop() {
        while (active) {
            long start = System.currentTimeMillis();
            updates++;
            if (mode != 5) { repaint(); serviceRepaints(); }
            if (mode == 2) period = (byte)((updates & 1) == 0 ? 35 : 70);
            if (mode == 1) {
                while (start + volatilePeriod > System.currentTimeMillis()) Thread.yield();
            } else {
                while (start + period > System.currentTimeMillis()) Thread.yield();
            }
        }
    }
    private static class Peer implements Runnable {
        public void run() { while (active) { try { Thread.sleep(1); } catch (InterruptedException ignored) {} } }
    }
}
