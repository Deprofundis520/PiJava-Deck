/** Standard API calls executed only by the custom VM test harness. */
public final class OptionalStandardApiChecks {
    private static int assertions;
    public static int run() throws Exception { return doubles() + exceptions(); }
    private static void check(boolean condition, String reason) {
        assertions++;
        if (!condition) throw new RuntimeException(reason);
    }
    public static int doubles() {
        assertions = 0;
        double[] values = {1.25, -42.75, 0.0, -0.0, 1.0e20, 1.0e-9,
                0.0/0.0, 1.0/0.0, -1.0/0.0};
        for (int i = 0; i < values.length; i++) {
            String expected = String.valueOf(values[i]);
            check(Double.toString(values[i]).equals(expected), "Double static formatting matches String conversion");
            check(Double.toString(values[i]).equals(new Double(values[i]).toString()), "Double static and instance conversion agree");
        }
        return assertions;
    }
    private static void unsupported(String message) {
        throw new UnsupportedOperationException(message);
    }
    public static int exceptions() throws Exception {
        assertions = 0;
        check(Class.forName("java.lang.UnsupportedOperationException") == UnsupportedOperationException.class,
                "standard exception is loadable by its qualified name");
        UnsupportedOperationException empty = new UnsupportedOperationException();
        check(empty.getMessage() == null, "default exception message is null");
        check(empty instanceof RuntimeException, "standard exception extends RuntimeException");
        check(empty.toString().equals("java.lang.UnsupportedOperationException"), "default exception type formatting");
        try { throw empty; }
        catch (UnsupportedOperationException expected) {
            check(expected == empty, "exact exception catch preserves identity");
        }
        try { unsupported("operation unavailable 中文"); }
        catch (RuntimeException expected) {
            check(expected instanceof UnsupportedOperationException, "exception is catchable through RuntimeException");
            check(expected.getMessage().equals("operation unavailable 中文"), "message constructor preserves Unicode detail");
        }
        UnsupportedOperationException nullMessage = new UnsupportedOperationException((String)null);
        check(nullMessage.getMessage() == null, "explicit null message preserved");
        return assertions;
    }
}
