import java.util.Hashtable;
import java.util.Enumeration;
import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Graphics;

public class StringIndexChecks {
    static Hashtable saved;
    static String savedKey;
    static int checks, calls;
    static int seed = 0x220cafe;
    static void check(boolean yes) { if (!yes) throw new RuntimeException("String index " + checks); checks++; }
    static int next() { seed = seed * 1664525 + 1013904223; return seed & 0x7fffffff; }
    static String key(int i) { return new String(new char[]{(char)(i >> 8), (char)i}); }
    static class SideKey {
        boolean bad;
        SideKey(boolean bad) { this.bad = bad; }
        public boolean equals(Object other) {
            calls++;
            if (bad) throw new IllegalArgumentException("observed stored-key callback");
            return "needle".equals(other);
        }
        public int hashCode() { throw new RuntimeException("legacy find does not call hashCode"); }
    }
    static class SubString extends String {
        SubString() { super(new char[]{'s','u','b'}); }
        public boolean equals(Object other) { calls++; return super.equals(other); }
    }
    static class SubTable extends Hashtable {}
    public static int run() {
        Hashtable h = new Hashtable(1);
        String[] keys = new String[96]; Object[] vals = new Object[96]; int count = 0;
        for (int i=0;i<6000;i++) {
            int choice=next()%5; String k=key(next()%91); int at=-1;
            for(int j=0;j<count;j++)if(keys[j].equals(k)){at=j;break;}
            if(choice<2){Object val=new Integer(i);check(h.put(k,val)==(at<0?null:vals[at]));if(at<0){keys[count]=k;vals[count++]=val;}else vals[at]=val;}
            else if(choice==2){check(h.remove(k)==(at<0?null:vals[at]));if(at>=0){for(int j=at;j<count-1;j++){keys[j]=keys[j+1];vals[j]=vals[j+1];}keys[--count]=null;vals[count]=null;}}
            else{check(h.get(k)==(at<0?null:vals[at]));check(h.containsKey(k)==(at>=0));}
            check(h.size()==count);
            if(i%97==0){Enumeration e=h.keys(),v=h.elements();for(int j=0;j<count;j++){check(e.hasMoreElements()&&v.hasMoreElements());check(e.nextElement()==keys[j]&&v.nextElement()==vals[j]);}check(!e.hasMoreElements()&&!v.hasMoreElements());}
            if(i%503==0){h.clear();count=0;check(h.isEmpty());}
        }
        h.clear();String[] edges={"", "FB", "Ea", "Aa", "BB", "\u0000", "\u4e2d\u6587", "\ud800", "\udfff", "\ud83d\ude00"};
        for(int i=0;i<edges.length;i++)h.put(new String(edges[i]),new Integer(i));
        for(int i=0;i<edges.length;i++)check(((Integer)h.get(new String(edges[i]))).intValue()==i);
        h.put(new Integer(42),"int");h.put(new Character('x'),"char");h.put(new Long(42),"long");
        check("int".equals(h.get(new Integer(42)))&&"char".equals(h.get(new Character('x')))&&"long".equals(h.get(new Long(42))));
        check(h.get("42")==null&&((Integer)h.get("FB")).intValue()==1);
        h.clear();h.put(new SideKey(false),"callback");h.put("plain","plain");calls=0;
        check("callback".equals(h.get(new String("needle")))&&calls==1);
        calls=0;check("plain".equals(h.get(new String("plain")))&&calls==1);
        h.clear();h.put(new SideKey(true),"bad");calls=0;
        try{h.get("plain");check(false);}catch(IllegalArgumentException expected){check(calls==1);}
        calls=0;try{h.put("plain",null);check(false);}catch(NullPointerException expected){check(calls==0);}
        for(int i=0;i<3;i++){try{if(i==0)h.get(null);else if(i==1)h.containsKey(null);else h.remove(null);check(false);}catch(NullPointerException expected){checks++;}}
        h.clear();h.put(new SubString(),"subclass");calls=0;check("subclass".equals(h.get(new String("sub")))&&calls==1);
        h.clear();h.put("sub","base");calls=0;check("base".equals(h.get(new SubString()))&&calls==0);
        h=new SubTable();h.put("a","subtable");check("subtable".equals(h.get(new String("a"))));
        char[] large=new char[1025];for(int i=0;i<large.length;i++)large[i]='x';String longKey=new String(large);
        h=new Hashtable();h.put("plain","short");h.put(longKey,"long");check("long".equals(h.get(new String(large)))&&"short".equals(h.get(new String("plain"))));
        return checks;
    }
    public static void setup() { saved=new Hashtable();savedKey=new String(new char[]{'a','l','p','h','a'});saved.put(savedKey,"value");saved.put("second","two"); }
    public static int verify() { return "value".equals(saved.get(new String("alpha")))&&"two".equals(saved.get(new String("second")))?1:0; }
    public static void drop() { saved=null;savedKey=null; }
}
class StringIndexCanvas extends Canvas { protected void paint(Graphics g) {} }
