import javax.bluetooth.*;
import javax.microedition.io.Connection;
import java.util.Enumeration;
import java.io.IOException;

/** Portable SDP values and deliberately unavailable radio; actual PiJava consumer. */
public final class OptionalBluetoothChecks {
    private static int count;
    private static void check(boolean ok, String why) { count++; if (!ok) throw new RuntimeException(why); }
    public static int numeric() {
        count=0;
        int[] types={8,9,10,16,17,18,19};
        long[] lo={0,0,0,-128,-32768,-2147483648L,Long.MIN_VALUE};
        long[] hi={255,65535,4294967295L,127,32767,2147483647L,Long.MAX_VALUE};
        for(int i=0;i<types.length;i++) {
            check(new DataElement(types[i],lo[i]).getLong()==lo[i],"numeric minimum");
            check(new DataElement(types[i],hi[i]).getLong()==hi[i],"numeric maximum");
            check(new DataElement(types[i],0).getDataType()==types[i],"numeric type");
            if(i<6) {
                try { new DataElement(types[i],lo[i]-1); check(false,"underflow"); } catch(IllegalArgumentException e) { check(true,"underflow rejected"); }
                try { new DataElement(types[i],hi[i]+1); check(false,"overflow"); } catch(IllegalArgumentException e) { check(true,"overflow rejected"); }
            }
        }
        int[] bad={-1,0,11,12,20,24,32,40,48,56,64,99};
        for(int i=0;i<bad.length;i++) try { new DataElement(bad[i],0L); check(false,"wrong long type"); } catch(IllegalArgumentException e) { check(true,"wrong long type rejected"); }
        check(new DataElement(true).getBoolean()&&!new DataElement(false).getBoolean(),"boolean values");
        check(new DataElement(true).getDataType()==DataElement.BOOL,"boolean type");
        try { new DataElement(true).getLong(); check(false,"boolean long"); } catch(ClassCastException e) { check(true,"boolean long rejected"); }
        try { new DataElement(8,0L).getBoolean(); check(false,"number boolean"); } catch(ClassCastException e) { check(true,"number boolean rejected"); }
        try { new DataElement(8,0L).getValue(); check(false,"number object"); } catch(ClassCastException e) { check(true,"number object rejected"); }
        return count;
    }
    public static int objects() {
        count=0;
        check(new DataElement(DataElement.NULL).getDataType()==0,"null type");
        try { new DataElement(0).getValue(); check(false,"null getValue"); } catch(ClassCastException e) { check(true,"null has no object value"); }
        check(new DataElement(32,"name").getValue().equals("name"),"string");
        check(new DataElement(64,"btspp://value").getValue().equals("btspp://value"),"URL is portable data");
        UUID uuid=new UUID(0x1101L);
        check(new DataElement(24,uuid).getValue().equals(uuid),"UUID value");
        int[] types={11,12,20};
        for(int i=0;i<types.length;i++) {
            int len=i==0?8:16; byte[] original=new byte[len]; original[0]=7; original[len-1]=-1;
            DataElement data=new DataElement(types[i],original); original[0]=9;
            byte[] first=(byte[])data.getValue(); check(first[0]==7&&first[len-1]==-1,"constructor copies bytes");
            first[0]=12; byte[] second=(byte[])data.getValue(); check(second!=first&&second[0]==7,"getter copies bytes");
            check(data.getDataType()==types[i],"large integer type");
            try { new DataElement(types[i],new byte[len-1]); check(false,"wrong length"); } catch(IllegalArgumentException e) { check(true,"wrong length rejected"); }
            try { data.getLong(); check(false,"large long"); } catch(ClassCastException e) { check(true,"large integer requires bytes"); }
        }
        int[] bad={0,8,9,10,16,17,18,19,40,48,56,99};
        for(int i=0;i<bad.length;i++) try { new DataElement(bad[i],new Object()); check(false,"wrong object type"); } catch(IllegalArgumentException e) { check(true,"wrong object type rejected"); }
        int[] objectTypes={11,12,20,24,32,64};
        for(int i=0;i<objectTypes.length;i++) {
            try { new DataElement(objectTypes[i],null); check(false,"null object"); } catch(IllegalArgumentException e) { check(true,"null object rejected"); }
            try { new DataElement(objectTypes[i],new Object()); check(false,"wrong payload"); } catch(IllegalArgumentException e) { check(true,"wrong payload rejected"); }
        }
        try { new DataElement(32); check(false,"wrong empty type"); } catch(IllegalArgumentException e) { check(true,"wrong empty type rejected"); }
        return count;
    }
    public static int sequence() {
        count=0;
        for(int t=48;t<=56;t+=8) {
            DataElement seq=new DataElement(t), a=new DataElement(32,"a"), b=new DataElement(true);
            check(seq.getSize()==0,"empty sequence");
            seq.addElement(a); seq.insertElementAt(b,0); seq.insertElementAt(a,2);
            Enumeration e=(Enumeration)seq.getValue();
            check(e.nextElement()==b&&e.nextElement()==a&&e.nextElement()==a&&!e.hasMoreElements(),"ordered references and duplicate sequence elements");
            check(seq.getSize()==3&&seq.removeElement(a)&&seq.getSize()==2,"remove first matching reference");
            check(seq.removeElement(a)&&!seq.removeElement(a),"absent removal false");
            DataElement inner=new DataElement(48); seq.addElement(inner); inner.addElement(a);
            Enumeration outer=(Enumeration)seq.getValue(); outer.nextElement();
            check(((DataElement)outer.nextElement()).getSize()==1,"sequence intentionally retains element references");
            try { seq.addElement(null); check(false,"null append"); } catch(NullPointerException x) { check(true,"null append rejected"); }
            try { seq.removeElement(null); check(false,"null removal"); } catch(NullPointerException x) { check(true,"null removal rejected"); }
            try { seq.insertElementAt(null,0); check(false,"null insert"); } catch(NullPointerException x) { check(true,"null insert rejected"); }
            try { seq.insertElementAt(a,-1); check(false,"negative index"); } catch(IndexOutOfBoundsException x) { check(true,"negative index rejected"); }
            try { seq.insertElementAt(a,seq.getSize()+1); check(false,"large index"); } catch(IndexOutOfBoundsException x) { check(true,"large index rejected"); }
            try { seq.getLong(); check(false,"sequence long"); } catch(ClassCastException x) { check(true,"sequence long rejected"); }
        }
        DataElement scalar=new DataElement(false), a=new DataElement(0);
        try { scalar.addElement(a); check(false,"scalar add"); } catch(ClassCastException e) { check(true,"scalar add rejected"); }
        try { scalar.insertElementAt(a,0); check(false,"scalar insert"); } catch(ClassCastException e) { check(true,"scalar insert rejected"); }
        try { scalar.removeElement(a); check(false,"scalar remove"); } catch(ClassCastException e) { check(true,"scalar remove rejected"); }
        try { scalar.getSize(); check(false,"scalar size"); } catch(ClassCastException e) { check(true,"scalar size rejected"); }
        return count;
    }
    public static int fallback() {
        count=0; boolean offline=false;
        try {
            DataElement request=new DataElement(DataElement.STRING,"optional multiplayer");
            check(request.getValue().equals("optional multiplayer"),"portable data before radio acquisition");
            LocalDevice.getLocalDevice();
            check(false,"radio must not succeed");
        } catch(Exception expected) {
            check(expected instanceof BluetoothStateException,"radio absence reaches existing game exception handler");
            offline=true;
        }
        check(offline,"game continues into offline branch");
        return count;
    }
    private static final class Listener implements DiscoveryListener {
        int events;
        public void deviceDiscovered(RemoteDevice d,DeviceClass c){events++;}
        public void inquiryCompleted(int t){events++;}
        public void servicesDiscovered(int t,ServiceRecord[] r){events++;}
        public void serviceSearchCompleted(int t,int c){events++;}
    }
    private static final class Remote extends RemoteDevice { Remote(){super("001122334455");} }
    private static final class Dummy implements Connection { public void close(){} }
    private static final class ForeignRecord implements ServiceRecord {
        public DataElement getAttributeValue(int id){return null;}
        public int[] getAttributeIDs(){return new int[0];}
        public RemoteDevice getHostDevice(){return null;}
        public boolean populateRecord(int[] ids) throws IOException{return false;}
        public String getConnectionURL(int security,boolean master){return null;}
        public void setDeviceServiceClasses(int classes){}
        public boolean setAttributeValue(int id,DataElement value){return false;}
    }
    public static int unavailable(LocalDevice local) throws Exception {
        count=0; Listener listener=new Listener(); DiscoveryAgent agent=new DiscoveryAgent(); Remote remote=new Remote(); UUID uuid=new UUID(1L);
        boolean fallback=false; try { LocalDevice.getLocalDevice(); } catch(Exception e) { fallback=e instanceof BluetoothStateException; }
        check(fallback&&!LocalDevice.isPowerOn(),"game-style catch Exception selects offline branch");
        check(LocalDevice.getProperty("bluetooth.api.version")==null,"no capability advertised");
        try { LocalDevice.getProperty(null); check(false,"null property"); } catch(NullPointerException e) { check(true,"null property rejected"); }
        check(!agent.cancelInquiry(listener)&&!agent.cancelServiceSearch(7),"nothing to cancel");
        check(agent.retrieveDevices(0)==null&&agent.retrieveDevices(1)==null,"no invented devices");
        try { agent.startInquiry(DiscoveryAgent.GIAC,listener); check(false,"inquiry success"); } catch(BluetoothStateException e) { check(true,"inquiry unavailable"); }
        try { agent.searchServices(null,new UUID[]{uuid},remote,listener); check(false,"search success"); } catch(BluetoothStateException e) { check(true,"search unavailable"); }
        try { agent.selectService(uuid,0,false); check(false,"select success"); } catch(BluetoothStateException e) { check(true,"select unavailable"); }
        try { agent.startInquiry(0,listener); check(false,"bad inquiry access"); } catch(IllegalArgumentException e) { check(true,"bad inquiry rejected"); }
        try { agent.startInquiry(DiscoveryAgent.GIAC,null); check(false,"null listener"); } catch(NullPointerException e) { check(true,"null listener rejected"); }
        try { agent.cancelInquiry(null); check(false,"null cancel listener"); } catch(NullPointerException e) { check(true,"null cancel rejected"); }
        try { agent.retrieveDevices(-1); check(false,"bad retrieve option"); } catch(IllegalArgumentException e) { check(true,"bad retrieve rejected"); }
        try { agent.selectService(uuid,3,false); check(false,"bad security"); } catch(IllegalArgumentException e) { check(true,"bad security rejected"); }
        try { agent.selectService(null,0,false); check(false,"null UUID"); } catch(NullPointerException e) { check(true,"null UUID rejected"); }
        try { agent.searchServices(null,new UUID[0],remote,listener); check(false,"empty UUIDs"); } catch(IllegalArgumentException e) { check(true,"empty UUIDs rejected"); }
        try { agent.searchServices(null,new UUID[]{uuid,uuid},remote,listener); check(false,"duplicate UUIDs"); } catch(IllegalArgumentException e) { check(true,"duplicate UUIDs rejected"); }
        try { agent.searchServices(null,new UUID[]{null},remote,listener); check(false,"null UUID entry"); } catch(NullPointerException e) { check(true,"null UUID entry rejected"); }
        int[][] attrs={new int[0],{-1},{65536},{1,1}};
        for(int i=0;i<attrs.length;i++) try { agent.searchServices(attrs[i],new UUID[]{uuid},remote,listener); check(false,"bad attrs"); } catch(IllegalArgumentException e) { check(true,"bad attrs rejected"); }
        try { local.setDiscoverable(-1); check(false,"bad discoverable"); } catch(IllegalArgumentException e) { check(true,"bad discoverable rejected"); }
        try { local.setDiscoverable(0); check(false,"discoverable success"); } catch(BluetoothStateException e) { check(true,"discoverable unavailable"); }
        check(local.getDiscoverable()==0,"not discoverable");
        try { local.getRecord(null); check(false,"null notifier"); } catch(NullPointerException e) { check(true,"null notifier rejected"); }
        try { local.getRecord(new Dummy()); check(false,"invalid notifier"); } catch(IllegalArgumentException e) { check(true,"invalid notifier rejected"); }
        try { local.updateRecord(null); check(false,"null record"); } catch(NullPointerException e) { check(true,"null record rejected"); }
        try { local.updateRecord(new ForeignRecord()); check(false,"foreign record"); } catch(IllegalArgumentException e) { check(true,"foreign record rejected"); }
        check(new ServiceRegistrationException().getMessage()==null,"service exception default message");
        check(new ServiceRegistrationException("radio off").getMessage().equals("radio off"),"service exception message");
        try { throw new ServiceRegistrationException("unavailable"); } catch(IOException e) { check(e instanceof ServiceRegistrationException,"service exception catches as IOException"); }
        check(listener.events==0,"unavailable operations emit no discovery events");
        return count;
    }
}
