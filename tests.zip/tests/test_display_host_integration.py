#!/usr/bin/env python3
"""Compile production Switch display preparation with simulated backend state."""
from pathlib import Path
import os
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]
source = (ROOT / "src/platform/switch_host.inc").read_text()

def function(name):
    start = source.index("static void " + name + "(")
    brace = source.index("{", start)
    depth = 1
    end = brace + 1
    while depth:
        depth += (source[end] == "{") - (source[end] == "}")
        end += 1
    return source[start:end]

# Run the actual preparation statements before FPS/backend presentation.
start = source.index("    g_display_pixels=nullptr;", source.index("static void present()"))
end = source.index("    VMS_PLAT_LOCAL(fps_shown", start)
prepare = "static void prepare_display(){\n" + source[start:end] + "}\n"
harness = r'''
#include "src/host_display_preferences.h"
#include "src/host_display_menu.h"
#include "src/menu_actions.h"
#include "src/presentation/orientation.h"
#include "src/presentation/gpu_filter.h"
#include <cassert>
#include <iostream>
#define J2ME_ENABLE_DEKO3D 1
#define VMS_PLAT(x) x
#define VMS_RS(x) x
namespace resver { uint64_t g_epoch=1; }
enum class HostSurface { Game,Menu,Import };
HostSurface g_host_surface=HostSurface::Game;
host_menu::Settings g_menu_settings;
std::vector<uint8_t> g_fb;
int g_screen_w=3,g_screen_h=2,g_game_frames=1,g_cpu_cleared=3;
bool g_fb_dirty=false;
presentation::orientation::Cache g_orientation;
const std::vector<uint8_t>* g_display_pixels=nullptr;
int g_display_w=0,g_display_h=0;
struct Raw { int invalidations=0;void invalidate(){++invalidations;} };
struct Layers { Raw raw_frame; } g_gpu_layers;
struct Gpu { int invalidations=0;void invalidate_game(){++invalidations;} } g_gpu_present;
void log_line(const std::string&) {}
using u64=uint64_t;
constexpr u64 HidNpadButton_B=1,HidNpadButton_A=2,HidNpadButton_AnyUp=4,HidNpadButton_AnyDown=8;
struct Entry { std::string path,label; };
host_display_menu::Model g_display_menu;
menu_actions::Deletion g_menu_delete;
menu_actions::Repeat g_menu_repeat;
u64 g_chapter_blocked=0;
bool g_menu_note_error=false,g_menu_note_neutral=true;
struct Chapter { bool open=false;bool begin(const std::vector<Entry>& items,int){open=items.size()>1;return open;} } g_chapter_import;
namespace game_names { std::string strip_jar(const std::string& path){return path;} }
bool instant_state_exists(const std::string&){return false;}
bool delete_instant_state(const std::string&){return false;}
std::vector<Entry> scan_games(){return {};}
struct Names {struct Catalog {void invalidate_saved(){}} catalog;} g_menu_name_ui;
int menu_draws=0;
void draw_menu(const std::vector<Entry>&,int,const std::string&){++menu_draws;}
'''
harness += function("invalidate_display_preferences") + "\n"
harness += function("select_display_preferences") + "\n" + prepare
harness += function("update_display_menu") + "\n"
harness += function("update_menu_delete") + "\n"
harness += r'''
int main() {
    for(uint8_t n=1;n<=6;++n)for(int c=0;c<3;++c)g_fb.push_back(n+c*20);
    const auto original=g_fb;
    g_menu_settings.rotation=1;
    prepare_display();
    assert(g_display_w==2&&g_display_h==3);
    assert((*g_display_pixels)[0]==4&&(*g_display_pixels)[3]==1);
    assert(g_fb==original);
    std::vector<uint32_t> raw;
    assert(j2me_present::gpu_filter::pack(*g_display_pixels,g_display_w,g_display_h,
        display_filter::Filter::Bilinear,raw,true));
    const auto vp=j2me_present::game_viewport(g_display_w,g_display_h,true);
    assert(vp.w==480&&vp.h==720); // The same oriented geometry drives CPU and GPU viewport.
    const int invalidations=g_gpu_layers.raw_frame.invalidations;
    g_fb_dirty=false;g_cpu_cleared=3;
    prepare_display();
    assert(g_gpu_layers.raw_frame.invalidations==invalidations);
    g_menu_settings.rotation=3; // Same geometry, different pixels: texture must refresh.
    prepare_display();
    assert(g_display_w==2&&g_display_h==3);
    assert((*g_display_pixels)[0]==3&&(*g_display_pixels)[3]==6);
    assert(g_gpu_layers.raw_frame.invalidations==invalidations+1&&g_cpu_cleared==0);
    g_menu_settings.rotation=0;
    prepare_display();
    assert(g_display_pixels==&g_fb&&g_display_pixels->data()==g_fb.data());
    g_host_surface=HostSurface::Menu;
    prepare_display();
    assert(g_display_pixels==nullptr); // Browsing menus does not rotate an old framebuffer.
    char dir[]="/tmp/fit6-host-prefs-XXXXXX";assert(mkdtemp(dir));
    const std::string a=std::string(dir)+"/a.jar", b=std::string(dir)+"/b.jar";
    assert(host_display::save_rotation(a,3));
    assert(host_display::save_screen(a,480,800));
    select_display_preferences(a,true);
    assert(g_menu_settings.rotation==3);
    assert(host_menu::canvas_size(g_menu_settings.canvas)==std::make_pair(480,800));
    g_screen_w=480;g_screen_h=800;g_fb.assign(size_t(480)*800*3,123);
    g_fb[0]=7;g_fb[g_fb.size()-3]=9;g_host_surface=HostSurface::Game;
    prepare_display();
    assert(g_display_w==800&&g_display_h==480);
    assert((*g_display_pixels)[size_t(479)*800*3]==7&&(*g_display_pixels)[799*3]==9);
    assert(g_fb[0]==7&&g_fb[g_fb.size()-3]==9);
    const auto landscape=j2me_present::game_viewport(g_display_w,g_display_h,true);
    assert(landscape.x==40&&landscape.y==0&&landscape.w==1200&&landscape.h==720);
    assert(j2me_present::gpu_filter::pack(*g_display_pixels,g_display_w,g_display_h,
        display_filter::Filter::Bilinear,raw,true));
    select_display_preferences(b);
    assert(g_menu_settings.rotation==0&&g_menu_settings.canvas==0);
    select_display_preferences(a);
    assert(g_menu_settings.rotation==3);
    assert(host_display::save_rotation(a,2));
    select_display_preferences(a,true); // Launch and continue force a fresh selected-game read.
    assert(g_menu_settings.rotation==2);
    select_display_preferences(b,true);
    std::vector<Entry> games={{a,"A"},{b,"B"}};
    std::string status;
    g_display_menu.begin();
    update_display_menu(HidNpadButton_AnyDown,0,games,1,status);
    update_display_menu(HidNpadButton_A,0,games,1,status);
    assert(g_display_menu.open&&host_display::load(b).w==128&&host_display::load(b).h==128);
    assert(host_display::load(a).w==480&&host_display::load(a).h==800);
    update_display_menu(HidNpadButton_AnyUp,0,games,1,status);
    update_display_menu(HidNpadButton_A,0,games,1,status);
    assert(g_display_menu.open&&host_display::load(b).rotation==1&&host_display::load(a).rotation==2);
    update_display_menu(HidNpadButton_B,0,games,1,status);
    assert(!g_display_menu.open&&host_display::load(b).rotation==1);
    g_display_menu.begin();g_display_menu.move(1);g_display_menu.move(1);g_display_menu.move(1);
    update_display_menu(HidNpadButton_A,0,games,1,status);
    assert(!g_display_menu.open&&g_menu_delete.open&&g_menu_delete.confirming&&g_menu_delete.selection==0&&g_menu_delete.path==b);
    int selected_game=1;
    update_menu_delete(HidNpadButton_B,games,selected_game,status);
    assert(!g_menu_delete.open&&g_display_menu.open&&g_display_menu.selection==3);
    g_menu_delete.begin(b,"test");g_menu_delete.selection=1;g_menu_delete.confirming=true;g_display_menu.open=false;
    update_menu_delete(HidNpadButton_B,games,selected_game,status);
    assert(!g_menu_delete.open&&g_display_menu.open&&g_display_menu.selection==4);
    g_menu_delete.open=false;g_display_menu.begin();g_display_menu.move(1);g_display_menu.move(1);
    update_display_menu(HidNpadButton_A,16,games,1,status);
    assert(!g_display_menu.open&&g_chapter_import.open&&g_chapter_blocked==16);
    std::cout << "display_host_integration: PASS\n";
}
'''
with tempfile.TemporaryDirectory(prefix="fit6-host-integration-") as scratch:
    cpp = Path(scratch) / "test.cpp"
    binary = Path(scratch) / "test"
    cpp.write_text(harness)
    subprocess.run(["c++", "-std=c++17", "-O1", "-g", "-fsanitize=address,undefined",
                    "-fno-omit-frame-pointer", "-I", str(ROOT), str(cpp), "-o", str(binary)], check=True)
    subprocess.run([str(binary)], check=True, env=dict(os.environ, ASAN_OPTIONS="detect_leaks=0"))
