#pragma once
// Test-only storage fixture for the bounded retry/backoff protocol. A single
// maximum-size slice still needs to retire an entire native mapping in these
// cases. Production ordinary arenas are larger, so construct the old 256 KiB
// geometry directly through the real CodeBlock allocation/publication API.
// No fault switch or alternate geometry is added to production installation.
inline std::shared_ptr<jit236::CodeBlock> small_retry_arena(const std::vector<uint8_t>& bytes) {
    auto block=std::make_shared<jit236::CodeBlock>();
    const char* error="none";uint32_t result=0;
    if(!block->create(262144,error,result)||!block->write(0,bytes,error,result))return {};
    jit236::code_blocks().push_back(block);
    return block;
}
