// Real sink + engine; only libnx's external audio service is replaced.
#include "../src/switch_audio.h"
#include <cassert>
#include <deque>
#include <iostream>
#include <vector>
static std::deque<AudioOutBuffer*> pending, released;
static std::vector<std::vector<int16_t>> appended;
static uint64_t fakeUs=0, starvationFrames=0;
static size_t frontFrame=0;
static bool service=false, started=false;
static uint64_t clockMicros(){return fakeUs;}
Result audoutInitialize(){assert(!service);service=true;return 0;}
void audoutExit(){assert(service);service=started=false;pending.clear();released.clear();frontFrame=0;}
u32 audoutGetSampleRate(){return 48000;} u32 audoutGetChannelCount(){return 2;}
PcmFormat audoutGetPcmFormat(){return PcmFormat_Int16;} bool hosversionBefore(int,int,int){return false;}
void armDCacheFlush(void* p,size_t n){assert((uintptr_t(p)&4095)==0 && n==4096);}
Result audoutAppendAudioOutBuffer(AudioOutBuffer* b){
    assert(service && b->next==nullptr && b->buffer_size==4096 && b->data_size==4096 && b->data_offset==0);
    for(auto* p:pending)assert(p!=b);for(auto* p:released)assert(p!=b);
    auto* samples=static_cast<int16_t*>(b->buffer);appended.emplace_back(samples,samples+2048);
    pending.push_back(b);return 0;
}
Result audoutGetReleasedAudioOutBuffer(AudioOutBuffer** b,u32* count){
    assert(service);*b=nullptr;*count=0;
    if(!released.empty()){*b=released.front();released.pop_front();*count=1;}return 0;
}
Result audoutStartAudioOut(){assert(service);started=true;return 0;}
Result audoutStopAudioOut(){assert(service);started=false;return 0;}
Result audoutFlushAudioOutBuffers(bool* flushed){
    assert(service && !started);*flushed=!pending.empty();
    while(!pending.empty()){released.push_back(pending.front());pending.pop_front();}frontFrame=0;return 0;
}
// 48 kHz playback retains a partly consumed descriptor until its final frame.
static void advance(unsigned us){
    fakeUs+=us;if(!started)return;
    size_t frames=us*48/1000;
    while(frames && !pending.empty()){
        size_t n=std::min(frames,size_t(1024)-frontFrame);frames-=n;frontFrame+=n;
        if(frontFrame==1024){released.push_back(pending.front());pending.pop_front();frontFrame=0;}
    }
    starvationFrames+=frames;
}
int main(){
    j2me_audio::Engine engine,reference;j2me_audio::SwitchAudioSink sink(clockMicros);
    assert(sink.init()==0);appended.clear();sink.takeStats();
    int h=engine.playTone(69,10000,75),hr=reference.playTone(69,10000,75);assert(h>0 && hr>0);
    assert(sink.pumpThrottled(engine,true)==0 && appended.empty() && engine.time(h)==0);
    for(int i=0;i<30;++i){advance(50000);assert(sink.pumpThrottled(engine,true)==0);}
    std::cout<<"INFO late_pumps=30 gap_us=50000 starvation_frames="<<starvationFrames
        <<" empty_polls="<<sink.metrics().queue_empty_polls<<" rendered_blocks="<<appended.size()<<std::endl;
    // A one-block refill cannot replenish what the next 50 ms consumes.
    assert(starvationFrames==0 && sink.metrics().queue_empty_polls==0);
    // Every rendered block is submitted once, in order, including player time.
    int16_t pcm[2048];
    for(const auto& block:appended){reference.render(pcm,1024);assert(std::equal(pcm,pcm+2048,block.begin()));}
    assert(engine.time(h)==reference.time(hr));
    auto t=engine.time(h);assert(sink.suspend(engine,true)==0);auto blocks=appended.size();
    advance(5000000);assert(sink.pumpThrottled(engine,true)==0 && engine.time(h)==t && appended.size()==blocks);
    assert(sink.suspend(engine,false)==0 && sink.queuedBuffers()==4);
    for(size_t i=blocks;i<appended.size();++i){reference.render(pcm,1024);assert(std::equal(pcm,pcm+2048,appended[i].begin()));}
    assert(engine.time(h)==reference.time(hr));
    assert(sink.reset(engine)==0 && sink.queuedBuffers()==4 && engine.state(h)==0);
    for(auto* b:pending)for(size_t i=0;i<2048;++i)assert(static_cast<int16_t*>(b->buffer)[i]==0);
    assert(sink.shutdown()==0 && !service);
    std::cout<<"PASS late frame pumps replenish PCM without recurring starvation; ordered PCM/time, pause/resume and reset preserved\n";
}
