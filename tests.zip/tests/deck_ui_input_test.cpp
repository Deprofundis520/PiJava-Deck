#include "platform/deck_ui_input.h"
#include "platform/deck_navigation.h"
#include <iostream>
using namespace deck_ui_input;
#define CHECK(x) do{if(!(x)){std::cerr<<"Direction test line "<<__LINE__<<"\n";return 1;}}while(0)
int main(){
    // Replay the physical Menu press plus Steam's keyboard echo in both orders.
    using CS=CommandSource;using I=deck_navigation::Input;using S=deck_navigation::Screen;
    CommandGate gate;deck_navigation::State menu;
    auto event=[&](CS source,int button,bool down,int64_t time,I command){
        if(!down){gate.release(source,button);return;}
        if(gate.press(source,button,time))menu.input(command);
    };
    for(bool keyboard_first:{false,true}){
        gate.reset();menu.launched();
        const CS first=keyboard_first?CS::Keyboard:CS::Controller,second=keyboard_first?CS::Controller:CS::Keyboard;
        event(first,1,true,100,keyboard_first?I::Back:I::Menu);
        event(second,1,true,101,keyboard_first?I::Menu:I::Back);
        CHECK(menu.screen==S::Pause);
        event(first,1,false,102,I::Menu);event(second,1,false,103,I::Menu);
        // A delayed alias after both releases must not close the pause menu.
        event(second,1,true,220,keyboard_first?I::Menu:I::Back);CHECK(menu.screen==S::Pause);
        event(second,1,false,221,I::Menu);
        event(first,1,true,240,keyboard_first?I::Back:I::Menu);CHECK(menu.screen==S::Game);
        event(first,1,false,241,I::Menu);
    }
    gate.reset();menu.launched();event(CS::Controller,1,true,100,I::Menu);
    event(CS::Controller,1,true,1000,I::Menu);CHECK(menu.screen==S::Pause);
    // An emulated Enter from the same physical press must not choose Continue.
    event(CS::Keyboard,2,true,1001,I::Confirm);CHECK(menu.screen==S::Pause);
    event(CS::Keyboard,2,false,1002,I::Confirm);event(CS::Controller,1,false,1003,I::Menu);
    event(CS::Controller,2,true,1010,I::Confirm);CHECK(menu.screen==S::Game);
    gate.reset();CHECK(gate.press(CS::Keyboard,1,1100));gate.release(CS::Keyboard,1);
    CHECK(gate.press(CS::Keyboard,1,1101));gate.reset();CHECK(gate.press(CS::Controller,1,1102));
    Axis a;
    CHECK(a.button(Dpad,1,true,100)==1);CHECK(a.tick(116)==0);CHECK(a.tick(399)==0);CHECK(a.tick(400)==1);CHECK(a.tick(479)==0);CHECK(a.tick(480)==1);
    CHECK(a.button(Dpad,1,false,481)==0);CHECK(a.tick(900)==0);
    a.reset();CHECK(a.button(Keyboard,1,true,100)==1);CHECK(a.button(Dpad,1,true,101)==0);CHECK(a.button(Keyboard,1,false,102)==0);CHECK(a.tick(399)==0);CHECK(a.tick(400)==1);a.button(Dpad,1,false,410);CHECK(a.tick(1000)==0);
    a.reset();CHECK(a.button(Keyboard,1,true,100)==1);a.button(Keyboard,1,false,101);CHECK(a.button(Dpad,1,true,102)==0);a.button(Dpad,1,false,103);CHECK(a.button(Keyboard,1,true,120)==1);a.button(Keyboard,1,false,121);
    a.reset();CHECK(a.button(Dpad,1,true,100)==1);a.button(Dpad,1,false,101);CHECK(a.button(Dpad,1,true,110)==1);a.button(Dpad,1,false,111);
    a.reset();CHECK(a.stick(17000,100)==1);CHECK(a.stick(20000,101)==0);CHECK(a.stick(13000,110)==0);CHECK(a.stick(16500,111)==0);CHECK(a.tick(399)==0);CHECK(a.tick(400)==1);a.stick(0,410);CHECK(a.tick(900)==0);
    a.reset();CHECK(a.stick(-20000,100)==-1);CHECK(a.button(Keyboard,-1,true,101)==0);CHECK(a.stick(-25000,102)==0);
    a.reset();CHECK(a.button(Dpad,1,true,100)==1);a.block_until_release();CHECK(a.tick(500)==0);CHECK(a.button(Keyboard,1,true,501)==0);a.button(Dpad,1,false,502);a.button(Keyboard,1,false,503);CHECK(a.button(Dpad,1,true,600)==1);
    a.reset();deck_navigation::State nav;nav.launched();nav.input(deck_navigation::Input::Menu);
    if(a.button(Dpad,1,true,100))nav.input(deck_navigation::Input::Down);
    CHECK(nav.pause_selection==1);nav.input(deck_navigation::Input::Confirm);CHECK(nav.screen==deck_navigation::Screen::Settings);
    a.block_until_release();CHECK(a.tick(500)==0);CHECK(nav.option==0);
    // Same press reaching both keyboard and pad must adjust a value only once.
    a.reset();int changes=0;changes+=a.button(Keyboard,1,true,100)!=0;changes+=a.button(Dpad,1,true,101)!=0;changes+=a.tick(116)!=0;CHECK(changes==1);
    std::cout<<"PASS: Menu/Escape in both orders, delayed aliases, repeated downs, Enter echo, intentional repeat/confirm, reset; single step, shared sources, rapid taps, long hold, stick hysteresis, page transitions\n";
}
