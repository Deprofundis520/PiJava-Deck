#!/usr/bin/env python3
"""Exercise the exact production cold-launch selector without compiling the VM."""
from pathlib import Path
import subprocess
import tempfile
root=Path(__file__).resolve().parents[1]
source=(root/'src/j2mevm.cpp').read_text()
start=source.index('static void select_screen_sidecar(')
opening=source.index('{',start);depth=1;end=opening+1
while depth:
    depth += (source[end]=='{')-(source[end]=='}');end+=1
selector=source[start:end]
with tempfile.TemporaryDirectory(prefix='canvas-select-') as temporary:
    path=Path(temporary)
    code=r'''
#include "canvas_resolution.h"
#include "canvas_declared_size.h"
static std::string g_canvas_notice;
static std::unordered_map<std::string,std::vector<uint8_t>> g_jar_files;
#include <cassert>
#include <fstream>
#include <iostream>
#define VMS_RS(x) x
#define VMS_CL(x) x
static int g_screen_w=240,g_screen_h=320;
static std::unordered_map<std::string,std::string> g_props;
static std::string message;
static void log_line(const std::string& text){message=text;}
'''+selector+r'''
static void check(const std::string& file,int w,int h){
 select_screen_sidecar(file,"e808c5b9878639757edcf67d330536a7b95f553790c2cf23c7d267df06ecb6b8");
 if(g_screen_w!=w||g_screen_h!=h){std::cerr<<"FAIL "<<file<<" expected "<<w<<"x"<<h<<" got "<<g_screen_w<<"x"<<g_screen_h<<" "<<message<<"\n";std::exit(1);}
}
int main(){
 check("2048-320x240.jar",320,240);check("2048-240x320.jar",240,320);check("2048-128x160.jar",128,160);
 check("Game-800x480.jar",800,480);check("Game-480x800.jar",480,800);check("Game-640X360.jar",640,360);
 for(const auto* file:{"Unknown.jar","800x480/Unknown.jar","Game-800x800.jar","Game-1320x240.jar","Game-320x2400.jar","Game-320x240backup.jar","Game-320x240x64.jar","Game-320x240-240x320.jar"})check(file,240,320);
 g_props={{"SEMC-Screen-Size","800,480"}};check("Game-240x320.jar",800,480);
 g_props={{"Nokia-MIDlet-Original-Display-Size","176,208"},{"Nokia-MIDlet-Target-Display-Size","640,360"}};check("Game-320x240.jar",176,208);
 g_props={{"Nokia-MIDlet-Original-Display-Size","176,208"},{"SEMC-Screen-Size","240,320"}};check("Game-320x240.jar",240,320);
 g_props={{"SEMC-Screen-Size","broken"}};check("Game-320x240.jar",240,320);
 g_props={{"Nokia-MIDlet-Target-Display-Size","640,360"}};check("Game-320x240.jar",320,240);
 g_props.clear();
 {std::ofstream f("Game-320x240.jar.screen");f<<"360x360\n";}check("Game-320x240.jar",360,360);
 {std::ofstream f("Game-320x240.jar.screen");f<<"bad";}check("Game-320x240.jar",240,320);
 std::cout<<"PASS cold canvas: three 2048 variants, metadata priority, explicit filename tokens, bounds/conflicts, no SHA profiles, explicit sidecar boundaries\n";
}
'''
    (path/'checks.cpp').write_text(code)
    subprocess.run(['g++','-std=c++17','-O2','-I'+str(root/'src'),str(path/'checks.cpp'),'-o',str(path/'checks')],check=True)
    subprocess.run([str(path/'checks')],cwd=path,check=True)
