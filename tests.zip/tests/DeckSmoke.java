import javax.microedition.midlet.MIDlet;
import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.AlertType;
import javax.microedition.rms.RecordStore;
public class DeckSmoke extends MIDlet {
    protected void startApp() {
        try {
            RecordStore r = RecordStore.openRecordStore("deck-smoke", true);
            byte[] data = {12, 34, 56};
            if (r.getNumRecords() == 0) r.addRecord(data, 0, data.length);
            byte[] saved = r.getRecord(1);
            if (saved.length != 3 || saved[0] != 12) throw new RuntimeException("RMS mismatch");
            r.closeRecordStore();
        } catch (Exception e) { throw new RuntimeException("RMS smoke failure"); }
        Display.getDisplay(this).setCurrent(new Screen());
        AlertType.INFO.playSound(Display.getDisplay(this));
    }
    protected void pauseApp() {}
    protected void destroyApp(boolean unconditional) {}
    static class Screen extends Canvas {
        protected void paint(Graphics g) {
            g.setColor(0x1248ac);g.fillRect(0,0,getWidth(),getHeight());
            g.setColor(0xffffff);g.fillRect(10,10,32,32);
            g.drawString("PiJava Deck smoke",10,60,Graphics.TOP|Graphics.LEFT);
        }
    }
}
