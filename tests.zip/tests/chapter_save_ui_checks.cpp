#include "../src/chapter_save_ui.h"
#include <cassert>
#include <filesystem>
#include <fstream>
#include <iostream>
namespace fs=std::filesystem;
struct Entry {std::string label,path;};
static void put(const std::string& p,const std::string& s){fs::create_directories(fs::path(p).parent_path());std::ofstream(p,std::ios::binary)<<s;}
int main(int argc,char** argv){assert(argc==2);std::string root=argv[1];
 std::vector<Entry> items;for(int i=0;i<14;++i){std::string path=root+"/games/"+std::to_string(i)+".jar";put(path,"fixture"+std::to_string(i));items.push_back({"章节"+std::to_string(i),path});}
 using chapter_ui::Action;using chapter_ui::Event;chapter_ui::State ui;
 assert(!ui.begin(std::vector<Entry>{},0));assert(!ui.begin(std::vector<Entry>{items[0]},0));
 assert(ui.begin(items,5)&&ui.target_path==items[5].path&&ui.sources.size()==13);
 ui.act(Action::Up);assert(ui.selected==12);ui.act(Action::NextPage);assert(ui.selected==0);ui.act(Action::Back);assert(!ui.open);
 assert(ui.begin(items,5));assert(ui.act(Action::Confirm)==Event::Prepare);std::string error;
 assert(!ui.prepare(root,error)&&!ui.confirming); // no source RMS yet
 const auto source_id=chapter_save::jar_identity(ui.sources[0].path),target_id=chapter_save::jar_identity(items[5].path);
 put(root+"/suites/"+source_id+"/r53617665.bin",std::string("\0\0\0\1",4)+'A');
 assert(ui.prepare(root,error)&&ui.confirming&&ui.stores==1);
 const int selected=ui.selected;ui.act(Action::Down);assert(ui.selected==selected);ui.act(Action::Back);assert(ui.open&&!ui.confirming);
 assert(ui.prepare(root,error));put(items[5].path,"replaced JAR");auto changed=ui.execute(root);assert(!changed.ok&&ui.open&&!ui.confirming);
 put(items[5].path,"fixture5");assert(ui.prepare(root,error));assert(ui.act(Action::Confirm)==Event::Import);
 auto done=ui.execute(root);assert(done.ok&&!ui.open&&fs::exists(root+"/suites/"+target_id+"/r53617665.bin"));
 assert(!ui.execute(root).ok); // can't repeat after closing
 // Same-byte renamed JAR is not a different suite.
 put(items[5].path,"fixture0");assert(ui.begin(items,5));assert(!ui.prepare(root,error));
 std::vector<uint32_t> pixels(1280*720);std::vector<std::string> texts;
 host_menu::Text text=[&](int x,int y,const std::string& s,uint32_t,int px,int width){assert(x>=0&&y>=0&&x+width<=1280&&y+px<=720);texts.push_back(s);};
 chapter_ui::render(pixels.data(),1280,ui,text);
 assert(std::find(texts.begin(),texts.end(),"继承游戏内存档")!=texts.end());
 put(items[5].path,"fixture5");assert(ui.prepare(root,error));texts.clear();chapter_ui::render(pixels.data(),1280,ui,text);
 assert(std::find(texts.begin(),texts.end(),"来源："+items[0].label)!=texts.end());assert(std::find(texts.begin(),texts.end(),"目标："+items[5].label)!=texts.end());
 assert(std::find(texts.begin(),texts.end(),"仅适用于存档格式兼容的章节；不会转换即时存档。")!=texts.end());
 std::cout<<"PASS chapter UI: fixed target, explicit source, wrap/page, cancel, two-step confirm, no-source, same-content rejection, fresh hash revalidation, single execution, bounded rendering\n";
}
