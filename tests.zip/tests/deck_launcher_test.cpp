#ifdef _WIN32
#define lstat stat
#endif
#include "platform/deck_launcher.h"
#include <iostream>
#include <iterator>
namespace fs=std::filesystem;
static void put(const fs::path& p,const std::string& s){fs::create_directories(p.parent_path());std::ofstream(p,std::ios::binary)<<s;}
static std::string read(const fs::path& p){std::ifstream f(p,std::ios::binary);return {(std::istreambuf_iterator<char>(f)),{}};}
int main(){
    const auto root=fs::temp_directory_path()/"pijava-launcher-test";
    fs::create_directories(root);
    const auto source=root/"portable",data=root/"user data",desktop=root/"Desktop";
    put(source/"games/original.jar","original game");put(source/"pijava-deck","ELF test executable");put(source/"romfs/classes/Object.class","class");put(source/"icon.png","icon");
    put(data/"pijava/rms/sentinel","existing save");put(data/"pijava/games/test.jar","existing game");
    std::string error;
    if(!deck_launcher::install(source,data,desktop,error)){std::cerr<<error;return 1;}
    if(read(data/"pijava/app/pijava-deck")!="ELF test executable"||read(data/"pijava/app/romfs/classes/Object.class")!="class")return 2;
    if(read(data/"pijava/rms/sentinel")!="existing save"||read(data/"pijava/games/test.jar")!="existing game")return 3;
    if(deck_games::normalized(deck_games::load_root(data/"pijava/source-games.path"))!=deck_games::normalized(source/"games"))return 11;
    const auto entry=read(data/"applications/pijava-deck.desktop");
    if(entry.find("Terminal=false")==std::string::npos||entry.find("Exec=\"")==std::string::npos)return 4;
    if(entry.find("--add-to-steam")==std::string::npos)return 10;
    if(!fs::exists(desktop/fs::u8path("PiJava 模拟器.desktop")))return 5;
    put(source/"pijava-deck","updated executable");
    if(!deck_launcher::install(source,data,desktop,error)||read(data/"pijava/app/pijava-deck")!="updated executable")return 6;
    if(!deck_launcher::install(data/"pijava/app",data,desktop,error))return 7;
    if(deck_launcher::valid_path(fs::path("bad\npath")))return 8;
    const auto quoted=deck_launcher::exec_path(fs::path("/tmp/a b/100%/$x"));
    if(quoted.find("100%%")==std::string::npos||quoted.find("\\\\$")==std::string::npos)return 9;
    std::cout<<"PASS: first install, update, self install, desktop entry, path escaping, games and RMS preserved\n";
}
