#define main emulator_main
#include PROBE_VM
#undef main
#include PROBE_HOST_MENU
#include PROBE_HOST_SPEED
static host_menu::Settings g_menu_settings;
static std::string instant_state_path(const std::string&){return "unused-memory-test";}
#include PROBE_STATE
#include PROBE_MEMORY
#include "../src/platform/deck_memory_menu.h"
#include "../src/platform/deck_ui.h"
#include "../src/platform/deck_memory_render.h"
using namespace deck_memory;
static unsigned checks=0;
static void check(bool b,const char*why){++checks;if(!b){std::cerr<<"FAIL "<<why<<'\n';std::exit(1);}}
static Value call(const char*name,const char*desc="()V") {int c=ensure_class("DeckMemoryCases");auto*m=find_method(c,name,desc,false);check(m,"method exists");auto v=run_event_callback(m,{});check(!VMS_EXEC(g_thrown)&&!current_context().unhandled,"Java call completed");return v;}
static void complete(Session&s){size_t n=0;while(s.busy){s.step(37);check(++n<100000,"bounded scan termination");}}
static Target named(Session&s,const std::string&name,Kind kind=Kind::Field){for(auto&c:s.candidates)if(c.target.kind==kind&&s.describe(c.target).find(name)!=std::string::npos)return c.target;check(false,"named target exists");return {};}
static void image(deck_ui::UI&ui,const char*path){std::ofstream f(path,std::ios::binary);f<<"P6\n1280 720\n255\n";for(auto p:ui.pixels){char v[]={char(p),char(p>>8),char(p>>16)};f.write(v,3);}}
int main(int argc,char**argv){
    check(argc==4,"fixture, library and output paths");VMS_CL(g_classpath)={argv[1],argv[2]};VMS_RS(g_fb).assign(240*320*3,0);VMS_EXEC(g_midlet_state)=MidletState::Active;call("setup");
    int cls=ensure_class("DeckMemoryCases");auto*app=find_field(cls,"app","LDeckMemoryCases$App;");VMS_EXEC(g_midlet)=VMS_CL(g_classes)[cls].statics[app->slot].ref;host_events();
    for(const char*n:{"DeckMemoryCases","DeckMemoryBase","DeckMemoryCases$App","DeckMemoryCases$View"}){std::vector<uint8_t>b;check(read_whole(std::string(argv[1])+"/"+n+".class",b),"class bytes available");VMS_CL(g_jar_files)[std::string(n)+".class"]=std::move(b);}
    deck_text::Editor numeric;numeric.begin(deck_text::Editor::Purpose::Memory,"-9223372036854775808",20,2);check(numeric.keys().size()==11,"integer keypad has digits and minus only");numeric.all_selected=true;check(numeric.insert("9223372036854775807"),"replace selected 64-bit value");numeric.toggle_sign();check(numeric.value=="-9223372036854775807","sign toggle");numeric.toggle_sign();check(numeric.value=="9223372036854775807","sign toggles back");check(!numeric.insert("x"),"numeric editor rejects letters");
    Session s(deck_memory_vm::backend());Panel p;
    check(s.start(Type::Int,Compare::Exact,100),"start exact");s.step(1);check(s.busy,"scan yields to UI");complete(s);check(s.candidates.size()==3,"inherited field, gold and array; final fields excluded");
    for(auto&c:s.candidates)check(s.describe(c.target).find("fixed")==std::string::npos,"no final fields");
    auto inherited=named(s,"inherited");check(inherited.cls!=cls,"inherited target uses declaring owner");
    call("spend");check(s.start(Type::Int,Compare::Decreased,0,true),"decrease scan");complete(s);check(s.candidates.size()==1,"decrease isolates gold");auto gold=s.candidates[0].target;
    check(s.set(gold,9999)&&call("gold","()I").i==9999,"edit observed by Java");check(s.revert()&&call("gold","()I").i==90,"undo restores previous value");
    check(s.set(gold,9999)&&s.toggle(gold),"edit and lock");call("spend");s.apply();check(call("gold","()I").i==9999,"lock reapplied after Java work");
    s.locks_enabled=false;call("spend");s.apply();check(call("gold","()I").i==9989,"global pause stops lock");s.locks_enabled=true;s.apply();check(call("gold","()I").i==9999,"global resume reapplies lock");
    check(s.set(gold,7777)&&s.locks[0].value==7777,"editing locked value updates rule");check(s.revert()&&s.locks.empty(),"undo disables matching lock");
    check(s.set(gold,1000),"new edit");call("spend");check(!s.revert()&&call("gold","()I").i==990,"undo refuses to overwrite later game progress");
    check(s.start(Type::Int,Compare::Exact,3),"static scan");complete(s);auto gems=named(s,"gems",Kind::Static);check(s.set(gems,20)&&call("gems","()I").i==20,"static edit");
    check(s.start(Type::Int,Compare::Exact,100),"array search");complete(s);Target array;bool found=false;for(auto&c:s.candidates)if(c.target.kind==Kind::Array){array=c.target;found=true;break;}check(found,"array located");auto stamp=VMS_HEAP(g_heap)[array.object].elems.content_version();check(s.set(array,55)&&call("item","()I").i==55,"array edit");check(VMS_HEAP(g_heap)[array.object].elems.content_version()!=stamp,"array write barrier");
    for(auto t:{Type::Byte,Type::Short,Type::Int,Type::Long}){for(auto value:{int64_t(-1),int64_t(0),int64_t(1)}){int64_t n;check(parse(std::to_string(value),t,n)&&n==value,"signed parse roundtrip");}}
    int64_t number;check(!parse("128",Type::Byte,number)&&!parse("-129",Type::Byte,number)&&!parse("32768",Type::Short,number)&&!parse("2147483648",Type::Int,number)&&!parse("9223372036854775808",Type::Long,number),"reject typed overflow");check(parse("-9223372036854775808",Type::Long,number)&&number==INT64_MIN&&!parse("1x",Type::Long,number)&&!parse("",Type::Int,number),"long minimum and invalid syntax");
    for(auto type:{Type::Byte,Type::Short,Type::Long}){int64_t wanted=type==Type::Byte?5:type==Type::Short?6:9000000000LL;check(s.start(type,Compare::Exact,wanted),"typed scan");complete(s);auto t=named(s,type==Type::Byte?"ammo":type==Type::Short?"potions":"experience");check(s.set(t,type==Type::Byte?-128:type==Type::Short?-32768:INT64_MIN),"typed write");if(type!=Type::Long)check(!s.set(t,type==Type::Byte?128:32768),"narrow overflow rejected");}
    check(call("experience","()J").l==INT64_MIN,"Java reads long minimum");
    check(call("ammo","()I").i==-128&&call("potions","()I").i==-32768,"byte and short Java reads");
    check(s.start(Type::Long,Compare::Exact,INT64_MAX),"long array max search");complete(s);check(s.candidates.size()==1,"long array maximum");check(s.set(s.candidates[0].target,INT64_MIN),"long array minimum write");
    check(s.start(Type::Int,Compare::Exact,990),"prepare baseline");complete(s);check(s.candidates.size()==1,"known gold baseline");auto before=s.candidates;
    check(s.start(Type::Int,Compare::Unknown),"unknown scan start");s.step(1);s.cancel();check(s.candidates.size()==before.size()&&s.candidates[0].target==before[0].target,"cancel preserves previous result");
    check(s.start(Type::Int,Compare::Unknown),"unknown initial values");complete(s);check(!s.candidates.empty(),"unknown baseline populated");call("spend");check(s.start(Type::Int,Compare::Changed,0,true),"changed refine");complete(s);check(s.candidates.size()==1,"changed isolates gold");
    check(s.start(Type::Int,Compare::Unchanged,0,true),"unchanged refine");complete(s);check(s.candidates.size()==1,"unchanged retains gold");s.set(gold,1001);check(s.start(Type::Int,Compare::Increased,0,true),"increase refine");complete(s);check(s.candidates.size()==1,"increase retains gold");
    call("many");before=s.candidates;check(s.start(Type::Int,Compare::Unknown),"over-limit scan start");complete(s);check(s.candidates.size()==before.size()&&s.note.find("10万")!=std::string::npos,"over-limit abort preserves baseline instead of partial results");
    // Lock budget, per-rule pause, deletion and bounded undo history.
    auto*largeField=find_field(cls,"large","[I");int largeRef=VMS_CL(g_classes)[largeField->owner].statics[largeField->slot].ref;
    Target lt;lt.epoch=resver::g_epoch;lt.object=largeRef;lt.generation=VMS_HEAP(g_heap)[largeRef].generation;lt.kind=Kind::Array;lt.layout=VMS_HEAP(g_heap)[largeRef].elems.layout_version();
    for(int i=0;i<64;++i){lt.slot=i;check(s.toggle(lt),"lock budget admits 64 rules");}lt.slot=64;check(!s.toggle(lt)&&s.locks.size()==64,"65th lock rejected");
    lt.slot=3;check(s.toggle(lt),"pause individual lock");VMS_HEAP(g_heap)[largeRef].elems.set(3,Value::of_i(27));s.apply();check(VMS_HEAP(g_heap)[largeRef].elems.get(3).i==27,"paused individual rule does not write");s.toggle(lt);s.apply();check(VMS_HEAP(g_heap)[largeRef].elems.get(3).i==0,"resumed individual rule writes");
    Panel lockPanel;lockPanel.right=true;lockPanel.show_locks=true;lockPanel.row=3;lockPanel.input(s,deck_navigation::Input::Save);check(s.locks.size()==63,"panel removes selected lock");
    s.locks.clear();for(int i=0;i<35;++i)check(s.set(gold,10000+i),"undo history write");check(s.undo.size()==Session::MaxUndo,"undo history bounded");
    // An array reset within a live handle invalidates old targets via layout.
    int scratch=alloc_array("[I",1);Target oldArray;oldArray.epoch=resver::g_epoch;oldArray.object=scratch;oldArray.generation=VMS_HEAP(g_heap)[scratch].generation;oldArray.kind=Kind::Array;oldArray.layout=VMS_HEAP(g_heap)[scratch].elems.layout_version();
    int64_t tmp;check(s.read(oldArray,tmp),"array target live before reset");VMS_HEAP(g_heap)[scratch].elems.reset("[I",1);check(!s.read(oldArray,tmp)&&!s.set(oldArray,9),"layout reset rejects target");
    Target immutable=gold;immutable.slot=find_field(cls,"fixed","I")->slot;check(!s.set(immutable,5),"direct final field write rejected");
    Target constant;constant.epoch=resver::g_epoch;constant.cls=cls;constant.kind=Kind::Static;constant.slot=find_field(cls,"CONSTANT","I")->slot;check(!s.set(constant,5),"direct static final write rejected");
    int pRef=gold.object;VMS_HEAP(g_heap)[pRef].indexed_key=true;auto ie=VMS_NATIVE(g_index_key_epoch);check(s.set(gold,9999)&&VMS_NATIVE(g_index_key_epoch)==ie+1,"indexed field write barrier");check(jitr_h_getfield(pRef,gold.slot,0)==jitr::pack(9999,0),"JIT read helper sees changed value without cached payload");
    // Exercise the same panel state/submit path used by the SDL host.
    p.control=1;check(p.input(s,deck_navigation::Input::Confirm)==Route::Editor,"new search opens numeric editor");std::string err;check(!p.submit(s,"2147483648",err),"panel rejects overflow");check(p.submit(s,"9999",err),"panel submits search");complete(s);p.control=8;p.input(s,deck_navigation::Input::Confirm);check(p.right,"results focus");check(p.input(s,deck_navigation::Input::Confirm)==Route::Editor,"selected edit opens editor");check(p.submit(s,"8888",err)&&call("gold","()I").i==8888,"panel edit reaches actual VM");p.input(s,deck_navigation::Input::Reset);check(s.locked(gold),"panel X locks");p.input(s,deck_navigation::Input::Save);check(!s.locks_enabled,"panel Y global toggle");p.input(s,deck_navigation::Input::Save);
    deck_ui::UI ui;ui.load_fonts();render(ui,s,p);image(ui,(std::string(argv[3])+"/memory-results.ppm").c_str());p.right=false;p.control=9;p.input(s,deck_navigation::Input::Confirm);render(ui,s,p);image(ui,(std::string(argv[3])+"/memory-locks.ppm").c_str());
    ui.pause_menu(7);image(ui,(std::string(argv[3])+"/memory-pause.ppm").c_str());numeric.title="修改目标数值 · 64位整数";ui.text_menu(numeric);image(ui,(std::string(argv[3])+"/memory-numeric.ppm").c_str());
    check(p.input(s,deck_navigation::Input::View)==Route::Game&&p.input(s,deck_navigation::Input::Menu)==Route::Pause,"view resumes; menu returns to pause");
    SavState saved,decoded;std::string bytes;check(capture_state(saved,"memory.jar")&&encode_state(saved,bytes)&&decode_state(bytes,decoded),"modified state encoded");check(s.set(gold,22)&&apply_state(decoded),"modified state restored");check(!s.guard()&&s.candidates.empty()&&s.locks.empty()&&s.undo.empty(),"restore clears all targets and rules");check(call("gold","()I").i==8888&&call("gems","()I").i==20&&call("item","()I").i==55,"edited values persist through J2S5");check(!s.set(gold,0),"old target rejected after restore");
    cls=ensure_class("DeckMemoryCases");auto*fresh=find_field(cls,"gold","I");
    int ref=alloc_obj(cls);Target stale;stale.epoch=resver::g_epoch;stale.object=ref;stale.generation=VMS_HEAP(g_heap)[ref].generation;stale.cls=fresh->owner;stale.slot=fresh->slot;check(s.set(stale,50)&&s.toggle(stale),"temporary target initially writable");gc_collect("memory-test");s.apply();check(s.locks.empty()&&!s.set(stale,100),"GC prunes lock and rejects target");int reused=alloc_obj(cls);check(reused==ref&&!s.set(stale,100),"recycled slot cannot reuse stale target");
    std::cout<<"PASS production memory engine and panel checks="<<checks<<" search_refine_cancel_limits=1 typed_write=1 lock_undo=1 barriers=1 snapshot=1 gc_generation=1 ui_render=1 native_jit_executed=0\n";
}
