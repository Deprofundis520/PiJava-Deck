#define main emulator_main
#include "../src/j2mevm.cpp"
#undef main

static void standard_check(bool ok, const char* label) {
    if (!ok) { std::cerr << "FAIL " << label << "\n"; std::exit(1); }
}
int main(int argc, char** argv) {
    if (argc != 4) return 2;
    VMS_CL(g_classpath) = {argv[1], argv[2]};
    VMS_DIAG(g_log_draw) = false;
    const std::string mode = argv[3];
    if (mode == "double") {
        int cls = ensure_class("java/lang/Double");
        Method* method = find_method(cls, "toString", "(D)Ljava/lang/String;", false);
        standard_check(method && (method->flags & 0x0009) == 0x0009,
                "Double exposes public static toString(double)");
        int fixture = ensure_class("OptionalStandardApiChecks");
        auto result = run(find_method(fixture, "doubles", "()I", false), {});
        standard_check(result.i == 18, "actual Java Double formatting checks");
        std::cout << "PASS OptionalStandardApiDouble 18 actual Java checks\n";
    } else if (mode == "unsupported") {
        int cls = load_class_file("java/lang/UnsupportedOperationException", false);
        standard_check(cls >= 0, "UnsupportedOperationException loads from frozen API library");
        standard_check(VMS_CL(g_classes)[cls].super_id == ensure_class("java/lang/RuntimeException"),
                "UnsupportedOperationException extends RuntimeException");
        standard_check(find_method(cls, "<init>", "()V", false) &&
                find_method(cls, "<init>", "(Ljava/lang/String;)V", false), "standard exception constructors resolve");
        int fixture = ensure_class("OptionalStandardApiChecks");
        auto result = run(find_method(fixture, "exceptions", "()I", false), {});
        standard_check(result.i == 8, "actual Java exception constructor, message and catch checks");
        std::cout << "PASS OptionalStandardApiUnsupportedOperationException 8 actual Java checks\n";
    } else return 2;
}
