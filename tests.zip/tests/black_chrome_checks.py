#!/usr/bin/env python3
"""Execute production Switch CPU-chrome and GPU layer-cache blocks on host."""
import pathlib,subprocess,sys
root=pathlib.Path(__file__).resolve().parents[1]
out=pathlib.Path(sys.argv[1]).resolve();out.mkdir(parents=True,exist_ok=True)
s=(root/'src/platform/switch_host.inc').read_text()
def block(marker):
 start=s.index(marker);brace=s.index('{',start);depth=1;end=brace+1
 while depth:depth+=(s[end]=='{')-(s[end]=='}');end+=1
 return s[start:end]
struct=block('struct GpuHostLayerCache')+';'
sync=block('static void sync_controller_legends()')
start=s.index('    // Phone skin and the FPS badge are host chrome.')
chrome=s[start:s.index('    const uint8_t* src =',start)]
start=s.index('        const bool rebuild=');end=s.index('        was_layered=layered;',start)+len('        was_layered=layered;')
gpu=s[start:end]
cpp=r'''
#include "controller_skin_labels.h"
#include "host_skin.h"
#include "host_speed.h"
#include "presentation/layers.h"
#include "presentation/gpu_filter.h"
#include <cassert>
#include <cstdio>
#define VMS_PLAT(x) x
#define VMS_EXEC(x) x
#define VMS_RS(x) x
using u32=uint32_t;
host_controller::Legends g_controller_legends;
host_menu::UniversalLayout g_universal_layout;
auto g_universal_legend_layout=host_controller::universal_game_layout(g_universal_layout);
host_keymap::Config g_keymap_active;
bool standard_game_keys(){return false;}
host_menu::Settings g_menu_settings;
host_skin::Cache g_host_skin;
int g_screen_w=240,g_screen_h=320,g_cpu_cleared=0,g_chrome_bezel=-2,g_chrome_fps=-2,g_speed_cap=0,text_calls=0;
struct Font{struct M{bool ok;int advance;};M measure(const std::string& s,int n){return {true,host_menu::text_advance(s,n)};}} g_host_font;
void log_line(const std::string&){}
host_menu::Text host_text_callback(u32* frame,u32 pitch,bool centered=false){return [=](int x,int y,const std::string&,uint32_t ink,int px,int maxw){++text_calls;if(centered){x-=maxw/2;y-=px/2;}host_menu::rect(frame,pitch,x,y,maxw,px,ink);};}
'''+struct+'\n'+sync+r'''
void compose_host_surface(u32* frame,u32 pitch,const std::string&,bool,bool force_chrome){
'''+chrome+r'''
}
GpuHostLayerCache cache;
void gpu_step(){sync_controller_legends();auto& canvas=cache.canvas;auto& generation=cache.generation;auto& bezel=cache.bezel;auto& fps=cache.fps;
 auto& was_layered=cache.was_layered;auto& previous_label=cache.previous_label;const bool layered=true;const std::string label="";
'''+gpu+r'''
 g_cpu_cleared=3;
}
int main(){
 g_menu_settings.bezel=7;g_menu_settings.show_fps=false;int reads=0;
 assert(g_host_skin.select(7,{},[&](const char*,host_skin::Pixels& p,std::string&){++reads;p.assign(host_skin::pixel_count,host_menu::color(0x334455));return true;}));
 std::array<std::vector<uint32_t>,3> frames;for(auto& f:frames){f.resize(host_skin::pixel_count);compose_host_surface(f.data(),1280,"",true,false);}
 assert(reads==1&&g_cpu_cleared==3);assert(frames[0][360*1280+100]!=host_menu::color(0));
 const auto original=frames[0];const auto warm=g_controller_legends.generation();
 gpu_step();const auto initial=cache.generation;gpu_step();assert(cache.generation==initial);
 g_menu_settings.bezel=6;gpu_step();const auto fixed=cache.generation;assert(fixed>initial&&cache.canvas!=original&&reads==1);
 g_menu_settings.bezel=7;gpu_step();assert(cache.generation>fixed&&cache.canvas==original&&reads==1);
 // Both source transitions happen with the same hypothetical epoch/frame/FPS.
 g_screen_w=320;g_screen_h=240;gpu_step();assert(cache.generation>initial&&cache.canvas!=original);
 const auto landscape=cache.generation;g_screen_w=640;g_screen_h=480;gpu_step();assert(cache.generation>landscape); // same aspect too
 const auto same_aspect=cache.generation;gpu_step();assert(cache.generation==same_aspect);
 g_screen_w=640;g_screen_h=360;gpu_step();assert(cache.generation>same_aspect);for(auto p:cache.canvas)assert(p==host_menu::color(0));
 // CPU rotation repaints all slots, then stable frames do not redraw or reload.
 g_screen_w=360;g_screen_h=360;for(auto& f:frames)compose_host_surface(f.data(),1280,"",true,false);
 assert(frames[0]==frames[1]&&frames[1]==frames[2]&&frames[0]!=original&&g_cpu_cleared==3);
 const auto calls=text_calls;compose_host_surface(frames[0].data(),1280,"",true,false);assert(text_calls==calls&&reads==1);
 assert(g_controller_legends.generation()>warm);
 std::puts("PASS UniversalChrome: production CPU triple slots, portrait/landscape/square/fullwidth geometry, stable cache reuse and GPU source changes with same frame/FPS and same aspect");
}
'''
p=out/'black-chrome.cpp';p.write_text(cpp)
commands=[['g++','-std=c++17','-fno-exceptions','-O1','-g','-fno-pie','-no-pie','-fsanitize=address,undefined','-fno-sanitize-recover=all','-I'+str(root/'src'),str(p),'-o',str(out/'black-chrome')],[str(out/'black-chrome')]]
for c in commands:
 r=subprocess.run(c,cwd=root,capture_output=True,text=True)
 print(r.stdout+r.stderr,end='')
 if r.returncode:sys.exit(r.returncode)
