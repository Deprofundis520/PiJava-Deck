#!/usr/bin/env python3
"""Real JAR region on real VM/emitter/pool with finite libnx mock.

No production edits: diagnostic VM and baseline pool are isolated in --output.
With --cross-root, builds/runs AArch64 code under qemu-user as well as x64.
"""
import argparse
import hashlib
import os
from pathlib import Path
import shlex
import subprocess
import zipfile


def baseline_pool(path):
    data = path.read_bytes()
    expected = '0c9430270676a58bc1602e0441aea6d9023e4993a9b050e47670005a78159cd4'
    if hashlib.sha256(data).hexdigest() != expected:
        raise SystemExit('Wrong original Fit18 source ZIP SHA-256')
    with zipfile.ZipFile(path) as archive:
        names = [name for name in archive.namelist()
                 if name == 'src/jit_code_pool.h' or name.endswith('/src/jit_code_pool.h')]
        if len(names) != 1:
            raise SystemExit('Expected exactly one src/jit_code_pool.h in original Fit18 ZIP')
        return archive.read(names[0])


def main():
    source = Path(__file__).resolve().parents[2]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--jar', type=Path, required=True)
    parser.add_argument('--baseline-source-zip', type=Path, required=True,
                        help='Original Fit18 source ZIP with pinned SHA-256; no git metadata needed')
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--cross-root', type=Path)
    args = parser.parse_args()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    jar = args.jar.resolve()
    jar_sha = hashlib.sha256(jar.read_bytes()).hexdigest()
    if jar_sha != '0ecdc696a3bb5fd03921640b9e4ce24164963c641120abf3b4ec578f05fab85d':
        raise SystemExit('Wrong original game JAR SHA-256')
    vm = (source / 'src/j2mevm.cpp').read_text()
    needle = '#include "native_jit236.h"'
    if vm.count(needle) != 1:
        raise SystemExit('Expected one native_jit236 include')
    hybrid = vm.replace(needle, '#define __SWITCH__ 1\n' + needle + '\n#undef __SWITCH__')
    stale = "jit236::fault_stale()=(f[0]=='1');"
    if hybrid.count(stale) != 1:
        raise SystemExit('Expected one desktop stale fault setter')
    hybrid = hybrid.replace(stale, 'if(f[0]==\'1\')die("hybrid boundary disallows stale injection");')
    if os.environ.get('J2ME_JIT_FAULT_STALE'):
        raise SystemExit('Desktop stale injection unsupported by this diagnostic boundary')
    diagnostic = output / 'j2mevm-jit-mock.cpp'
    diagnostic.write_text(hybrid)
    baseline = output / 'baseline-headers'
    baseline.mkdir(exist_ok=True)
    (baseline / 'native_jit236.h').write_bytes((source / 'src/native_jit236.h').read_bytes())
    # Keep #pragma-once identities consistent: the region header itself includes
    # native_jit236.h relative to its own directory.
    (baseline / 'jit_region.h').write_bytes((source / 'src/jit_region.h').read_bytes())
    (baseline / 'runtime').mkdir(exist_ok=True)
    (baseline / 'runtime/native_jit.inc').write_bytes((source / 'src/runtime/native_jit.inc').read_bytes())
    baseline_vm = output / 'j2mevm-baseline-jit-mock.cpp'
    baseline_vm.write_text(hybrid.replace('#include "runtime/native_jit.inc"',
        '#include "' + str(baseline / 'runtime/native_jit.inc') + '"'))
    original_zip = args.baseline_source_zip.resolve()
    old_pool = baseline_pool(original_zip)
    (baseline / 'jit_code_pool.h').write_bytes(old_pool)
    fingerprints = [f'{jar_sha}  {jar}',
                    f'{hashlib.sha256(original_zip.read_bytes()).hexdigest()}  {original_zip}']
    for path in [source / 'src/j2mevm.cpp', source / 'src/native_jit236.h',
                 source / 'src/jit_code_pool.h', source / 'src/jit_region.h',
                 source / 'src/runtime/native_jit.inc', Path(__file__),
                 source / 'tests/runtime_fit19/real_jar_region_checks.cpp',
                 source / 'tests/runtime_fit13/jit_mock/switch.h', diagnostic, baseline_vm,
                 baseline / 'jit_code_pool.h']:
        fingerprints.append(f'{hashlib.sha256(path.read_bytes()).hexdigest()}  {path}')
    (output / 'source-sha256.txt').write_text('\n'.join(fingerprints) + '\n')

    def run(label, command, env=None):
        command = list(map(str, command))
        print(label + ': ' + shlex.join(command), flush=True)
        result = subprocess.run(command, cwd=source, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=300)
        (output / (label + '.log')).write_bytes(result.stdout)
        print(result.stdout.decode(errors='replace'), end='', flush=True)
        print(f'{label}_signedrc={result.returncode}', flush=True)
        if result.returncode:
            raise SystemExit(result.returncode)

    architectures = [('x64', ['gcc'], ['g++'], [], None)]
    if args.cross_root:
        cross = args.cross_root.resolve()
        env = os.environ.copy()
        env['LD_LIBRARY_PATH'] = str(cross / 'usr/lib/x86_64-linux-gnu')
        sysroot = '--sysroot=' + str(cross)
        architectures.append(('a64', [cross / 'usr/bin/aarch64-linux-gnu-gcc', sysroot],
                              [cross / 'usr/bin/aarch64-linux-gnu-g++', sysroot],
                              [cross / 'usr/bin/qemu-aarch64', '-L', cross / 'usr/aarch64-linux-gnu'], env))
    for arch, cc, cxx, emulator, env in architectures:
        puff = output / ('puff-' + arch + '.o')
        run('build-puff-' + arch, cc + ['-O1', '-c', source / 'src/puff.c', '-o', puff], env)
        for variant in ['new', 'baseline']:
            exe = output / ('real-jar-' + variant + '-' + arch)
            includes = (['-I' + str(baseline)] if variant == 'baseline' else [])
            run('build-' + variant + '-' + arch, cxx + ['-O0', '-g0', '-std=c++17', '-fno-exceptions',
                '-ffunction-sections', '-fdata-sections'] + includes + ['-I' + str(source / 'src'),
                '-I' + str(source / 'tests/runtime_fit13/jit_mock'),
                '-DJ2ME_TEST_VM="' + str(baseline_vm if variant == 'baseline' else diagnostic) + '"',
                source / 'tests/runtime_fit19/real_jar_region_checks.cpp', puff,
                '-Wl,--gc-sections', '-pthread', '-ldl', '-o', exe], env)
            run(variant + '-pool-' + arch, emulator + [exe, jar, source / 'romfs/classes'] +
                (['baseline'] if variant == 'baseline' else []), env)


if __name__ == '__main__':
    main()
