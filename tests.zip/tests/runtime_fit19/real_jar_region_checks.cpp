// Real game class bytes and real VM region glue, finite libnx object mock.
// Explicit QuickSite resolution/initialized classes and constructed state:
// this is a deterministic installation contract, not natural game warm-up/FPS.
#ifndef J2ME_TEST_VM
#error "Select a diagnostic VM copy whose native_jit236 include uses the finite libnx mock"
#endif
#define main emulator_main
#include J2ME_TEST_VM
#undef main

static void check(bool ok,const char* why){if(!ok){std::cerr<<"FAIL real-region "<<why<<" result="<<jit236::Executable::last_result()<<" blocks="<<jit236::code_pool_stats().blocks<<" objects="<<fit13_mock::live<<'\n';std::exit(1);}}
static std::vector<jit236::Executable> fill(unsigned count,jit236::InstallMode mode=jit236::InstallMode::Normal){
 const uint8_t bc[]={26,4,96,172};const std::string desc="(I)I";jit236::Spec s{bc,sizeof bc,&desc,8,1,2,false,false,nullptr};
 jit236::Program p;check(jit236::verify(s,p),"filler verifies");std::vector<jit236::Executable> out(count);
 for(auto& e:out){auto id=jit236::next_install_id();check(e.install(jit236::emit_host(p,id),id,mode),"filler installs");}return out;
}
int main(int argc,char** argv){
 check(argc>=3,"jar and classpath arguments");VMS_DIAG(g_log_draw)=false;
 VMS_CL(g_classpath).push_back(argv[2]);std::vector<uint8_t> bytes;std::string error;
 check(read_whole(argv[1],bytes)&&unzip(bytes,VMS_CL(g_jar_files),error),"original JAR unzip");
 const int cls=ensure_class("v");unsigned mi=0;bool found=false;
 for(;mi<VMS_CL(g_classes)[cls].methods.size();++mi){auto& m=VMS_CL(g_classes)[cls].methods[mi];if(m.name=="a"&&m.desc=="(Ljavax/microedition/lcdui/Graphics;Ljava/lang/String;III)V"){found=true;break;}}
 check(found,"actual v.a(Graphics,String,III)V method");
 // Do not hold Class references across ensure_class: loading may reallocate.
 auto raw=VMS_CL(g_classes)[cls].methods[mi].code;
 for(size_t pc=0;pc<raw.size();){int op=raw[pc];int len=jvm_op_length(raw,pc);check(len>0,"bytecode decoding");
  if(op==178||op==180){std::string owner,name,desc;resolve_member(VMS_CL(g_classes)[cls],(raw[pc+1]<<8)|raw[pc+2],owner,name,desc);
   int cid=ensure_class(owner);auto* f=find_field(cid,name,desc);check(f!=nullptr,"real field resolves");
   auto& m=VMS_CL(g_classes)[cls].methods[mi];if(m.quick.empty())m.quick.resize(m.code.size());m.quick[pc].kind=1;m.quick[pc].a=f->owner;m.quick[pc].b=f->slot;
   std::cout<<"RESOLVE pc="<<pc<<" op="<<op<<" field="<<owner<<'.'<<name<<':'<<desc<<" cls="<<f->owner<<" slot="<<f->slot<<'\n';}
  std::cout<<"BC pc="<<pc<<" op="<<op;for(int k=1;k<len;++k)std::cout<<' '<<int(raw[pc+k]);std::cout<<'\n';pc+=len;}
 for(auto& c:VMS_CL(g_classes))c.init_state=2;
 auto& m=VMS_CL(g_classes)[cls].methods[mi];
 std::cout<<"METHOD code="<<m.code.size()<<" locals="<<m.max_locals<<" stack="<<m.max_stack<<" flags="<<m.flags<<'\n';
 std::vector<jit236::Constant> constants(VMS_CL(g_classes)[cls].cp.size());
 for(size_t i=0;i<constants.size();++i){auto& c=VMS_CL(g_classes)[cls].cp[i];if(c.tag==3)constants[i]={true,int32_t(c.a)};}
 std::vector<jitr::StaticSite> statics(m.code.size());std::vector<int> fields(m.code.size(),-1);
 for(size_t pc=0;pc<m.quick.size();++pc)if(m.quick[pc].kind==1){if(m.code[pc]==178)statics[pc]={m.quick[pc].a,m.quick[pc].b};else if(m.code[pc]==180)fields[pc]=m.quick[pc].b;}
 jitr::Spec spec;spec.code=m.code.data();spec.size=m.code.size();spec.entry=108;spec.max_locals=m.max_locals;spec.max_stack=m.max_stack;spec.constants=&constants;spec.static_site=&statics;spec.field_slot=&fields;spec.int_array_stores=true;
 jitr::Region region;check(jitr::build(spec,region),"actual region at108 builds");
 for(int pc:{108,110,127,140,151,174}){bool compiled=false;for(const auto& n:region.ins)if(n.pc==pc&&n.kind==jitr::K_OP)compiled=true;check(compiled,"logged hotspot PCs present as compiled ops");}
 const jitr::Helpers helpers{jitr_h_getfield,jitr_h_aload,jitr_h_alen,jitr_h_icget,jitr_h_icchk,jitr_h_cast,jitr_h_inst,jitr_h_icgfx,jitr_h_iastore,jitr_h_getstatic};
 std::cout<<"REGION entry=108 nodes="<<region.ins.size()<<" ops="<<region.ops<<" a64_low_id_bytes="<<jitr::emit_a64(region,helpers,1).size()<<" a64_full_id_bytes="<<jitr::emit_a64(region,helpers,0x4a320001).size()<<" host_full_id_bytes="<<jitr::emit_host(region,helpers,0x4a320001).size()<<'\n';
 // Safe, deliberately constructed 8x8 one-character glyph; no Graphics call.
 if(VMS_HEAP(g_heap).empty())VMS_HEAP(g_heap).push_back(Obj{});
 const int bits=alloc_array("[B",8),pixels=alloc_array("[I",64);
 for(unsigned i=0;i<8;++i)VMS_HEAP(g_heap)[bits].elems.set(i,Value::of_i(255));
 auto setstatic=[&](const char* name,const char* desc,Value value){auto* f=find_field(cls,name,desc);check(f&&f->is_static,"actual game static slot");VMS_CL(g_classes)[f->owner].statics[f->slot]=value;};
 setstatic("a","B",Value::of_i(8));setstatic("b","B",Value::of_i(1));setstatic("e","[B",Value::of_ref(bits));setstatic("g","[I",Value::of_ref(pixels));
 auto state=[&](){Frame f;f.method=&m;f.pc=108;f.op_pc=-1;f.locals.resize(m.max_locals);for(auto p:std::vector<std::pair<int,int>>{{5,0},{6,7},{7,7},{8,8},{9,0},{11,1},{12,8},{13,0},{14,65},{15,0x123456}})f.locals[p.first]=Value::of_i(p.second);return f;};
 auto resetpixels=[&](){for(unsigned i=0;i<64;++i)VMS_HEAP(g_heap)[pixels].elems.set(i,Value::of_i(0));};
 fit13_mock::limit=10;std::string why;check(jit_region_self_test(why),"real dedicated region self-test passes");
 auto owners=fill(144);auto before=jit236::code_pool_stats();check(before.slices==144&&!before.quarantined_pages&&before.dedicated_blocks==1,"144 live pages plus dedicated selftest, no retired pages");
 auto& engine=VMS_NATIVE(g_native_jit);engine.enabled=engine.available=true;
 int done=0;for(unsigned i=0;i<JitRegionHot;++i){auto f=state();done=jit_region_try(f,10000);}
 const bool old=argc>3&&std::string(argv[3])=="baseline";
 const auto& e=g_jit_regions[&m].at[108];
 std::cout<<"INSTALL expected="<<(old?"reject":"success")<<" actual="<<(e.state==1?"success":"reject")<<" done="<<done<<" block_bytes="<<jit236::CodeBlockBytes<<" before_objects="<<before.blocks<<" after_objects="<<fit13_mock::live<<" peak_objects="<<fit13_mock::peak<<" live_pages="<<jit236::code_pool_stats().used_bytes/jit236::CodePage<<" result="<<jit236::Executable::last_result()<<" error="<<jit236::Executable::last_error()<<'\n';
 if(old){check(e.state!=1&&!done&&jit236::Executable::last_result()==0xce01,"old pool reproduces native resource rejection of same real region");}
 else{
  check(e.state==1&&done>0&&fit13_mock::peak<=10,"new pool installs and executes actual region under ten-object ceiling");
  const auto hostbytes=jitr::emit_host(region,helpers,e.exe.id);check(e.exe.size==((hostbytes.size()+4095)&~size_t(4095)),"VM installs expected emitted region geometry");
  for(unsigned budget:{1u,2u,3u,8u,32u,128u,1024u,10000u}){
   resetpixels();auto reference=state();int expected=execute_fast_batch(reference,budget);std::vector<int32_t> expectedpixels(64);for(unsigned i=0;i<64;++i)expectedpixels[i]=VMS_HEAP(g_heap)[pixels].elems.get(i).i;
   resetpixels();auto f=state();int actual=jit_region_try(f,budget);check(actual==expected&&f.pc==reference.pc&&f.op_pc==reference.op_pc&&f.stack.size()==reference.stack.size(),"real region interpreter exact PC/budget/stack depth");
   for(unsigned i=0;i<f.locals.size();++i)check(f.locals[i].i==reference.locals[i].i&&f.locals[i].ref==reference.locals[i].ref,"real region interpreter locals");
   for(unsigned i=0;i<f.stack.size();++i)check(f.stack[i].i==reference.stack[i].i&&f.stack[i].ref==reference.stack[i].ref,"real region interpreter live operands");
   uint64_t checksum=0;for(unsigned i=0;i<64;++i){int32_t value=VMS_HEAP(g_heap)[pixels].elems.get(i).i;check(value==expectedpixels[i],"real region interpreter pixel stores");checksum+=uint32_t(value);}
   std::cout<<"DIFFERENTIAL budget="<<budget<<" ops="<<actual<<" exit="<<f.pc<<" last="<<f.op_pc<<" checksum="<<checksum<<'\n';
   if(budget==10000)check(f.pc==211&&checksum==uint64_t(64)*0x123456,"all 64 pixels written and stop before real Graphics call");
  }
 }
 jit_region_reset();engine.clear();owners.clear();while(!jit236::code_quarantine().empty())jit236::release_oldest_quarantine();jit236::dedicated_blocks().clear();
 check(!fit13_mock::live&&!jit236::code_pool_stats().slices,"all resources released");
 std::cout<<"PASS real_jar_region host="<<jit236::architecture()<<" finite_libnx_mock=1 resolved_quicksites_fixture=1 natural_game_warmup=0 game_fps_claim=0\n";
}
