// Real allocator/emitter, finite libnx boundary. This is an object-count
// regression matching the Fit18 device failure, not a Switch FPS benchmark.
#define main fit13_resource_checks_main
#include "../runtime_fit13/jit_resource_checks.cpp"
#undef main

static void hot_install() {
    fit13_mock::limit = 10;
    jit236::Executable self; install(self, jit236::InstallMode::Dedicated); self.close();
    std::vector<jit236::Executable> owners(144);
    for (auto& e : owners) install(e);
    const auto before = jit236::code_pool_stats();
    check(!before.quarantined_pages, "device fixture has no reclaimable pages");
    jit236::Executable hot; const auto id = jit236::next_install_id();
    auto bytes = code(id); bytes.resize(3360, 0);
    check(hot.install(bytes, id), "3360-byte hot code installs after 144 live pages plus dedicated self-test");
    runs(hot);
    for (auto& e : owners) runs(e);
    check(fit13_mock::peak <= 10, "hot installation uses at most ten native resources");
    // Keep a dedicated object isolated, and fill the nine ordinary objects.
    // No page from the reserved self-test arena may enter the ordinary pool.
    constexpr size_t ordinary_pages = 9 * jit236::CodeBlockBytes / jit236::CodePage;
    std::vector<jit236::Executable> remaining(ordinary_pages - owners.size() - 1);
    for (auto& e : remaining) install(e);
    check(fit13_mock::live == 10 && jit236::code_pool_stats().slices == ordinary_pages,
          "ten objects hold exactly 4608 ordinary live pages plus isolated self-test arena");
    check(jit236::code_pool_stats().reserved_bytes == 9 * jit236::CodeBlockBytes + jit236::CodeDedicatedBytes,
          "backing accounting includes the smaller isolated mapping at its actual size");
    jit236::Executable overflow; const auto overflow_id = jit236::next_install_id();
    check(!overflow.install(code(overflow_id), overflow_id), "live-only pressure terminates without stealing dedicated pages");
    runs(hot); for (auto& e : owners) runs(e); for (auto& e : remaining) runs(e);
    hot.close(); owners.clear(); remaining.clear(); cleanup();
}

static void all_pages() {
    fit13_mock::limit = 1;
    constexpr size_t pages = jit236::CodeBlockBytes / jit236::CodePage;
    check(pages == 512, "arena has 512 pages under unchanged 20 MiB budget");
    std::vector<jit236::Executable> owners(pages);
    std::vector<void*> addresses;
    for (auto& e : owners) {
        install(e); addresses.push_back(reinterpret_cast<void*>(e.fn));
    }
    for (size_t i = 0; i < pages; ++i) {
        runs(owners[i]);
        for (size_t j = i + 1; j < pages; ++j)
            check(addresses[i] != addresses[j], "all eight bitmap words describe distinct pages");
    }
    jit236::Executable overflow; const auto id = jit236::next_install_id();
    check(!overflow.install(code(id), id), "full live arena falls back without overwriting a peer");
    // Release the high bit then reuse it under resource pressure.
    owners.back().close();
    check(overflow.install(code(id), id), "page 511 can be released and reused");
    check(reinterpret_cast<void*>(overflow.fn) == addresses.back(), "only retired high page is reused");
    runs(overflow);
    for (size_t i = 0; i + 1 < pages; ++i) runs(owners[i]);
    overflow.close(); owners.clear(); cleanup();
    // Exercise a full 64-bit mask and a >32-page contiguous allocation.
    for (size_t n : {size_t(33), size_t(64)}) {
        jit236::Executable e; const auto large_id = jit236::next_install_id();
        auto bytes = code(large_id); bytes.resize(n * jit236::CodePage, 0);
        check(e.install(bytes, large_id), "large contiguous slice installs"); runs(e);
        check(jit236::code_pool_stats().used_bytes == n * jit236::CodePage, "large page accounting exact");
        e.close(); cleanup();
    }
}

int main(int argc, char** argv) {
    if (argc != 2) return 2;
    const std::string scenario = argv[1];
    if (scenario == "hot") hot_install();
    else if (scenario == "pages") all_pages();
    else return 2;
    std::cout << "PASS fit19 " << scenario << " host=" << jit236::architecture()
              << " block_bytes=" << jit236::CodeBlockBytes << " peak_objects=" << fit13_mock::peak << '\n';
}
