#include "../src/host_menu_settings.h"
#include "../src/host_skin.h"
#include <cassert>
#include <filesystem>
#include <fstream>
int main(int argc,char** argv){
 assert(argc==2);assert(host_menu::bezel_count==8);
 assert(std::string(host_menu::bezel_name(7))=="自适应屏幕");
 assert(host_menu::bezel_choices.size()==7);
 for(int id:host_menu::bezel_choices)assert(id!=0);
 assert(host_menu::next_bezel(3)==7&&host_menu::next_bezel(7)==4);
 {std::ofstream old((std::filesystem::path(argv[1])/"old.cfg").string());old<<"J2ME_MENU 2\nbezel=0\nshow_fps=0\n";}
 host_menu::Settings old;assert(host_menu::load_settings((std::filesystem::path(argv[1])/"old.cfg").string(),old));
 assert(old.bezel==7&&!old.show_fps);
 host_menu::Settings s;s.bezel=7;s.filter=display_filter::Filter::Crt;
 auto p=(std::filesystem::path(argv[1])/"menu.cfg").string();assert(host_menu::save_settings(p,s));
 host_menu::Settings t;assert(host_menu::load_settings(p,t)&&t.bezel==7&&t.filter==s.filter);
 assert(std::string(host_skin::path(7))==host_skin::path(6));
 std::vector<uint32_t> frame(1280*720,0xff123456),old_texture(1280*720,0xffffffff);
 host_menu::render_bezel(frame.data(),1280,7,{},old_texture.data(),old_texture.size());
 host_menu::UniversalLayout layout;
 for(int y=0;y<720;++y)for(int x=0;x<1280;++x){
  bool side=false;for(const auto& pane:layout.panes)side|=x>=pane.x&&x<pane.x+pane.w&&y>=pane.y&&y<pane.y+pane.h;
  assert(frame[size_t(y)*1280+x]==(side?0xffffffff:0xff000000));
 }
 std::puts("PASS adaptive menu: selectable mode7, config roundtrip, shared black skin, side artwork projection and black game viewport");
}
