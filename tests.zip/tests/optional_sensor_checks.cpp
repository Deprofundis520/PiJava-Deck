#define main emulator_main
#include "../src/j2mevm.cpp"
#undef main

static void require(bool ok, const char* label) {
    if (!ok) { std::cerr << "FAIL " << label << "\n"; std::exit(1); }
}
int main(int argc, char** argv) {
    if (argc != 4) return 2;
    VMS_CL(g_classpath) = {argv[1], argv[2]};
    VMS_DIAG(g_log_draw) = false;
    const std::string mode = argv[3];
    int manager = load_class_file("javax/microedition/sensor/SensorManager", false);
    require(manager >= 0, "SensorManager class is present in frozen API");
    if (mode == "declarations") {
        require((VMS_CL(g_classes)[manager].flags & 0x11) == 0x11, "SensorManager public final");
        for (const char* name : {"SensorInfo", "SensorListener", "SensorConnection", "Channel", "ChannelInfo", "Condition", "ConditionListener", "Data", "DataListener", "DataAndErrorListener"}) {
            int cls = ensure_class(std::string("javax/microedition/sensor/") + name);
            require((VMS_CL(g_classes)[cls].flags & 0x601) == 0x601, "sensor contracts are public abstract interfaces");
        }
        require(class_assignable(ensure_class("javax/microedition/sensor/SensorConnection"), ensure_class("javax/microedition/io/Connection")), "SensorConnection extends Connection");
        require(class_assignable(ensure_class("javax/microedition/sensor/DataAndErrorListener"), ensure_class("javax/microedition/sensor/DataListener")), "DataAndErrorListener extends DataListener");
        require(find_method(manager, "findSensors", "(Ljava/lang/String;Ljava/lang/String;)[Ljavax/microedition/sensor/SensorInfo;", false), "two-argument discovery descriptor");
        require(find_method(manager, "findSensors", "(Ljava/lang/String;)[Ljavax/microedition/sensor/SensorInfo;", false), "URL discovery descriptor");
        std::cout << "PASS OptionalSensor declarations and dependency closure\n";
        return 0;
    }
    int expected = mode == "discovery" ? 8 : mode == "fallback" ? 3 : mode == "validation" ? 12 : mode == "listeners" ? 6 : mode == "values" ? 7 : -1;
    if (expected < 0) return 2;
    int fixture = ensure_class("OptionalSensorChecks");
    auto result = run(find_method(fixture, mode == "fallback" ? "gameFallback" : mode, "()I", false), {});
    require(!VMS_EXEC(g_thrown), "Java test has no uncaught exception");
    require(result.i == expected, "actual VM sensor assertions");
    std::cout << "PASS OptionalSensor " << mode << " result=" << result.i << "\n";
}
