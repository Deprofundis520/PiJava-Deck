#pragma once
#include <windows.h>
#include <cstdint>
#define ST_RDONLY 1
struct statvfs {uint64_t f_flag=0,f_frsize=4096,f_bsize=4096,f_bavail=0;};
inline int statvfs(const char* path,struct statvfs* s){ULARGE_INTEGER free{},total{},all{};if(!GetDiskFreeSpaceExA(path,&free,&total,&all))return -1;s->f_bavail=free.QuadPart/4096;return 0;}
