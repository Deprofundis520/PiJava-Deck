#pragma once
#include <windows.h>
#include <io.h>
#include <direct.h>
#include <sys/stat.h>
#include <cstdlib>
#define lstat stat
#define mkdir(path,...) _mkdir(path)
#define sched_getcpu() int(GetCurrentProcessorNumber())
inline int setenv(const char*n,const char*v,int overwrite){if(!overwrite&&std::getenv(n))return 0;return _putenv_s(n,v);}
inline int unsetenv(const char*n){return _putenv_s(n,"");}
