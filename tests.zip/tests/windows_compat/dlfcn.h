#pragma once
#include <windows.h>
#define RTLD_NOW 0
#define RTLD_LOCAL 0
inline void* dlopen(const char* p,int){return reinterpret_cast<void*>(LoadLibraryA(p));}
inline void* dlsym(void* p,const char*n){return reinterpret_cast<void*>(GetProcAddress(reinterpret_cast<HMODULE>(p),n));}
inline int dlclose(void*p){return FreeLibrary(reinterpret_cast<HMODULE>(p))?0:-1;}
inline const char* dlerror(){return "Windows diagnostic host: dynamic library unavailable";}
