#include "../src/presentation/gpu_filter.h"
#include "../src/presentation/viewport.h"
#include <cassert>
#include <cstdio>

namespace {
using F=display_filter::Filter;
uint32_t read(const std::vector<uint32_t>& p,int w,int x,int y){return p[4+size_t(y)*w+x];}
uint32_t reference(const std::vector<uint32_t>& p,int x,int y,int ow,int oh){
 const int w=p[0],h=p[1];const F f=F(p[2]);
 if(f==F::Bilinear){
  int nx=(2*x+1)*w-ow,ny=(2*y+1)*h-oh,sx=0,sy=0,fx=0,fy=0;
  if(nx>0){sx=nx/(2*ow);fx=nx%(2*ow);}if(ny>0){sy=ny/(2*oh);fy=ny%(2*oh);}
  if(sx>=w-1){sx=w-1;fx=0;}if(sy>=h-1){sy=h-1;fy=0;}
  const uint32_t c[]={read(p,w,sx,sy),read(p,w,std::min(sx+1,w-1),sy),read(p,w,sx,std::min(sy+1,h-1)),read(p,w,std::min(sx+1,w-1),std::min(sy+1,h-1))};
  const unsigned weights[]={unsigned((2*ow-fx)*(2*oh-fy)),unsigned(fx*(2*oh-fy)),unsigned((2*ow-fx)*fy),unsigned(fx*fy)};
  const unsigned denominator=4*ow*oh;uint32_t out=0xff000000u;
  for(int shift=0;shift<24;shift+=8){unsigned sum=0;for(int i=0;i<4;++i)sum+=((c[i]>>shift)&255u)*weights[i];out|=((sum+denominator/2)/denominator)<<shift;}return out;
 }
 if(f==F::Scale2x){
  int vx=x*w*2/ow,vy=y*h*2/oh,sx=vx/2,sy=vy/2;
  uint32_t b=read(p,w,sx,std::max(0,sy-1)),d=read(p,w,std::max(0,sx-1),sy),e=read(p,w,sx,sy),r=read(p,w,std::min(w-1,sx+1),sy),hue=read(p,w,sx,std::min(h-1,sy+1));
  if(b==hue||d==r)return e;if(!(vy&1))return !(vx&1)?(d==b?d:e):(b==r?r:e);return !(vx&1)?(d==hue?d:e):(hue==r?r:e);
 }
 int sx=f==F::ScanlinesDX?((2*x+1)*w)/(2*ow):x*w/ow,sy=f==F::ScanlinesDX?((2*y+1)*h)/(2*oh):y*h/oh;
 uint32_t c=read(p,w,sx,sy),out=0xff000000u;
 for(unsigned channel=0;channel<3;++channel){unsigned v=(c>>(channel*8))&255;
  if(f==F::Lcd){if(channel!=unsigned(x)%3)v=v*3/4;if(y&1)v=v*7/8;}
  else if(f==F::Crt){if(y&1)v=v*3/4;}
  else if(f==F::ScanlinesDX)v=std::min(255u,(v*display_filter::detail::scanlinesdx_gains()[size_t(y%64)*48+x%48]+2048)/4096);
  out|=v<<(channel*8);
 }return out;
}
}
int main(){
 using namespace j2me_present::gpu_filter;
 static_assert(header_words==4,"adaptive uses the existing fourth raw word");
 uint64_t compared=0;
 // Exercise corrected float-division estimates near every output denominator,
 // including bilinear sums approaching the full-white uint32 bound.
 for(unsigned denominator=1;denominator<=3686400;denominator=denominator<256?denominator+1:denominator+7919){
  for(unsigned q:{0u,1u,17u,254u,255u})for(int delta:{-1,0,1}){
   const int64_t n=int64_t(denominator)*q+delta;
   if(n>=0&&n<(1ll<<30))assert(gpu_filter_divide(unsigned(n),denominator)==unsigned(n)/denominator);
  }
 }
 uint32_t random=0x8e21b73u;
 for(unsigned i=0;i<1000000;++i){random=random*1664525u+1013904223u;unsigned n=random&0x3fffffffu;random=random*1664525u+1013904223u;unsigned d=1u+random%3686400u;if(n/d<(1u<<24))assert(gpu_filter_divide(n,d)==n/d);}
 // The shader and presenter independently derive the same integer fit bounds.
 for(unsigned h=1;h<=800;++h)for(unsigned w=1;w<=800;++w){
  if(!logical_screen::valid_extent(int(w),int(h)))continue;
  const auto gpu=gpu_filter_viewport(w,h,1u);const auto cpu=j2me_present::game_viewport(w,h,true);
  assert(gpu.x==unsigned(cpu.x)&&gpu.y==unsigned(cpu.y)&&gpu.w==unsigned(cpu.w)&&gpu.h==unsigned(cpu.h));
 }

 for(auto size:{std::pair<int,int>{1,1},{1,640},{640,1},{17,19},{239,321},{240,320},{640,360},{640,640},{480,800},{800,480},{512,800},{800,512}}){
  int w=size.first,h=size.second,ow,oh;if(w*720>=h*1280){ow=1280;oh=std::max(1,h*1280/w);}else{oh=720;ow=std::max(1,w*720/h);}
  const auto rect=gpu_filter_viewport(w,h,1u);assert(rect.w==unsigned(ow)&&rect.h==unsigned(oh)&&rect.x==unsigned((1280-ow)/2)&&rect.y==unsigned((720-oh)/2));
  const auto fixed=gpu_filter_viewport(w,h,0u);assert(fixed.x==400&&fixed.y==40&&fixed.w==480&&fixed.h==640);
  std::vector<uint8_t> rgb(size_t(w)*h*3);for(size_t i=0;i<rgb.size();++i)rgb[i]=uint8_t((i*73+i/17)^0xad);
  for(unsigned pattern=0;pattern<2;++pattern)for(F f:{F::Bilinear,F::Scale2x,F::Lcd,F::Crt,F::ScanlinesDX}){
   if(pattern==1)std::fill(rgb.begin(),rgb.end(),255);
   std::vector<uint32_t> p;assert(pack(rgb,w,h,f,p,true));assert(p[3]==1);
   for(unsigned y=0;y<rect.h;++y)for(unsigned x=0;x<rect.w;++x){
    unsigned gain=display_filter::detail::scanlinesdx_gains()[size_t(y%64)*48+x%48];
    assert(gpu_filter_pixel_extent(p.data()+4,x,y,w,h,unsigned(f),gain,rect.w,rect.h)==reference(p,x,y,ow,oh));++compared;
   }
   assert(pack(rgb,w,h,f,p));assert(p[3]==0);
  }
 }
 FrameKey key{7,10,17,19,F::Crt};FrameCache cache;cache.committed(key);auto adaptive=key;adaptive.adaptive=true;
 assert(!(adaptive==key)&&cache.needs_upload(adaptive));cache.committed(adaptive);assert(!cache.needs_upload(adaptive)&&cache.needs_upload(key));
 std::printf("PASS adaptive GPU integer/reference pixels=%llu; fit origins, thin/odd/portrait/landscape, five filters, local ScanlinesDX, four-word header and cache; NOT GPU execution\n",(unsigned long long)compared);
}
