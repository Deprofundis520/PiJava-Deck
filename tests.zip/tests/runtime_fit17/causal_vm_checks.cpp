// Independent synthetic-class real-VM integration regression.
// No ROM/JAR, no VM/interpreter replacement, no game/RMS/save state.
// 20ms sleep uses actual host wait. 83/163ms cases mark only the fixture's
// earned-frame deadline / forced ready deadline as SYNTHETIC inputs below.
#ifndef J2ME_TEST_VM
#error Define J2ME_TEST_VM to the actual source/src/j2mevm.cpp
#endif
#if !__has_include("causal_diagnostics.h")
#error CAUSAL_FEATURE_MISSING_expected_RED
#else
#define main emulator_main
#include J2ME_TEST_VM
#undef main
#include <iostream>
#include <chrono>
#include <thread>
#include <cstdlib>
static void require(bool x,const char* why){if(!x){std::cerr<<"FAIL causal-real-vm "<<why<<std::endl;std::_Exit(1);}}
static CpEntry utf(const char* s){CpEntry c;c.tag=1;c.utf=s;return c;}
static CpEntry cp(int tag,int a,int b=0){CpEntry c;c.tag=uint8_t(tag);c.a=a;c.b=b;return c;}
static int klass(const char* name){const int id=int(VMS_CL(g_classes).size());Class c;c.name=name;c.init_state=2;
    VMS_CL(g_classes).push_back(std::move(c));VMS_CL(g_class_index)[name]=id;return id;}
static Method method(int cls,const char* name,const char* desc,std::initializer_list<uint8_t> code){Method m;m.class_id=cls;m.name=name;m.desc=desc;
    m.flags=8;m.max_locals=2;m.max_stack=4;m.code=code;return m;}
static Method *array_loop=nullptr,*nap=nullptr;static int fixture_cls=0,thread_cls=0;
static void setup(){
    VMS_DIAG(g_log_draw)=false;VMS_DIAG(g_p1).enabled=false;VMS_NATIVE(g_native_jit).enabled=false;
    VMS_EXEC(g_speed_cap)=0;VMS_EXEC(g_slice_ms)=14;VMS_EXEC(g_midlet_state)=MidletState::Active;
    VMS_HEAP(g_heap).assign(1,Obj{});VMS_HEAP(g_free).clear();VMS_CL(g_classes).clear();VMS_CL(g_class_index).clear();
    fixture_cls=klass("CausalFixture");thread_cls=klass("java/lang/Thread");
    auto& thread=VMS_CL(g_classes)[thread_cls];thread.methods.reserve(1);
    thread.methods.push_back(method(thread_cls,"sleep","(J)V",{}));thread.methods[0].native=true;thread.methods[0].flags|=0x100;
    auto& c=VMS_CL(g_classes)[fixture_cls];c.methods.reserve(2);
    c.cp={CpEntry{},utf("java/lang/Thread"),cp(7,1),utf("sleep"),utf("(J)V"),cp(12,3,4),cp(10,2,5)};
    // Actual bytecode loop: iconst0;istore1; bipush9;newarray int;pop;iinc1;
    // iload1;iload0;if_icmplt -10;return. newarray's original op_pc is4.
    c.methods.push_back(method(fixture_cls,"allocate","(I)V",{3,60,16,9,188,10,87,132,1,1,27,26,161,255,246,177}));
    // Actual invokestatic java/lang/Thread.sleep(J)V at original op_pc1.
    c.methods.push_back(method(fixture_cls,"nap","(J)V",{30,184,0,6,177}));
    array_loop=&c.methods[0];nap=&c.methods[1];
    diag_causal_reset();
}
static JavaThreadContext& new_worker(){VMS_EXEC(g_threads).emplace_back();auto& t=VMS_EXEC(g_threads).back();
    t.ref=alloc_obj(thread_cls);t.begun=true;t.state=ThreadState::Runnable;return t;}
static void start_nap(JavaThreadContext& t,int64_t ms){
    auto saved=VMS_EXEC(g_exec_ctx).save_slice();VMS_EXEC(g_exec_ctx).enter_thread(&t);
    VMS_EXEC(g_resume_request)=true;run(nap,{Value::of_l(ms)});VMS_EXEC(g_exec_ctx).restore_slice(saved);
    require(t.state==ThreadState::Sleeping,"actual invokestatic must yield as Sleeping");
    require(g_device_diag.sleeps.pending()==1,"Thread.sleep integration must create pending span");
}
static const runtime_cause::SleepCompletion& last(){auto& s=g_device_diag.sleeps;
    require(s.completions>0,"missing completed/canceled span");return s.history[size_t((s.completions-1)%s.history.size())];}
static void allocation_case(){
    g_device_diag.allocations.clear();run(array_loop,{Value::of_i(7)});
    auto& a=g_device_diag.allocations;
    require(a.calls==7&&a.bytes==7*9*4,"actual newarray int9 seven iterations must report7 allocations252bytes");
    bool found=false;for(const auto& r:a.rows)if(r.used&&r.method==diag_method(array_loop)&&r.bci==4&&r.kind=='I'){
        require(r.calls==7&&r.bytes==252&&r.min_length==9&&r.max_length==9,"wrong exact allocation-site counters");found=true;}
    require(found,"actual newarray must keep methodID and original op_pc4");
    std::cout<<"PASS actual_bytecode_newarray method=CausalFixture.allocate(I)V bci=4 calls=7 length=9 payload_bytes=252\n";
}
static void real_sleep_case(){
    auto& t=new_worker();const auto before=g_device_diag.sleeps.completions;start_nap(t,20);
    require(g_device_diag.sleeps.completions==before,"request is not completion");
    std::this_thread::sleep_for(std::chrono::milliseconds(23));refresh_thread(t);
    require(t.state==ThreadState::Runnable,"actual refresh_thread after host wait must observe runnable");
    require(g_device_diag.sleeps.completions==before&&g_device_diag.sleeps.pending()==1,"ready is not dispatch completion");
    std::this_thread::sleep_for(std::chrono::milliseconds(3));require(pump_one_thread(),"actual pump must dispatch ready fixture");
    auto c=last();require(c.status==runtime_cause::Status::Completed,"actual pump completion status");
    require(c.request.requested_ms==20&&c.request.effective_ms==20,"unpaced20 request/effective distinction");
    require(c.request.method==diag_method(nap)&&c.request.bci==1,"Thread.sleep caller must preserve invoke op_pc1");
    require(c.ready_us>=c.request.started_us&&c.dispatched_us>=c.ready_us,"request/ready/dispatch monotonic order");
    require(c.dispatched_us-c.ready_us>=1000,"deliberately deferred real dispatch must remain visible separately");
    require(c.request.generation==VMS_HEAP(g_heap)[t.ref].generation,"weak thread slot generation must be copied");
    require(g_device_diag.sleeps.pending()==0,"completed span removed");
    std::cout<<"PASS real_sleep20 requested_ms="<<c.request.requested_ms<<" effective_ms="<<c.request.effective_ms
        <<" residence_us="<<c.ready_us-c.request.started_us<<" dispatch_delay_us="<<c.dispatched_us-c.ready_us<<'\n';
}
static void pacing_case(int64_t requested){
    auto& t=new_worker();VMS_EXEC(g_speed_cap)=60;
    // SYNTHETIC fixture-only frame proof/deadline. No rendering/game state is loaded.
    t.frame_due_us=paint_clock_us()+16667;
    start_nap(t,requested);
    // SYNTHETIC deadline advance: skip actually waiting163ms; refresh_thread and
    // pump remain production paths. Request/effective recording precedes this input.
    t.wake_us=paint_clock_us()-1;t.wake=monotonic_ms()-1;refresh_thread(t);
    require(pump_one_thread(),"synthetic-ready fixture must use real pump dispatch");const auto c=last();
    require(c.request.requested_ms==requested,"requested value must be retained unchanged");
    if(requested==83){require(c.request.effective_ms>=1&&c.request.effective_ms<=17,"actual83ms pacing must use earned near16ms deadline");
        require(c.request.route==runtime_cause::Route::Frame&&c.request.owned_before,"83 frame route and owned-before evidence");}
    else {require(c.request.effective_ms==163,"actual >120ms rule must preserve163ms");
        require(c.request.route==runtime_cause::Route::LongUnpaced,"163 outside-frame-range route evidence");}
    std::cout<<"PASS actual_sleep_rule requested_ms="<<requested<<" effective_ms="<<c.request.effective_ms<<" route="<<runtime_cause::route_name(c.request.route)
        <<" synthetic_fixture_frame_deadline=1 synthetic_ready_deadline=1\n";VMS_EXEC(g_speed_cap)=0;
}
static void reset_cancel_generation_case(){
    auto& t=new_worker();start_nap(t,20);auto n=g_device_diag.sleeps.completions;finish_thread(t);
    require(g_device_diag.sleeps.pending()==0&&g_device_diag.sleeps.completions==n+1,"actual finish_thread hook must cancel pending span");
    require(last().status==runtime_cause::Status::Canceled,"cancel reason distinct from completion");
    t.state=ThreadState::Runnable;t.frames.clear();start_nap(t,20);n=g_device_diag.sleeps.completions;
    reset_runtime_stats();require(g_device_diag.sleeps.pending()==0,"actual reset_runtime_stats must cancel in-flight span");
    require(g_device_diag.sleeps.completions==n+1&&last().status==runtime_cause::Status::Canceled,"reset retains canceled span evidence");
    require(g_device_diag.allocations.calls==0&&g_device_diag.sleeps.window_requests==0,"reset clears window counters");
    t.state=ThreadState::Runnable;t.frames.clear();start_nap(t,20);n=g_device_diag.sleeps.completions;
    // SYNTHETIC weak-slot reuse: only self-owned fixture Obj generation changes.
    ++VMS_HEAP(g_heap)[t.ref].generation;diag_sleep_ready(t);diag_sleep_dispatch(t);
    require(g_device_diag.sleeps.pending()==0&&g_device_diag.sleeps.completions==n+1,"reused slot must retire old request exactly once");
    require(last().status==runtime_cause::Status::StaleGeneration,"generation mismatch must never complete as a new thread");
    std::cout<<"PASS cancel_reset_weak_generation synthetic_self_owned_generation_reuse=1\n";
}
int main(){setup();allocation_case();real_sleep_case();pacing_case(83);pacing_case(163);reset_cancel_generation_case();
    std::cout<<"PASS causal real VM integration fixture; no game/JAR/ROM/RMS; JIT benchmark is separate\n";
}

#endif // causal feature availability
