#include "runtime_diagnostics.h"
#include "fit16-real-windows.h"
#include <iostream>
#include <array>
using namespace runtime_diag;
static Window convert(const RealWindow& r) {
    Window w;w.duration_us=r.duration;w.worker_cpu_ns=r.cpu;w.draws=r.draws;w.changes=r.changes;
    w.presents=r.presents;w.max_draw_interval_us=r.gap;w.budget_frames=r.budget;w.cap=r.cap;
    w.active=r.lifecycle==1;w.paused=r.paused!=0;w.budget_valid=w.cap==30||w.cap==60;return w;
}
int main() {
    int failures=0;WindowDetector detector;std::array<unsigned,58> flags{};
    for(const auto& r:real_windows)flags[r.id]=detector.observe(r.end,convert(r));
    auto check=[&](bool ok,const char* label){std::cout<<(ok?"PASS ":"FAIL ")<<label<<'\n';failures+=!ok;};
    // Exact source windows, unchanged. Zero draw max=0 is lack of completed interval,
    // not proof of no freeze. The observation need not claim root cause.
    check(flags[28]!=0,"real w28 armed continuous draw demand, zero completed draw, 928ms worker CPU: progress observation");
    check(flags[29]&WindowDetector::LongGap,"real w29 2099696us interval survives intervening zero-draw window");
    check(flags[41]&WindowDetector::CapShortfall,"real w41 15 paced draws, 1005780us, 214722809ns CPU: severe single-window shortfall");
    check(flags[47]&WindowDetector::CapShortfall,"real w47 17 paced draws, 1002203us, 196641513ns CPU: severe single-window shortfall");
    check(flags[30]==0&&flags[48]==0,"actual recovery windows30/48 do not emit stale shortfall");
    // Synthetic policy controls BELOW are explicitly separate from frozen input.
    Window control=convert(real_windows[40]);
    auto suppress=[&](Window w,const char* name){WindowDetector d;unsigned all=0;
        for(int n=1;n<=6;++n)all|=d.observe(n*1000000,w);check(all==0,name);};
    control.paused=true;suppress(control,"synthetic paused overlay is suppressed");
    control.paused=false;control.active=false;suppress(control,"synthetic inactive/menu overlay is suppressed");
    control.active=true;control.cap=0;control.budget_valid=false;suppress(control,"synthetic native15fps overlay has no fixed-cap shortfall");
    control.cap=60;control.budget_valid=true;control.draws=1;control.changes=1;control.budget_frames=1;control.max_draw_interval_us=1000000;
    suppress(control,"synthetic never-armed static1fps has no shortfall/gap incident");
    control=convert(real_windows[28]);WindowDetector startup;
    check(startup.observe(1000000,control)==0&&startup.observe(2000000,control)==0,"synthetic first two windows retain init grace");
    std::cout<<"failures="<<failures<<'\n';return failures?1:0;
}
