#include <iostream>
#if !__has_include("causal_diagnostics.h")
int main(){std::cerr<<"MISSING_FEATURE allocation/sleep causal records\n";return 1;}
#else
#include "causal_diagnostics.h"
int main(){
    using namespace runtime_cause;int failures=0;
    auto check=[&](bool ok,const char* what){if(!ok){++failures;std::cerr<<"FAIL "<<what<<"\n";}};
    Allocations allocations;
    for(int n=0;n<100;++n)allocations.note(7,256,'I',9,36);
    allocations.note(8,22,'B',100,100);
    check(allocations.calls==101&&allocations.bytes==3700,"exact allocation counts");
    bool found=false;for(const auto& row:allocations.rows)if(row.used&&row.method==7){found=true;check(row.bci==256&&row.calls==100&&row.min_length==9&&row.max_length==9&&row.bytes==3600,"allocation source and length");}
    check(found,"allocation source retained");
    for(uint32_t n=0;n<1000;++n)allocations.note(n+100,1,'I',1,4);
    uint64_t retained=0;for(const auto& row:allocations.rows)retained+=row.calls;
    check(retained+allocations.overflow_calls==allocations.calls,"bounded collision overflow accounted");
    Sleeps sleeps;SleepRequest r;r.thread=10;r.generation=2;r.started_us=1000;r.requested_ms=83;r.effective_ms=16;r.deadline_us=17000;r.method=7;r.bci=53;r.route=Route::Frame;
    const auto first=sleeps.begin(r);check(first!=0,"request ID");
    check(sleeps.ready(10,2,18000),"first ready");check(sleeps.dispatch(10,2,19000),"first dispatch");
    auto c=sleeps.history[0];check(c.status==Status::Completed&&c.request.requested_ms==83&&c.request.effective_ms==16&&c.ready_us==18000&&c.dispatched_us==19000,"request/retime/ready/dispatch distinct");
    r.started_us=20000;r.requested_ms=r.effective_ms=163;r.deadline_us=183000;r.route=Route::LongUnpaced;
    sleeps.begin(r);sleeps.ready(10,2,183000);sleeps.dispatch(10,2,184000);c=sleeps.history[1];
    check(c.dispatched_us-c.request.started_us==164000&&c.request.route==Route::LongUnpaced,"actual long span retains route");
    r.started_us=200000;sleeps.begin(r);check(!sleeps.ready(10,3,201000),"generation mismatch not a valid wake");check(sleeps.normal_completed==2,"stale generation cannot complete sleep");
    r.generation=3;sleeps.begin(r);sleeps.cancel_all(202000);check(sleeps.pending()==0&&sleeps.canceled>0,"reset cancels pending observations");
    r.thread=11;r.started_us=300000;sleeps.begin(r);sleeps.clear_window();check(sleeps.pending()==1,"one-second rollup preserves pending span");
    sleeps.ready(11,3,465000);sleeps.dispatch(11,3,466000);check(sleeps.normal_completed==3,"cross-window completion");
    for(int n=0;n<300;++n){r.started_us=500000+n*1000;sleeps.begin(r);sleeps.ready(11,3,r.started_us+100);sleeps.dispatch(11,3,r.started_us+200);}
    check(sleeps.history_overwritten()>0,"bounded completion history");
    std::cout<<"causal_failures="<<failures<<"\n";return failures?1:0;
}
#endif
