// A rejected archive must not prevent the next game from launching in this VM.
#define main emulator_main
#include "../src/j2mevm.cpp"
#undef main
static void require(bool ok,const char* why){if(!ok){std::cerr<<"FAIL "<<why<<"\n";std::exit(1);}}
int main(int argc,char**argv){
    if(argc!=4)return 2;
    VMS_CL(g_classpath)={argv[3]};VMS_DIAG(g_log_draw)=false;
    std::vector<uint8_t> bad,good;std::string error;
    require(read_whole(argv[1],bad)&&read_whole(argv[2],good),"read fixtures");
    // Repeat the same rejection/reset/cold-launch sequence in a single process.
    for(int pass=0;pass<3;++pass){
        stop_thread();VMS_CL(g_jar_files).clear();VMS_CL(g_props).clear();
        require(!unzip(bad,VMS_CL(g_jar_files),error),"truncated resource remains rejected");
        require(error.find("zip inflate mismatch: mm.mid")!=std::string::npos,"resource diagnostic identifies mm.mid");
        stop_thread();VMS_CL(g_jar_files).clear();VMS_CL(g_props).clear();
        require(unzip(good,VMS_CL(g_jar_files),error),"following game archive loads");
        load_props();auto name=manifest_midlet();if(name.empty())name=find_midlet_class();
        for(char&c:name)if(c=='.')c='/';require(!name.empty(),"following game MIDlet found");
        select_screen_sidecar(argv[2],rms_jar_identity(good.data(),good.size()));
        VMS_RS(g_fb).assign(size_t(VMS_RS(g_screen_w))*VMS_RS(g_screen_h)*3,0);
        launch_class(name,rms_jar_identity(good.data(),good.size()));
        const auto until=paint_clock_us()+1500000;
        while(paint_clock_us()<until&&VMS_EXEC(g_midlet_state)!=MidletState::Destroyed){
            sched_game_work(false,[]{},[](int64_t ms){std::this_thread::sleep_for(std::chrono::milliseconds(ms));});
        }
        require(!VMS_EXEC(g_thrown)&&VMS_EXEC(g_error).empty(),"following game has no VM error");
        require(VMS_RS(g_game_frames)>0,"following game paints");
        lifecycle_destroy();std::cout<<"PASS ZIP rejection then next game "<<pass+1<<"\n";
    }
    p7::pool().shutdown();log_shutdown();return 0;
}
