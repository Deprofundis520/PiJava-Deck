package javax.microedition.lcdui;
public class Display {
 public static native Display getDisplay(javax.microedition.midlet.MIDlet m);
 public native void setCurrent(Displayable d);
 public native Displayable getCurrent();
 public native void setCurrentItem(Item i);
}
