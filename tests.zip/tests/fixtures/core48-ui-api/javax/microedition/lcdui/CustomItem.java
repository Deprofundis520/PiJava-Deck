package javax.microedition.lcdui;
public abstract class CustomItem extends Item {
 protected static final int NONE=0,TRAVERSE_HORIZONTAL=1,TRAVERSE_VERTICAL=2,KEY_PRESS=4,KEY_RELEASE=8,KEY_REPEAT=16,POINTER_PRESS=32,POINTER_RELEASE=64,POINTER_DRAG=128;
 protected CustomItem(String l){}
 public native int getGameAction(int code);
 protected final native int getInteractionModes();
 protected abstract int getMinContentWidth(); protected abstract int getMinContentHeight();
 protected abstract int getPrefContentWidth(int h); protected abstract int getPrefContentHeight(int w);
 protected abstract void paint(Graphics g,int w,int h);
 protected void sizeChanged(int w,int h){} protected void showNotify(){} protected void hideNotify(){}
 protected boolean traverse(int d,int w,int h,int[] r){return false;} protected void traverseOut(){}
 protected void keyPressed(int c){} protected void keyReleased(int c){} protected void keyRepeated(int c){}
 protected final native void invalidate(); protected final native void repaint(); protected final native void repaint(int x,int y,int w,int h);
}
