package javax.microedition.lcdui;
public class StringItem extends Item {
 public StringItem(String l,String t){}
 public StringItem(String l,String t,int a){}
 public native int getAppearanceMode();
 public native void setFont(Font f);
 public native Font getFont();
}
