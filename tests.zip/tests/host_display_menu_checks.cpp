#include "../src/host_display_menu.h"
#include <cassert>
#include <climits>
#include <cstdio>
int main() {
    using namespace host_display_menu;
    Model model;
    assert(!model.open && model.selected() == Action::None);
    model.begin();assert(model.open && model.selected() == Action::Rotation);
    model.move(-1);assert(model.selection == 0);
    model.move(1);assert(model.selected() == Action::Canvas);
    model.move(1);assert(model.selected() == Action::Inherit);
    model.move(1);assert(model.selected() == Action::DeleteGame);
    model.move(1);assert(model.selected() == Action::DeleteInstant);
    model.move(INT_MAX);assert(model.selection == 4);
    constexpr size_t pitch=1297,guard=31;
    constexpr uint32_t sentinel=0x12345678;
    std::vector<uint32_t> pixels(guard+pitch*720+guard,sentinel);
    auto* frame=pixels.data()+guard;
    host_menu::Settings settings;settings.canvas=7;settings.rotation=3;
    std::vector<std::string> calls;
    host_menu::Text text=[&](int x,int y,const std::string& label,uint32_t,int height,int maxwidth){
        assert(x>=0&&y>=0&&x+maxwidth<=1280&&y+height<=720);calls.push_back(label);
    };
    for(int selection=0;selection<5;++selection){model.selection=selection;render(frame,pitch,model,settings,text);}
    for(const std::string expected:{"继承存档","画布尺寸","画面旋转","删除游戏","删除即时存档","更多设置","A 确认 / 调整    B 返回","240×320","270°"})
        assert(std::find(calls.begin(),calls.end(),expected)!=calls.end());
    assert(std::find(calls.begin(),calls.end(),"返回")==calls.end());
    for(size_t i=0;i<guard;++i)assert(pixels[i]==sentinel&&pixels[guard+pitch*720+i]==sentinel);
    for(int y=0;y<720;++y)for(size_t x=1280;x<pitch;++x)assert(frame[y*pitch+x]==sentinel);
    const auto previous=pixels;model.open=false;render(frame,pitch,model,settings,text);assert(pixels==previous);
    std::puts("PASS Plus display menu: five actions, navigation, current values, closed state and buffer bounds");
}
