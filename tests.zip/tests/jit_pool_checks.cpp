#include "../src/native_jit236.h"
#include <cassert>
#include <iostream>
#include <set>
using namespace jit236;
int main(){
    auto baseline=code_pool_stats().blocks;
    const auto reserved_baseline=code_pool_stats().reserved_bytes;
    std::string desc="(I)I";const uint8_t code[]={26,4,96,172};Program program;Spec spec{code,sizeof(code),&desc,8,1,2,false,false,nullptr};assert(verify(spec,program));auto bytes=emit_host(program);
    constexpr size_t pages_per_block=CodeBlockBytes/CodePage;
    std::vector<Executable> compiled(1800);
    const size_t initial_blocks=(compiled.size()+pages_per_block-1)/pages_per_block;
    for(auto& e:compiled)assert(e.install(bytes));
    assert(code_pool_stats().slices==1800 && code_pool_stats().blocks-baseline==initial_blocks);
    int32_t argument=41;
    for(auto& e:compiled){CodeCall call;assert(uint32_t(e.fn(&argument))==42);}
    // Free holes and refill them while the other immutable functions survive. 0.2.113: freed pages wait in the
    // quarantine (CodeQuarantinePages, FIFO), so the refill never lands on the most recently freed 512 pages; it uses
    // the never-written tail of the last block, pages that aged out, then new blocks.
    std::set<void*> quarantined;std::vector<void*> freed;
    for(size_t i=0;i<compiled.size();i+=2){freed.push_back(reinterpret_cast<void*>(compiled[i].fn));compiled[i].close();}
    for(size_t i=freed.size()-CodeQuarantinePages;i<freed.size();++i)quarantined.insert(freed[i]);
    assert(code_pool_stats().quarantined_pages==CodeQuarantinePages && code_pool_stats().quarantine_releases==freed.size()-CodeQuarantinePages);
    for(size_t i=0;i<compiled.size();i+=2){assert(compiled[i].install(bytes));assert(!quarantined.count(reinterpret_cast<void*>(compiled[i].fn)));}
    const size_t unused_pages=initial_blocks*pages_per_block-compiled.size();
    const size_t extra_blocks=(CodeQuarantinePages-unused_pages+pages_per_block-1)/pages_per_block;
    assert(code_pool_stats().blocks-baseline==initial_blocks+extra_blocks);
    for(auto& e:compiled){CodeCall call;assert(uint32_t(e.fn(&argument))==42);}
    {CodeCall active;assert(!compiled[0].install(bytes));assert(compiled[0].executable());}
    compiled.clear();assert(!code_pool_stats().slices && !code_pool_stats().used_bytes);
    assert(code_pool_stats().blocks-baseline<=code_pool_stats().quarantined_pages);   // only quarantine-pinned blocks remain
    std::set<const CodeBlock*> owners;size_t retained_bytes=0,retired_pages=0;
    for(const auto& entry:code_quarantine()){
        retired_pages+=entry.pages;
        if(owners.insert(entry.block.get()).second)retained_bytes+=entry.block->bytes;
    }
    assert(code_pool_stats().blocks==baseline+owners.size());
    assert(code_pool_stats().reserved_bytes==reserved_baseline+retained_bytes);
    assert(code_pool_stats().quarantined_pages==retired_pages);
    while(!code_quarantine().empty())release_oldest_quarantine();
    assert(code_pool_stats().blocks==baseline && !code_pool_stats().quarantined_pages &&
           code_pool_stats().reserved_bytes==reserved_baseline);
    // Move/replace releases exactly one slice and never invalidates its peers.
    Executable a,b;assert(a.install(bytes)&&b.install(bytes));auto address=b.fn;a=std::move(b);assert(!b.fn && a.fn==address);a.close();
    assert(!code_pool_stats().slices);
    while(!code_quarantine().empty())release_oldest_quarantine();
    assert(code_pool_stats().blocks==baseline && code_pool_stats().reserved_bytes==reserved_baseline);
    std::cout<<"PASS pooled W^X: 1800 functions / "<<initial_blocks<<" blocks, quarantined reuse, peer execution, active-call guard, move and reset\n";
}
