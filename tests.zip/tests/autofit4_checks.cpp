#include "../src/host_skin.h"
#include "../src/controller_skin_labels.h"
#include <cassert>
#include <cstdio>
int main(){
 using namespace host_menu;
 if(Settings{}.bezel!=7){std::puts("FAIL: fresh launch must default to aspect-fit");return 1;}
 struct Case{int w,h,x,y,dw,dh;};
 for(const auto c:{Case{240,320,370,0,540,720},Case{176,220,352,0,576,720},Case{360,360,280,0,720,720},Case{320,240,160,0,960,720},Case{800,480,40,0,1200,720},Case{640,360,0,0,1280,720},Case{800,400,0,40,1280,640}}){
  const auto v=j2me_present::game_viewport(c.w,c.h,true);
  assert(v.x==c.x&&v.y==c.y&&v.w==c.dw&&v.h==c.dh);
  assert(v.w==1280||v.h==720);assert(j2me_present::valid_viewport(v));
 }
 constexpr size_t pitch=1299,guard=13;constexpr uint32_t mark=0x12345678;
 std::vector<uint32_t> pixels(guard+pitch*720+guard,mark),texture(1280*720,color(0xff00ff));
 auto* frame=pixels.data()+guard;render_bezel(frame,pitch,7,{},texture.data(),texture.size());
 for(int y=0;y<720;++y){for(int x=0;x<1280;++x)assert(frame[size_t(y)*pitch+x]==color(0));for(size_t x=1280;x<pitch;++x)assert(frame[size_t(y)*pitch+x]==mark);}
 for(size_t i=0;i<guard;++i)assert(pixels[i]==mark&&pixels[guard+pitch*720+i]==mark);
 assert(host_skin::path(7)==nullptr);assert(!host_controller::mapped_skin(7));
 for(int n=4;n<=6;++n)assert(host_skin::path(n)&&host_controller::mapped_skin(n));
 std::puts("PASS AutoFit4: aspect-fit default, portrait/square/landscape/ultrawide first-edge stop, black bars without artwork, pitch guards, legacy skins retained");
}
