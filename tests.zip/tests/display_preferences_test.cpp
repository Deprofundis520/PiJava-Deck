#include "../src/host_display_preferences.h"
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <sys/stat.h>
#define CHECK(c) do { if (!(c)) { std::cerr << "FAIL line " << __LINE__ << ": " #c "\n"; std::exit(1); } } while (0)
static std::string contents(const std::string& path) { std::ifstream f(path); return std::string((std::istreambuf_iterator<char>(f)),{}); }
int main() {
    char dir[]="/tmp/fit6-display-XXXXXX"; CHECK(mkdtemp(dir));
    const std::string a=std::string(dir)+"/a.jar",b=std::string(dir)+"/b.jar";
    { std::ofstream f(a); f << "unchanged jar"; }
    CHECK(host_display::load(a).rotation==0);
    const std::string digits=std::string(dir)+"/2048.jar";
    CHECK(host_display::save_rotation(digits,1));
    CHECK(host_display::load(digits).rotation==1);
    CHECK(host_display::save_screen(digits,240,320));
    const std::string nul=digits+std::string("\0ignored",8);
    CHECK(!host_display::save_rotation(nul,2));
    CHECK(!host_display::save_screen(nul,320,240));
    CHECK(host_display::load(nul).rotation==0);
    CHECK(host_display::load(digits).rotation==1&&host_display::load(digits).w==240);
    CHECK(host_display::load(a).screen_state==0);
    CHECK(host_display::save_rotation(a,3));
    CHECK(contents(a+".rotation")=="3\n");
    CHECK(host_display::load(a).rotation==3 && host_display::load(b).rotation==0);
    host_menu::Settings selected; selected.rotation=2; selected.canvas=7;
    host_display::load_into(b,selected);
    CHECK(selected.rotation==0 && selected.canvas==0);
    CHECK(host_display::save_screen(a,320,240));
    auto loaded=host_display::load(a);
    CHECK(loaded.screen_state==1 && loaded.w==320 && loaded.h==240);
    CHECK(contents(a+".screen")=="320x240\n");
    host_display::load_into(a,selected);
    CHECK(selected.rotation==3 && host_menu::canvas_size(selected.canvas)==std::make_pair(320,240));
    CHECK(host_display::load(b).screen_state==0);
    CHECK(contents(a)=="unchanged jar");
    CHECK(host_display::save_screen(a,333,444)); // An existing custom size remains intact on load.
    CHECK(host_display::load(a).w==333 && host_display::load(a).h==444);
    CHECK(contents(a+".screen")=="333x444\n");
    host_display::load_into(a,selected);
    CHECK(selected.canvas==-1);
    CHECK(std::rename((a+".screen").c_str(),(a+".screen.previous").c_str())==0);
    loaded=host_display::load(a);
    CHECK(loaded.screen_state==1&&loaded.w==333&&loaded.h==444);
    { std::ofstream f(a+".screen");f << "damaged\n"; }
    CHECK(host_display::load(a).screen_state==-1); // Malformed main never silently recovers an old choice.
    CHECK(host_display::save_screen(a,333,444));
    { std::ofstream f(a+".screen.previous");f << "240x320\n"; }
    CHECK(host_display::save_screen(a,0,0)); // Only an explicit Auto request deletes the sidecar.
    CHECK(host_display::load(a).screen_state==0);
    CHECK(host_menu::settings_detail::file_status(a+".screen.previous")==host_menu::settings_detail::FileStatus::missing);
    CHECK(host_display::load(a).rotation==3);
    CHECK(host_display::save_screen(a,0,0)); // Missing is already Auto.
    CHECK(!host_display::save_screen(a,1,1));
    CHECK(!host_display::save_screen(a,800,800));
    CHECK(!host_display::save_rotation(a,4));
    CHECK(!host_display::save_rotation(a,-1));
    CHECK(host_display::load(a).rotation==3);
    { std::ofstream f(a+".rotation");f << "1garbage\n"; }
    CHECK(host_display::load(a).rotation==0);
    { std::ofstream f(a+".rotation");f << "2\r\n"; }
    CHECK(host_display::load(a).rotation==2);
    CHECK(std::rename((a+".rotation").c_str(),(a+".rotation.previous").c_str())==0);
    CHECK(host_display::load(a).rotation==2);
    CHECK(host_display::save_rotation(a,0));
    CHECK(host_display::load(a).rotation==0);
    CHECK(!host_display::save_screen(std::string(dir)+"/missing/game.jar",320,240));
    CHECK(!host_display::save_rotation(std::string(dir)+"/missing/game.jar",1));
    CHECK(!host_display::save_rotation("",1));
    CHECK(!host_display::save_screen("",0,0));
    CHECK(mkdir((b+".screen").c_str(),0700)==0);
    CHECK(!host_display::save_screen(b,0,0)); // Never remove an unreadable/non-file path.
    CHECK(!host_display::save_screen(b,320,240));
    std::cout << "display_preferences_test: PASS\n";
}
