#include "../src/p7_present.h"
#include "../src/presentation/viewport.h"
#include <cassert>
#include <vector>
#include <cstdio>
int main(){
 constexpr size_t pitch=1297,guard=19;constexpr uint32_t sentinel=0x12345678;
 for(auto dims:{std::pair<int,int>{240,320},{176,220},{320,240},{640,360},{360,360},{17,639},{639,17},{480,800},{800,480},{512,800},{800,512}}){
  int w=dims.first,h=dims.second;auto view=j2me_present::game_viewport(w,h,true);
  std::vector<uint8_t> rgb(size_t(w)*h*3);for(size_t i=0;i<rgb.size();++i)rgb[i]=uint8_t(i*17);
  auto source=rgb;
  for(int f=0;f<6;++f){
   std::vector<uint32_t> frame(guard+pitch*720+guard,sentinel),expected(size_t(view.w)*view.h);
   auto filter=static_cast<display_filter::Filter>(f);
   p7present::blit_game(frame.data()+guard,pitch,rgb.data(),w,h,filter,view);
   display_filter::render(expected.data(),view.w,rgb.data(),w,h,filter,view.w,view.h);
   for(size_t i=0;i<guard;++i)assert(frame[i]==sentinel&&frame[guard+pitch*720+i]==sentinel);
   for(int y=0;y<720;++y)for(size_t x=0;x<pitch;++x){
    bool inside=int(x)>=view.x&&int(x)<view.x+view.w&&y>=view.y&&y<view.y+view.h;
    uint32_t want=inside?expected[size_t(y-view.y)*view.w+x-view.x]:sentinel;
    assert(frame[guard+size_t(y)*pitch+x]==want);
   }
   assert(rgb==source);
  }
 }
 std::puts("PASS adaptive CPU: six filters, seven aspect ratios, direct viewport pixels/source immutability/frame-pitch guards");
}
