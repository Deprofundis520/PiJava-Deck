// Standalone host test: c++ -std=c++14 tests/orientation_test.cpp -o /tmp/orientation_test
#include "../src/presentation/orientation.h"
#include <cstdlib>
#include <iostream>
#include <vector>

#define CHECK(c) do { if (!(c)) { std::cerr << "FAIL line " << __LINE__ << ": " #c "\n"; std::exit(1); } } while (0)
using presentation::orientation::Cache;
using Bytes = std::vector<uint8_t>;
static Bytes pixels(std::initializer_list<uint8_t> labels) {
    Bytes out;
    for (auto v : labels) { out.push_back(v); out.push_back(v + 20); out.push_back(v + 40); }
    return out;
}
int main() {
    // Independent hand-labelled 3x2 fixture: 1 2 3 / 4 5 6. All channels travel together.
    auto source = pixels({1,2,3,4,5,6});
    source.push_back(0xa5); // Bytes beyond the declared image are never read or overwritten.
    const auto original = source;
    Cache cache;
    const auto& identity = cache.apply(source,3,2,0,1,1,false);
    CHECK(&identity == &source && identity.data() == source.data());
    CHECK(cache.width() == 3 && cache.height() == 2);
    CHECK(cache.apply(source,3,2,1,1,1,false) == pixels({4,1,5,2,6,3}));
    CHECK(cache.width() == 2 && cache.height() == 3);
    CHECK(cache.apply(source,3,2,2,1,1,false) == pixels({6,5,4,3,2,1}));
    CHECK(cache.width() == 3 && cache.height() == 2);
    CHECK(cache.apply(source,3,2,3,1,1,false) == pixels({3,6,2,5,1,4}));
    CHECK(source == original);

    // Stable clean frames reuse the cached pixels; a same-frame dirty write must refresh.
    cache.apply(source,3,2,1,1,1,false);
    source[0] = 9;
    CHECK(cache.apply(source,3,2,1,1,1,false)[3] == 1);
    CHECK(cache.apply(source,3,2,1,1,1,true)[3] == 9);
    source[0] = 10;
    CHECK(cache.apply(source,3,2,1,2,1,false)[3] == 10); // A new run can reuse frame 1.
    source[0] = 11;
    CHECK(cache.apply(source,3,2,1,2,2,false)[3] == 11);
    auto replacement = pixels({7,8,9,10,11,12});
    CHECK(cache.apply(replacement,3,2,1,2,2,false) == pixels({10,7,11,8,12,9}));
    CHECK(cache.apply(replacement,2,3,1,2,2,false) == pixels({11,9,7,12,10,8}));

    // Returning through the direct route must not revive stale rotated data.
    cache.apply(source,3,2,1,3,3,false);
    CHECK(&cache.apply(source,3,2,0,3,3,false) == &source);
    source[0] = 12;
    CHECK(cache.apply(source,3,2,1,3,3,false)[3] == 12);

    CHECK(cache.apply(source,0,2,1,1,1,false).empty());
    CHECK(cache.width() == 0 && cache.height() == 0);
    CHECK(cache.apply(source,3,-1,1,1,1,false).empty());
    CHECK(cache.apply(source,801,1,1,1,1,false).empty());
    CHECK(cache.apply(source,800,800,1,1,1,false).empty());
    CHECK(cache.apply(source,4,2,1,1,1,false).empty());
    CHECK(cache.apply(source,3,2,-1,1,1,false).empty());
    CHECK(cache.apply(source,3,2,4,1,1,false).empty());
    Bytes edge(800*512*3,17);
    CHECK(cache.apply(edge,800,512,1,1,1,false).size() == edge.size());
    CHECK(cache.width() == 512 && cache.height() == 800);
    CHECK(cache.apply(pixels({5}),1,1,3,1,1,false) == pixels({5}));
    std::cout << "orientation_test: PASS\n";
}
