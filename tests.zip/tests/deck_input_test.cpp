#include "platform/deck_input.h"
#include <vector>
#include <utility>
#include <cstdlib>
int main(){
    deck_input::State s;std::vector<std::pair<int,bool>> events;
    auto send=[&](int k,bool up){events.emplace_back(k,up);};
    s.update(1,-1,send);s.update(2,-1,send);s.update(1,0,send);
    if(events!=std::vector<std::pair<int,bool>>{{-1,false}})return 1;
    s.update(2,-2,send);
    if(events!=std::vector<std::pair<int,bool>>{{-1,false},{-1,true},{-2,false}})return 2;
    s.update(2,-2,send);if(events.size()!=3)return 3;
    s.clear(send);if(events.back()!=std::make_pair(-2,true)||!s.codes().empty())return 4;
    s.clear(send);if(events.size()!=4)return 5;
    return 0;
}
