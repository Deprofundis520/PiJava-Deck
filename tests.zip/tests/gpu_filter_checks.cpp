#include "../src/presentation/gpu_filter.h"
#if defined(GPU_INLINE) || defined(GPU_PIXEL_SOURCE) || defined(GPU_PIXEL_READ)
#error GPU shader bridge macros must not leak into the rest of the emulator
#endif
#include <cassert>
#include <cstdio>

int main(){
    using namespace j2me_present;
    using F=display_filter::Filter;
    uint64_t compared=0;unsigned scale_quadrants=0;
    for(F f:{F::Original,F(-1),F(6)})assert(!gpu_filter::supported(f));
    for(F f:{F::Bilinear,F::Scale2x,F::Lcd,F::Crt,F::ScanlinesDX}){
        assert(gpu_filter::supported(f));
        for(auto size:{std::pair<int,int>{1,1},{1,19},{17,1},{17,19},{176,208},{239,321},{240,320},{360,640},{640,360},{640,640},{480,800},{800,480},{512,800},{800,512}})for(unsigned pattern=0;pattern<3;++pattern){
            int w=size.first,h=size.second;std::vector<uint8_t> rgb(size_t(w)*h*3);
            for(size_t i=0;i<rgb.size();++i){
                const uint32_t pixel=uint32_t(i/3),palette=((pixel*1103515245u+12345u)>>16)%4;
                rgb[i]=pattern==1?255:pattern==2?uint8_t(palette*73):uint8_t((i*73+i/17)^0xad);
            }
            const auto original=rgb;std::vector<uint32_t> packed,expected(480*640);
            assert(gpu_filter::pack(rgb,w,h,f,packed));
            assert(packed.size()==size_t(w)*h+4&&packed[0]==unsigned(w)&&packed[1]==unsigned(h)&&packed[2]==unsigned(f));
            display_filter::render(expected.data(),480,rgb.data(),w,h,f);
            for(unsigned y=0;y<640;++y)for(unsigned x=0;x<480;++x){
                unsigned gain=display_filter::detail::scanlinesdx_gains()[(y%64)*48+x%48];
                uint32_t got=gpu_filter::gpu_filter_pixel(packed.data()+4,x,y,w,h,unsigned(f),gain);
                assert(got==expected[size_t(y)*480+x]);
                if(f==F::Scale2x){
                    unsigned vx=x*unsigned(w)*2/480,vy=y*unsigned(h)*2/640;
                    if(got!=packed[4+size_t(vy/2)*w+vx/2])scale_quadrants|=1u<<((vy&1u)*2+(vx&1u));
                }
                ++compared;
            }
            assert(rgb==original);
        }
    }
    assert(scale_quadrants==15&&"Scale2x must exercise all four non-center corner selections");
    std::vector<uint32_t> packed{42};std::vector<uint8_t> invalid(3);
    assert(!gpu_filter::pack(invalid,0,1,F::Crt,packed)&&packed==std::vector<uint32_t>{42});
    assert(!gpu_filter::pack(invalid,641,1,F::Crt,packed));
    assert(!gpu_filter::pack(invalid,1,1,F::Original,packed));
    gpu_filter::FrameKey key{7,10,17,19,F::Crt};gpu_filter::FrameCache cache;
    assert(cache.needs_upload(key));cache.committed(key);assert(!cache.needs_upload(key));
    auto changed=key;++changed.epoch;assert(cache.needs_upload(changed));
    changed=key;++changed.frame;assert(cache.needs_upload(changed));
    changed=key;++changed.w;assert(cache.needs_upload(changed));
    changed=key;++changed.h;assert(cache.needs_upload(changed));
    changed=key;changed.filter=F::Lcd;assert(cache.needs_upload(changed));
    cache.invalidate();assert(cache.needs_upload(key));
    cache.committed(key);for(F f:{F::Bilinear,F::Scale2x,F::Lcd,F::Crt,F::ScanlinesDX}){
        changed=key;changed.filter=f;assert(cache.needs_upload(changed)==(f!=key.filter));
    }
    // Each ring slot owns its own version. A heartbeat only becomes free after
    // every used slot has uploaded that completed frame.
    gpu_filter::FrameCache slots[3];for(auto& slot:slots){assert(slot.needs_upload(key));slot.committed(key);}
    for(auto& slot:slots)assert(!slot.needs_upload(key));
    std::printf("PASS five GPU filter pixel arithmetic vs unchanged CPU: %llu pixels, thin/odd/non240/max, full-white and palette edges, immutable raw, cache transitions; NOT GPU execution\n",(unsigned long long)compared);
}
