// Production split-JPEG artwork and production bitmap-font fallback previews.
#include "../src/host_skin.h"
#include "../src/controller_skin_labels.h"
#include "../src/latin16.h"
#include <cassert>
#include <filesystem>
#include <fstream>
#include <iterator>
int main(int argc,char** argv){
 assert(argc==2);const std::filesystem::path out=argv[1];std::filesystem::create_directories(out);
 host_skin::Pixels skin;std::string error;assert(host_skin::load_file("romfs/skins/controller-black.skin",skin,error));
 std::ifstream cjkfile("romfs/font/cjk16.bin",std::ios::binary);std::vector<uint8_t> cjk((std::istreambuf_iterator<char>(cjkfile)),{});assert(cjk.size()>38);
 const auto next=[](const std::string& s,size_t& i){const auto c=uint8_t(s[i++]);if(c<128)return int(c);int cp=c&((c&0xe0)==0xc0?31:15);int rest=(c&0xe0)==0xc0?1:2;while(rest--&&i<s.size())cp=(cp<<6)|(uint8_t(s[i++])&63);return cp;};
 const auto bitmap=[&](int cp){const int count=int(host_skin::le32(cjk.data()));for(int n=0;n<count;++n){const auto* p=cjk.data()+4+size_t(n)*34;if(host_skin::le16(p)==cp)return p+2;}return static_cast<const uint8_t*>(nullptr);};
 for(auto dims:{std::pair<int,int>{240,320},{360,360},{320,240},{640,360}}){
  host_menu::UniversalLayout layout;layout.update(dims.first,dims.second);std::vector<uint32_t> frame(host_skin::pixel_count);
  host_menu::render_bezel(frame.data(),1280,7,{},skin.data(),skin.size(),&layout);
  const host_menu::Text draw=[&](int x,int y,const std::string& s,uint32_t ink,int px,int maxw){
   int cx=x;size_t offset=0;while(offset<s.size()){const int cp=next(s,offset),width=cp<128?px/2:px;if(cx-x+width>maxw)break;const auto* glyph=cp>=128?bitmap(cp):nullptr;
    for(int row=0;row<px;++row){const int sy=row*16/px;const unsigned bits=cp>=32&&cp<127?latin16[cp-32][sy]:glyph?(unsigned(glyph[sy*2])<<8)|glyph[sy*2+1]:(sy==0||sy==15?0xffff:0x8001);
     for(int col=0;col<width;++col){const int sx=col*(cp<128?8:16)/width,xx=cx+col,yy=y+row;if((bits&(0x8000u>>sx))&&unsigned(xx)<1280&&unsigned(yy)<720)frame[size_t(yy)*1280+xx]=ink;}
    }cx+=width;
   }
  };
  const host_menu::CenteredText center=[&](int x,int y,const std::string& s,uint32_t ink,int px,int maxw){draw(x-std::min(maxw,host_menu::text_advance(s,px))/2,y-px/2,s,ink,px,maxw);};
  host_controller::Legends legends;auto projected=host_controller::universal_game_layout(layout);legends.update({},false,7,{},&projected);legends.render(frame.data(),1280,7,draw,host_controller::Context::Game,center);
  const auto& v=layout.viewport;for(int y=v.y;y<v.y+v.h;++y)for(int x=v.x;x<v.x+v.w;++x)assert(frame[size_t(y)*1280+x]==host_menu::color(0));
  // FPS remains the final game/chrome layer, including full-width layouts.
  host_menu::render_fps(frame.data(),1280,7,"60",draw);
  const auto name="black-"+std::to_string(dims.first)+"x"+std::to_string(dims.second)+".ppm";std::ofstream ppm(out/name,std::ios::binary);ppm<<"P6\n1280 720\n255\n";
  for(auto p:frame){const char rgb[]={char(p&255),char((p>>8)&255),char((p>>16)&255)};ppm.write(rgb,3);}
 }
 std::puts("PASS UniversalPreview: actual controller-black.skin + bundled latin16/cjk16 runtime fallback, black viewport verified before final FPS layer; four aspect previews");
}
