#include "../src/presentation/viewport.h"
#include <cassert>
#include <cstdio>
#include <initializer_list>
int main(){
 using namespace j2me_present;
 for(auto v:{game_viewport(240,320,true),game_viewport(176,220,true)})assert(v.h==720&&v.y==0);
 auto a=game_viewport(240,320,true);assert(a.x==370&&a.y==0&&a.w==540&&a.h==720);
 a=game_viewport(176,220,true);assert(a.x==352&&a.w==576&&a.h==720);
 a=game_viewport(320,240,true);assert(a.x==160&&a.w==960&&a.h==720);
 a=game_viewport(640,360,true);assert(a.x==0&&a.y==0&&a.w==1280&&a.h==720);
 a=game_viewport(360,360,true);assert(a.x==280&&a.w==720&&a.h==720);
 assert(!valid_viewport(game_viewport(0,320,true)));
 for(int w=1;w<=640;++w)for(int h=1;h<=640;++h){
  a=game_viewport(w,h,true);assert(valid_viewport(a));assert(a.w==1280||a.h==720);
  assert(a.x==(1280-a.w)/2&&a.y==(720-a.h)/2);
  auto old=game_viewport(w,h);assert(old.x==400&&old.y==40&&old.w==480&&old.h==640);
 }
 std::puts("PASS adaptive viewport: examples and all409600 valid source sizes, centered/bounded/edge-fit; legacy unchanged");
}
