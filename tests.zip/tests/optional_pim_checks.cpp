#define main emulator_main
#include "../src/j2mevm.cpp"
#undef main

static void require(bool ok, const char* label) {
    if (!ok) { std::cerr << "FAIL " << label << "\n"; std::exit(1); }
}
static Method* interface_method(int cls, const char* name, const char* desc) {
    if (auto* m = find_method(cls, name, desc, false)) return m;
    for (int parent : VMS_CL(g_classes)[cls].interfaces)
        if (auto* m = interface_method(parent, name, desc)) return m;
    return nullptr;
}
int main(int argc, char** argv) {
    if (argc != 4) return 2;
    VMS_CL(g_classpath) = {argv[1], argv[2]};
    VMS_DIAG(g_log_draw) = false;
    const std::string mode = argv[3];
    // Intentional non-fatal load for a precise RED assertion before production exists.
    int pim = load_class_file("javax/microedition/pim/PIM", false);
    require(pim >= 0, "PIM class is present in frozen API");
    if (mode == "declarations") {
        require((VMS_CL(g_classes)[pim].flags & 0x401) == 0x401, "PIM is public abstract");
        Method* instance = find_method(pim, "getInstance", "()Ljavax/microedition/pim/PIM;", false);
        require(instance && (instance->flags & 0x9) == 0x9, "PIM.getInstance public static descriptor");
        require(find_method(pim, "openPIMList", "(II)Ljavax/microedition/pim/PIMList;", false), "PIM default-list overload");
        require(find_method(pim, "openPIMList", "(IILjava/lang/String;)Ljavax/microedition/pim/PIMList;", false), "PIM named-list overload");
        require(find_method(pim, "listPIMLists", "(I)[Ljava/lang/String;", false), "PIM list names descriptor");
        require(find_method(pim, "fromSerialFormat", "(Ljava/io/InputStream;Ljava/lang/String;)[Ljavax/microedition/pim/PIMItem;", false), "PIM import descriptor");
        require(find_method(pim, "toSerialFormat", "(Ljavax/microedition/pim/PIMItem;Ljava/io/OutputStream;Ljava/lang/String;Ljava/lang/String;)V", false), "PIM export descriptor");
        require(find_method(pim, "supportedSerialFormats", "(I)[Ljava/lang/String;", false), "PIM format descriptor");
        int list = ensure_class("javax/microedition/pim/PIMList");
        int item = ensure_class("javax/microedition/pim/PIMItem");
        int contact = ensure_class("javax/microedition/pim/Contact");
        int contacts = ensure_class("javax/microedition/pim/ContactList");
        for (int cls : {list, item, contact, contacts})
            require((VMS_CL(g_classes)[cls].flags & 0x601) == 0x601, "PIM contact contracts are public interfaces");
        require(class_assignable(contact, item), "Contact inherits PIMItem");
        require(class_assignable(contacts, list), "ContactList inherits PIMList");
        require(interface_method(contact, "getString", "(II)Ljava/lang/String;"), "Contact inherited getString descriptor");
        require(interface_method(contacts, "items", "()Ljava/util/Enumeration;"), "ContactList inherited items descriptor");
        require(interface_method(contacts, "close", "()V"), "ContactList inherited close descriptor");
        require(find_method(contacts, "createContact", "()Ljavax/microedition/pim/Contact;", false), "contact factory descriptor");
        require(find_method(contacts, "importContact", "(Ljavax/microedition/pim/Contact;)Ljavax/microedition/pim/Contact;", false), "contact import descriptor");
        require(find_method(contacts, "removeContact", "(Ljavax/microedition/pim/Contact;)V", false), "contact removal descriptor");
        require(class_assignable(ensure_class("javax/microedition/pim/PIMException"), ensure_class("java/lang/Exception")), "PIM checked exception inheritance");
        std::cout << "PASS OptionalPim declarations and inherited collection descriptors\n";
        return 0;
    }
    int fixture = ensure_class("OptionalPimChecks");
    const char* method = mode == "denied" ? "denied" : mode == "fallback" ? "gameFallback" : mode == "exceptions" ? "exceptions" : nullptr;
    if (!method) return 2;
    auto result = run(find_method(fixture, method, "()I", false), {});
    require(!VMS_EXEC(g_thrown), "Java test has no uncaught exception");
    require(result.i == (mode == "denied" ? 1 : mode == "fallback" ? 3 : 12), "actual VM PIM fallback assertions");
    std::cout << "PASS OptionalPim " << mode << " assertions=" << result.i << "\n";
}
