#ifdef _WIN32
#define lstat stat
#endif
#include "platform/deck_games.h"
#include <iostream>
#include <chrono>
#define CHECK(x) do{if(!(x)){std::cerr<<"Game scan line "<<__LINE__<<"\n";return 1;}}while(0)
int main(){
    namespace fs=std::filesystem;using namespace deck_games;
    const auto root=fs::temp_directory_path()/fs::u8path("PiJava 游戏扫描测试-"+std::to_string(std::chrono::steady_clock::now().time_since_epoch().count()));const auto a=root/"portable/games",b=root/"installed/games",data=root/"data";
    fs::create_directories(a/fs::u8path("子文件夹"));fs::create_directories(b);fs::create_directories(data);
    auto put=[](const fs::path& p){std::ofstream(p,std::ios::binary)<<"PK test archive";};
    put(a/fs::u8path("中文游戏.jar"));put(a/"UPPER.JAR");put(a/fs::u8path("子文件夹/nested.jar"));put(a/"not-game.zip");put(b/"installed.jar");
    auto r=scan({a,b,a});CHECK(r.games.size()==4&&r.roots.size()==2&&!r.truncated);CHECK(r.roots[0].jars==3);
    CHECK(save_root(data/"source-games.path",a));CHECK(normalized(load_root(data/"source-games.path"))==normalized(a));
    // A JAR copied to the original portable directory after desktop installation is visible.
    put(a/"added-after-install.jar");r=scan({b,load_root(data/"source-games.path")});CHECK(r.games.size()==5);
    Browser browser;browser.open(a);CHECK(browser.error.empty()&&!browser.items.empty());int jar_count=0;for(const auto& item:browser.items)jar_count+=item.game;CHECK(jar_count==3);
    auto before=browser.folder;browser.open(before/fs::u8path("子文件夹"));CHECK(browser.items.size()==2&&browser.parent(0));browser.move(-9);CHECK(browser.selected>=0&&browser.selected<int(browser.items.size()));
    r=scan({root/"missing"});CHECK(r.games.empty()&&r.roots.size()==1&&!r.roots[0].error.empty());
    std::cout<<"PASS: portable/installed roots, Chinese names, uppercase JAR, subfolders, source registration, new games after install, directory browser\n";
}
