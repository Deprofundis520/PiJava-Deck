#include "../src/host_skin.h"
#include "../src/controller_skin_labels.h"
#include <cassert>
#include <cstdio>
#include <cstdlib>
static size_t allocations=0;
void* operator new(size_t n){if(auto* p=std::malloc(n?n:1)){++allocations;return p;}std::abort();}
void* operator new[](size_t n){return ::operator new(n);}
void operator delete(void* p)noexcept{std::free(p);}
void operator delete[](void* p)noexcept{std::free(p);}
void operator delete(void* p,size_t)noexcept{std::free(p);}
void operator delete[](void* p,size_t)noexcept{std::free(p);}
int main(){
 using namespace host_menu;
 constexpr size_t pitch=1297,guard=19;constexpr uint32_t sentinel=0x12345678;
 std::vector<uint32_t> texture(host_skin::pixel_count);
 for(int y=0;y<720;++y)for(int x=0;x<1280;++x)texture[size_t(y)*1280+x]=0xff000000u|uint32_t(x+1280*y+1);
 assert(std::string(host_skin::path(7))==host_skin::path(6));
 host_skin::Cache cache;int loads=0;const host_skin::Loader load=[&](const char* path,host_skin::Pixels& p,std::string&){assert(std::string(path)==host_skin::path(6));++loads;p=texture;return true;};
 assert(cache.select(7,{},load));const auto* active=cache.data();
 const auto cache_allocations=allocations;
 for(int n=0;n<30;++n)assert(cache.select(n%2?6:7,{},load)&&loads==1&&cache.data()==active);
 assert(allocations==cache_allocations);
 host_skin::Cache failed;int attempts=0;const host_skin::Loader fail=[&](const char*,host_skin::Pixels&,std::string& e){++attempts;e="missing";return false;};
 for(int n=0;n<10;++n)assert(!failed.select(7,{},fail));assert(attempts==1);
 UniversalLayout layout;host_controller::Legends labels;
 for(auto dims:{std::pair<int,int>{240,320},{360,360},{320,240},{480,800},{800,480},{640,360},{800,512},{512,800},{17,639},{639,17},{136,90},{545,360},{363,240}}){
  const int sw=dims.first,sh=dims.second;layout.update(sw,sh);const auto v=j2me_present::game_viewport(sw,sh,true);
  assert(layout.viewport.x==v.x&&layout.viewport.y==v.y&&layout.viewport.w==v.w&&layout.viewport.h==v.h);
  auto projected=host_controller::universal_game_layout(layout);labels.invalidate();
  std::vector<uint32_t> pixels(guard+pitch*720+guard,sentinel);auto* frame=pixels.data()+guard;
  render_bezel(frame,pitch,7,{},texture.data(),texture.size(),&layout);
  for(int y=0;y<720;++y)for(int x=0;x<1280;++x){
   uint32_t want=color(0);
   for(const auto& p:layout.panes)if(x>=p.x&&x<p.x+p.w&&y>=p.y&&y<p.y+p.h){
    const int sx=p.source_x+(x-p.x)*352/p.w,sy=(y-p.y)*352/p.w;
    want=texture[size_t(sy)*1280+sx];assert(x<v.x||x>=v.x+v.w);
   }
   assert(frame[size_t(y)*pitch+x]==want);
  }
  for(size_t n=0;n<layout.panes.size();++n){const auto& p=layout.panes[n];const int sidebar=n?1280-v.x-v.w:v.x;assert(p.w<=352&&p.h==p.w*720/352);if(sidebar<96)assert(p.w==0);else assert(p.w==std::min(352,sidebar));}
  assert(labels.update({},false,7,{},&projected));
  int calls=0;
  const Text text=[&](int x,int y,const std::string&,uint32_t ink,int px,int maxw){assert(ink==color(0xffffff));assert(x>=0&&y>=0&&x+maxw<=1280&&y+px<=720);assert(x+maxw<=v.x||x>=v.x+v.w);++calls;rect(frame,pitch,x,y,maxw,px,ink);};
  const auto before=allocations;labels.render(frame,pitch,7,text);assert(allocations==before);
  for(int n=0;n<10;++n)assert(!labels.update({},false,7,{},&projected));assert(allocations==before);
  assert(calls==(layout.panes[0].w?8:0)+(layout.panes[1].w?8:0));
  for(int y=v.y;y<v.y+v.h;++y)for(int x=v.x;x<v.x+v.w;++x)assert(frame[size_t(y)*pitch+x]==color(0));
  // The corresponding sampled source and mapped label centers agree within one pixel.
  const auto& base=host_controller::game_layout(6);
  for(size_t n=0;n<projected.size();++n){const auto& a=projected[n];const auto& b=base[n];const auto& p=layout.panes[n/8];if(!p.w){assert(a.w==0&&a.h==0);continue;}
   assert(std::abs((a.x+a.w/2)-(p.x+(b.x+b.w/2-p.source_x)*p.w/352))<=1);
   assert(std::abs((a.y+a.h/2)-(p.y+(b.y+b.h/2)*p.w/352))<=1);
  }
  for(int y=0;y<720;++y)for(size_t x=1280;x<pitch;++x)assert(frame[size_t(y)*pitch+x]==sentinel);
  for(size_t n=0;n<guard;++n)assert(pixels[n]==sentinel&&pixels[guard+pitch*720+n]==sentinel);
  render_bezel(frame,pitch,7,{},nullptr,0,&layout);for(int y=0;y<720;++y)for(int x=0;x<1280;++x)assert(frame[size_t(y)*pitch+x]==color(0));
  render_bezel(frame,pitch,7,{},texture.data(),texture.size()-1,&layout);for(int y=0;y<720;++y)for(int x=0;x<1280;++x)assert(frame[size_t(y)*pitch+x]==color(0));
 }
 assert(layout.update(240,320));assert(!layout.update(240,320));assert(layout.update(480,640)); // same aspect, distinct geometry key
 std::puts("PASS UniversalBlack: 13 aspects, exact sampled side crops, black game viewport/fallback, pitch guards, shared single-load asset, projected white legends, zero stable/render allocations and source geometry keys");
}
