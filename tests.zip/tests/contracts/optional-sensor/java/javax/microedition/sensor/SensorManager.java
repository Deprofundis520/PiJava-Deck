/*
 * Copyright 2017 Nikita Shakarun
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package javax.microedition.sensor;

/** Compile-only contract; never installed in the VM runtime path. */
public final class SensorManager {
    public static void addSensorListener(SensorListener listener, String quantity) {}
    public static void addSensorListener(SensorListener listener, SensorInfo info) {}
    public static SensorInfo[] findSensors(String url) { return null; }
    public static SensorInfo[] findSensors(String quantity, String contextType) { return null; }
    public static void removeSensorListener(SensorListener listener) {}
}
