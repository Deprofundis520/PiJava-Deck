"""Exercise the actual + menu controller before any game/instant-save deletion."""
from pathlib import Path
import subprocess,tempfile
root=Path(__file__).resolve().parents[1]
source=(root/'src/platform/switch_host.inc').read_text()
start=source.index('static void update_menu_delete(')
controller=source[start:source.index('static std::string button_names(',start)]
prefix=r'''
#include "host_menu.h"
#include "chapter_save_ui.h"
#include <cassert>
#include <filesystem>
#include <fstream>
using u64=uint64_t;
constexpr u64 HidNpadButton_A=1,HidNpadButton_B=2,HidNpadButton_AnyUp=4,HidNpadButton_AnyDown=8;
struct Entry{std::string label,path;};
menu_actions::Deletion g_menu_delete;chapter_ui::State g_chapter_import;
menu_actions::Repeat g_menu_repeat;u64 g_chapter_blocked=0;
bool g_menu_note_error=false,g_menu_note_neutral=true;
struct Catalog{void invalidate_saved(){}};struct Ui{Catalog catalog;} g_menu_name_ui;
int removed=0,instant_deleted=0,drawn=0;
bool instant_state_exists(const std::string&){return true;}
bool delete_instant_state(const std::string&){++instant_deleted;return true;}
std::vector<Entry> scan_games(){++removed;return {};}
void draw_menu(const std::vector<Entry>&,int,const std::string&){++drawn;}
void log_line(const std::string&){}
'''
tail=r'''
int main(){
 const std::string target="target.jar",origin="origin.jar";
 std::ofstream(target)<<"target";std::ofstream(origin)<<"origin";
 std::vector<Entry> items={{"目标",target},{"来源",origin}};int sel=0;std::string status;
 assert(g_menu_delete.begin(target,"目标"));
 update_menu_delete(HidNpadButton_AnyDown,items,sel,status);
 update_menu_delete(HidNpadButton_AnyDown,items,sel,status);
 assert(g_menu_delete.selection==2 && "plus menu must expose a third inheritance choice");
 update_menu_delete(HidNpadButton_A,items,sel,status,HidNpadButton_A);
 assert(g_chapter_import.open && !g_chapter_import.confirming && !g_menu_delete.open);
 assert(g_chapter_import.target_path==target && removed==0 && instant_deleted==0);
 assert(g_chapter_blocked==HidNpadButton_A); // release this A before source confirmation
 assert(std::filesystem::exists(target) && std::filesystem::exists(origin));
 // The first confirmation only opens source selection, no RMS copy is performed.
 assert(!std::filesystem::exists("sdmc:/switch/j2me/rms"));
 g_chapter_import={};g_menu_delete.begin(target,"目标");
 update_menu_delete(HidNpadButton_AnyUp,items,sel,status);assert(g_menu_delete.selection==2);
 update_menu_delete(HidNpadButton_B|HidNpadButton_A,items,sel,status);
 assert(!g_menu_delete.open && !g_chapter_import.open && removed==0 && instant_deleted==0);
 // A single installed game produces a message and preserves the JAR.
 items.resize(1);g_menu_delete.begin(target,"目标");
 update_menu_delete(HidNpadButton_AnyUp,items,sel,status);
 update_menu_delete(HidNpadButton_A,items,sel,status);
 assert(!g_chapter_import.open && status.find("至少需要两款游戏")!=std::string::npos);
 assert(std::filesystem::exists(target) && removed==0 && instant_deleted==0);
 std::vector<uint32_t> frame(1280*720);std::vector<std::string> labels;
 auto text=[&](int x,int y,const std::string& s,uint32_t,int size,int width){
 assert(x>=0&&y>=0&&x+width<=1280&&y+size<=720);labels.push_back(s);};
 g_menu_delete.begin(target,"目标");host_menu::render_delete(frame.data(),1280,g_menu_delete,text,{});
 assert(std::find(labels.begin(),labels.end(),"继承存档")!=labels.end());
 assert(std::find(labels.begin(),labels.end(),"删除游戏")!=labels.end());
 assert(std::find(labels.begin(),labels.end(),"删除即时存档")!=labels.end());
 labels.clear();host_menu::render_menu(frame.data(),1280,{"目标"},0,host_menu::Focus::Games,{},"",text);
 assert(std::find(labels.begin(),labels.end(),"Y 继承存档")==labels.end());
 std::puts("PASS + menu inheritance: source picker, no implicit write/delete, cancel priority, single-game notice, visible third row and bounded footer");
}
'''
build=root/'build/menu-inherit-entry';build.mkdir(parents=True,exist_ok=True)
cpp=build/'checks.cpp';cpp.write_text(prefix+controller+tail);exe=build/'checks'
subprocess.run(['g++','-std=c++17','-O2','-I'+str(root/'src'),cpp,'-o',exe],check=True)
with tempfile.TemporaryDirectory(prefix='plus-inherit-') as d:subprocess.run([exe],cwd=d,check=True)
