#include "platform/deck_steam.h"
#include <fstream>
#include <iostream>
#define CHECK(x) do{if(!(x)){std::cerr<<"Steam test line "<<__LINE__<<"\n";return 1;}}while(0)
int main(int argc,char** argv){
    using namespace deck_steam;
    CHECK(crc("123456789")==0xcbf43926u);
    std::string out,error;uint32_t id=0;bool changed=false;
    CHECK(add("","/home/deck/a b/pijava-deck","/home/deck/a b","/home/deck/a b/icon.png",out,id,changed,error)&&changed);
    std::vector<Entry> entries;size_t end=0;CHECK(parse(out,entries,end)&&entries.size()==1&&entries[0].appid==id);
    CHECK(entries[0].exe=="\"/home/deck/a b/pijava-deck\"");
    std::string again;CHECK(add(out,"/home/deck/a b/pijava-deck","/home/deck/a b","",again,id,changed,error)&&!changed&&again==out);
    std::string old;obj(old,"shortcuts");obj(old,"7");num(old,"appid",42);str(old,"AppName","Existing game");str(old,"Exe","\"/existing\"");obj(old,"tags");str(old,"0","untouched tag");old+='\10';num(old,"UnrecognizedButPreserved",123);old+='\10';old+='\10';old+='\10';
    entries.clear();CHECK(parse(old,entries,end));const auto prefix=old.substr(0,end);
    CHECK(add(old,"/home/deck/pijava-deck","/home/deck","",out,id,changed,error)&&changed);
    CHECK(out.substr(0,prefix.size())==prefix);
    entries.clear();CHECK(parse(out,entries,end)&&entries.size()==2&&entries[0].key=="7"&&entries[1].key=="8");
    CHECK(!add(std::string("\0bad",4),"/p","/","",again,id,changed,error));
    CHECK(!add(old.substr(0,old.size()-3),"/p","/","",again,id,changed,error));
    if(argc>1){std::ofstream f(argv[1],std::ios::binary);f.write(out.data(),std::streamsize(out.size()));}
    std::cout<<"PASS: VDF new entry, append, unknown field preservation, duplicate detection, malformed file rejection, CRC32\n";
}
