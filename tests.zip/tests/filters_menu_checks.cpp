// Catches unreachable filter focus, incorrect direction/wrap, lost old safe
// preferences and filter choices which disappear on restart.
#include <cstdio>
#include <cstdlib>
#if !__has_include("../src/presentation/filters.h")
#include "../src/host_menu.h"
int main(){
    std::vector<uint32_t> frame(1280*720);bool found=false;
    host_menu::Text text=[&](int,int,const std::string& s,uint32_t,int,int){if(s=="滤镜")found=true;};
    host_menu::render_menu(frame.data(),1280,{"game"},0,host_menu::Focus::Bezel,{},"",text);
    if(!found){std::fputs("ASSERT menu must expose independent filter row below bezel\n",stderr);return 1;}return 0;
}
#else
#include "../src/host_menu_settings.h"
#include <fstream>
#include <iterator>
#include <unistd.h>
static void require(bool ok,const char* message){if(!ok){std::fprintf(stderr,"ASSERT %s\n",message);std::exit(1);}}
static void write(const std::string& p,const std::string& s){std::ofstream f(p,std::ios::binary);f<<s;require(bool(f),"fixture write");}
int main(){
    using namespace host_menu;using display_filter::Filter;
    char tmp[]="/tmp/j2me-filters-XXXXXX";require(mkdtemp(tmp)!=nullptr,"temporary directory");
    const std::string path=std::string(tmp)+"/menu.cfg";
    Settings s;require(s.filter==Filter::Original,"missing setting defaults to original");
    require(option_step(Focus::Bezel,1)==Focus::Filter&&option_step(Focus::Filter,-1)==Focus::Bezel,"filter focus directly below bezel");
    require(option_step(Focus::Filter,1)==Focus::Speed&&option_step(Focus::Speed,1)==Focus::Fps,"remaining options reachable");
    require(option_step(Focus::Fps,1)==Focus::Fps&&option_step(Focus::Bezel,-1)==Focus::Bezel,"option endpoints clamped");
    require(s.canvas==0&&canvas_size(0)==std::make_pair(0,0),"canvas defaults to auto");
    require(change_canvas(s,-1)&&s.canvas==16&&canvas_size(s.canvas)==std::make_pair(800,480),"canvas wraps backward");
    require(change_canvas(s,1)&&s.canvas==0,"canvas wraps forward");
    require(!change_canvas(s,0),"canvas zero direction does nothing");
    const std::pair<int,int> sizes[]={{128,128},{128,160},{176,205},{176,208},{176,220},{208,208},{240,320},{240,400},{320,240},{320,480},{352,416},{360,360},{360,640},{480,800},{640,360},{800,480}};
    for(int i=1;i<=16;++i){require(change_canvas(s,1)&&s.canvas==i&&canvas_size(i)==sizes[i-1],"canvas presets match order");require(std::string(canvas_name(i))==std::to_string(sizes[i-1].first)+"×"+std::to_string(sizes[i-1].second),"canvas label matches dimensions");}
    require(canvas_size(-1)==std::make_pair(0,0)&&canvas_size(999)==std::make_pair(0,0),"invalid canvas uses auto");
    s=Settings{};s.canvas=7;require(save_settings(path,s),"canvas selection does not block global settings save");
    {std::ifstream input(path);const std::string bytes((std::istreambuf_iterator<char>(input)),{});require(bytes.find("canvas")==std::string::npos,"canvas never persists in global menu config");}
    s.canvas=-1;require(std::string(canvas_name(s.canvas))=="自定义（现有配置）"&&canvas_size(s.canvas)==std::make_pair(0,0),"existing custom canvas is labeled without dimensions override");
    require(change_canvas(s,1)&&s.canvas==0,"custom canvas forward chooses auto");
    s.canvas=-1;require(change_canvas(s,-1)&&s.canvas==16,"custom canvas backward chooses last preset");
    require(s.rotation==0,"rotation defaults to zero clockwise quarter turns");
    require(change_rotation(s,-1)&&s.rotation==3,"rotation left wraps to 270 degrees");
    require(change_rotation(s,1)&&s.rotation==0,"rotation right wraps to zero");
    require(!change_rotation(s,0)&&s.rotation==0,"zero direction leaves rotation unchanged");
    for(int r=0;r<4;++r){s.rotation=r;s.bezel=2;s.show_fps=false;s.filter=Filter::Crt;
        require(save_settings(path,s),"rotation saves");Settings restored;
        require(load_settings(path,restored)&&restored.rotation==r&&restored.filter==Filter::Crt&&restored.bezel==2&&!restored.show_fps,"rotation and old preferences roundtrip");}
    s=Settings{};s.rotation=1;require(save_settings(path,s),"rotation with default filter saves");
    {Settings restored;require(load_settings(path,restored)&&restored.rotation==1&&restored.filter==Filter::Original,"rotation with original filter roundtrips");}
    for(const std::string value:{"4","-1","bad","999999999999999999999999999","","1\ntrailing"}){
        write(path,"J2ME_MENU 2\nbezel=3\nshow_fps=0\nfilter=4\nrotation="+value+"\n");s=Settings{};s.rotation=2;
        require(load_settings(path,s)&&s.rotation==0&&s.bezel==3&&!s.show_fps&&s.filter==Filter::Crt,"bad optional rotation preserves bezel FPS and filter");}
    for(const std::string extra:{"", "filter=2\n"}){
        write(path,"J2ME_MENU 2\nbezel=2\nshow_fps=0\n"+extra);s.rotation=3;
        require(load_settings(path,s)&&s.rotation==0,"old records reset caller rotation to zero");}
    for(int invalid:{-1,4}){s=Settings{};s.rotation=invalid;require(!save_settings(path,s),"invalid rotation cannot save");}
    s=Settings{};
    require(change_filter(s,-1)&&s.filter==Filter::ScanlinesDX,"left wraps from original to ScanlinesDX");
    require(change_filter(s,1)&&s.filter==Filter::Original,"right wraps to original");
    const Filter expected[]={Filter::Bilinear,Filter::Scale2x,Filter::Lcd,Filter::Crt,Filter::ScanlinesDX,Filter::Original};
    for(Filter f:expected){require(change_filter(s,1)&&s.filter==f,"forward cycle order");s.bezel=2;s.show_fps=false;
        require(save_settings(path,s),"menu selection saves");Settings restored;
        require(load_settings(path,restored)&&restored.filter==f&&restored.bezel==2&&!restored.show_fps,"filter and safe preferences survive reload");}
    for(int v:{1,2}){write(path,"J2ME_MENU "+std::to_string(v)+"\nbezel=2\nshow_fps=0\n");s.filter=Filter::Crt;
        require(load_settings(path,s)&&s.filter==Filter::Original&&s.bezel==(v==1?7:2)&&!s.show_fps,"legacy records reset filter and preserve safe settings");}
    for(const std::string value:{"999","-1","bad","999999999999999999999999999",""}){
        write(path,"J2ME_MENU 2\nbezel=3\nshow_fps=0\nfilter="+value+"\n");s=Settings{};s.filter=Filter::Crt;
        require(load_settings(path,s)&&s.bezel==3&&!s.show_fps&&s.filter==Filter::Original,"bad optional filter preserves validated old preferences");}
    s=Settings{};s.filter=static_cast<Filter>(999);require(!save_settings(path,s),"invalid filter save rejected");
    struct Call{std::string text;int y;};std::vector<Call> calls;std::vector<uint32_t> frame(1280*720);
    Text text=[&](int,int y,const std::string& t,uint32_t,int,int){calls.push_back({t,y});};
    s=Settings{};s.filter=Filter::Scale2x;render_menu(frame.data(),1280,{"game"},0,Focus::Filter,s,"",text);
    int bezel=-1,filter=-1,rotation=-1,canvas=-1,speed=-1,fps=-1;bool selected=false,pane_hint=false,wrong_hint=false;
    for(const auto& c:calls){if(c.text=="遮罩")bezel=c.y;if(c.text=="滤镜")filter=c.y;if(c.text=="画面旋转")rotation=c.y;if(c.text=="画布尺寸")canvas=c.y;if(c.text=="速度")speed=c.y;if(c.text=="显示帧数")fps=c.y;if(c.text=="Scale2x")selected=true;if(c.text=="← → 游戏 / 选项")pane_hint=true;if(c.text=="← → 切换滤镜")wrong_hint=true;}
    require(bezel>=0&&bezel<filter&&filter<speed&&rotation==-1&&canvas==-1&&speed<fps&&fps<586&&selected,"independent visible filter row and chosen name");
    require(frame[size_t(filter)*1280+914]==color(0xf4dddd),"real filter focus highlight visible");
    require(pane_hint&&!wrong_hint,"filter footer describes pane navigation, not horizontal filter changes");
    require(std::remove(path.c_str())==0&&rmdir(tmp)==0,"cleanup");
    std::puts("PASS FiltersMenuChecks: focus, directional cycle, visible row, persistence and legacy safety");
}
#endif
