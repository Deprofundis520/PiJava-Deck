#include "host_keymap_ui.h"
#include <cassert>
#include <filesystem>
#include <fstream>
#include <iostream>
using namespace host_keymap;
static host_controller::Ink measure(const std::string& s,int p){return {std::max(1,int(s.size())*p/3),p-1,true};}
int main(){
 Store store;Editor e;e.begin(store,std::string(64,'a'),"fixture",false,false);e.page=Page::Keymap;e.phone=N5;
 const size_t pitch=1297,guard=31;const uint32_t sentinel=0xdeadbeef;std::vector<uint32_t> mem(guard+pitch*720+guard,sentinel);auto* frame=mem.data()+guard;
 host_pro::Preview preview;assert(preview.load("romfs/ui/pro-controller.rgba"));
 struct Call{int x,y;std::string text;};std::vector<Call> calls;
 host_menu::Text text=[&](int x,int y,const std::string& s,uint32_t,int px,int width){assert(x>=0&&y>=0&&x+width<=1280&&y+px<=720);calls.push_back({x,y,s});};
 host_menu::CenteredText center=[&](int x,int y,const std::string& s,uint32_t,int,int){calls.push_back({x,y,s});};
 TextRight right=[](const std::string& s,int p){return int(s.size())*p/3;};
 auto x_of=[&](const std::string& s){for(const auto& c:calls)if(c.text==s)return c.x;return -1;};
 for(Phase phase:{Phase::Phone,Phase::Slot,Phase::Choice})for(int slot=0;slot<3;++slot){
  e.phase=phase;e.slot=slot;e.choice=choice_for_input(A);calls.clear();DRAW_EDITOR();
  assert(x_of("选择手机按键")==188);assert(x_of("选择 Switch 按键")==572);
  for(int y=120;y<605;++y)for(int x=48;x<160;++x)assert(frame[y*pitch+x]==host_menu::color(0xf2f4f7));
  assert(188+(3*102+2*9)+60+(3*164+2*14)==1092); // equal outer margins
  if(phase!=Phase::Choice){bool star=false,hash=false;for(const auto& c:calls){star|=c.text=="*"&&c.x==776&&c.y==243;hash|=c.text=="#"&&c.x==890&&c.y==243;}assert(star&&hash);}
  for(size_t i=0;i<guard;++i)assert(mem[i]==sentinel&&mem[guard+pitch*720+i]==sentinel);
  for(int y=0;y<720;++y)for(size_t x=1280;x<pitch;++x)assert(frame[y*pitch+x]==sentinel);
 }
 // The translated Pro image, lock/fallback markers and selection rings
 // remain exactly the same pixels relative to the controller for every input.
 const host_menu::Text no_text=[](int,int,const std::string&,uint32_t,int,int){};
 const host_menu::CenteredText no_center=[](int,int,const std::string&,uint32_t,int,int){};
 std::vector<uint32_t> original(1280*720),shifted(1280*720);
 for(int input=-1;input<InputCount;++input){
  std::fill(original.begin(),original.end(),0xffbbbbbb);std::fill(shifted.begin(),shifted.end(),0xffbbbbbb);
  preview.render(original.data(),1280,e.draft,false,input,no_text,no_center,measure);
  preview.render(shifted.data(),1280,e.draft,false,input,no_text,no_center,measure,-144);
  for(int y=151;y<469;++y)for(int x=748;x<1208;++x)assert(original[y*1280+x]==shifted[y*1280+x-144]);
 }
 assert(!std::filesystem::exists("romfs/ui/nokia5300.rgba"));
 std::cout<<"PASS actual centered keymap: no phone bitmap, grid/right pane centered, Phone/Slot/Choice x3 slots, translated star/hash, frame/pitch guards\n";
}
