#include "platform/deck_state.h"
#include <iostream>
#include <chrono>
#define CHECK(x) do{if(!(x)){std::cerr<<"State line "<<__LINE__<<"\n";return 1;}}while(0)
int main(){
    namespace fs=std::filesystem;using deck_state::Store;
    auto root=fs::temp_directory_path()/fs::u8path("PiJava 即时存档-"+std::to_string(std::chrono::steady_clock::now().time_since_epoch().count()));
    Store store{root/"data/state",root/"portable/state"};CHECK(store.prepare());fs::create_directories(store.bundle);
    const auto jar=root/"game.jar";std::ofstream(jar)<<"abc";
    const auto id=deck_state::identity(jar);CHECK(id=="ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad");
    CHECK(deck_state::identity(root/"missing").empty());CHECK(store.primary("../escape").empty());
    auto primary=store.primary(id);CHECK(store.readable(jar,id).empty());
    CHECK(instant_state_file::save(primary.string(),"J2S5-test"));
    CHECK(store.readable(jar,id)==primary);
    // Reopening the store models a new process; moving the JAR preserves its slot.
    Store reopened{store.root,store.bundle};auto moved=root/"renamed.jar";fs::copy_file(jar,moved);
    CHECK(reopened.readable(moved,deck_state::identity(moved))==primary);
    auto different=root/"other/game.jar";fs::create_directories(different.parent_path());std::ofstream(different)<<"different";
    CHECK(store.primary(deck_state::identity(different))!=primary);
    fs::rename(primary,fs::path(primary.string()+".previous"));std::string bytes;
    CHECK(store.readable(jar,id)==primary);CHECK(instant_state_file::load(primary.string(),bytes)&&bytes=="J2S5-test");
    auto imported=store.bundle/"original.jar.sav";CHECK(instant_state_file::save(imported.string(),"J2S5-legacy"));
    CHECK(store.readable(root/"original.jar",id)==primary); // Primary has precedence.
    const auto otherid=deck_state::identity(different);
    CHECK(store.readable(root/"original.jar",otherid)==imported);
    Store installed{store.root,root/"installed/state"};CHECK(installed.readable(moved,id)==primary);
    std::cout<<"PASS: SHA256 slots, new-process reopen, renamed JAR, same-name isolation, imported upstream name, journal recovery, installed persistence\n";
}
