// PROPOSAL ONLY. Include after normal_case(), before main(), in the existing
// diagnostics_vm_checks.cpp. Uses the real included VM, not replacement logic.
// Run each case in a fresh process. The windows case uses synthetic elapsed
// fixture accounting; it is not a real-time FPS or Switch performance test.
static size_t proposal_count_lines(const std::string& source,const char* token) {
    std::istringstream input(source);std::string line;size_t count=0;
    while(std::getline(input,line))if(line.find(token)!=std::string::npos)++count;
    return count;
}
static void reset_boundary_case(){
    runtime_diag::Window w;w.active=true;w.cap=60;w.duration_us=1000000;w.worker_cpu_ns=700000000;w.draws=w.changes=40;w.budget_frames=40;w.budget_valid=true;
    auto& detector=g_device_diag.detector;detector.reset();
    for(int n=1;n<=3;++n)require(detector.observe(n*1000000,w)==0,"initial grace/one short window must not trigger");
    // This is the actual common reset used by lifecycle_pause/resume. No
    // paused statistics window is inserted to accidentally clear the streak.
    reset_runtime_stats();
    require(detector.observe(4000000,w)==0,"old shortfall streak survived actual reset_runtime_stats boundary");
    VMS_EXEC(g_midlet_state)=MidletState::Active;VMS_PLAT(g_host_paused)=false;
    host_freeze236(true);host_freeze236(false);
    require(detector.observe(5000000,w)==0,"host freeze/resume did not start fresh grace");
}
static void windows_case() {
    reset_runtime_stats();
    VMS_RS(g_fb).assign(3,0); // Tiny synthetic RGB, no commercial content.
    VMS_RS(g_frame_metrics).reset();
    const int modes[]={0,0,30,30,30,60,60,60,60,0};
    const int draws[]={15,15,30,30,30,60,60,60,60,15};
    unsigned color=0;
    for(size_t window=0;window<10;++window) {
        const bool pause=window==1||window==8;
        VMS_EXEC(g_speed_cap)=modes[window];
        VMS_EXEC(g_midlet_state)=pause?MidletState::Paused:MidletState::Active;
        VMS_PLAT(g_host_paused)=pause;
        const auto draw_before=VMS_RS(g_game_frames);
        // Artificial completed one-second window in a fast fixture. Keep the
        // real paint_clock_us(), real maybe_emit_runtime_stats(), and original
        // counter take/reset logic; do not sleep ten seconds or replace clocks.
        const auto now=paint_clock_us();
        VMS_RS(g_paint_stats).reset(now-1000001,draw_before);
        for(int n=0;n<draws[window];++n) {
            VMS_RS(g_fb)[0]=uint8_t(++color);
            VMS_RS(g_drawacc).on=false;
            draw_end("DiagnosticsWindow");
            VMS_RS(g_paint_stats).completed(1000);
        }
        VMS_RS(g_present_frames)+=draws[window];
        VMS_EXEC(g_speed_budget_window_frames)=uint64_t(draws[window]);
        // Explicit fixture accounting, not measured CPU workload.
        auto& pending=VMS_EXEC(g_runtime_profile).pending;
        pending.worker_gross_us=1000+int64_t(window);
        pending.worker_cpu_ns=1000000;pending.cpu_samples=1;
        const auto draw_after=VMS_RS(g_game_frames);
        maybe_emit_runtime_stats();
        require(g_device_diag.windows==window+1,"missing per-second diagnostic window");
        require(VMS_RS(g_game_frames)==draw_after,"diagnostic window changed raw draw counter");
        require(VMS_EXEC(g_speed_cap)==modes[window],"diagnostics changed speed mode");
        require(VMS_PLAT(g_host_paused)==pause,"diagnostics changed pause flag");
        require(VMS_RS(g_frame_metrics).pending.completed_draws==0,"legacy frame counter not consumed");
        require(VMS_EXEC(g_runtime_profile).pending.worker_gross_us==0,"worker window not consumed");
        require(VMS_RS(g_paint_stats).pending.canvas_paints==0,"paint window not consumed");
        const auto seen=g_device_diag.windows;
        maybe_emit_runtime_stats(); // Same clock, not another completed second.
        require(g_device_diag.windows==seen,"one completed window was emitted/taken twice");
    }
    require(j2melog::drain(),"windows fixture logger drain failed");
    const auto output=file_text();
    require(proposal_count_lines(output," DIAGWIN ")==10,"expected ten complete DIAGWIN file records");
    require(proposal_count_lines(output," DIAGDETAIL ")==10,"expected ten matching budget/gfx detail records");
    require(proposal_count_lines(output," STAT slice=")==1,"default legacy block should emit once in fast fixture");
    require(line_with(output,{"FRAMESTAT ","completed_draws=15 "}),"first legacy FRAMESTAT lost counters to new diagnostics");
    require(line_with(output,{"WORKSTAT ","worker_gross_ms=1.000 "}),"first legacy WORKSTAT lost counters to new diagnostics");
    for(size_t window=0;window<10;++window) {
        const auto id="window="+std::to_string(window+1)+" ";
        const auto mode="mode="+std::to_string(modes[window])+" ";
        const auto raw="raw_draws="+std::to_string(draws[window])+" ";
        const auto paused=std::string("paused=")+((window==1||window==8)?"1 ":"0 ");
        const auto budget="cap_budget_frames="+std::to_string(draws[window])+" ";
        require(line_with(output,{" DIAGWIN ",id.c_str(),mode.c_str(),raw.c_str(),paused.c_str()}),"window identity/mode/draw/pause disagreement");
        require(line_with(output,{" DIAGDETAIL ",id.c_str(),budget.c_str(),"cap_budget_scope=budget_not_logic"}),"budget detail lost counter or window identity");
    }
    require(output.find("DIAGFAULT")==std::string::npos,"healthy synthetic mode/pause windows fabricated incident");
    std::cout<<"WINDOW_SCOPE synthetic_elapsed_fixture=1 completed_windows=10 legacy_blocks=1 "
             <<"actual_stats_function=1 real_time_FPS=not_measured Switch_performance=not_measured\n";
}

struct ProposalNativeTiming {int64_t wall_us=0,cpu_ns=-1;int64_t checksum=0;};
static ProposalNativeTiming proposal_measure_native(void (*body)(Method*,Frame&),Frame& frame,size_t count) {
    const auto cpu_before=j2me_cpu_clock::now_ns();
    const auto wall_before=paint_clock_us();
    int64_t checksum=0;
    for(size_t n=0;n<count;++n) {
        frame.stack.clear(); // Retain warmed vector capacity; never grow N returns.
        body(test_native,frame);
        checksum+=frame.stack.back().i;
    }
    const auto wall_after=paint_clock_us();
    const auto cpu_after=j2me_cpu_clock::now_ns();
    require(frame.stack.size()==1,"native benchmark retained multiple returns");
    require(checksum==int64_t(count)*test_exception,"native benchmark changed identityHashCode result");
    return {wall_after-wall_before,j2me_cpu_clock::difference(cpu_before,cpu_after),checksum};
}
static void benchmark_case() {
    Frame frame;frame.method=test_native;frame.locals=test_args;frame.op_pc=23;
    frame.stack.reserve(2);
    const auto before_throws=g_device_diag.throw_count;
    const auto before_roots=VMS_HEAP(g_root_stacks).size();
    // Real same-body native implementation is the control; no mock dispatch.
    proposal_measure_native(call_native_impl,frame,1000);
    proposal_measure_native(call_native,frame,1000);
    const auto capacity=frame.stack.capacity();
    constexpr size_t count=100000;
    const auto control=proposal_measure_native(call_native_impl,frame,count);
    const auto wrapped=proposal_measure_native(call_native,frame,count);
    require(control.checksum==wrapped.checksum,"wrapper/control native results differ");
    require(frame.stack.capacity()==capacity,"benchmark frame stack unexpectedly reallocated");
    require(g_device_diag.throw_count==before_throws&&!VMS_EXEC(g_thrown),"benchmark fabricated exception");
    require(VMS_HEAP(g_root_stacks).size()==before_roots,"benchmark changed root stack");
    runtime_diag::LiveSnapshot live;
    require(g_device_diag.live.read(live)&&live.phase!=runtime_diag::Phase::Native,"benchmark wrapper did not restore phase");
    const auto delta_wall=wrapped.wall_us-control.wall_us;
    const auto delta_cpu=wrapped.cpu_ns>=0&&control.cpu_ns>=0?wrapped.cpu_ns-control.cpu_ns:-1;
    std::cout<<"NATIVE_BENCH iterations_each="<<count<<" warmup_each=1000 order=impl_then_wrapper "
             <<"method=java/lang/System.identityHashCode(Ljava/lang/Object;)I actual_native=1 "
             <<"impl_wall_us="<<control.wall_us<<" wrapped_wall_us="<<wrapped.wall_us
             <<" delta_wall_us="<<delta_wall<<" delta_wall_ns_per_call="<<double(delta_wall)*1000/count
             <<" cpu_available="<<int(control.cpu_ns>=0&&wrapped.cpu_ns>=0)
             <<" cpu_source="<<j2me_cpu_clock::source()<<" impl_cpu_ns="<<control.cpu_ns
             <<" wrapped_cpu_ns="<<wrapped.cpu_ns<<" delta_cpu_ns="<<delta_cpu
             <<" scope=desktop_native_wrapper_overhead not_Switch_FPS=1 not_full_frame_cost=1\n";
    // A negative delta is measurement noise, not a reason to clamp or fail.
    require(j2melog::drain(),"benchmark fixture logger drain failed");
}
