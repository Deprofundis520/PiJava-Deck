#include <algorithm>
#include <cerrno>
#include <chrono>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iostream>
#include <string>
#include <thread>
#include <vector>
static std::ofstream g_log;
#define VMS_PLAT(x) x
#ifndef LOGGER_HEADER
#define LOGGER_HEADER "../../src/async_log.inc"
#endif
#include LOGGER_HEADER
struct FailingFlush:std::streambuf {
    std::streamsize xsputn(const char*,std::streamsize n)override{return n;}
    int overflow(int c)override{return c;}
    int sync()override{return -1;}
};
int main(int argc,char** argv){
    if(argc!=3)return 2;
    const std::string which=argv[1],path=argv[2];
    if(which=="pressure"){
        j2melog::g_started=true;
        j2melog::enqueue("DIAGFAULT id=1 origin=first-fault",true);
        for(size_t n=0;n<j2melog::kQueueCap+32;++n)j2melog::enqueue("EX ordinary="+std::to_string(n),true);
        bool retained=false;for(const auto& row:j2melog::g_q)retained|=row.line.find("origin=first-fault")!=std::string::npos;
        j2melog::g_started=false;j2melog::g_q.clear();
        std::cout<<"fault_retained="<<retained<<" bounded="<<(j2melog::g_q.size()<=j2melog::kQueueCap)<<" drops="<<j2melog::g_drops<<"\n";
        return retained?0:1;
    }
    if(which=="write-failure"){
        j2melog::g_path=path+"/missing-parent/log.txt";
        j2melog::start_writer();j2melog::enqueue("EX write-failure",true);
        const bool acknowledged=j2melog::drain();j2melog::shutdown();
        std::cout<<"drain_success="<<acknowledged<<" io_failures="<<j2melog::g_failures<<"\n";
        return !acknowledged&&j2melog::g_failures>0?0:1;
    }
    if(which=="flush-failure"){
        j2melog::g_path=path+"/flush.txt";g_log.open(j2melog::g_path);
        FailingFlush failing;auto* original=static_cast<std::ostream&>(g_log).rdbuf(&failing);
        j2melog::start_writer();j2melog::enqueue("EX flush-failure",true);
        const bool acknowledged=j2melog::drain();j2melog::shutdown();
        const auto failures=j2melog::g_failures.load();
        static_cast<std::ostream&>(g_log).rdbuf(original);g_log.clear();g_log.close();
        std::cout<<"drain_success="<<acknowledged<<" io_failures="<<failures<<"\n";
        return !acknowledged&&failures>0?0:1;
    }
    if(which=="normal"){
        j2melog::g_path=path+"/normal.txt";g_log.open(j2melog::g_path);
        j2melog::start_writer();j2melog::enqueue("EX normal-fixture",true);
        const bool acknowledged=j2melog::drain();j2melog::shutdown();g_log.close();
        std::ifstream in(j2melog::g_path);std::string line;std::getline(in,line);
        std::cout<<"drain_success="<<acknowledged<<" line="<<line<<"\n";
        return acknowledged&&line=="EX normal-fixture"?0:1;
    }
    return 2;
}
