"""Build/run the unmodified real VM fixture, recording every actual signedrc.

On Windows use --syntax-only for an honest platform/dependency result.
Linux default builds puff+VM and runs five independent processes.
"""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

here = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source-root', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--syntax-only', action='store_true')
parser.add_argument('--windows-adapter', type=Path)
parser.add_argument('--compiler', type=Path)
parser.add_argument('--specs', type=Path)
parser.add_argument('--puff-object', type=Path)
parser.add_argument('--puff-source-baseline', type=Path)
args = parser.parse_args()
source = args.source_root.resolve()
output = args.output.resolve()
output.mkdir(parents=True, exist_ok=True)
records = []

def run(label, argv):
    argv = [str(value) for value in argv]
    p = subprocess.run(argv, cwd=here, capture_output=True, text=True, timeout=240)
    rc = p.returncode - 2**32 if p.returncode >= 2**31 else p.returncode
    records.append(dict(label=label, argv=argv, cwd=str(here), signedrc=rc,
                        stdout=p.stdout, stderr=p.stderr))
    (output / 'commands-results.json').write_text(
        json.dumps(records, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    print(label, 'signedrc=', rc, flush=True)
    print(p.stdout + p.stderr, end='', flush=True)
    return rc

cxx = str(args.compiler.resolve()) if args.compiler else shutil.which('g++')
cc = shutil.which('gcc')
if not cxx or not cc:
    raise SystemExit('Requires actual gcc and g++')
fixture = here / 'diagnostics_vm_checks.cpp'
common = [cxx, '-O0', '-g0', '-std=c++17', '-fno-exceptions', '-pthread',
          '-I' + str(source / 'src'),
          '-DJ2ME_TEST_VM="' + str(source / 'src/j2mevm.cpp') + '"', fixture]
if args.windows_adapter:
    adapter = args.windows_adapter.resolve()
    common += ['-I' + str(adapter), '-include', adapter / 'windows_posix.h', '-Dlstat=stat']
if args.specs:
    common += ['-specs=' + str(args.specs.resolve())]
if args.syntax_only:
    raise SystemExit(run('syntax-only', common + ['-fsyntax-only']))
if not sys.platform.startswith('linux') and not args.windows_adapter:
    raise SystemExit('Full real VM build requires Linux POSIX headers; no platform stubs are introduced')
puff = output / 'puff.o'
if args.puff_object:
    baseline = args.puff_source_baseline.resolve() if args.puff_source_baseline else None
    if not baseline or baseline.read_bytes() != (source / 'src/puff.c').read_bytes():
        raise SystemExit('Reusing puff requires an identical explicit --puff-source-baseline')
    original_object = args.puff_object.resolve()
    shutil.copyfile(original_object, puff)
    (output / 'puff-reuse.json').write_text(json.dumps(dict(
        source_sha256=hashlib.sha256(baseline.read_bytes()).hexdigest(),
        baseline_source=str(baseline), source=str(source / 'src/puff.c'),
        original_object=str(original_object),
        object_sha256=hashlib.sha256(puff.read_bytes()).hexdigest()), indent=2) + '\n')
else:
    rc = run('build-puff', [cc, '-O0', '-c', source / 'src/puff.c', '-o', puff])
    if rc:
        raise SystemExit(rc)
exe = output / 'diagnostics_vm_checks'
if args.windows_adapter:
    exe = exe.with_suffix('.exe')
link = [puff, '-ffunction-sections', '-fdata-sections', '-Wl,--gc-sections']
if not args.windows_adapter:
    link += ['-ldl']
rc = run('build-real-vm', common + link + ['-o', exe])
if rc:
    raise SystemExit(rc)
failures = []
for scenario in ('caught', 'uncaught', 'die', 'native-fault', 'normal', 'windows', 'benchmark', 'reset-boundary'):
    rc = run(scenario, [exe, scenario, output])
    if rc:
        failures.append(rc)
raise SystemExit(failures[0] if failures else 0)
