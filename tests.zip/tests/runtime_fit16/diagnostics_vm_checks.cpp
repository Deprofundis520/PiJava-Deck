// Independent real-VM proposal. No JIT mock, no replacement interpreter/native,
// no guest-field overrides, no user JAR/RMS/save files.
// Build on Linux with:
// gcc -O0 -c <source>/src/puff.c -o <out>/puff.o
// g++ -O0 -g0 -std=c++17 -fno-exceptions -pthread -I<source>/src
//   -DJ2ME_TEST_VM='"<source>/src/j2mevm.cpp"' diagnostics_vm_checks.cpp
//   <out>/puff.o -ldl -o <out>/diagnostics_vm_checks
// Run each case in a FRESH process, with an existing ASCII output directory:
// diagnostics_vm_checks caught|uncaught|die|native-fault|normal <out>
// Output format contract: method owner/name/descriptor and bci must occur in
// one recorded line; caught records include handler_bci=2. If production chooses
// different field spelling, adapt ONLY the expected text below, not the VM.
#ifndef J2ME_TEST_VM
#error "Define J2ME_TEST_VM to the actual j2mevm.cpp under test"
#endif
#if !__has_include("runtime_diagnostics.h")
#error "DIAG_FEATURE_MISSING: Fit15 has no runtime diagnostics feature (expected RED)"
#else
#define main emulator_main
#include J2ME_TEST_VM
#undef main

#include <initializer_list>
#include <sstream>

static Method* test_outer=nullptr;
static Method* test_inner=nullptr;
static Method* test_normal=nullptr;
static Method* test_native=nullptr;
static Method* test_bad_native=nullptr;
static Method* test_bad_opcode=nullptr;
static std::vector<Value> test_args;
static std::string test_path;
static int test_exception=0;

static void require(bool ok,const char* message) {
    if(ok)return;
    std::cerr<<"FAIL diagnostics-real-vm "<<message<<std::endl;
    std::cout.flush();std::cerr.flush();
    std::_Exit(1); // A broken logger must not hide the assertion in atexit.
}
static std::string history() {
    std::string out;
    g_device_diag.flight.dump([&](const char* line){out+=line;out+='\n';},runtime_diag::Flight::Capacity);
    return out;
}
static bool line_with(const std::string& text,std::initializer_list<const char*> tokens) {
    std::istringstream input(text);std::string line;
    while(std::getline(input,line)) {
        bool all=true;for(const char* token:tokens)all=all&&line.find(token)!=std::string::npos;
        if(all)return true;
    }
    return false;
}
static std::string file_text() {
    std::ifstream input(test_path);
    return std::string(std::istreambuf_iterator<char>(input),{});
}
static void assert_origin(const std::string& text,const char* method,int bci) {
    const std::string where="bci="+std::to_string(bci);
    require(line_with(text,{"DiagnosticsOrigin",method,"(Ljava/lang/Object;)I",where.c_str()}),
            "missing exact owner/method/descriptor/throw-op_pc on one copied record");
}
static CpEntry utf(const char* text) {CpEntry cp;cp.tag=1;cp.utf=text;return cp;}
static CpEntry link(int tag,int a,int b=0) {CpEntry cp;cp.tag=uint8_t(tag);cp.a=a;cp.b=b;return cp;}
static Method method(int owner,const char* name,const char* desc,std::initializer_list<uint8_t> code) {
    Method out;out.class_id=owner;out.name=name;out.desc=desc;
    out.flags=0x0008;out.max_locals=1;out.max_stack=2;out.code=code;
    return out;
}
static int add_class(const char* name) {
    const int id=int(VMS_CL(g_classes).size());
    Class value;value.name=name;value.init_state=2;
    VMS_CL(g_classes).push_back(std::move(value));VMS_CL(g_class_index)[name]=id;
    return id;
}
static void initialize(const char* output,const char* scenario) {
    VMS_PLAT(g_boot_ms)=now_ms();VMS_DIAG(g_log_draw)=false;
    VMS_DIAG(g_p1).enabled=true;VMS_EXEC(g_speed_cap)=0;
    VMS_NATIVE(g_native_jit).enabled=false;
    VMS_HEAP(g_heap).assign(1,Obj{});VMS_HEAP(g_free).clear();
    VMS_CL(g_classes).clear();VMS_CL(g_class_index).clear();
    // Class storage is a deque; reserve individual method vectors below.
    const int owner=add_class("DiagnosticsOrigin");
    const int exception_class=add_class("DiagnosticsTestException");
    const int system=add_class("java/lang/System");
    auto& c=VMS_CL(g_classes)[owner];c.methods.reserve(4);
    // cp6 is DiagnosticsOrigin.inner(Ljava/lang/Object;)I.
    c.cp={CpEntry{},utf("DiagnosticsOrigin"),link(7,1),utf("inner"),
          utf("(Ljava/lang/Object;)I"),link(12,3,4),link(10,2,5)};
    c.methods.push_back(method(owner,"outer","(Ljava/lang/Object;)I",{0,0,42,184,0,6,172}));
    c.methods.push_back(method(owner,"inner","(Ljava/lang/Object;)I",{42,191,87,16,77,172}));
    c.methods.push_back(method(owner,"normalReturn","(I)I",{26,4,96,172}));
    // nop; illegal/reserved opcode 202 -> die at bci1, with a real live frame.
    c.methods.push_back(method(owner,"fatalOpcode","(Ljava/lang/Object;)I",{0,202}));
    test_outer=&c.methods[0];test_inner=&c.methods[1];
    test_normal=&c.methods[2];test_bad_opcode=&c.methods[3];
    auto& native=VMS_CL(g_classes)[system];native.methods.reserve(2);
    native.methods.push_back(method(system,"identityHashCode","(Ljava/lang/Object;)I",{}));
    native.methods.push_back(method(system,"diagnosticsUnknown","(Ljava/lang/Object;)I",{}));
    for(auto& entry:native.methods){entry.native=true;entry.flags|=0x0100;}
    test_native=&native.methods[0];test_bad_native=&native.methods[1];
    test_exception=alloc_obj(exception_class);test_args={Value::of_ref(test_exception)};
    test_path=std::string(output)+"/diagnostics-"+scenario+".log";
    log_open(test_path.c_str(),true);
    diag_launch("diagnostics-synthetic-fixture","DiagnosticsOrigin");
    diag_host(true,false);
    g_device_diag.flight.reset(); // Only reset this single-owner fixture ring.
}
static void caught_case() {
    test_inner->handlers.push_back(Handler{0,2,2,0});
    const auto count=g_device_diag.throw_count;
    const Value answer=run(test_outer,test_args);
    require(answer.i==77,"actual caught bytecode return changed");
    require(g_device_diag.throw_count==count+1,"throw_ref must record one original throw");
    require(VMS_DIAG(g_p1).caught_count==1,"actual interpreter catch not reached");
    require(current_context().unhandled==0,"caught exception marked unhandled");
    require(VMS_EXEC(g_run_depth)==0&&VMS_HEAP(g_root_stacks).empty(),"normal RunScope did not unwind");
    const auto copied=history();assert_origin(copied,"inner",1);
    assert_origin(copied,"outer",3);
    require(line_with(copied,{"event=catch","DiagnosticsOrigin.inner(Ljava/lang/Object;)I","handler_bci=2","outcome=caught"}),"catch-site handler not recorded");
    require(g_device_diag.caught_count==1,"diagnostic caught count disagrees with actual catch");
    require(copied.find("uncaught")==std::string::npos,"caught path recorded as uncaught");
    // Destroy live Method/Frame storage only AFTER normal run return. Copied
    // event text must remain sufficient without dereferencing guest metadata.
    VMS_CL(g_classes).clear();VMS_CL(g_class_index).clear();
    require(history()==copied,"history retained borrowed Method/frame pointers");
    require(j2melog::drain(),"caught fixture logger drain failed");
    require(file_text().find("EX uncaught")==std::string::npos,"caught path emitted uncaught EX");
}

// No test-local strings/vectors/lock guards are created between setjmp and run.
// The fixture exercises the EXISTING VM longjmp recovery path; it does not
// make that mechanism C++ exception-safe or prove arbitrary recovery safe.
static void fatal_case(const char* which) {
    const bool java=std::strcmp(which,"uncaught")==0;
    const bool native=std::strcmp(which,"native-fault")==0;
    const auto before=g_device_diag.throw_count;
    g_die_catch=true;
    if(setjmp(g_die_jmp)==0) {
        run(java?test_outer:native?test_bad_native:test_bad_opcode,test_args);
        require(false,"expected actual run/throw/report/die path to longjmp");
    }
    g_die_catch=false;
    const auto copied=history();
    if(java) {
        require(g_device_diag.throw_count==before+1,"uncaught throw was not recorded before unwind");
        assert_origin(copied,"inner",1);
        assert_origin(copied,"outer",3);
        require(copied.find("handler_bci=2")==std::string::npos,"uncaught path invented a catch handler");
        require(VMS_DIAG(g_p1).caught_count==0,"uncaught path counted as caught");
    } else if(native) {
        require(line_with(copied+"\n"+file_text(),{"java/lang/System","diagnosticsUnknown","(Ljava/lang/Object;)I"}),
                "native fatal snapshot lost wrapper method/descriptor");
    } else {
        assert_origin(copied,"fatalOpcode",1);
    }
    // This is intentionally BEFORE stop_thread/VM teardown: an event that
    // appears only after cleanup cannot diagnose a cleanup that never returns.
    // A native-only entry has no Java frames. Its copied boundary may be
    // emitted directly as DIAGCTX rather than stored as a Java stack event.
    require(native?line_with(file_text(),{"DIAGCTX","method=java/lang/System.diagnosticsUnknown(Ljava/lang/Object;)I"}):!copied.empty(),
            "die snapshot missing before cleanup");
    log_line("DIAGTEST after_longjmp logger_can_continue=1");
    require(j2melog::drain(),"logger remained locked after longjmp");
    const auto output=file_text();
    require(output.find("DIAGTEST after_longjmp logger_can_continue=1")!=std::string::npos,
            "post-longjmp record did not reach actual file sink");
    if(java)require(output.find("EX uncaught DiagnosticsTestException")!=std::string::npos,
                    "actual report_uncaught classification absent");
    // Follow the same real host cleanup used by Switch's setjmp branch.
    stop_thread();
    require(history().find("DiagnosticsOrigin")!=std::string::npos||native,
            "real cleanup erased the copied incident record");
}
static void normal_case() {
    const auto before=g_device_diag.throw_count;
    require(run(test_normal,{Value::of_i(41)}).i==42,"normal run return changed");
    Frame frame;frame.method=test_native;frame.locals=test_args;frame.op_pc=23;
    call_native(test_native,frame);
    require(frame.stack.size()==1&&frame.stack.back().i==test_exception,"normal call_native return changed");
    require(run(test_native,test_args).i==test_exception,"run(native) return changed");
    require(g_device_diag.throw_count==before,"normal path fabricated exception");
    require(!VMS_EXEC(g_thrown)&&current_context().unhandled==0,"normal path left exception state");
    require(VMS_EXEC(g_run_depth)==0&&VMS_HEAP(g_root_stacks).empty(),"normal path left root stack");
    runtime_diag::LiveSnapshot live;
    require(g_device_diag.live.read(live),"cannot read published native-return state");
    require(live.phase!=runtime_diag::Phase::Native,"native wrapper failed to restore phase");
    diag_host(true,true);require(g_device_diag.live.read(live)&&live.paused,"paused host state not published");
    diag_host(true,false);require(g_device_diag.live.read(live)&&!live.paused,"active host state not restored");
    require(j2melog::drain(),"normal logger drain failed");
}
#include "additional_cases.inc"
int main(int argc,char** argv) {
    if(argc!=3){std::cerr<<"usage: diagnostics_vm_checks caught|uncaught|die|native-fault|normal ASCII-output-dir\n";return 2;}
    std::cout<<std::unitbuf;
    initialize(argv[2],argv[1]);
    if(std::strcmp(argv[1],"caught")==0)caught_case();
    else if(std::strcmp(argv[1],"normal")==0)normal_case();
    else if(std::strcmp(argv[1],"windows")==0)windows_case();
    else if(std::strcmp(argv[1],"benchmark")==0)benchmark_case();
    else if(std::strcmp(argv[1],"reset-boundary")==0)reset_boundary_case();
    else if(std::strcmp(argv[1],"uncaught")==0||std::strcmp(argv[1],"die")==0||std::strcmp(argv[1],"native-fault")==0)fatal_case(argv[1]);
    else return 2;
    log_shutdown();VMS_PLAT(g_log).close();
    std::cout<<"PASS diagnostics-real-vm case="<<argv[1]
             <<" actual_interpreter=1 actual_native=1 jit_mock=0 user_state=0 platform=desktop\n";
    return 0;
}
#endif
