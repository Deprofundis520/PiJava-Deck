#include <iostream>
#if !__has_include("runtime_diagnostics.h")
int main(){std::cerr<<"MISSING_FEATURE bounded diagnostics/atomic heartbeat\n";return 1;}
#else
#include "runtime_diagnostics.h"
#include <thread>
#include <vector>
#include <string>
static int failures=0;
#define CHECK(x) do{if(!(x)){std::cerr<<"failed line "<<__LINE__<<": "<<#x<<"\n";++failures;}}while(0)
int main(){
    using namespace runtime_diag;
    char utf8[5];CHECK(text(utf8,sizeof(utf8),u8"中文"));CHECK(std::string(utf8)==u8"中");
    Flight flight;std::vector<std::string> lines;auto sink=[&](const char* s){lines.emplace_back(s);};
    for(unsigned i=0;i<140;++i)flight.note(i,"input",std::to_string(i).c_str());
    flight.dump(sink);CHECK(flight.overwritten()==12);CHECK(lines.size()==Flight::Capacity);
    CHECK(lines.front().find("seq=13 ")!=std::string::npos);CHECK(lines.back().find("seq=140 ")!=std::string::npos);
    lines.clear();std::string huge(2000,'a');huge[5]='\n';flight.note(141,"throw",huge.c_str());flight.dump(sink,1);
    CHECK(lines[0].find("truncated=1")!=std::string::npos);CHECK(lines[0].find('\n')==std::string::npos);
    Labels labels;const auto id=labels.add("game.Actor.attack()V");CHECK(id>0);CHECK(std::string(labels.get(id))=="game.Actor.attack()V");CHECK(std::string(labels.get(999999))=="unknown");
    const auto long_id=labels.add(std::string(1000,'x').c_str());CHECK(std::string(labels.get(long_id)).find("[truncated]")!=std::string::npos);
    Live live;LiveSnapshot s;s.active=true;s.host_us=1000000;s.point_us=1100000;s.method=id;s.bci=42;s.depth=3;s.session=19;s.launch=2;
    live.publish(s);LiveSnapshot got;CHECK(live.read(got));CHECK(got.bci==42&&got.session==19);
    Watchdog watch;lines.clear();watch.poll(3100001,live,labels,sink);CHECK(lines.size()==1);CHECK(lines[0].find("HOST_TURN_STALLED")!=std::string::npos);CHECK(lines[0].find("game.Actor.attack()V")!=std::string::npos);
    watch.poll(4000000,live,labels,sink);CHECK(lines.size()==1);
    s.launch=3;live.publish(s);watch.poll(4000001,live,labels,sink);CHECK(lines.size()==2);
    s.host_us=4100000;live.publish(s);watch.poll(4100001,live,labels,sink);CHECK(lines.size()==3);CHECK(lines.back().find("HOST_TURN_RECOVERED")!=std::string::npos);
    s.paused=true;s.host_us=100;live.publish(s);watch.poll(9000000,live,labels,sink);CHECK(lines.size()==3);
    s.paused=false;s.active=false;live.publish(s);watch.poll(20000000,live,labels,sink);CHECK(lines.size()==3);
    WindowDetector detector;Window w;w.active=true;w.cap=60;w.duration_us=1000000;w.draws=60;w.changes=60;w.worker_cpu_ns=600000000;
    CHECK(detector.observe(1000000,w)==0);CHECK(detector.observe(2000000,w)==0);CHECK(detector.observe(3000000,w)==0);
    w.draws=15;w.changes=15;CHECK(detector.observe(4000000,w)&WindowDetector::CapShortfall);CHECK(detector.observe(5000000,w)&WindowDetector::CapShortfall);
    w.cap=0;w.draws=14;w.changes=14;w.max_draw_interval_us=70000;CHECK(detector.observe(6000000,w)==0);CHECK(detector.observe(7000000,w)==0);CHECK(detector.observe(8000000,w)==0);
    w.paused=true;w.max_draw_interval_us=2000000;CHECK(detector.observe(9000000,w)==0);
    w.paused=false;w.cap=30;w.draws=30;w.changes=30;w.max_draw_interval_us=33334;
    CHECK(detector.observe(10000000,w)==0);CHECK(detector.observe(11000000,w)==0);CHECK(detector.observe(12000000,w)==0);
    w.max_draw_interval_us=400000;CHECK(detector.observe(13000000,w)&WindowDetector::LongGap);
    w.draws=1;w.changes=1;w.worker_cpu_ns=1000000;w.max_draw_interval_us=1000000;detector.reset();
    for(int n=1;n<=4;++n)CHECK(detector.observe(n*1000000,w)==0);
    IncidentGate gate;CHECK(gate.allow(0,1));CHECK(!gate.allow(0,2));CHECK(gate.count(0)==2);CHECK(gate.allow(0,10000002));CHECK(gate.allow(0,10000003,true));
    w.cap=60;w.draws=120;w.changes=120;w.worker_cpu_ns=700000000;w.max_draw_interval_us=8334;w.budget_valid=true;w.budget_frames=15;detector.reset();
    for(int n=1;n<3;++n)CHECK(detector.observe(n*1000000,w)==0);
    CHECK(detector.observe(3000000,w)&WindowDetector::CapShortfall);
    CHECK(detector.observe(4000000,w)&WindowDetector::CapShortfall); // Helper flushes cannot hide missed paced frames.
    AudioLive audio;AudioSnapshot sample;sample.request_us=10;sample.service_us=9;sample.queued=2;sample.empty_polls=3;audio.publish(sample);
    AudioSnapshot observed;CHECK(audio.read(observed)&&observed.request_us==10&&observed.service_us==9&&observed.queued==2&&observed.empty_polls==3);
    LiveSnapshot initial;initial.bci=0;live.publish(initial);
    std::atomic<bool> done{false};std::thread writer([&]{for(uint64_t n=1;n<50000;++n){LiveSnapshot v;v.session=n;v.launch=n;v.bci=int(n);live.publish(v);}done=true;});
    while(!done.load()){LiveSnapshot v;if(live.read(v))CHECK(v.session==v.launch&&v.bci==int(v.session));}
    writer.join();
    std::cout<<"diagnostics_failures="<<failures<<"\n";return failures?1:0;
}
#endif
