// Build with -D__SWITCH__ -Itests/runtime_fit13/jit_mock.
// Uses the REAL pool/leaf engine and a controlled libnx API boundary.
// Each named scenario runs in a fresh process to isolate process-global pools.
#ifndef J2ME_TEST_JIT_HEADER
#define J2ME_TEST_JIT_HEADER "../../src/native_jit236.h"
#endif
#include J2ME_TEST_JIT_HEADER
#include "../jit_small_arena_fixture.h"
#include <iostream>
#include <string>
#include <vector>
#include <cstdlib>

static void check(bool ok, const char* message) {
    if (!ok) {
        const auto& s = jit236::code_pool_stats();
        std::cerr << "FAIL " << message << " result=" << jit236::Executable::last_result()
                  << " blocks=" << s.blocks << " slices=" << s.slices
                  << " quarantine=" << s.quarantined_pages << " releases=" << s.quarantine_releases
                  << " native_live=" << fit13_mock::live << " creates=" << fit13_mock::creates << '\n';
        std::exit(1);
    }
}
static constexpr size_t pages_per_block = jit236::CodeBlockBytes / jit236::CodePage;
static const uint8_t bytecode[] = {26, 4, 96, 172}; // (I)I: arg + 1; 4 bytecodes
static const std::string descriptor = "(I)I";
static jit236::Spec spec() { return {bytecode, sizeof(bytecode), &descriptor, 8, 1, 2, false, false, nullptr}; }
static std::vector<uint8_t> code(uint32_t id) {
    jit236::Program p; check(jit236::verify(spec(), p), "leaf fixture verifies");
    return jit236::emit_host(p, id);
}
static void install(jit236::Executable& e, jit236::InstallMode mode = jit236::InstallMode::Normal) {
    const auto id = jit236::next_install_id();
    check(e.install(code(id), id, mode), "fixture installs");
}
static uint64_t invoke(jit236::Executable& e, uint32_t expected) {
    int32_t args[jit236::StaleIdSlot + 1]{};
    args[0] = 41; args[jit236::StaleIdSlot] = static_cast<int32_t>(expected);
    const auto before = std::vector<int32_t>(args, args + jit236::StaleIdSlot + 1);
    uint64_t value;
    { jit236::CodeCall active;
#if defined(_WIN32) && defined(__x86_64__)
      // Production x64 emitter uses SysV; MinGW's default function ABI is MS.
      using HostFn = uint64_t (__attribute__((sysv_abi)) *)(const int32_t*);
      value = reinterpret_cast<HostFn>(e.fn)(args);
#else
      value = e.fn(args);
#endif
    }
    check(std::equal(before.begin(), before.end(), args), "leaf does not mutate arguments");
    return value;
}
static void runs(jit236::Executable& e) {
    check(e.executable(), "live slice remains executable");
    const auto r = invoke(e, e.id);
    check(uint32_t(r) == 42 && uint32_t(r >> 32) == 4, "live slice executes exact result and cost");
}
static void accounting() {
    const auto& s = jit236::code_pool_stats();
    check(s.blocks == fit13_mock::live, "pool block count matches owned native resources");
    check(s.blocks <= fit13_mock::limit && s.reserved_bytes <= jit236::CodePoolMaxBytes,
          "native and configured resource caps respected");
    check(s.used_bytes <= s.reserved_bytes, "live page accounting fits actual backing bytes");
}
static void cleanup() {
    check(!jit236::active_code_calls(), "cleanup is outside compiled execution");
    while (!jit236::code_quarantine().empty()) jit236::release_oldest_quarantine();
    jit236::dedicated_blocks().clear();
    check(!jit236::code_pool_stats().slices && !jit236::code_pool_stats().used_bytes &&
          !fit13_mock::live && !jit236::code_pool_stats().blocks && !jit236::code_pool_stats().reserved_bytes,
          "all test resources closed exactly once");
}
static void pressure_reuse() {
    fit13_mock::limit = 2;
    std::vector<jit236::Executable> live(2 * pages_per_block);
    for (auto& e : live) install(e);
    for (size_t i = 1; i < live.size(); i += 2) live[i].close();
    check(jit236::code_pool_stats().quarantined_pages == pages_per_block, "fixture retains retired pages below aging threshold");
    const unsigned attempts = fit13_mock::creates;
    jit236::Executable recovered; const auto id = jit236::next_install_id();
    check(recovered.install(code(id), id), "normal install recovers retired pages after native resource failure");
    check(fit13_mock::creates <= attempts + 2, "pressure recovery has bounded native allocation attempts");
    runs(recovered);
    const auto stale = invoke(recovered, recovered.id ^ 0x01010101u);
    check(jit236::stale_result(stale) && uint32_t(stale) == recovered.id,
          "reused code still rejects mismatched install id before executing");
    for (size_t i = 0; i < live.size(); i += 2) runs(live[i]);
    check(jit236::code_pool_stats().slices == pages_per_block + 1, "recovery preserves every healthy live slice");
    check(jit236::code_pool_stats().quarantine_releases > 0, "pressure makes retired backing reusable");
    accounting(); recovered.close(); live.clear(); cleanup();
}
static bool prepare(jit236::Engine& engine, jit236::Site& site) {
    bool ready = false;
    for (unsigned i = 0; i <= jit236::Engine::HotThreshold && !ready; ++i) ready = engine.prepare(site, spec());
    return ready;
}
static void reset_recovery() {
    // Keep every retired game page quarantined and leave an Engine entry for
    // the native-resource failure, rather than hitting the leaf entry budget.
    check(pages_per_block <= jit236::CodeQuarantinePages, "one ordinary arena fits in quarantine");
    fit13_mock::limit = 2;
    jit236::Executable selftest; install(selftest, jit236::InstallMode::Dedicated); selftest.close();
    jit236::Engine engine; engine.enabled = engine.available = true;
    std::vector<jit236::Site> sites(std::min(pages_per_block - 1, size_t(jit236::Engine::MaxEntries - 1)));
    for (auto& s : sites) check(prepare(engine, s), "first epoch fills every available game block");
    std::vector<jit236::Executable> fillers(pages_per_block - sites.size());
    for (auto& e : fillers) install(e);
    jit236::Site exhausted;
    check(!prepare(engine, exhausted) && engine.admission_closed, "initial resource shortage closes admission");
    check(jit236::Executable::last_result() == fit13_mock::OutOfResource, "initial failure preserves native result");
    const auto epoch = engine.epoch(); const auto old_site = sites.front();
    engine.clear();
    fillers.clear();
    check(engine.epoch() != epoch && !engine.admission_closed && !engine.bytes(), "reset clears epoch admission and live budget");
    check(jit236::code_pool_stats().quarantined_pages == pages_per_block && !jit236::code_pool_stats().slices &&
          jit236::code_pool_stats().blocks == fit13_mock::limit &&
          jit236::code_pool_stats().reserved_bytes == jit236::CodeBlockBytes + jit236::CodeDedicatedBytes,
          "all native resources remain retained with every game page quarantined and no live code");
    int32_t arg = 41, result = -7; unsigned ops = 0;
    check(!engine.call(old_site, &arg, 1, 100, result, ops) && result == -7 && ops == 0,
          "old epoch call cannot dereference retired executable");
    jit236::Site next; const unsigned attempts = fit13_mock::creates;
    check(prepare(engine, next), "second epoch recovers despite persistent native resource ceiling");
    check(!engine.admission_closed && engine.stats.compiled == 1 && engine.bytes() == jit236::CodePage,
          "recovery reopens real compilation and accounts one live page");
    check(fit13_mock::creates <= attempts + 2, "second epoch recovery does not spin allocations");
#ifndef _WIN32
    check(engine.call(next, &arg, 1, 100, result, ops) && result == 42 && ops == 4,
          "recovered engine executes exact Java result and bytecode cost");
#endif
    accounting(); engine.clear(); cleanup();
}
static void active_guard() {
    fit13_mock::limit = 1;
    jit236::Executable live, retired; install(live); install(retired); retired.close();
    const auto q = jit236::code_pool_stats().quarantined_pages;
    const unsigned attempts = fit13_mock::creates; auto fn = live.fn;
    { jit236::CodeCall active;
      check(!live.install(code(jit236::next_install_id())), "installation blocked while compiled call active");
      check(live.fn == fn && live.executable(), "active guard preserves existing executable"); }
    check(jit236::code_pool_stats().quarantined_pages == q && fit13_mock::creates == attempts,
          "active guard neither reclaims nor allocates");
    runs(live); accounting(); live.close(); cleanup();
}
static void fresh_guard() {
    fit13_mock::limit = 1;
    std::vector<jit236::Executable> live(pages_per_block); for (auto& e : live) install(e);
    live.back().close();
    jit236::Executable replacement; const auto id = jit236::next_install_id();
    const unsigned attempts = fit13_mock::creates;
    check(!replacement.install(code(id), id, jit236::InstallMode::Fresh),
          "fresh stale recovery never installs on a written page in a live block");
    check(fit13_mock::creates <= attempts + 2, "fresh failure is bounded");
    for (size_t i = 0; i < live.size() - 1; ++i) runs(live[i]);
    check(jit236::code_pool_stats().slices == live.size() - 1, "fresh failure retains all live peers");
    accounting(); live.clear(); cleanup();
}
static void no_resources() {
    fit13_mock::limit = 0;
    jit236::Executable e; const auto id = jit236::next_install_id();
    check(!e.install(code(id), id), "resource failure without reclaimable pages falls back");
    check(jit236::Executable::last_result() == fit13_mock::OutOfResource && fit13_mock::creates <= 2,
          "persistent failure retains error and terminates promptly");
    accounting(); cleanup();
}
static void retired_block_retry(bool persistent_failure) {
    fit13_mock::limit = 1;
    jit236::Executable retired; const auto old_id = jit236::next_install_id();
    auto arena = small_retry_arena(code(old_id));
    check(bool(arena), "small whole-mapping retry fixture allocates and publishes");
    auto large = code(old_id); large.resize(262144, 0);
    check(retired.install(large, old_id), "whole-block fixture installs");
    arena.reset();
    runs(retired); retired.close();
    // One quarantine entry owns the whole block. Releasing it destroys the
    // block before pick() can find any remaining free slot; creation must retry.
    if (persistent_failure) fit13_mock::forced_error = fit13_mock::OutOfResource;
    const unsigned attempts = fit13_mock::creates;
    jit236::Executable next; const auto id = jit236::next_install_id();
    const bool ok = next.install(code(id), id);
    check(fit13_mock::creates == attempts + 2,
          "whole retired block gets exactly one post-reclamation allocation retry");
    if (persistent_failure) {
        check(!ok && !next.executable() && jit236::Executable::last_result() == fit13_mock::OutOfResource,
              "failed bounded retry preserves native resource result");
        check(!fit13_mock::live && !jit236::code_pool_stats().slices,
              "failed retry does not invent a resource or live slice");
    } else {
        check(ok, "whole-block retirement permits bounded fresh allocation recovery");
        runs(next);
        check(jit236::Executable::last_result() == 0 && std::string(jit236::Executable::last_error()) == "none",
              "successful installation clears obsolete allocation failure");
    }
    accounting(); next.close(); cleanup();
}
static void nonresource_error() {
    fit13_mock::limit = 1;
    std::vector<jit236::Executable> live(pages_per_block); for (auto& e : live) install(e);
    live.back().close();
    const unsigned attempts = fit13_mock::creates;
    const auto releases = jit236::code_pool_stats().quarantine_releases;
    fit13_mock::forced_error = 0xd401; // InvalidCurrentMemory, not resource pressure
    jit236::Executable next; const auto id = jit236::next_install_id();
    check(!next.install(code(id), id) && jit236::Executable::last_result() == 0xd401,
          "nonresource native error remains visible");
    check(fit13_mock::creates == attempts + 1 &&
          jit236::code_pool_stats().quarantine_releases == releases,
          "nonresource error neither reclaims quarantine nor retries");
    for (size_t i = 0; i < live.size() - 1; ++i) runs(live[i]);
    accounting(); live.clear(); cleanup();
}
static void fresh_internal_cap() {
    fit13_mock::limit = static_cast<unsigned>(jit236::CodePoolMaxBlocks);
    std::vector<jit236::Executable> live(jit236::CodePoolMaxBlocks * pages_per_block);
    for (auto& e : live) install(e);
    live.back().close(); // retired written page still shares a block with peers
    const unsigned attempts = fit13_mock::creates;
    jit236::Executable replacement; const auto id = jit236::next_install_id();
    check(!replacement.install(code(id), id, jit236::InstallMode::Fresh),
          "internal-budget fallback must not give Fresh a written page");
    check(fit13_mock::creates == attempts,
          "internal cap never asks native allocator to exceed configured blocks");
    for (size_t i = 0; i < live.size() - 1; i += pages_per_block) runs(live[i]);
    runs(live[live.size() - 2]);
    check(jit236::code_pool_stats().slices == live.size() - 1,
          "Fresh cap fallback retains all healthy slices");
    accounting(); live.clear(); cleanup();
}
int main(int argc, char** argv) {
    if (argc != 2) { std::cerr << "scenario required: pressure reset active fresh empty retry retryfail nonresource freshcap\n"; return 2; }
    const std::string scenario = argv[1];
    if (scenario == "pressure") pressure_reuse();
    else if (scenario == "reset") reset_recovery();
    else if (scenario == "active") active_guard();
    else if (scenario == "fresh") fresh_guard();
    else if (scenario == "empty") no_resources();
    else if (scenario == "retry") retired_block_retry(false);
    else if (scenario == "retryfail") retired_block_retry(true);
    else if (scenario == "nonresource") nonresource_error();
    else if (scenario == "freshcap") fresh_internal_cap();
    else return 2;
    std::cout << "PASS " << scenario << " real_pool=1 libnx_mock=finite_resource_policy host="
              << jit236::architecture() << " dual_RW_RX_views=1 peak=" << fit13_mock::peak
              << " creates=" << fit13_mock::creates << " closes=" << fit13_mock::closes << '\n';
    return 0;
}
