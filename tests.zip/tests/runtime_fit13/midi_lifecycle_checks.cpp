// Synthetic SMF only: no game assets, backend, or frame scheduler required.
// Compile with -I<source>/src so this same test can exercise Fit12 and Fit13.
#ifdef _WIN32
// MinGW lacks this Linux diagnostic. No workers/core-affinity checks run here;
// the PCM engine and all lifecycle operations below are the real production code.
static inline int sched_getcpu() { return 0; }
#endif
#include "audio_engine.h"
#include <algorithm>
#include <functional>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

using Engine = j2me_audio::Engine;
using Bytes = std::vector<uint8_t>;
using PCM = std::vector<int16_t>;

// Read the existing private diagnostic for a hard global-polyphony invariant.
// Explicit member instantiation grants this narrowly scoped test access without
// changing Engine's layout, header, compilation flags, or runtime behavior.
struct VoiceCounterTag {
    using type = size_t (Engine::*)() const;
    friend type voiceCounter(VoiceCounterTag);
};
template <typename Tag, typename Tag::type Member> struct PrivateMember {
    friend typename Tag::type voiceCounter(Tag) { return Member; }
};
template struct PrivateMember<VoiceCounterTag, &Engine::activeVoices>;
static size_t runningVoices(const Engine& engine) {
    return (engine.*voiceCounter(VoiceCounterTag{}))();
}

static void require(bool ok, const std::string& why) {
    if (!ok) throw std::runtime_error(why);
}
static void be32(Bytes& bytes, uint32_t value) {
    for (int shift : {24, 16, 8, 0}) bytes.push_back(uint8_t(value >> shift));
}
static void vlq(Bytes& bytes, unsigned value) {
    uint8_t parts[4]; int count = 0;
    parts[count++] = uint8_t(value & 127);
    while ((value >>= 7)) parts[count++] = uint8_t((value & 127) | 128);
    while (count) bytes.push_back(parts[--count]);
}
static Bytes chord(unsigned notes = 32, unsigned durationTicks = 1920) {
    // SMF0, 96 ticks/quarter, default 500000us/quarter. Program40 sustains.
    Bytes track = {0, 0xc0, 40};
    for (unsigned n = 0; n < notes; ++n)
        track.insert(track.end(), {0, 0x90, uint8_t(48 + n), 70});
    vlq(track, durationTicks);
    track.insert(track.end(), {0xff, 0x2f, 0});
    Bytes bytes = {'M','T','h','d',0,0,0,6,0,0,0,1,0,96,'M','T','r','k'};
    be32(bytes, uint32_t(track.size()));
    bytes.insert(bytes.end(), track.begin(), track.end());
    return bytes;
}
static int load(Engine& engine, unsigned notes = 32, unsigned ticks = 1920) {
    std::string error;
    const int handle = engine.load(chord(notes, ticks), "audio/midi", error);
    require(handle > 0, "synthetic valid SMF load failed: " + error);
    return handle;
}
static PCM render(Engine& engine, size_t frames = 1024) {
    PCM pcm(frames * 2);
    engine.render(pcm.data(), frames);
    return pcm;
}
static bool audible(const PCM& pcm) {
    return std::any_of(pcm.begin(), pcm.end(), [](int16_t s) { return s != 0; });
}
static void stopped_tracks_do_not_exhaust_new_track() {
    // Break caught: counting voices retained by Prefetched players against
    // global polyphony makes the third newly loaded track permanently silent.
    Engine engine;
    for (int cycle = 0; cycle < 6; ++cycle) {
        const int handle = load(engine);
        require(engine.start(handle), "start chord");
        require(audible(render(engine)), "new track silent after stopped tracks; cycle=" + std::to_string(cycle));
        const auto position = engine.time(handle);
        require(engine.stop(handle), "stop chord");
        require(!audible(render(engine)), "stopped player still audible");
        require(engine.time(handle) == position, "stop advanced media time");
        require(engine.state(handle) == Engine::Prefetched, "stop changed lifecycle state");
    }
    require(engine.loadedPlayers() == 6 && engine.activePlayers() == 0, "stopped players should remain loaded");
}
static void stop_start_preserves_held_notes_and_position() {
    // Break caught: clearing voices on stop loses a long held note on restart.
    Engine paused, uninterrupted;
    const int a = load(paused, 1), b = load(uninterrupted, 1);
    require(paused.start(a) && uninterrupted.start(b), "start continuity tracks");
    require(render(paused) == render(uninterrupted), "reference initial PCM mismatch");
    const auto position = paused.time(a);
    require(paused.stop(a), "stop held note");
    for (int block = 0; block < 4; ++block) require(!audible(render(paused)), "stopped held note audible");
    require(paused.time(a) == position, "stop lost position");
    require(paused.start(a) && paused.time(a) == position, "restart rewound stopped player");
    const auto resumed = render(paused);
    require(audible(resumed) && resumed == render(uninterrupted), "stop/start lost held-note PCM continuity");
}
static void pause_resume_preserves_pcm_and_time() {
    Engine paused, uninterrupted;
    const int a = load(paused, 4), b = load(uninterrupted, 4);
    require(paused.start(a) && uninterrupted.start(b), "start pause tracks");
    require(render(paused) == render(uninterrupted), "pause reference mismatch");
    const auto position = paused.time(a);
    paused.pause(true);
    require(paused.paused() && !audible(render(paused, 4800)), "pause did not silence output");
    require(paused.time(a) == position && paused.state(a) == Engine::Started, "pause changed player time/state");
    paused.pause(false);
    require(render(paused) == render(uninterrupted), "pause/resume lost PCM continuity");
}
static void close_and_reset_release_voice_budget() {
    Engine engine;
    for (int cycle = 0; cycle < 80; ++cycle) {
        const int handle = load(engine);
        require(engine.start(handle) && audible(render(engine)), "close cycle lost output");
        require(engine.close(handle), "close failed");
        require(engine.state(handle) == Engine::Closed && !audible(render(engine)), "closed player audible");
    }
    const int handle = load(engine);
    require(engine.start(handle) && audible(render(engine)), "pre-reset output missing");
    engine.reset();
    require(!engine.loadedPlayers() && !engine.activePlayers() && !audible(render(engine)), "reset retained audio");
    const int next = load(engine);
    require(engine.start(next) && audible(render(engine)), "reset did not release budget");
}
static void restore_stopped_players_does_not_mute_started_player() {
    Engine original;
    for (int n = 0; n < 2; ++n) {
        const int handle = load(original);
        require(original.start(handle) && audible(render(original)), "restore seed output missing");
        require(original.stop(handle), "restore seed stop failed");
    }
    const int live = load(original, 1);
    require(original.start(live), "start restored live player");
    const auto saved = original.capture();
    Engine restored;
    require(restored.restore(saved) == 3, "restore dropped a player");
    require(restored.activePlayers() == 1 && restored.time(live) == 0, "restore lost player state/time");
    require(audible(render(restored)), "restored stopped voices muted live player");
}
static void finite_and_infinite_loops_keep_end_semantics() {
    Engine engine;
    const int handle = load(engine, 1, 96); // Exactly 24000 frames / 500000us.
    require(engine.duration(handle) == 500000, "fixture duration mismatch");
    require(engine.loop(handle, 2) && engine.start(handle), "start finite loop");
    render(engine, 24000);
    int ended = 0;
    require(engine.state(handle) == Engine::Started && !engine.pollEnd(ended), "finite loop ended early");
    render(engine, 24000);
    require(engine.state(handle) == Engine::Prefetched && engine.time(handle) == 500000, "finite loop did not finish");
    require(engine.pollEnd(ended) && ended == handle && !engine.pollEnd(ended), "finite loop end event incorrect");
    require(engine.loop(handle, -1) && engine.start(handle) && engine.time(handle) == 0, "restart finished player failed");
    require(audible(render(engine, 72000)), "infinite loop output silent");
    require(engine.state(handle) == Engine::Started && !engine.pollEnd(ended), "infinite loop emitted end");
}
static void running_voice_admission_remains_bounded() {
    // Two active 32-note chords fill the64-voice budget. New voices must not
    // be admitted into an empty third player until active budget is released.
    Engine engine;
    int left = load(engine), right = load(engine), extra = load(engine, 1);
    require(engine.start(left) && engine.start(right), "start full budget");
    render(engine);
    require(engine.start(extra), "start bounded extra player");
    // Mute the full-budget players without stopping them; this isolates the
    // third player's real PCM without freeing its allocation budget.
    require(engine.volume(left, 0) == 0 && engine.volume(right, 0) == 0, "mute budget tracks");
    require(!audible(render(engine)), "new player bypassed full running voice budget");
    require(engine.close(left) && engine.seek(extra, 0) == 0, "free and retry voice budget");
    require(audible(render(engine)), "new player remained silent after freeing running budget");
}
static Engine::SavedPlayer heldSnapshot(int handle, unsigned notes, int state) {
    Engine seed;
    const int loaded = load(seed, notes);
    require(seed.start(loaded) && audible(render(seed)), "held snapshot seed silent");
    auto saved = seed.capture().front();
    saved.handle = handle;
    saved.state = state;
    return saved;
}
static void resume_into_full_budget_preserves_time_and_other_players() {
    // A valid scene under stopped-player accounting:32 held stopped voices plus
    //64 currently playing voices. Resume must not revive all96 at once.
    Engine engine;
    const auto stopped = heldSnapshot(1, 32, Engine::Prefetched);
    const auto left = heldSnapshot(2, 32, Engine::Started);
    const auto right = heldSnapshot(3, 32, Engine::Started);
    require(engine.restore({stopped, left, right}) == 3, "restore resume edge fixture");
    const auto stoppedTime = engine.time(1);
    require(engine.start(1), "resume into full budget failed");
    require(engine.time(1) == stoppedTime, "budget admission rewound media time");
    require(runningVoices(engine) <= 64, "resume admitted more than64 running voices");
    require(audible(render(engine)), "resume silenced existing full-budget music");
    require(engine.state(2) == Engine::Started && engine.state(3) == Engine::Started,
            "resume disturbed already playing players");
}
static void resume_with_spare_budget_preserves_all_held_notes() {
    Engine engine, uninterrupted;
    const int held = load(engine, 16), reference = load(uninterrupted, 16);
    require(engine.start(held) && uninterrupted.start(reference), "start spare-budget reference");
    require(render(engine) == render(uninterrupted), "spare-budget reference mismatch");
    require(engine.stop(held), "stop spare-budget track");
    const auto stoppedTime = engine.time(held);
    const int other = load(engine, 32);
    require(engine.start(other) && audible(render(engine)), "spare-budget other track silent");
    require(engine.volume(other, 0) == 0, "mute spare-budget isolation track");
    require(engine.start(held) && engine.time(held) == stoppedTime, "spare-budget resume lost media position");
    require(runningVoices(engine) == 48, "spare-budget resume dropped held notes");
    require(render(engine) == render(uninterrupted), "spare-budget admission changed held-note PCM");
}
static void restore_respects_available_global_voice_budget() {
    // Temporary restore players are not in Engine::players_ during MIDI seek;
    // with63 voices already running, a final32-note player may admit only1.
    Engine engine;
    require(engine.restore({heldSnapshot(1, 31, Engine::Started),
                            heldSnapshot(2, 32, Engine::Started),
                            heldSnapshot(3, 32, Engine::Started)}) == 3,
            "restore over-budget fixture failed");
    require(runningVoices(engine) == 64, "restore bypassed64 running-voice limit");
    require(engine.time(3) == 21333 && engine.state(3) == Engine::Started,
            "restore admission changed media time/state");
    require(audible(render(engine)), "bounded restored music silent");
}
static void restore_stopped_after_full_budget_keeps_held_notes() {
    // Saved-player order must not destroy a stopped track's reconstructed held
    // notes merely because earlier restored Started players already use64.
    Engine engine;
    require(engine.restore({heldSnapshot(1, 32, Engine::Started),
                            heldSnapshot(2, 32, Engine::Started),
                            heldSnapshot(3, 16, Engine::Prefetched)}) == 3,
            "restore late stopped-player fixture failed");
    require(engine.state(3) == Engine::Prefetched && engine.time(3) == 21333,
            "restore changed late stopped player's state/time");
    require(engine.close(1) && engine.close(2), "free budget for late restored stopped track");
    const auto position = engine.time(3);
    require(engine.start(3) && engine.time(3) == position, "late restored resume rewound held note");
    require(runningVoices(engine) == 16, "restore lost stopped held notes behind full running budget");
    require(audible(render(engine)), "late restored held notes silent after freeing budget");
}
int main() {
    const std::vector<std::pair<const char*, std::function<void()>>> tests = {
        {"stopped_tracks_do_not_exhaust_new_track", stopped_tracks_do_not_exhaust_new_track},
        {"stop_start_preserves_held_notes_and_position", stop_start_preserves_held_notes_and_position},
        {"pause_resume_preserves_pcm_and_time", pause_resume_preserves_pcm_and_time},
        {"close_and_reset_release_voice_budget", close_and_reset_release_voice_budget},
        {"restore_stopped_players_does_not_mute_started_player", restore_stopped_players_does_not_mute_started_player},
        {"finite_and_infinite_loops_keep_end_semantics", finite_and_infinite_loops_keep_end_semantics},
        {"running_voice_admission_remains_bounded", running_voice_admission_remains_bounded},
        {"resume_into_full_budget_preserves_time_and_other_players", resume_into_full_budget_preserves_time_and_other_players},
        {"resume_with_spare_budget_preserves_all_held_notes", resume_with_spare_budget_preserves_all_held_notes},
        {"restore_respects_available_global_voice_budget", restore_respects_available_global_voice_budget},
        {"restore_stopped_after_full_budget_keeps_held_notes", restore_stopped_after_full_budget_keeps_held_notes},
    };
    int failed = 0;
    for (const auto& test : tests) {
        try { test.second(); std::cout << "PASS " << test.first << '\n'; }
        catch (const std::exception& e) { ++failed; std::cout << "FAIL " << test.first << ": " << e.what() << '\n'; }
    }
    std::cout << "midi lifecycle checks: " << tests.size() - size_t(failed) << '/' << tests.size() << " passed\n";
    return failed ? 1 : 0;
}
