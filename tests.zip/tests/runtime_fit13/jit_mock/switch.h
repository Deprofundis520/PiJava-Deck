#pragma once
// Test-only libnx boundary. The finite CodeMemory count is a MOCK POLICY,
// not a claim about Horizon's actual kernel resource limits.
// Keep separate RW and RX aliases; execute production-generated host code.
#include <cstdint>
#include <cstddef>
#include <cstdlib>
#ifdef _WIN32
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#else
#include <sys/mman.h>
#include <unistd.h>
#include <cstdio>
#endif

using Result = uint32_t;
#define R_FAILED(x) ((x) != 0)
#define R_SUCCEEDED(x) ((x) == 0)
enum JitType { JitType_SetProcessMemoryPermission, JitType_CodeMemory };
struct Jit {
    JitType type = JitType_CodeMemory;
    void* src_addr = nullptr;
    void* rx_addr = nullptr;
    void* rw_addr = nullptr;
    size_t size = 0;
    uintptr_t handle = 0;
    bool is_executable = false;
};
namespace fit13_mock {
constexpr Result OutOfResource = 0xce01;
inline unsigned limit = 10, live = 0, peak = 0, creates = 0, closes = 0;
inline uintptr_t next_handle = 1000;
inline unsigned writable = 0, executable = 0, dcache = 0, icache = 0;
inline Result forced_error = 0;
}
inline Result jitCreate(Jit* j, size_t size) {
    using namespace fit13_mock;
    ++creates;
    if (forced_error) return forced_error;
    if (live >= limit) return OutOfResource;
#ifdef _WIN32
    HANDLE h = CreateFileMappingW(INVALID_HANDLE_VALUE, nullptr, PAGE_EXECUTE_READWRITE,
                                 0, static_cast<DWORD>(size), nullptr);
    if (!h) std::abort();
    void* rw = MapViewOfFile(h, FILE_MAP_READ | FILE_MAP_WRITE, 0, 0, size);
    void* rx = MapViewOfFile(h, FILE_MAP_READ | FILE_MAP_EXECUTE, 0, 0, size);
    if (!rw || !rx) std::abort();
    const uintptr_t handle = reinterpret_cast<uintptr_t>(h);
#else
    FILE* file = std::tmpfile();
    if (!file || ftruncate(fileno(file), static_cast<off_t>(size))) std::abort();
    void* rw = mmap(nullptr, size, PROT_READ | PROT_WRITE, MAP_SHARED, fileno(file), 0);
    void* rx = mmap(nullptr, size, PROT_READ | PROT_EXEC, MAP_SHARED, fileno(file), 0);
    if (rw == MAP_FAILED || rx == MAP_FAILED) std::abort();
    fclose(file);
    const uintptr_t handle = ++next_handle; // opaque identity, not an OS handle
#endif
    *j = {JitType_CodeMemory, rw, rx, rw, size, handle, false};
    ++live; if (live > peak) peak = live;
    return 0;
}
inline Result jitTransitionToWritable(Jit* j) {
    ++fit13_mock::writable; j->is_executable = false; return 0;
}
inline Result jitTransitionToExecutable(Jit* j) {
    ++fit13_mock::executable; j->is_executable = true; return 0;
}
inline void* jitGetRwAddr(Jit* j) { return j->rw_addr; }
inline void* jitGetRxAddr(Jit* j) { return j->rx_addr; }
inline void armDCacheFlush(void* p, size_t n) {
    ++fit13_mock::dcache;
#ifdef _WIN32
    FlushInstructionCache(GetCurrentProcess(), p, n);
#else
    __builtin___clear_cache(static_cast<char*>(p), static_cast<char*>(p) + n);
#endif
}
inline void armICacheInvalidate(void* p, size_t n) {
    ++fit13_mock::icache;
#ifdef _WIN32
    FlushInstructionCache(GetCurrentProcess(), p, n);
#else
    __builtin___clear_cache(static_cast<char*>(p), static_cast<char*>(p) + n);
#endif
}
inline Result jitClose(Jit* j) {
    if (!j->rw_addr) std::abort();
#ifdef _WIN32
    UnmapViewOfFile(j->rw_addr); UnmapViewOfFile(j->rx_addr);
    CloseHandle(reinterpret_cast<HANDLE>(j->handle));
#else
    munmap(j->rw_addr, j->size); munmap(j->rx_addr, j->size);
#endif
    --fit13_mock::live; ++fit13_mock::closes; *j = {}; return 0;
}
