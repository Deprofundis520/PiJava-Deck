#define main emulator_main
#include "../src/j2mevm.cpp"
#undef main
#include "../src/chapter_save.h"
#include <cassert>
#include <filesystem>
int main(int argc,char** argv){assert(argc==6);const std::string root=argv[1];setenv("J2ME_RMS_DIR",root.c_str(),1);
 VMS_DIAG(g_log_draw)=false;VMS_CL(g_classpath)={argv[2],argv[3]};
 auto launch=[&](const std::string& jar){std::vector<uint8_t> bytes;assert(read_whole(jar,bytes));VMS_CL(g_jar_files).clear();VMS_CL(g_props).clear();std::string e;
 assert(unzip(bytes,VMS_CL(g_jar_files),e));load_props();launch_class(manifest_midlet(),rms_jar_identity(bytes.data(),bytes.size()),false);};
 auto invoke=[&](const std::string& method,int value=0){int cls=ensure_class("RmsIsolationChecks");bool put=method=="put";
 Method* m=find_method(cls,method,put?"(Ljava/lang/String;I)I":"(Ljava/lang/String;)I",false);assert(m);std::vector<Value> args={Value::of_ref(make_string("ChapterSave"))};if(put)args.push_back(Value::of_i(value));int result=run(m,args).i;assert(!VMS_EXEC(g_thrown));return result;};
 const auto a=chapter_save::jar_identity(argv[4]),b=chapter_save::jar_identity(argv[5]);assert(a!=b);
 launch(argv[4]);assert(invoke("put",73)==73);stop_thread();
 launch(argv[5]);assert(invoke("read")==-1);assert(invoke("put",19)==19);stop_thread();
 auto r=chapter_save::import_stores(root,a,b);assert(r.ok&&r.stores==1&&!r.backup.empty());
 launch(argv[5]);assert(invoke("read")==73);assert(invoke("put",99)==99);stop_thread();
 launch(argv[4]);assert(invoke("read")==73);stop_thread();
 // A third suite is still isolated, despite using identical Java classes and store name.
 launch_class("RmsIsolationChecks",std::string(64,'c'),false);assert(invoke("read")==-1);stop_thread();
 std::cout<<"PASS actual Java RecordStore: cross-JAR import reads source progress, target writes do not affect source, independent third suite stays isolated\n";
}
