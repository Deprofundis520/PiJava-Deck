#pragma once
#include <SDL.h>
#include <cstdint>
#include <cstddef>
// SDL owns only the output queue. The VM/mixer stays on its original thread.
namespace deck_audio {
inline SDL_AudioDeviceID device=0;
inline bool init() {
    SDL_AudioSpec want{}, have{};
    want.freq=48000; want.format=AUDIO_S16SYS; want.channels=2; want.samples=1024;
    device=SDL_OpenAudioDevice(nullptr,0,&want,&have,0);
    if(device) SDL_PauseAudioDevice(device,0);
    return device!=0;
}
inline void clear(){if(device)SDL_ClearQueuedAudio(device);}
inline void pause(bool value){if(device){SDL_PauseAudioDevice(device,value?1:0);clear();}}
inline void queue(const int16_t* pcm,size_t frames){
    if(!device)return;
    // Bound latency after a debugger stop, suspend, or slow frame.
    if(SDL_GetQueuedAudioSize(device)>48000*4/10)clear();
    SDL_QueueAudio(device,pcm,Uint32(frames*4));
}
inline void shutdown(){if(device)SDL_CloseAudioDevice(device);device=0;}
}
