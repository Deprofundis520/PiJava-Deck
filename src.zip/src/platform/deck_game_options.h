#pragma once
#include "deck_phone.h"
#include "deck_text.h"
#include "deck_custom_skin.h"
#include "deck_state.h"
#include "host_menu_settings.h"
#include <map>
#include <sstream>
namespace deck_game_options {
namespace fs=std::filesystem;
struct Resolution {int w,h;const char* label;};
inline constexpr std::array<Resolution,23> resolutions={{
    {0,0,"默认 / 游戏旁 .screen"},{128,128,"128x128 方屏"},{128,160,"128x160 竖屏"},
    {176,200,"176x200 竖屏"},{176,208,"176x208 竖屏"},{176,220,"176x220 竖屏"},
    {208,208,"208x208 方屏"},{240,260,"240x260 竖屏"},{240,320,"240x320 竖屏"},
    {320,240,"320x240 横屏"},{400,240,"400x240 横屏"},{480,320,"480x320 横屏"},
    {360,640,"360x640 竖屏"},{640,360,"640x360 横屏"},{640,480,"640x480 横屏"},
    {176,205,"176x205 竖屏"},{240,400,"240x400 竖屏"},{320,480,"320x480 竖屏"},
    {352,416,"352x416 竖屏"},{360,360,"360x360 方屏"},{480,800,"480x800 竖屏"},
    {800,480,"800x480 横屏"},{0,0,"自动识别游戏画布"}
}};
inline constexpr int automatic_resolution=22;
struct Options {int resolution=0,profile=0,rotation=0;std::string alias,skin;};
inline bool valid(Options o){return o.resolution>=0&&o.resolution<int(resolutions.size())&&o.rotation>=0&&o.rotation<4&&deck_phone::valid(o.profile)&&deck_text::units(o.alias)>=0&&deck_text::units(o.alias)<=64&&o.alias.find_first_of("\r\n\0",0,3)==std::string::npos&&(o.skin.empty()||deck_custom_skin::valid_id(o.skin));}
struct Store {
    fs::path root;
    struct Identity {uintmax_t bytes;fs::file_time_type time;std::string id;};
    std::map<fs::path,Identity> identities;
    std::string identity(const fs::path& jar){
        std::error_code ec;auto size=fs::file_size(jar,ec);if(ec)return {};
        auto time=fs::last_write_time(jar,ec);if(ec)return {};
        auto found=identities.find(jar);if(found!=identities.end()&&found->second.bytes==size&&found->second.time==time)return found->second.id;
        auto id=deck_state::identity(jar);if(!id.empty())identities[jar]={size,time,id};return id;
    }
    fs::path path(const std::string& id)const{
        if(id.size()!=64||id.find_first_not_of("0123456789abcdef")!=std::string::npos)return {};
        return root/(id+".cfg");
    }
    Options load(const std::string& id)const{
        std::ifstream f(path(id),std::ios::binary);std::string header,extra;Options o;
        if(!std::getline(f,header)||(header!="PIJAVA_DECK_GAME 1"&&header!="PIJAVA_DECK_GAME 2"&&header!="PIJAVA_DECK_GAME 3")||!(f>>o.resolution>>o.profile))return {};
        if(header=="PIJAVA_DECK_GAME 3"&&!(f>>o.rotation))return {};
        if(header!="PIJAVA_DECK_GAME 1"&&!(f>>std::quoted(o.alias)>>std::quoted(o.skin)))return {};
        if(!valid(o)||(f>>extra))return {};
        return o;
    }
    bool save(const std::string& id,Options o)const{
        if(!valid(o)||path(id).empty())return false;std::error_code ec;fs::create_directories(root,ec);if(ec)return false;
        std::ostringstream record;record<<"PIJAVA_DECK_GAME 3\n"<<o.resolution<<' '<<o.profile<<' '<<o.rotation<<'\n'<<std::quoted(o.alias)<<'\n'<<std::quoted(o.skin)<<'\n';
        return host_menu::save_record(path(id).string(),record.str());
    }
    // Separate records preserve the J2S5 wire format. Keying by snapshot bytes
    // also keeps an older .previous snapshot paired with its original profile.
    fs::path snapshot_path(const std::string& hash)const{
        if(path(hash).empty())return {};
        return root/"snapshot-phones"/(hash+".cfg");
    }
    bool save_snapshot(const fs::path& snapshot,deck_phone::Profile profile)const{
        const auto p=snapshot_path(deck_state::identity(snapshot));
        if(p.empty()||!deck_phone::valid(profile))return false;
        std::error_code ec;fs::create_directories(p.parent_path(),ec);if(ec)return false;
        return host_menu::save_record(p.string(),"PIJAVA_DECK_SNAPSHOT_PHONE 1\n"+std::to_string(int(profile))+"\n");
    }
    deck_phone::Profile load_snapshot(const std::string& hash,bool& recorded)const{
        std::ifstream f(snapshot_path(hash),std::ios::binary);std::string header,extra;int profile=-1;
        recorded=std::getline(f,header)&&header=="PIJAVA_DECK_SNAPSHOT_PHONE 1"&&(f>>profile)&&deck_phone::valid(profile)&&!(f>>extra);
        return recorded?static_cast<deck_phone::Profile>(profile):deck_phone::Standard;
    }
};
}
