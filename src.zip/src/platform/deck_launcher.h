#pragma once
#include <filesystem>
#include <fstream>
#include <string>
#include <vector>
#include "deck_games.h"
namespace deck_launcher {
namespace fs=std::filesystem;
inline bool valid_path(const fs::path& p){const auto s=p.string();return !s.empty()&&s.find_first_of("\r\n\t")==std::string::npos;}
inline std::string value(const std::string& s){std::string out;for(char c:s){if(c=='\\')out+="\\\\";else out+=c;}return out;}
inline std::string exec_path(const fs::path& path){
    // Exec arguments are quoted first, then escaped as Desktop Entry strings.
    std::string arg="\"";
    for(char c:path.string()){
        if(c=='%')arg+="%%";
        else{if(c=='\\'||c=='\"'||c=='$'||c=='`')arg+='\\';arg+=c;}
    }
    arg+='\"';return value(arg);
}
inline std::string desktop_entry(const fs::path& app){
    return "[Desktop Entry]\nVersion=1.0\nType=Application\nName=PiJava Emulator\nName[zh_CN]=PiJava 模拟器\nComment=Play Java mobile games\nComment[zh_CN]=启动 Java 手机游戏模拟器\nExec="+exec_path(app/"pijava-deck")+
        "\nPath="+value(app.string())+"\nIcon="+value((app/"icon.png").string())+"\nTerminal=false\nCategories=Game;Emulator;\nStartupNotify=false\nActions=AddToSteam;\n\n[Desktop Action AddToSteam]\nName=Add to Gaming Mode\nName[zh_CN]=添加到游戏模式\nExec="+exec_path(app/"pijava-deck")+" --add-to-steam\n";
}
inline bool install(const fs::path& source,const fs::path& data,const fs::path& desktop,std::string& error){
    const auto app=data/"pijava/app";std::error_code ec;
    if(!valid_path(app)||!valid_path(desktop)){error="安装路径含有不支持的换行或制表符";return false;}
    auto fail=[&](const std::string& step){error=step+"："+ec.message();return false;};
    fs::create_directories(app,ec);if(ec)return fail("无法创建程序目录");
    fs::create_directories(data/"applications",ec);if(ec)return fail("无法创建应用入口目录");
    fs::create_directories(desktop,ec);if(ec)return fail("无法创建桌面目录");
    fs::create_directories(data/"pijava/games",ec);if(ec)return fail("无法创建游戏目录");
    auto src=fs::weakly_canonical(source,ec);if(ec)return fail("无法读取程序路径");
    auto dst=fs::weakly_canonical(app,ec);if(ec)return fail("无法读取安装路径");
    if(src!=dst){
        for(const char* dir:{"romfs","licenses","games","state","skins"}){
            if(!fs::exists(source/dir,ec)){if(ec)return fail("无法读取资源");continue;}
            fs::copy(source/dir,app/dir,fs::copy_options::recursive|fs::copy_options::overwrite_existing,ec);
            if(ec)return fail(std::string("无法复制资源 ")+dir);
        }
        for(const char* name:{"icon.png","launch-steamdeck.sh","LICENSE","NOTICE.md","THIRD_PARTY.md","STEAMDECK.md","更新说明.md"}){
            if(!fs::is_regular_file(source/name,ec)){if(ec&&ec!=std::errc::no_such_file_or_directory)return fail("无法读取文件");ec.clear();continue;}
            fs::copy_file(source/name,app/name,fs::copy_options::overwrite_existing,ec);if(ec)return fail("无法复制程序文件");
        }
        // Publish a complete executable with an atomic rename; an old running
        // process can retain its inode. Save data is outside the app directory.
        const auto tmp=app/"pijava-deck.installing";
        fs::copy_file(source/"pijava-deck",tmp,fs::copy_options::overwrite_existing,ec);if(ec)return fail("无法复制模拟器");
        fs::permissions(tmp,fs::perms::owner_all|fs::perms::group_read|fs::perms::group_exec|fs::perms::others_read|fs::perms::others_exec,ec);if(ec)return fail("无法设置执行权限");
#ifdef _WIN32
        fs::copy_file(tmp,app/"pijava-deck",fs::copy_options::overwrite_existing,ec);
#else
        fs::rename(tmp,app/"pijava-deck",ec);
#endif
        if(ec)return fail("无法更新模拟器");
    }
    // Keep scanning the original portable games directory, including JARs
    // copied there after the desktop/Steam installation was created.
    if(src!=dst&&fs::is_directory(source/"games",ec)){
        if(!deck_games::save_root(data/"pijava/source-games.path",source/"games")){error="无法记录原游戏目录";return false;}
    }
    ec.clear();
    const auto record=desktop_entry(app);
    for(const auto& path:{data/"applications/pijava-deck.desktop",desktop/fs::u8path("PiJava 模拟器.desktop")}){
        std::ofstream out(path,std::ios::binary|std::ios::trunc);out<<record;out.close();
        if(!out){error="无法创建中文启动图标";return false;}
        fs::permissions(path,fs::perms::owner_all|fs::perms::group_read|fs::perms::group_exec|fs::perms::others_read|fs::perms::others_exec,ec);if(ec)return fail("无法设置启动图标权限");
    }
    return true;
}
}
