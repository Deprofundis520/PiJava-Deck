#pragma once
#include <cstdint>
#include <string>
#include <vector>
#include <algorithm>
namespace deck_steam {
inline uint32_t crc(const std::string& s){uint32_t c=0xffffffff;for(unsigned char b:s){c^=b;for(int i=0;i<8;++i)c=(c>>1)^(0xedb88320u&uint32_t(-int(c&1)));}return c^0xffffffff;}
inline void z(std::string& out,const std::string& s){out+=s;out+='\0';}
inline void obj(std::string& out,const std::string& k){out+='\0';z(out,k);}
inline void str(std::string& out,const std::string& k,const std::string& v){out+='\1';z(out,k);z(out,v);}
inline void num(std::string& out,const std::string& k,uint32_t v){out+='\2';z(out,k);for(int i=0;i<4;++i)out+=char(v>>(i*8));}
struct Entry {std::string key,exe,name;uint32_t appid=0;};
struct Reader {
    const std::string& bytes;size_t p=0;int fields=0;
    bool zero(std::string& out){size_t end=bytes.find('\0',p);if(end==std::string::npos||end-p>1024*1024)return false;out=bytes.substr(p,end-p);p=end+1;return true;}
    bool body(int depth,Entry* entry=nullptr){
        if(depth>32)return false;
        while(p<bytes.size()&&++fields<1000000){
            unsigned t=static_cast<unsigned char>(bytes[p++]);if(t==8)return true;
            std::string key;if(!zero(key))return false;
            if(t==0){if(!body(depth+1))return false;}
            else if(t==1){std::string v;if(!zero(v))return false;if(entry){std::string k=key;for(char& c:k)if(c>='A'&&c<='Z')c+=32;if(k=="exe")entry->exe=v;else if(k=="appname")entry->name=v;}}
            else if(t==2||t==3||t==4||t==6){
                if(bytes.size()-p<4)return false;
                if(entry&&key=="appid"){entry->appid=0;for(int i=0;i<4;++i)entry->appid|=uint32_t(static_cast<unsigned char>(bytes[p+i]))<<(i*8);}
                p+=4;
            }else if(t==7||t==10){if(bytes.size()-p<8)return false;p+=8;}
            else if(t==5){bool done=false;while(p+1<bytes.size()){if(bytes[p]==0&&bytes[p+1]==0){p+=2;done=true;break;}p+=2;}if(!done)return false;}
            else return false;
        }
        return false;
    }
};
inline bool parse(const std::string& bytes,std::vector<Entry>& entries,size_t& root_end){
    if(bytes.size()>64*1024*1024||bytes.empty())return false;
    Reader r{bytes};if(bytes[r.p++]!=0)return false;std::string root;if(!r.zero(root)||root!="shortcuts")return false;
    while(r.p<bytes.size()){
        if(static_cast<unsigned char>(bytes[r.p])==8){root_end=r.p++;if(r.p+1<bytes.size())return false;return r.p==bytes.size()||(r.p+1==bytes.size()&&bytes[r.p]==8);}
        if(bytes[r.p++]!=0||entries.size()>10000)return false;
        Entry entry;if(!r.zero(entry.key)||!r.body(1,&entry))return false;entries.push_back(entry);
    }
    return false;
}
inline bool add(const std::string& old,const std::string& executable,const std::string& directory,const std::string& icon,std::string& result,uint32_t& appid,bool& changed,std::string& error){
    changed=false;
    if(executable.find_first_of("\"\n\r")!=std::string::npos){error="程序路径包含不支持的字符";return false;}
    std::string base=old;
    if(base.empty()){obj(base,"shortcuts");base+='\10';base+='\10';}
    std::vector<Entry> entries;size_t end=0;
    if(!parse(base,entries,end)){error="Steam 快捷方式文件格式无法识别，已保留原文件";return false;}
    const std::string exe="\""+executable+"\"",name="PiJava 模拟器";
    unsigned next=0;
    for(const auto& e:entries){
        if(e.exe==exe||e.exe==executable){result=base;appid=e.appid;return true;}
        unsigned n=0;if(e.key.empty()||e.key.size()>5||e.key.find_first_not_of("0123456789")!=std::string::npos){error="Steam 快捷方式编号异常，已保留原文件";return false;}
        for(char c:e.key)n=n*10+unsigned(c-'0');next=std::max(next,n+1);
    }
    if(next>10000){error="Steam 快捷方式数量过多";return false;}
    appid=crc(exe+name)|0x80000000u;
    std::string record;obj(record,std::to_string(next));num(record,"appid",appid);str(record,"AppName",name);str(record,"Exe",exe);str(record,"StartDir","\""+directory+"\"");str(record,"icon",icon);str(record,"ShortcutPath","");str(record,"LaunchOptions","");
    num(record,"IsHidden",0);num(record,"AllowDesktopConfig",1);num(record,"AllowOverlay",1);num(record,"OpenVR",0);num(record,"Devkit",0);str(record,"DevkitGameID","");num(record,"DevkitOverrideAppID",0);num(record,"LastPlayTime",0);str(record,"FlatpakAppID","");obj(record,"tags");str(record,"0","PiJava");record+='\10';record+='\10';
    result=base.substr(0,end)+record+base.substr(end);changed=true;return true;
}
}
