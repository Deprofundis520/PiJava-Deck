#pragma once
#include <array>
// Profiles follow the user's j2me-nx-port switch-input.js KEY_PROFILES table.
// Physical bindings retain logical phone keys; only the game's wire codes vary.
namespace deck_phone {
enum Profile { Standard=0, NokiaKeyboard, Motorola, Count };
inline Profile active=Standard;
inline bool valid(int value){return value>=0&&value<Count;}
inline const char* name(int value){
    switch(value){case NokiaKeyboard:return "诺基亚横屏键盘";case Motorola:return "摩托罗拉";default:return "标准 / 诺基亚";}
}
inline constexpr std::array<int,12> digits={{49,50,51,52,53,54,55,56,57,42,48,35}};
inline constexpr std::array<int,12> letters={{114,116,121,102,103,104,118,98,110,117,109,106}};
inline int encode(int logical,Profile profile=active){
    if(profile==Motorola){if(logical==-6)return -21;if(logical==-7)return -22;if(logical==-5)return -20;}
    if(profile==NokiaKeyboard)for(unsigned i=0;i<digits.size();++i)if(logical==digits[i])return letters[i];
    return logical;
}
inline int canonical(int raw,Profile profile=active){
    if(profile==Motorola){if(raw==-21)return -6;if(raw==-22)return -7;if(raw==-20)return -5;}
    if(profile==NokiaKeyboard)for(unsigned i=0;i<letters.size();++i)if(raw==letters[i])return digits[i];
    return raw;
}
inline int action_code(int action){
    int logical=action==1?-1:action==6?-2:action==2?-3:action==5?-4:action==8?-5:
                action==9?49:action==10?51:action==11?55:action==12?57:0;
    // Preserve the legacy standard Canvas.getKeyCode values exactly.
    if(active==Standard)return action==8?8:action>=9&&action<=12?action:logical;
    return encode(logical);
}
}
