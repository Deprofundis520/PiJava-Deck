#pragma once
#include <array>
#include <cstdint>
namespace deck_ui_input {
enum Source { Keyboard, Dpad, Stick, SourceCount };
enum class CommandSource { Keyboard, Controller };
// Steam desktop bindings can deliver Escape/Enter alongside native pad events.
// Keep key edges across screen changes, and absorb a delayed echo after release.
class CommandGate {
    std::array<std::array<bool,512>,2> held_{};
    int last_source_=-1;
    int64_t last_press_=0;
public:
    void reset(){*this=CommandGate{};}
    void release(CommandSource source,int button){if(button>=0&&button<512)held_[int(source)][button]=false;}
    bool press(CommandSource source,int button,int64_t now){
        if(button<0||button>=512)return false;
        const int s=int(source);if(held_[s][button])return false;
        held_[s][button]=true;
        for(bool held:held_[1-s])if(held)return false;
        if(last_source_>=0&&last_source_!=s&&now>=last_press_&&now-last_press_<=200)return false;
        last_source_=s;last_press_=now;return true;
    }
};
// One logical navigation axis owns both edge presses and held repeats. Physical
// and Steam-emulated keyboard sources share that axis rather than each moving it.
class Axis {
    std::array<unsigned,SourceCount> held_{};
    int direction_=0,last_direction_=0,last_source_=-1;
    int64_t next_=0,last_press_=0;
    bool blocked_=false;
    static unsigned bit(int direction){return direction<0?1u:direction>0?2u:0u;}
    int held_direction()const{
        unsigned combined=0;for(unsigned h:held_)combined|=h;
        return combined==1?-1:combined==2?1:0;
    }
    bool neutral()const{for(unsigned h:held_)if(h)return false;return true;}
    int update(Source source,unsigned held,int64_t now){
        held_[source]=held;const int current=held_direction();
        if(!current){direction_=0;next_=0;if(neutral())blocked_=false;return 0;}
        if(blocked_){direction_=current;return 0;}
        if(direction_==current)return 0;
        direction_=current;next_=now+300;
        // A short tap can be delivered as keyboard down/up followed by gamepad
        // down/up in the same pump. Suppress only a matching cross-source echo;
        // two rapid presses from the same source remain two genuine presses.
        if(current==last_direction_&&last_source_>=0&&last_source_!=int(source)&&now>=last_press_&&now-last_press_<=60)return 0;
        last_direction_=current;last_source_=int(source);last_press_=now;return current;
    }
public:
    void reset(){*this=Axis{};}
    void block_until_release(){blocked_=!neutral();next_=0;}
    int button(Source source,int direction,bool down,int64_t now){
        const unsigned mask=bit(direction);if(!mask)return 0;
        return update(source,down?held_[source]|mask:held_[source]&~mask,now);
    }
    int stick(int value,int64_t now){
        const unsigned old=held_[Stick];int direction=0;
        if(value < -16000 || (old==1&&value < -11000))direction=-1;
        else if(value > 16000 || (old==2&&value > 11000))direction=1;
        return update(Stick,bit(direction),now);
    }
    int tick(int64_t now){
        if(blocked_||!direction_||!next_||now<next_)return 0;
        next_=now+80;return direction_;
    }
};
}
