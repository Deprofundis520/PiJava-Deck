#pragma once
#include <algorithm>
#include <string>
#include <vector>
namespace deck_text {
inline int next(const std::string& s,size_t& i){
    if(i>=s.size())return -1;unsigned a=static_cast<unsigned char>(s[i++]);if(a<128)return int(a);
    int count=a>=0xc2&&a<=0xdf?1:a>=0xe0&&a<=0xef?2:a>=0xf0&&a<=0xf4?3:0;if(!count||i+count>s.size())return -1;
    unsigned cp=a&((1u<<(6-count))-1);
    for(int j=0;j<count;++j){unsigned b=static_cast<unsigned char>(s[i++]);if((b&192)!=128)return -1;cp=(cp<<6)|(b&63);}
    if((count==1&&cp<128)||(count==2&&cp<2048)||(count==3&&cp<65536)||cp>0x10ffff||(cp>=0xd800&&cp<=0xdfff))return -1;
    return int(cp);
}
inline int units(const std::string& s){int n=0;for(size_t i=0;i<s.size();){int c=next(s,i);if(c<0)return -1;n+=c>65535?2:1;}return n;}
inline bool valid(const std::string& s,int constraints,bool final=true){
    const int mode=constraints&65535;if(mode!=2&&mode!=3&&mode!=5)return true;
    bool point=false;
    for(size_t i=0;i<s.size();++i){const char c=s[i];if(c>='0'&&c<='9')continue;
        if(mode==3&&(c=='+'||c=='*'||c=='#'||c==' '||c=='-'||c=='('||c==')'))continue;
        if(mode!=3&&c=='-'&&i==0&&(!final||s.size()>1))continue;
        if(mode==5&&c=='.'&&!point&&(!final||s.size()>1)){point=true;continue;}
        return false;
    }return true;
}
struct Editor {
    enum class Purpose { Rename,Game,Memory } purpose=Purpose::Rename;
    std::string value,composition,error,title;size_t caret=0;int selected=0,max_units=64,constraints=0;bool capitals=false,password=false,all_selected=false;
    bool numeric()const{int m=constraints&65535;return m==2||m==3||m==5;}
    std::vector<std::string> keys()const{
        std::vector<std::string> out;
        if(purpose==Purpose::Memory){for(char c:std::string("1234567890-"))out.push_back(std::string(1,c));return out;}
        if(numeric()){for(char c:std::string("1234567890-.*#+ ()"))out.push_back(std::string(1,c));return out;}
        for(char c=capitals?'A':'a';c<=(capitals?'Z':'z');++c)out.push_back(std::string(1,c));
        for(char c:std::string("1234567890 -_.,@/:?!*#\n'"))out.push_back(std::string(1,c=='\n'&&purpose==Purpose::Rename?'&':c));return out;
    }
    void begin(Purpose p,const std::string& initial,int maximum=64,int flags=0){
        *this=Editor{};purpose=p;value=initial;caret=value.size();max_units=maximum;constraints=flags;password=(flags&0x10000)!=0;
        title=p==Purpose::Rename?"修改游戏显示名":"游戏文字输入";
    }
    bool insert(const std::string& text){
        if(text.empty())return true;
        if(text.size()>65536){error="粘贴内容过长";return false;}
        if(purpose==Purpose::Rename)for(unsigned char c:text)if(c<32||c==127){error="名称不能包含换行或控制字符";return false;}
        for(unsigned char c:text)if(c==0){error="文字不能包含空字符";return false;}
        const size_t position=all_selected?0:caret;std::string proposed=all_selected?std::string{}:value;proposed.insert(position,text);const int n=units(proposed);
        if(n<0){error="输入不是有效的 UTF-8 文字";return false;}
        if(n>max_units||proposed.size()>65536){error="已达到输入框允许的最大长度";return false;}
        if(!valid(proposed,constraints,false)){error=purpose==Purpose::Memory?"内存修改只接受十进制整数":"此输入框只接受指定格式的数字或电话号码";return false;}
        value=std::move(proposed);caret=position+text.size();all_selected=false;composition.clear();error.clear();return true;
    }
    void move(int direction){
        if(all_selected){caret=direction<0?0:value.size();all_selected=false;composition.clear();return;}
        if(direction<0&&caret){--caret;while(caret&&(static_cast<unsigned char>(value[caret])&192)==128)--caret;}
        else if(direction>0&&caret<value.size()){size_t i=caret;next(value,i);caret=i;}
        composition.clear();error.clear();
    }
    void clear(){value.clear();caret=0;all_selected=false;composition.clear();error.clear();}
    void toggle_sign(){
        if(!value.empty()&&value[0]=='-'){value.erase(0,1);if(caret)--caret;}
        else{if(int(value.size())>=max_units){error="已达到输入长度限制";return;}value.insert(0,"-");++caret;}
        all_selected=false;composition.clear();error.clear();
    }
    void backspace(){if(all_selected){clear();return;}if(!caret)return;size_t end=caret;move(-1);value.erase(caret,end-caret);}
    void erase(){if(all_selected){clear();return;}if(caret>=value.size())return;size_t end=caret;next(value,end);value.erase(caret,end-caret);composition.clear();error.clear();}
    void select(int dx,int dy){
        int n=int(keys().size());if(dx)selected=(selected+dx+n)%n;
        if(dy){int col=selected%10,row=(selected/10+dy+(n+9)/10)%((n+9)/10);selected=std::min(row*10+col,n-1);}
    }
    std::string visible()const{
        std::string before=value.substr(0,caret),after=value.substr(caret);
        if(password){before=std::string(size_t(std::max(0,units(before))),'*');after=std::string(size_t(std::max(0,units(after))),'*');}
        // Keep the caret visible for long fields. The complete value is retained.
        size_t first=before.size()>32?before.size()-32:0;while(first<before.size()&&(static_cast<unsigned char>(before[first])&192)==128)++first;
        before=before.substr(first);size_t end=std::min<size_t>(after.size(),42);while(end<after.size()&&(static_cast<unsigned char>(after[end])&192)==128)++end;after.resize(end);
        std::string result=(first?"…":"")+before+"|"+after;
        for(char& c:result)if(c=='\n'||c=='\r'||c=='\t')c=' ';return result;
    }
};
}
