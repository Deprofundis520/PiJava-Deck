#pragma once
#include "deck_i18n.h"
#include "host_skin.h"
#include "host_menu_settings.h"
#include "host_speed.h"
#include "host_font.h"
#include "logical_screen.h"
#include "deck_keymap.h"
#include "deck_games.h"
#include "deck_game_options.h"
#include "deck_view.h"
#include <map>
// The original host menu and original skin assets, shared by SDL and test runner.
extern unsigned char font8x8_basic[128][8];
namespace deck_ui {
struct UI {
    host_menu::Settings settings;
    host_menu::Focus focus=host_menu::Focus::Games;
    host_skin::Cache skin;
    std::vector<uint32_t> pixels=std::vector<uint32_t>(1280*720);
    std::vector<uint32_t> chrome;
    int chrome_bezel=-1;
    deck_custom_skin::Meta custom_meta;
    host_skin::Pixels custom_image;
    void custom(const deck_custom_skin::Meta& meta,const host_skin::Pixels& image){custom_meta=meta;custom_image=image;chrome.clear();chrome_bezel=-1;}
    std::function<const uint8_t*(int)> cjk;
    host_font::Font font;
    std::vector<std::vector<uint8_t>> font_bytes;
    void load_fonts(){
        // Prefer the font explicitly supplied by the user, then trusted system fonts.
        const char* paths[]={"romfs/font/cjk.ttf","/usr/share/fonts/noto-cjk/NotoSansCJK-Regular.ttc","/usr/share/fonts/noto-cjk/NotoSansCJKsc-Regular.otf","/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc","/usr/share/fonts/TTF/DroidSansFallbackFull.ttf"};
        for(const char* path:paths){
            FILE* f=std::fopen(path,"rb");if(!f)continue;
            if(std::fseek(f,0,SEEK_END)!=0){std::fclose(f);continue;}long size=std::ftell(f);
            if(size<=0||size>64*1024*1024||std::fseek(f,0,SEEK_SET)!=0){std::fclose(f);continue;}
            std::vector<uint8_t> bytes(size_t(size),0);bool ok=std::fread(bytes.data(),1,bytes.size(),f)==bytes.size();std::fclose(f);
            if(ok){font_bytes.push_back(std::move(bytes));if(!font.add_font(font_bytes.back().data(),font_bytes.back().size()))font_bytes.pop_back();else if(std::string(path)=="romfs/font/cjk.ttf")return;}
        }
    }
    static int next(const std::string& s,size_t& i){
        unsigned c=static_cast<unsigned char>(s[i++]);if(c<128)return int(c);
        int n=c>=0xf0?3:c>=0xe0?2:c>=0xc0?1:0;
        unsigned cp=c&((1u<<(6-n))-1);
        if(!n||i+size_t(n)>s.size())return '?';
        while(n--){unsigned d=static_cast<unsigned char>(s[i++]);if((d&0xc0)!=0x80)return '?';cp=(cp<<6)|(d&63);}
        return int(cp);
    }
    void text(int x,int y,const std::string& source,uint32_t color,int size,int max_width){
        const std::string s=deck_i18n::tr(source);
        if(deck_i18n::english&&max_width>0){auto m=font.measure(s,size);if(m.ok&&m.advance>max_width)size=std::max(11,int(double(size)*max_width/m.advance));}
        if(size<=0||max_width<=0)return;
        if(font.draw(pixels.data(),1280,x,y,s,color,size,max_width,1280,720))return;
        const int right=std::min(1280,x+max_width);
        for(size_t i=0;i<s.size()&&x<right;){
            int cp=next(s,i);const uint8_t* bits=cp>=128&&cjk?cjk(cp):nullptr;
            const int sw=bits?16:8,sh=bits?16:8,w=cp>=128?size:std::max(1,size/2);
            for(int yy=0;yy<size;++yy)for(int xx=0;xx<w;++xx){
                int sx=xx*sw/w,sy=yy*sh/size;
                bool on=bits?(bits[sy*2+sx/8]&(0x80>>(sx%8))):((font8x8_basic[cp<128&&cp>=0?cp:'?'][sy]>>sx)&1);
                int px=x+xx,py=y+yy;
                if(on&&px>=0&&px<right&&py>=0&&py<720)pixels[size_t(py)*1280+px]=color;
            }
            x+=w;
        }
    }
    host_menu::Text text_callback(){return [this](int x,int y,const std::string& s,uint32_t c,int sz,int w){text(x,y,s,c,sz,w);};}
    void menu(const std::vector<std::string>& labels,int selection,const std::string& status,int speed,bool active,int64_t time,const std::vector<uint8_t>& saved={}){
        deck_i18n::begin_frame();for(const auto&label:labels)deck_i18n::protect(label);
        auto cb=text_callback();
        host_menu::render_menu(pixels.data(),1280,labels,selection,focus,settings,status,cb,{},host_speed::label(speed),saved, {},{},time,nullptr,false,true,true);
        // Replace the Switch-only shortcuts with actions implemented on Deck.
        host_menu::rect(pixels.data(),1280,48,628,840,72,host_menu::color(0xf3f3f3));
        text(48,640,"方向键 选择 / 切换选项   A 确认   L1/R1 翻页或调整",host_menu::color(0x696969),18,840);
        host_menu::rect(pixels.data(),1280,900,20,344,80,host_menu::color(0xf3f3f3));
        host_menu::rect(pixels.data(),1280,920,28,160,56,host_menu::color(0x343434));
        text(940,44,"设置管理",host_menu::color(0xffffff),24,130);
        host_menu::rect(pixels.data(),1280,1100,28,140,56,host_menu::color(0xd91526));
        text(1140,44,"关闭",host_menu::color(0xffffff),24,90);
        host_menu::rect(pixels.data(),1280,400,28,180,56,host_menu::color(0x343434));
        text(440,44,"游戏目录",host_menu::color(0xffffff),24,120);
        text(610,48,"v3.14",host_menu::color(0x696969),18,120);
        host_menu::rect(pixels.data(),1280,740,28,164,56,host_menu::color(0x343434));
        text(754,44,deck_i18n::english?"中文 / EN":"EN / 中文",host_menu::color(0xffffff),22,145);
        text(48,674,active?"L3 游戏目录   菜单键 设置   X 读档 B 返回当前游戏   Y 刷新   R3 全屏":"L3 游戏目录   菜单键 设置   X 读档   B 退出   Y 刷新   R3 全屏",host_menu::color(0x696969),18,840);
    }
    void game(const uint8_t* rgb,int w,int h,const std::string& fps){
        const int effective_bezel=w>h||!custom_image.empty()?0:settings.bezel;
        if(!custom_image.empty()){
            pixels=custom_image;const auto r=custom_meta.rect;host_menu::rect(pixels.data(),1280,r.x,r.y,r.w,r.h,host_menu::color(0));
        }
        else if(chrome_bezel!=effective_bezel||chrome.empty()){
            skin.select(effective_bezel,{},[](const char* name,host_skin::Pixels& out,std::string& error){
                std::string path=name;if(path.compare(0,7,"romfs:/")==0)path="romfs/"+path.substr(7);
                return host_skin::load_file(path.c_str(),out,error);
            });
            host_menu::render_bezel(pixels.data(),1280,effective_bezel,text_callback(),skin.data(),skin.size());
            chrome=pixels;chrome_bezel=effective_bezel;
        }else pixels=chrome;
        if(rgb&&logical_screen::valid(w,h)){
            const auto rect=custom_image.empty()?deck_view::fit(w,h,effective_bezel!=0&&effective_bezel!=j2me_present::adaptive_bezel):deck_custom_skin::fit(w,h,custom_meta.rect);
            display_filter::render(pixels.data()+size_t(rect.y)*1280+rect.x,1280,rgb,w,h,settings.filter,rect.w,rect.h);
        }
        if(settings.show_fps)host_menu::render_fps(pixels.data(),1280,effective_bezel,fps,text_callback());
        if(w<=h&&custom_image.empty()){
            host_menu::rect(pixels.data(),1280,1068,28,174,56,host_menu::color(0x343434));
            for(int y:{43,52,61})host_menu::rect(pixels.data(),1280,1082,y,22,3,host_menu::color(0xffffff));
            text(1120,44,"菜单",host_menu::color(0xffffff),24,110);
        }
    }
    static bool games_hit(int x,int y){return x>=400&&x<580&&y>=28&&y<84;}
    static bool close_hit(int x,int y){return x>=1100&&x<1240&&y>=28&&y<84;}
    static bool library_settings_hit(int x,int y){return x>=920&&x<1080&&y>=28&&y<84;}
    static bool menu_hit(int x,int y){return x>=1068&&x<1242&&y>=28&&y<84;}
    static bool point(int width,int height,int px,int py,int& x,int& y){
        if(width<=0||height<=0)return false;
        const double scale=std::min(double(width)/1280,double(height)/720);
        const double left=(width-1280*scale)/2,top=(height-720*scale)/2;
        if(px<left||py<top||px>=width-left||py>=height-top)return false;
        x=int((px-left)/scale);y=int((py-top)/scale);return true;
    }
    void pause_menu(int selected,const std::string& note={}){
        for(auto& c:pixels)c=0xff000000u|((c&0xfefefeu)>>1);
        host_menu::rect(pixels.data(),1280,326,120,628,550,host_menu::color(0xf3f3f3));
        text(360,142,"游戏内菜单 · v3.14",host_menu::color(0x262626),28,560);
        const char* options[]={"返回游戏","显示设置","保存即时存档","读取即时存档","返回游戏列表","结束当前游戏","文字输入","内存修改"};
        for(int i=0;i<8;++i){
            if(i==selected)host_menu::rect(pixels.data(),1280,350,180+i*48,580,46,host_menu::color(0xf4dddd));
            text(372,190+i*48,options[i],host_menu::color(i==selected?0xd91526:0x262626),24,530);
        }
        text(360,586,note.empty()?"读档会替换当前进度；退出前请先保存":note,host_menu::color(0x718094),18,560);
        text(360,630,"方向键选择   A 确认   B 返回游戏",host_menu::color(0x696969),18,560);
    }
    void settings_menu(int selected,int speed,bool active,const std::string& note,deck_game_options::Options options={},const std::string& target={},const std::string& skin_label={}){
        deck_i18n::begin_frame();
        std::fill(pixels.begin(),pixels.end(),host_menu::color(0xf3f3f3));
        host_menu::rect(pixels.data(),1280,0,0,1280,6,host_menu::color(0xd91526));
        text(80,56,"游戏设置与管理",host_menu::color(0x262626),36,900);
        text(80,108,target.empty()?"请先在列表选择游戏":deck_i18n::raw(target),host_menu::color(0x696969),20,930);
        text(1080,110,std::to_string(selected+1)+" / 11",host_menu::color(0x696969),18,130);
        const char* names[]={"遮罩","滤镜","速度","显示帧数","按键映射","游戏分辨率","手机机型","游戏改名","自定义遮罩","画面旋转","语言 / Language"};
        const std::string values[]={host_menu::bezel_name(settings.bezel),display_filter::name(settings.filter),host_speed::label(speed),settings.show_fps?"开启":"关闭","按 A 进入",deck_game_options::resolutions[size_t(options.resolution)].label,deck_phone::name(options.profile),options.alias.empty()?"使用原文件名":deck_i18n::raw(options.alias),options.skin.empty()?"使用内置遮罩":deck_i18n::raw(skin_label),host_menu::rotation_name(options.rotation),deck_i18n::english?"English":"简体中文"};
        const int first=std::max(0,selected-6);
        for(int row=0;row<7&&first+row<11;++row){
            const int i=first+row,y=160+row*54;
            host_menu::rect(pixels.data(),1280,80,y,1120,48,host_menu::color(i==selected?0xf4dddd:0xffffff));
            text(112,y+12,names[i],host_menu::color(i==selected?0xd91526:0x262626),28,320);
            text(520,y+12,values[i],host_menu::color(0x262626),28,550);
        }
        text(80,558,"分辨率和机型保存后，下次按 A 正常开始生效；X 读档保留存档尺寸",host_menu::color(0x696969),18,1120);
        text(80,598,note,host_menu::color(0x718094),20,1120);
        text(80,648,"上下滚动选择   左右调整 / A 进入   B / 菜单键返回",host_menu::color(0x696969),22,1120);
        host_menu::rect(pixels.data(),1280,1068,28,174,56,host_menu::color(0x343434));
        text(1110,44,"返回",host_menu::color(0xffffff),24,120);
    }
    void keymap_menu(const deck_keymap::Editor& editor,const std::string& note){
        deck_i18n::begin_frame();
        using namespace deck_keymap;
        std::fill(pixels.begin(),pixels.end(),host_menu::color(0xf3f3f3));
        host_menu::rect(pixels.data(),1280,0,0,1280,6,host_menu::color(0xd91526));
        text(64,36,"手机按键映射",host_menu::color(0x262626),32,1100);
        text(64,92,"方向固定使用左摇杆；选择手机键后按菜单键录入",host_menu::color(0x696969),20,1160);
        for(int i=0;i<int(editable_codes.size());++i){
            const int y=138+i*30;
            host_menu::rect(pixels.data(),1280,64,y,510,28,host_menu::color(i==editor.selected?0xf4dddd:0xffffff));
            text(80,y+4,name(editable_codes[size_t(i)]),host_menu::color(i==editor.selected?0xd91526:0x262626),20,235);
            text(314,y+5,bindings(editor.draft,editable_codes[size_t(i)]),host_menu::color(0x696969),18,248);
        }
        host_menu::rect(pixels.data(),1280,610,138,606,420,host_menu::color(0xffffff));
        text(642,166,std::string("当前手机键：")+name(editor.phone()),host_menu::color(0x262626),26,540);
        if(editor.phase==Phase::Capture){
            text(642,252,"请按下要映射的按键",host_menu::color(0xd91526),30,540);
            text(642,310,"十字键、A/B/X/Y、肩键、扳机、摇杆按下",host_menu::color(0x696969),18,540);
            text(642,354,"左摇杆方向固定保留，不参与录入",host_menu::color(0x696969),20,540);
            text(642,422,"再次按菜单键取消录入",host_menu::color(0x696969),20,540);
        }else if(editor.phase==Phase::Review){
            text(642,238,std::string("捕获到：")+physical_names[editor.candidate],host_menu::color(0xd91526),30,540);
            text(642,302,editor.released?"按 A 确认，按 B 重新录入":"请先松开捕获的按键，再按 A 确认",host_menu::color(0x696969),22,540);
            text(642,364,"确认后，按视图键保存全部修改",host_menu::color(0x696969),22,540);
            const int previous=editor.draft.code(editor.candidate);
            if(previous&&previous!=editor.phone())text(642,426,std::string("将替换原绑定：")+name(previous),host_menu::color(0x696969),20,540);
        }else{
            text(642,240,"已绑定：",host_menu::color(0x696969),22,540);
            text(642,284,bindings(editor.draft,editor.phone()),host_menu::color(0x262626),28,540);
            text(642,366,"按菜单键开始录入",host_menu::color(0xd91526),28,540);
            text(642,424,"录入后确认，最后按视图键保存",host_menu::color(0x696969),22,540);
        }
        text(64,614,note.empty()?(editor.dirty?"有未保存修改，请按视图键保存":"左侧已列出全部手机键，方向使用左摇杆"):note,host_menu::color(0x718094),20,1150);
        const char* help=editor.phase==Phase::Browse?"上下选择   菜单键录入   视图键保存   X 恢复默认   Y 清空映射   B 返回":editor.phase==Phase::Capture?"等待按键输入；菜单键取消本次录入":"A 确认   B 重新录入   菜单键取消";
        text(64,662,help,host_menu::color(0x696969),22,1150);
    }
    void folder_menu(const deck_games::Browser& browser){
        deck_i18n::begin_frame();
        std::fill(pixels.begin(),pixels.end(),host_menu::color(0xf3f3f3));
        host_menu::rect(pixels.data(),1280,0,0,1280,6,host_menu::color(0xd91526));
        text(48,34,browser.images?"选择遮罩图片":"选择游戏目录",host_menu::color(0x262626),32,1000);
        host_menu::rect(pixels.data(),1280,1068,28,174,56,host_menu::color(0x343434));
        text(1110,44,"返回",host_menu::color(0xffffff),24,120);
        text(48,88,deck_i18n::raw(browser.folder.u8string()),host_menu::color(0x696969),18,1184);
        const char* shortcuts[]={"桌面","用户主目录","存储卡位置",browser.images?"程序旁 skins":"程序旁 games"};
        for(int i=0;i<4;++i){host_menu::rect(pixels.data(),1280,48,152+i*70,250,56,host_menu::color(0xffffff));text(70,168+i*70,shortcuts[i],host_menu::color(0x262626),22,210);}
        int first=browser.selected/9*9;
        for(int row=0;row<9&&first+row<int(browser.items.size());++row){
            const int index=first+row,y=142+row*47;const auto& item=browser.items[size_t(index)];
            host_menu::rect(pixels.data(),1280,330,y,902,43,host_menu::color(index==browser.selected?0xf4dddd:0xffffff));
            const std::string name=browser.parent(index)?"返回上一级":item.path.filename().u8string();
            text(350,y+10,browser.parent(index)?name:deck_i18n::raw(name),host_menu::color(0x262626),22,710);
            text(1080,y+12,item.directory?"文件夹":item.game?(browser.images?"遮罩":"JAR"):"其他文件",host_menu::color(item.game?0x208351:0x696969),17,135);
        }
        text(48,590,browser.error.empty()?(browser.images?"请选择 PNG、JPG、JPEG 或 .skin 文件":"找到 .jar 后，可按 Y 读取当前目录（包含子目录）"):browser.error,host_menu::color(0x718094),20,1184);
        text(48,654,"上下选择  A 打开  左 返回上级  B 取消",host_menu::color(0x696969),20,770);
        host_menu::rect(pixels.data(),1280,890,638,342,56,host_menu::color(0xd91526));
        text(920,652,browser.images?"A 选择当前文件":"Y 读取此文件夹",host_menu::color(0xffffff),24,290);
    }
    void change(int direction){
        if(focus==host_menu::Focus::Bezel){
            int index=0;for(int i=0;i<host_menu::bezel_count;++i)if(host_menu::bezel_choices[size_t(i)]==settings.bezel)index=i;
            settings.bezel=host_menu::bezel_choices[size_t((index+(direction>0?1:host_menu::bezel_count-1))%host_menu::bezel_count)];
        }else if(focus==host_menu::Focus::Filter)host_menu::change_filter(settings,direction);
        else if(focus==host_menu::Focus::Fps)settings.show_fps=!settings.show_fps;
    }
    void text_menu(const deck_text::Editor& e){
        deck_i18n::begin_frame();
        std::fill(pixels.begin(),pixels.end(),host_menu::color(0xf3f3f3));
        text(80,40,e.title,host_menu::color(0x262626),32,1050);
        text(80,94,e.purpose==deck_text::Editor::Purpose::Rename?"只修改列表名称；名称留空恢复文件名":e.purpose==deck_text::Editor::Purpose::Memory?"输入十进制整数；菜单键确认，B 取消；超出类型范围不会写入":"编辑当前 TextBox / Form 输入框，完成后写入游戏",host_menu::color(0x696969),20,1120);
        host_menu::rect(pixels.data(),1280,80,136,1120,72,host_menu::color(e.all_selected?0xcddff5:0xffffff));
        text(96,158,deck_i18n::raw(e.visible()),host_menu::color(0x262626),28,1088);
        text(80,222,e.password?"密码输入：内容已隐藏":e.composition.empty()?(e.purpose==deck_text::Editor::Purpose::Memory?"请输入十进制整数，可粘贴数字；Steam + X 调出系统键盘":"支持系统输入法、中文粘贴；可用 Steam + X 调出系统键盘"):"输入法组合："+deck_i18n::raw(e.composition),host_menu::color(0x696969),20,1120);
        text(80,258,std::to_string(std::max(0,deck_text::units(e.value)))+" / "+std::to_string(e.max_units)+" 字符单位",host_menu::color(0x696969),18,1120);
        const auto keys=e.keys();
        for(int i=0;i<int(keys.size());++i){int x=80+i%10*112,y=296+i/10*52;
            host_menu::rect(pixels.data(),1280,x,y,106,46,host_menu::color(i==e.selected?0xf4dddd:0xffffff));
            std::string label=keys[size_t(i)]==" "?"空格":keys[size_t(i)]=="\n"?"换行":keys[size_t(i)];
            text(x+22,y+10,label,host_menu::color(i==e.selected?0xd91526:0x262626),24,90);
        }
        const char* buttons[]={"退格","清空",e.purpose==deck_text::Editor::Purpose::Memory?"正负号":"空格","完成","取消"};
        for(int i=0;i<5;++i){int x=80+i*224;host_menu::rect(pixels.data(),1280,x,572,212,44,host_menu::color(i==3?0xd91526:0x343434));text(x+55,582,buttons[i],host_menu::color(0xffffff),22,160);}
        text(80,630,e.error,host_menu::color(0xd91526),20,1120);
        text(80,674,e.purpose==deck_text::Editor::Purpose::Memory?"方向选数 A 输入   X 退格   Y 正负号   L1/R1 光标   视图键清空   ≡ 确认   B 取消":"方向选字 A 输入   X 退格   Y 大小写   L1/R1 光标   视图键清空   ≡ 完成   B 取消",host_menu::color(0x696969),18,1120);
    }
    void skins_menu(const std::vector<deck_custom_skin::Entry>& entries,int selected,const std::string& note){
        deck_i18n::begin_frame();
        std::fill(pixels.begin(),pixels.end(),host_menu::color(0xf3f3f3));
        text(64,40,"自定义遮罩",host_menu::color(0x262626),34,1000);
        host_menu::rect(pixels.data(),1280,1068,28,174,56,host_menu::color(0x343434));text(1110,44,"返回",host_menu::color(0xffffff),24,120);
        text(64,94,"为当前游戏选择遮罩；支持图片导入和窗口区域调整",host_menu::color(0x696969),20,1100);
        const int count=int(entries.size())+2,first=selected/8*8;
        for(int row=0;row<8&&first+row<count;++row){int i=first+row,y=142+row*52;
            host_menu::rect(pixels.data(),1280,64,y,1152,46,host_menu::color(i==selected?0xf4dddd:0xffffff));
            const std::string label=i==0?"使用内置遮罩（取消此游戏的自定义遮罩）":i==1?"导入图片…":deck_i18n::raw(entries[size_t(i-2)].name);
            text(88,y+10,label,host_menu::color(i==selected?0xd91526:0x262626),24,1100);
        }
        text(64,584,note,host_menu::color(0x718094),20,1152);
        text(64,630,"可把 PNG / JPG / .skin 放到程序旁 skins；也可在此页直接拖入图片",host_menu::color(0x696969),20,1152);
        text(64,674,"上下选择   A 预览 / 导入   Y 刷新   L1/R1 翻页   B / ≡ 返回",host_menu::color(0x696969),20,1152);
    }
    void skin_layout(const deck_custom_skin::Meta& meta,const host_skin::Pixels& image,int selected,const std::string& note){
        deck_i18n::begin_frame();
        std::fill(pixels.begin(),pixels.end(),host_menu::color(0xf3f3f3));
        text(48,36,"遮罩预览与游戏窗口",host_menu::color(0x262626),32,1100);text(48,90,deck_i18n::raw(meta.name),host_menu::color(0x696969),20,1100);
        if(image.size()==1280*720)for(int y=0;y<450;++y)for(int x=0;x<800;++x)pixels[size_t(y+154)*1280+x+48]=image[size_t(y*720/450)*1280+x*1280/800];
        const auto r=meta.rect;int x=48+r.x*800/1280,y=154+r.y*450/720,w=std::max(1,r.w*800/1280),h=std::max(1,r.h*450/720);
        host_menu::rect(pixels.data(),1280,x,y,w,h,host_menu::color(0x151e2c));
        host_menu::rect(pixels.data(),1280,x,y,w,3,host_menu::color(0xee3344));host_menu::rect(pixels.data(),1280,x,y+h-3,w,3,host_menu::color(0xee3344));
        host_menu::rect(pixels.data(),1280,x,y,3,h,host_menu::color(0xee3344));host_menu::rect(pixels.data(),1280,x+w-3,y,3,h,host_menu::color(0xee3344));
        const std::string labels[]={"左边距 X："+std::to_string(r.x),"上边距 Y："+std::to_string(r.y),"窗口宽度："+std::to_string(r.w),"窗口高度："+std::to_string(r.h),"应用并保存","取消"};
        for(int i=0;i<6;++i){int yy=154+i*64;host_menu::rect(pixels.data(),1280,884,yy,348,54,host_menu::color(i==selected?0xf4dddd:0xffffff));text(904,yy+15,labels[i],host_menu::color(i==selected?0xd91526:0x262626),22,310);}
        text(48,630,note.empty()?"红框内显示游戏，保持等比；框的位置使用 1280×720 坐标":note,host_menu::color(0x718094),20,1184);
        text(48,674,"上下选项   左右 8px   L1/R1 1px   X 默认   Y 全窗口   ≡ 应用   B 取消",host_menu::color(0x696969),19,1184);
    }

};
}
