#pragma once
#include <algorithm>
#include <cstdint>
namespace deck_view {
struct Rect {int x=0,y=0,w=0,h=0;};
// All game effects share this rectangle. Menus retain their 1280x720 UI space.
inline Rect fit(int w,int h,bool bezel){
    if(w<=0||h<=0)return {};
    Rect box=(w>h||!bezel)?Rect{0,0,1280,720}:Rect{400,40,480,640};
    Rect out=box;
    if(int64_t(box.w)*h<=int64_t(box.h)*w){out.h=std::max(1,int(int64_t(h)*box.w/w));out.y+=(box.h-out.h)/2;}
    else{out.w=std::max(1,int(int64_t(w)*box.h/h));out.x+=(box.w-out.w)/2;}
    return out;
}
}
