// Host-thread adapter. Never stores pointers into the Java heap or creates GC roots.
#include "deck_memory.h"
#include "deck_i18n.h"
namespace deck_memory_vm {
using namespace deck_memory;
static bool game_class(int cls){
    if(cls<0||size_t(cls)>=VMS_CL(g_classes).size())return false;const auto&n=VMS_CL(g_classes)[cls].name;
    if(n.compare(0,5,"java/")==0||n.compare(0,6,"javax/")==0||n.compare(0,5,"j2me/")==0||n.compare(0,4,"sun/")==0)return false;
    return VMS_CL(g_jar_files).count(n+".class")!=0;
}
static const Field* field(const Target&t){
    if(t.cls<0||size_t(t.cls)>=VMS_CL(g_classes).size())return nullptr;
    for(const auto&f:VMS_CL(g_classes)[t.cls].fields)if(f.owner==t.cls&&f.slot==t.slot&&f.is_static==(t.kind==Kind::Static)&&f.desc.size()==1&&f.desc[0]==char(t.type)&&!(f.flags&0x10))return &f;
    return nullptr;
}
static bool valid(const Target&t){
    if(t.epoch!=resver::g_epoch||t.slot<0)return false;
    if(t.kind==Kind::Static)return game_class(t.cls)&&field(t)&&VMS_CL(g_classes)[t.cls].init_state==2&&size_t(t.slot)<VMS_CL(g_classes)[t.cls].statics.size();
    ResourceKey k;k.epoch=t.epoch;k.slot=t.object;k.generation=t.generation;if(!resource_key_valid(k))return false;const auto&o=VMS_HEAP(g_heap)[t.object];
    if(t.kind==Kind::Array)return o.is_array&&o.array_desc==std::string("[")+char(t.type)&&o.elems.layout_version()==t.layout&&size_t(t.slot)<o.elems.size();
    if(!game_class(t.cls)||!field(t)||size_t(t.slot)>=o.fields.size())return false;
    for(int c=o.cls;c>=0;c=VMS_CL(g_classes)[c].super_id)if(c==t.cls)return true;return false;
}
static bool read(const Target&t,int64_t&n){
    if(!valid(t))return false;Value v=t.kind==Kind::Static?VMS_CL(g_classes)[t.cls].statics[t.slot]:t.kind==Kind::Array?VMS_HEAP(g_heap)[t.object].elems.get(t.slot):VMS_HEAP(g_heap)[t.object].fields[t.slot];
    n=t.type==Type::Long?v.l:v.i;return fits(t.type,n);
}
static bool write(const Target&t,int64_t n){
    if(!fits(t.type,n)||!valid(t))return false;Value v=t.type==Type::Long?Value::of_l(n):Value::of_i(int32_t(n));
    if(t.kind==Kind::Static)VMS_CL(g_classes)[t.cls].statics[t.slot]=v;
    else if(t.kind==Kind::Array)VMS_HEAP(g_heap)[t.object].elems.set(t.slot,v);
    else{auto&o=VMS_HEAP(g_heap)[t.object];if(o.indexed_key)++VMS_NATIVE(g_index_key_epoch);o.fields[t.slot]=v;}
    return true;
}
static bool plan(Type type,std::vector<Span>&out,std::string&error){
    auto append=[&](Target t,size_t count){if(out.size()>=Session::MaxSpans){error="可搜索对象过多，请更换类型";return false;}out.push_back({t,count});return true;};
    std::vector<std::vector<Target>> fields(VMS_CL(g_classes).size());size_t field_count=0;
    for(size_t c=0;c<VMS_CL(g_classes).size();++c)if(game_class(int(c))){
        for(auto&f:VMS_CL(g_classes)[c].fields)if(f.owner==int(c)&&!(f.flags&0x10)&&f.desc==std::string(1,char(type))){
            Target t;t.epoch=resver::g_epoch;t.cls=int(c);t.slot=f.slot;t.type=type;t.kind=f.is_static?Kind::Static:Kind::Field;
            if(f.is_static){if(VMS_CL(g_classes)[c].init_state==2&&!append(t,1))return false;}else{if(++field_count>Session::MaxSpans){error="字段过多，请更换类型";return false;}fields[c].push_back(t);}
        }
    }
    for(size_t r=1;r<VMS_HEAP(g_heap).size();++r){
        if(!gc_slot_live(int(r)))continue;const auto&o=VMS_HEAP(g_heap)[r];
        if(o.is_array){if(o.array_desc==std::string("[")+char(type)&&!o.elems.empty()){Target t;t.epoch=resver::g_epoch;t.object=int(r);t.generation=o.generation;t.kind=Kind::Array;t.type=type;t.layout=o.elems.layout_version();if(!append(t,o.elems.size()))return false;}}
        else for(int c=o.cls;c>=0;c=VMS_CL(g_classes)[c].super_id)for(auto t:fields[c]){t.object=int(r);t.generation=o.generation;if(!append(t,1))return false;}
    }return true;
}
static std::string describe(const Target&t){
    if(t.kind==Kind::Array)return deck_i18n::tr(type_name(t.type))+(deck_i18n::english?" array #":"数组 #")+std::to_string(t.object)+" ["+std::to_string(t.slot)+"]";
    const auto*f=field(t);if(!f)return "失效字段";
    return VMS_CL(g_classes)[t.cls].name+"."+f->name+(t.kind==Kind::Static?(deck_i18n::english?" (static)":"（静态）"):" #"+std::to_string(t.object));
}
static Backend backend(){return {[]{return resver::g_epoch;},read,write,plan,describe};}
}
