#pragma once
#include "deck_launcher.h"
#include "deck_i18n.h"
#include <SDL.h>
#include <cstdio>
#include <cstdlib>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
namespace deck_install {
namespace fs=std::filesystem;
inline int choice(const char* title,const std::string& message,const std::vector<std::pair<int,std::string>>& items){
    std::vector<std::pair<int,std::string>> localized;for(auto&i:items)localized.push_back({i.first,deck_i18n::tr(i.second)});
    const auto caption=deck_i18n::tr(title),body=deck_i18n::tr(message);
    std::vector<SDL_MessageBoxButtonData> buttons;
    for(const auto& item:localized)buttons.push_back({Uint32(item.first==0?SDL_MESSAGEBOX_BUTTON_ESCAPEKEY_DEFAULT:0),item.first,item.second.c_str()});
    SDL_MessageBoxData box{SDL_MESSAGEBOX_INFORMATION,nullptr,caption.c_str(),body.c_str(),int(buttons.size()),buttons.data(),nullptr};
    int pressed=0;if(SDL_ShowMessageBox(&box,&pressed)!=0)return 0;return pressed;
}
inline int message_box(Uint32 flags,const char*title,const char*message,SDL_Window*w){auto t=deck_i18n::tr(title),m=deck_i18n::tr(message);return SDL_ShowSimpleMessageBox(flags,t.c_str(),m.c_str(),w);}
inline pid_t spawn(const std::vector<std::string>& args){
    std::vector<char*> argv;for(const auto& s:args)argv.push_back(const_cast<char*>(s.c_str()));argv.push_back(nullptr);
    pid_t p=fork();if(p==0){execvp(argv[0],argv.data());_exit(127);}return p;
}
inline bool import_steam(const fs::path& home,const fs::path& app,std::string& message){
    // Use the same SteamOS entry point as Dolphin's Add to Steam action.
    // Steam owns its running shortcut list; do not replace that list on disk.
    const auto desktop=app.parent_path().parent_path()/"applications/pijava-deck.desktop";
    for(const char* helper:{"/usr/bin/steamos-add-to-steam","/usr/local/bin/steamos-add-to-steam"}){
        if(access(helper,X_OK)!=0)continue;
        const pid_t child=spawn({helper,desktop.string()});
        if(child<0){message="无法启动系统的添加到 Steam 工具";return false;}
        int status=0;pid_t result;
        do{result=waitpid(child,&status,0);}while(result<0&&errno==EINTR);
        if(result<0||!WIFEXITED(status)||WEXITSTATUS(status)!=0){message="系统未能提交添加请求。可在 Steam 的游戏菜单中选择添加非 Steam 游戏，勾选 PiJava 模拟器。";return false;}
        message="已向 Steam 提交 PiJava 模拟器的添加请求。请完成 Steam 可能显示的确认，然后在库中查看。";
        return true;
    }
    // Systems without the SteamOS helper use Steam's own add-game dialog.
    // This also allows Steam to start normally if it was not already running.
    std::vector<std::string> command={"steam","steam://addnonsteamgame"};
    std::error_code ec;
    if(access("/usr/bin/steam",X_OK)!=0&&fs::is_directory(home/".var/app/com.valvesoftware.Steam",ec))
        command={"flatpak","run","com.valvesoftware.Steam","steam://addnonsteamgame"};
    if(spawn(command)<0){message="无法打开 Steam 的添加非 Steam 游戏窗口";return false;}
    message="已请求打开 Steam 的添加非 Steam 游戏窗口。请勾选 PiJava 模拟器，再点添加所选程序。";
    return true;
}
inline int run(const fs::path& source,bool direct_import){
    SDL_Init(SDL_INIT_VIDEO);
    const char* h=std::getenv("HOME");const char* x=std::getenv("XDG_DATA_HOME");
    const fs::path home=h&&*h?h:".",data=x&&*x?fs::path(x):home/".local/share";
    int action=2;
    if(!direct_import)do{action=choice("PiJava v3.14 一键安装","请选择操作。安装到用户目录，保留已有游戏、存档和设置。",{{0,"关闭"},{1,"安装到桌面"},{2,"安装并添加到游戏模式"},{3,"English / 中文"}});if(action==3&&!deck_i18n::save(!deck_i18n::english)){message_box(SDL_MESSAGEBOX_ERROR,"PiJava 提示","语言保存失败",nullptr);}
    }while(action==3);
    if(action!=1&&action!=2){SDL_Quit();return 0;}
    std::string message;bool ok=deck_launcher::install(source,data,home/"Desktop",message);
    if(ok&&action==2)ok=import_steam(home,data/"pijava/app",message);
    else if(ok)message="桌面和应用菜单图标已创建。以后双击「PiJava 模拟器」启动即可。";
    message_box(ok?SDL_MESSAGEBOX_INFORMATION:SDL_MESSAGEBOX_ERROR,ok?"PiJava 操作完成":"PiJava 提示",message.c_str(),nullptr);
    SDL_Quit();return ok?0:1;
}
}
