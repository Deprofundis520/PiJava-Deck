#pragma once
#include "deck_state.h"
#include "deck_view.h"
#include "host_skin.h"
#include "host_menu_settings.h"
#include <iomanip>
#include <set>
#include <sstream>
namespace deck_custom_skin {
namespace fs=std::filesystem;
inline std::string extension(const fs::path& p){std::string e=p.extension().string();for(char& c:e)if(c>='A'&&c<='Z')c+=32;return e;}
inline bool supported(const fs::path& p){const auto e=extension(p);return e==".png"||e==".jpg"||e==".jpeg"||e==".skin";}
inline bool valid_id(const std::string& s){return s.size()>64&&s.substr(0,64).find_first_not_of("0123456789abcdef")==std::string::npos&&supported(fs::u8path(s))&&s.find_first_of("/\\") ==std::string::npos&&s.substr(64)==extension(fs::u8path(s));}
inline bool valid_rect(deck_view::Rect r){return r.x>=0&&r.y>=0&&r.w>=16&&r.h>=16&&r.x<=1280-r.w&&r.y<=720-r.h;}
struct Meta {std::string id,name;deck_view::Rect rect{400,40,480,640};};
struct Entry {fs::path path;std::string name,id;};
using Decoder=std::function<bool(const std::vector<uint8_t>&,std::vector<uint8_t>&,std::vector<uint8_t>&,int&,int&,std::string&)>;
struct Store {
    fs::path root,bundle;
    Meta meta(const std::string& id)const{
        Meta m;m.id=id;m.name="自定义遮罩";if(!valid_id(id))return m;
        std::ifstream f(root/(id+".cfg"),std::ios::binary);std::string h,extra,name;deck_view::Rect rect;
        if(std::getline(f,h)&&h=="PIJAVA_DECK_SKIN 1"&&(f>>rect.x>>rect.y>>rect.w>>rect.h>>std::quoted(name))&&valid_rect(rect)&&name.size()<=512&&!(f>>extra)){m.rect=rect;m.name=name;}
        return m;
    }
    bool save(const Meta& m)const{
        if(!valid_id(m.id)||!valid_rect(m.rect)||m.name.size()>512)return false;
        std::error_code ec;fs::create_directories(root,ec);if(ec)return false;std::ostringstream s;
        s<<"PIJAVA_DECK_SKIN 1\n"<<m.rect.x<<' '<<m.rect.y<<' '<<m.rect.w<<' '<<m.rect.h<<'\n'<<std::quoted(m.name)<<'\n';
        return host_menu::save_record((root/(m.id+".cfg")).string(),s.str());
    }
    static bool read(const fs::path& p,std::vector<uint8_t>& bytes,std::string& error){
        std::error_code ec;auto n=fs::file_size(p,ec);if(ec||!n||n>16*1024*1024){error="图片无法读取或超过 16 MiB";return false;}
        std::ifstream f(p,std::ios::binary);bytes.resize(size_t(n));if(!f.read(reinterpret_cast<char*>(bytes.data()),std::streamsize(n))){error="图片读取失败";return false;}return true;
    }
    static bool pixels(const fs::path& p,host_skin::Pixels& out,std::string& error,const Decoder& decode){
        if(extension(p)==".skin")return host_skin::load_file(p.string().c_str(),out,error);
        std::vector<uint8_t> bytes,rgb,alpha;int w=0,h=0;if(!read(p,bytes,error))return false;
        if(!decode(bytes,rgb,alpha,w,h,error)||w<1||h<1||w>4096||h>4096||rgb.size()!=size_t(w)*h*3||(!alpha.empty()&&alpha.size()!=size_t(w)*h)){error="图片解码失败："+error;return false;}
        out.assign(1280*720,0xff000000u);int dw=1280,dh=720,x=0,y=0;
        if(int64_t(w)*720>=int64_t(h)*1280){dh=std::max(1,int(int64_t(h)*1280/w));y=(720-dh)/2;}
        else{dw=std::max(1,int(int64_t(w)*720/h));x=(1280-dw)/2;}
        for(int yy=0;yy<dh;++yy)for(int xx=0;xx<dw;++xx){size_t src=size_t(int64_t(yy)*h/dh)*w+int64_t(xx)*w/dw;unsigned a=alpha.empty()?255:alpha[src];
            out[size_t(y+yy)*1280+x+xx]=0xff000000u|uint32_t(rgb[src*3]*a/255)|(uint32_t(rgb[src*3+1]*a/255)<<8)|(uint32_t(rgb[src*3+2]*a/255)<<16);
        }return true;
    }
    bool load(const std::string& id,Meta& m,host_skin::Pixels& out,std::string& error,const Decoder& decode)const{
        if(!valid_id(id)){error="遮罩标识无效";return false;}m=meta(id);return pixels(root/fs::u8path(id),out,error,decode);
    }
    bool import(const fs::path& p,Meta& m,host_skin::Pixels& out,std::string& error,const Decoder& decode)const{
        if(!supported(p)){error="请选择 PNG、JPG、JPEG 或原版 .skin 文件";return false;}
        if(!pixels(p,out,error,decode))return false;
        std::vector<uint8_t> bytes;if(!read(p,bytes,error))return false;
        rms_suite_identity_detail::Sha256 hash;hash.update(bytes.data(),bytes.size());std::string id=hash.finish()+extension(p);
        std::error_code ec;fs::create_directories(root,ec);if(ec){error="无法创建遮罩目录";return false;}
        if(!host_menu::save_record((root/fs::u8path(id)).string(),std::string(reinterpret_cast<const char*>(bytes.data()),bytes.size()))){error="遮罩复制失败";return false;}
        m=meta(id);if(m.name=="自定义遮罩")m.name=p.stem().u8string();
        if(!save(m)){error="遮罩名称记录保存失败";return false;}return true;
    }
    std::vector<Entry> list()const{
        std::vector<Entry> out;std::set<fs::path> seen;
        for(const auto& folder:{root,bundle}){std::error_code ec;fs::directory_iterator it(folder,ec),end;
            while(!ec&&it!=end&&out.size()<128){const auto p=it->path();if(it->is_regular_file(ec)&&supported(p)){
                auto key=fs::weakly_canonical(p,ec);if(!ec&&seen.insert(key).second){const auto id=p.filename().u8string();const bool installed=valid_id(id)&&folder==root;out.push_back({p,installed?meta(id).name:p.stem().u8string(),installed?id:std::string{}});}
            }ec.clear();it.increment(ec);}
        }std::sort(out.begin(),out.end(),[](const Entry&a,const Entry&b){return a.name<b.name;});return out;
    }
};
inline deck_view::Rect fit(int w,int h,deck_view::Rect box){
    if(w<=0||h<=0||!valid_rect(box))return {};
    auto r=box;if(int64_t(box.w)*h<=int64_t(box.h)*w){r.h=std::max(1,int(int64_t(h)*box.w/w));r.y+=(box.h-r.h)/2;}
    else{r.w=std::max(1,int(int64_t(w)*box.h/h));r.x+=(box.w-r.w)/2;}return r;
}
}
