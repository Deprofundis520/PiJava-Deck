#pragma once
namespace deck_navigation {
enum class Screen { Library, Game, Pause, Settings, Keymap, Folders, Text, Skins, SkinFiles, SkinLayout, Memory };
enum class Input { Menu, View, Back, Up, Down, Left, Right, Confirm, Resume, PageLeft, PageRight, Save, Reset, Close, OpenGames };
enum class Effect { None, Launch, Stop, Quit, SelectPrevious, SelectNext, PagePrevious, PageNext, ValuePrevious, ValueNext, OpenKeymap, MapPrevious, MapNext, SaveKeymap, ResetKeymap, CaptureKeymap, ConfirmKeymap, BackKeymap, OpenFolderBrowser, EnterFolder, UseFolder, ParentFolder, SaveInstant, RestoreInstant, OpenText, Rename, OpenSkins, ClearKeymap, OpenMemory };
struct State {
    Screen screen=Screen::Library,settings_return=Screen::Library;
    bool active=false;
    int pause_selection=0,option=0;
    bool frozen()const{return active&&screen!=Screen::Game;}
    void launched(){active=true;screen=Screen::Game;}
    void stopped(){active=false;screen=Screen::Library;pause_selection=0;}
    void settings(Screen from){settings_return=from;screen=Screen::Settings;option=0;}
    Effect input(Input key){
        if(key==Input::Close)return Effect::Quit;
        if(key==Input::OpenGames){screen=Screen::Folders;return Effect::OpenFolderBrowser;}
        if(key==Input::Menu){
            if(screen==Screen::Game){screen=Screen::Pause;pause_selection=0;}
            else if(screen==Screen::Pause)screen=Screen::Game;
            else if(screen==Screen::Settings)screen=settings_return;
            else if(screen==Screen::Keymap)return Effect::CaptureKeymap;
            else if(screen==Screen::Folders)screen=Screen::Library;
            else settings(Screen::Library);
            return Effect::None;
        }
        if(key==Input::View){
            if(screen==Screen::Folders){screen=Screen::Library;return Effect::None;}
            if(screen==Screen::Keymap)return Effect::SaveKeymap;
            if(screen==Screen::Library&&active)screen=Screen::Game;else screen=Screen::Library;
            return Effect::None;
        }
        if(key==Input::Resume){if(screen==Screen::Library)return Effect::RestoreInstant;if(active)screen=Screen::Game;return Effect::None;}
        if(key==Input::Back){
            if(screen==Screen::Folders){screen=Screen::Library;return Effect::None;}
            if(screen==Screen::Keymap)return Effect::BackKeymap;
            else if(screen==Screen::Settings)screen=settings_return;
            else if(screen==Screen::Pause)screen=Screen::Game;
            else if(screen==Screen::Game)screen=Screen::Pause;
            else if(active)screen=Screen::Game;else return Effect::Quit;
            return Effect::None;
        }
        const int direction=key==Input::Up?-1:key==Input::Down?1:0;
        if(screen==Screen::Folders){
            if(direction)return direction<0?Effect::SelectPrevious:Effect::SelectNext;
            if(key==Input::Confirm||key==Input::Right)return Effect::EnterFolder;
            if(key==Input::Left)return Effect::ParentFolder;
            if(key==Input::Save)return Effect::UseFolder;
            if(key==Input::PageLeft)return Effect::PagePrevious;
            if(key==Input::PageRight)return Effect::PageNext;
            return Effect::None;
        }
        if(screen==Screen::Pause){
            if(direction)pause_selection=(pause_selection+direction+8)%8;
            else if(key==Input::Confirm){
                if(pause_selection==0)screen=Screen::Game;
                else if(pause_selection==1)settings(Screen::Pause);
                else if(pause_selection==2)return Effect::SaveInstant;
                else if(pause_selection==3)return Effect::RestoreInstant;
                else if(pause_selection==4)screen=Screen::Library;
                else if(pause_selection==5)return Effect::Stop;
                else if(pause_selection==6)return Effect::OpenText;
                else return Effect::OpenMemory;
            }
            return Effect::None;
        }
        if(screen==Screen::Keymap){
            if(direction)return direction<0?Effect::SelectPrevious:Effect::SelectNext;
            if(key==Input::Confirm)return Effect::ConfirmKeymap;

            if(key==Input::Reset)return Effect::ResetKeymap;
            if(key==Input::Save)return Effect::ClearKeymap;
            return Effect::None;
        }
        if(screen==Screen::Settings){
            if(direction)option=(option+direction+11)%11;
            else if(option==4&&(key==Input::Confirm||key==Input::Right)){screen=Screen::Keymap;return Effect::OpenKeymap;}
            else if(option==7&&(key==Input::Confirm||key==Input::Right))return Effect::Rename;
            else if(option==8&&(key==Input::Confirm||key==Input::Right))return Effect::OpenSkins;
            else if(key==Input::Left||key==Input::PageLeft)return Effect::ValuePrevious;
            else if(key==Input::Right||key==Input::PageRight||key==Input::Confirm)return Effect::ValueNext;
            return Effect::None;
        }
        if(screen==Screen::Library){
            if(key==Input::Right){settings(Screen::Library);return Effect::None;}
            if(direction)return direction<0?Effect::SelectPrevious:Effect::SelectNext;
            if(key==Input::Confirm)return Effect::Launch;
            if(key==Input::PageLeft)return Effect::PagePrevious;
            if(key==Input::PageRight)return Effect::PageNext;
        }
        return Effect::None;
    }
};
}
