// Included inside namespace deck after the host navigation/launch helpers.
static bool tool_screen(){using S=deck_navigation::Screen;return navigation.screen==S::Memory||navigation.screen==S::Text||navigation.screen==S::Skins||navigation.screen==S::SkinFiles||navigation.screen==S::SkinLayout;}
static void tool_screen(deck_navigation::Screen screen){auto before=navigation.screen;navigation.screen=screen;sync_navigation(before);}
static bool skin_decode(const std::vector<uint8_t>& b,std::vector<uint8_t>& rgb,std::vector<uint8_t>& alpha,int& w,int& h,std::string& error){
    if(b.size()>2&&b[0]==255&&b[1]==216)return j2me_image::decode_jpeg(b,rgb,alpha,w,h,error,4096);
    return decode_png(b,rgb,alpha,w,h,error);
}
static void apply_custom_skin(const deck_game_options::Options& options){
    deck_custom_skin::Meta meta;host_skin::Pixels image;std::string error;
    if(!options.skin.empty()&&!custom_skins.load(options.skin,meta,image,error,skin_decode)){
        status="自定义遮罩无法读取，已使用内置显示："+error;log_line("CUSTOMSKIN fallback id="+options.skin+" reason="+error);
    }ui.custom(meta,image);
}
static void relabel(){
    labels.clear();for(const auto& p:games){const auto o=game_options.load(game_options.identity(p));labels.push_back(o.alias.empty()?p.filename().u8string():o.alias);}
}
static int object_field(int ref,const char* name,const char* descriptor,bool reference=false){
    if(ref<=0||size_t(ref)>=VMS_HEAP(g_heap).size()||VMS_HEAP(g_heap)[ref].cls<0)return 0;
    const Field* f=find_field(VMS_HEAP(g_heap)[ref].cls,name,descriptor);if(!f||f->slot<0||size_t(f->slot)>=VMS_HEAP(g_heap)[ref].fields.size())return 0;
    return reference?VMS_HEAP(g_heap)[ref].fields[f->slot].ref:VMS_HEAP(g_heap)[ref].fields[f->slot].i;
}
static int current_text_field(){
    if(!in_game||VMS_RS(g_current)<=0)return 0;int current=VMS_RS(g_current),field=0;
    if(type_compatible(current,"javax/microedition/lcdui/TextBox"))field=object_field(current,"field","Ljavax/microedition/lcdui/TextField;",true);
    else if(type_compatible(current,"javax/microedition/lcdui/Form")){
        int items=object_field(current,"items","[Ljavax/microedition/lcdui/Item;",true),focus=object_field(current,"focus","I"),count=object_field(current,"count","I");
        if(items>0&&size_t(items)<VMS_HEAP(g_heap).size()&&focus>=0&&focus<count&&size_t(focus)<VMS_HEAP(g_heap)[items].elems.size())field=VMS_HEAP(g_heap)[items].elems.get(size_t(focus)).ref;
    }
    return field>0&&size_t(field)<VMS_HEAP(g_heap).size()&&type_compatible(field,"javax/microedition/lcdui/TextField")?field:0;
}
static void append_scalar(std::string& out,int c){
    if(c<128)out+=char(c);else if(c<2048){out+=char(192|(c>>6));out+=char(128|(c&63));}
    else if(c<65536){out+=char(224|(c>>12));out+=char(128|((c>>6)&63));out+=char(128|(c&63));}
    else{out+=char(240|(c>>18));out+=char(128|((c>>12)&63));out+=char(128|((c>>6)&63));out+=char(128|(c&63));}
}
static std::string from_vm_text(const std::string& text){
    std::string out;for(size_t i=0;i<text.size();){int c=utf8_next(text,i);
        if(c>=0xd800&&c<=0xdbff){size_t j=i;int low=utf8_next(text,j);if(low>=0xdc00&&low<=0xdfff){c=65536+((c-0xd800)<<10)+low-0xdc00;i=j;}else c=0xfffd;}
        else if(c>=0xdc00&&c<=0xdfff)c=0xfffd;append_scalar(out,c);
    }return out;
}
static std::string to_vm_text(const std::string& text){
    std::string out;for(size_t i=0;i<text.size();){int c=deck_text::next(text,i);if(c>65535){c-=65536;utf8_append(out,0xd800|(c>>10));utf8_append(out,0xdc00|(c&1023));}else utf8_append(out,c);}return out;
}
static void open_rename(){
    if(editing_identity.empty()){status="请先选择游戏";return;}
    text_editor.begin(deck_text::Editor::Purpose::Rename,editing_options.alias.empty()?editing_path.stem().u8string():editing_options.alias);
    text_return=deck_navigation::Screen::Settings;tool_screen(deck_navigation::Screen::Text);
}
static void open_game_text(){
    int field=current_text_field();if(!field){status="当前未选中标准输入框；TextBox 或 Form 的文字框才可编辑";return;}
    const int constraints=object_field(field,"constraints","I"),maximum=object_field(field,"maxSize","I");
    if(constraints&0x20000){status="此文字框只读，不能修改";return;}
    std::string initial=from_vm_text(read_string(object_field(field,"text","Ljava/lang/String;",true)));
    if(maximum<=0||initial.size()>65536||deck_text::units(initial)>16384){status="此输入框过大，无法在宿主编辑器中编辑";return;}
    text_editor.begin(deck_text::Editor::Purpose::Game,initial,std::min(maximum,16384),constraints);
    int caret=object_field(field,"caret","I"),units=0;size_t i=0;
    while(i<initial.size()&&units<caret){int c=deck_text::next(initial,i);units+=c>65535?2:1;}text_editor.caret=i;
    text_target=field;text_owner=VMS_RS(g_current);text_generation=VMS_HEAP(g_heap)[field].generation;
    text_return=deck_navigation::Screen::Pause;tool_screen(deck_navigation::Screen::Text);
}
static void submit_text(){
    auto& e=text_editor;
    if(e.purpose==deck_text::Editor::Purpose::Memory){if(!e.composition.empty()){e.error="请先完成输入法选字";return;}if(memory_panel.submit(memory,e.value,e.error))tool_screen(deck_navigation::Screen::Memory);return;}
    if(!e.composition.empty()){e.error="请先完成输入法选字";return;}
    int count=deck_text::units(e.value);if(count<0||count>e.max_units||!deck_text::valid(e.value,e.constraints)){e.error="文字长度或内容不符合此输入框要求";return;}
    if(e.purpose==deck_text::Editor::Purpose::Rename){
        auto options=editing_options;options.alias=e.value;const auto first=options.alias.find_first_not_of(' ');
        if(first==std::string::npos)options.alias.clear();else options.alias=options.alias.substr(first,options.alias.find_last_not_of(' ')-first+1);
        if(!game_options.save(editing_identity,options)){e.error="名称保存失败，请检查用户目录权限";return;}
        editing_options=options;relabel();tool_screen(text_return);status=options.alias.empty()?"已恢复原文件名显示":"游戏显示名已保存；原 JAR 和存档关联保持不变";return;
    }
    if(!in_game||text_owner!=VMS_RS(g_current)||text_target!=current_text_field()||VMS_HEAP(g_heap)[text_target].generation!=text_generation){e.error="游戏输入框已经变化，请取消后重新打开";return;}
    const int maximum=object_field(text_target,"maxSize","I"),constraints=object_field(text_target,"constraints","I");
    if((constraints&0x20000)||count>maximum||!deck_text::valid(e.value,constraints)){e.error="输入框当前不接受这些文字";return;}
    const std::string value=to_vm_text(e.value);const int caret=deck_text::units(e.value.substr(0,e.caret));int target=text_target;bool changed=read_string(object_field(target,"text","Ljava/lang/String;",true))!=value;
    // Return to the live VM before normal Java callbacks; target is still held by
    // the current TextBox/Form, and run() roots the setter's arguments.
    tool_screen(deck_navigation::Screen::Game);
    if(changed){Method* set=find_method(VMS_HEAP(g_heap)[target].cls,"setString","(Ljava/lang/String;)V",true);
        if(!set)die("TextField.setString missing");run_event_callback(set,{Value::of_ref(target),Value::of_ref(make_string(value))});
    }
    if(read_string(object_field(target,"text","Ljava/lang/String;",true))==value){
        if(const Field* f=find_field(ensure_class("javax/microedition/lcdui/TextField"),"caret","I"))VMS_HEAP(g_heap)[target].fields[f->slot]=Value::of_i(caret);
    }
    if(changed){
        const int owner=object_field(target,"owner","Ljavax/microedition/lcdui/Displayable;",true);
        if(owner>0&&type_compatible(owner,"javax/microedition/lcdui/Form")){
            Method* notify=find_method(VMS_HEAP(g_heap)[target].cls,"notifyStateChanged","()V",true);if(notify)run_event_callback(notify,{Value::of_ref(target)});
        }
    }
    status="文字已写入游戏输入框";VMS_RS(g_fb_dirty)=true;
}
static void refresh_skins(){skin_entries=custom_skins.list();skin_selection=std::min(skin_selection,int(skin_entries.size())+1);}
static void open_skins(){if(editing_identity.empty()){status="请先选择游戏";return;}refresh_skins();skin_selection=0;tool_screen(deck_navigation::Screen::Skins);status.clear();}
static void skin_preview(const deck_custom_skin::Entry& entry){
    std::string error;host_skin::Pixels image;deck_custom_skin::Meta meta;
    bool ok=entry.id.empty()?custom_skins.import(entry.path,meta,image,error,skin_decode):custom_skins.load(entry.id,meta,image,error,skin_decode);
    if(!ok){status=error;return;}skin_draft=std::move(meta);skin_draft_image=std::move(image);skin_layout_selection=0;tool_screen(deck_navigation::Screen::SkinLayout);status.clear();
}
static void apply_skin(){
    auto next=editing_options;next.skin=skin_draft.id;
    if(!custom_skins.save(skin_draft)||!game_options.save(editing_identity,next)){status="遮罩或游戏设置保存失败，请检查空间和权限";return;}
    editing_options=next;editing_skin_name=skin_draft.name;
    if(in_game&&game_options.identity(active_path)==editing_identity)ui.custom(skin_draft,skin_draft_image);
    skin_draft_image.clear();tool_screen(deck_navigation::Screen::Settings);status="自定义遮罩已保存并应用；同一遮罩的窗口配置共用";
}
static void skin_adjust(int amount){
    auto& r=skin_draft.rect;switch(skin_layout_selection){
    case 0:r.x=std::clamp(r.x+amount,0,1280-r.w);break;case 1:r.y=std::clamp(r.y+amount,0,720-r.h);break;
    case 2:r.w=std::clamp(r.w+amount,16,1280-r.x);break;case 3:r.h=std::clamp(r.h+amount,16,720-r.y);break;default:break;
    }
}
static void memory_input(deck_navigation::Input key){
    using namespace deck_navigation;
    auto route=memory_panel.input(memory,key);
    if(route==deck_memory::Route::Pause)tool_screen(Screen::Pause);
    else if(route==deck_memory::Route::Game)tool_screen(Screen::Game);
    else if(route==deck_memory::Route::Editor){
        text_editor.begin(deck_text::Editor::Purpose::Memory,memory_panel.prompt_value(memory),20,2);text_editor.title=std::string(memory_panel.prompt_title())+" · "+deck_memory::type_name(memory_panel.prompt_type(memory));text_editor.all_selected=!text_editor.value.empty();
        text_return=Screen::Memory;tool_screen(Screen::Text);
    }
}
static void tool_input(deck_navigation::Input key){
    using namespace deck_navigation;
    if(navigation.screen==Screen::Memory){memory_input(key);return;}
    if(navigation.screen==Screen::Text){
        auto& e=text_editor;
        if(key==Input::Up)e.select(0,-1);else if(key==Input::Down)e.select(0,1);else if(key==Input::Left)e.select(-1,0);else if(key==Input::Right)e.select(1,0);
        else if(key==Input::Confirm){const auto keys=e.keys();e.insert(keys[size_t(e.selected)]);}
        else if(key==Input::Reset)e.backspace();else if(key==Input::Save){if(e.purpose==deck_text::Editor::Purpose::Memory)e.toggle_sign();else e.capitals=!e.capitals;}
        else if(key==Input::PageLeft)e.move(-1);else if(key==Input::PageRight)e.move(1);
        else if(key==Input::View)e.clear();
        else if(key==Input::Menu)submit_text();else if(key==Input::Back){tool_screen(text_return);status="已取消文字编辑";}
        return;
    }
    if(navigation.screen==Screen::Skins){
        const int n=int(skin_entries.size())+2;
        if(key==Input::Up||key==Input::Down||key==Input::PageLeft||key==Input::PageRight){int delta=key==Input::Up?-1:key==Input::Down?1:key==Input::PageLeft?-8:8;skin_selection=(skin_selection+delta%n+n)%n;}
        else if(key==Input::Save)refresh_skins();
        else if(key==Input::Back||key==Input::Menu||key==Input::View)tool_screen(Screen::Settings);
        else if(key==Input::Confirm||key==Input::Right){
            if(skin_selection==0){auto next=editing_options;next.skin.clear();if(!game_options.save(editing_identity,next)){status="设置保存失败";return;}editing_options=next;editing_skin_name.clear();if(in_game&&game_options.identity(active_path)==editing_identity)apply_custom_skin(next);tool_screen(Screen::Settings);status="此游戏已恢复内置遮罩";}
            else if(skin_selection==1){const char* h=std::getenv("HOME");skin_browser.images=true;skin_browser.open(fs::path(h&&*h?h:".")/"Desktop");tool_screen(Screen::SkinFiles);status.clear();}
            else skin_preview(skin_entries[size_t(skin_selection-2)]);
        }return;
    }
    if(navigation.screen==Screen::SkinFiles){
        auto& b=skin_browser;
        if(key==Input::Up)b.move(-1);else if(key==Input::Down)b.move(1);else if(key==Input::PageLeft)b.move(-9);else if(key==Input::PageRight)b.move(9);
        else if(key==Input::Left)b.open(b.folder.parent_path());
        else if(key==Input::Back||key==Input::Menu||key==Input::View){refresh_skins();tool_screen(Screen::Skins);}
        else if((key==Input::Confirm||key==Input::Right)&&!b.items.empty()){
            auto item=b.items[size_t(b.selected)];if(item.directory)b.open(item.path);
            else if(item.game){skin_preview({item.path,item.path.stem().u8string(),{}});if(navigation.screen==Screen::SkinFiles)b.error=status;}
            else b.error="请选择 PNG、JPG、JPEG 或 .skin 文件";
        }return;
    }
    if(navigation.screen==Screen::SkinLayout){
        if(key==Input::Up)skin_layout_selection=(skin_layout_selection+5)%6;else if(key==Input::Down)skin_layout_selection=(skin_layout_selection+1)%6;
        else if(key==Input::Reset)skin_draft.rect={400,40,480,640};else if(key==Input::Save)skin_draft.rect={0,0,1280,720};
        else if(key==Input::Left)skin_adjust(-8);else if(key==Input::Right)skin_adjust(8);else if(key==Input::PageLeft)skin_adjust(-1);else if(key==Input::PageRight)skin_adjust(1);
        else if(key==Input::Menu||(key==Input::Confirm&&skin_layout_selection==4))apply_skin();
        else if(key==Input::Back||key==Input::View||(key==Input::Confirm&&skin_layout_selection==5)){skin_draft_image.clear();refresh_skins();tool_screen(Screen::Skins);status="未应用本次遮罩调整";}
    }
}
