#pragma once
#include "deck_memory_menu.h"
namespace deck_memory {
inline void render(deck_ui::UI&u,Session&s,Panel&p){
    deck_i18n::begin_frame();p.normalize(s);auto color=host_menu::color;
    auto box=[&](int x,int y,int w,int h,uint32_t c){host_menu::rect(u.pixels.data(),1280,x,y,w,h,color(c));};
    std::fill(u.pixels.begin(),u.pixels.end(),color(0xf3f3f3));box(0,0,1280,6,0xd91526);
    u.text(48,36,"内存修改",color(0x262626),34,800);box(1068,28,174,56,0x343434);u.text(1110,44,"返回",color(0xffffff),24,120);
    u.text(48,94,"游戏已暂停 · 仅本次运行有效 · 读档 / 重启会清空目标",color(0x696969),20,1160);
    const std::string controls[]={std::string("类型：")+type_name(p.type()),"新搜索数值…","未知初值搜索","再次搜索数值…","筛选：数值增加","筛选：数值减少","筛选：发生变化","筛选：保持不变","查看搜索结果","管理锁定列表","撤销上次修改","清空结果和锁定"};
    for(int i=0;i<Panel::ControlCount;++i){int y=148+i*36;box(48,y,298,32,!p.right&&p.control==i?0xf4dddd:0xffffff);u.text(62,y+6,controls[i],color(!p.right&&p.control==i?0xd91526:0x262626),20,275);}
    std::string header=p.show_locks?"锁定列表":"搜索结果（"+std::string(type_name(s.result_type))+"）";
    header+="  "+std::to_string(p.count(s))+" 项";
    if(p.count(s))header+=" · "+std::to_string(p.row+1)+"/"+std::to_string(p.count(s));
    u.text(374,136,header,color(0x696969),20,600);u.text(1010,136,s.locks_enabled?"锁定总开关：开":"锁定总开关：关",color(0x696969),17,222);
    int first=p.row/Panel::Page*Panel::Page;
    for(int i=0;i<Panel::Page&&first+i<int(p.count(s));++i){int n=first+i,y=170+i*48;const auto&t=p.show_locks?s.locks[n].target:s.candidates[n].target;int64_t value=0;bool valid=s.read(t,value);
        box(374,y,858,43,p.right&&n==p.row?0xf4dddd:0xffffff);
        u.text(390,y+5,deck_i18n::raw(s.describe(t)),color(valid?0x262626:0x999999),17,590);
        std::string mark=p.show_locks?(s.locks[n].enabled?"锁 ":"停 "):(s.locked(t)?"锁 ":"");
        std::string number=valid?std::to_string(value):"已失效";
        u.text(1000,y+6,mark+number,color(valid?0xd91526:0x999999),17,220);
        if(p.show_locks)u.text(390,y+24,"目标值："+std::to_string(s.locks[n].value),color(0x718094),14,580);
    }
    if(!p.count(s))u.text(406,250,p.show_locks?"没有锁定条目。先选结果，按 X 锁定当前值。":"先搜索数值，返回游戏改变它，再做筛选。",color(0x718094),22,790);
    const char* labels[]={"A 修改","X 锁定/暂停",p.show_locks?"Y 删除锁定":"Y 锁定总开关","视图键 继续"};
    for(int i=0;i<4;++i){int x=374+i*216;box(x,574,210,42,i==0?0xd91526:0x343434);u.text(x+15,584,labels[i],color(0xffffff),18,190);}
    std::string note=s.busy?"搜索中 "+std::to_string(s.visited)+" / "+std::to_string(s.total)+"；B 取消，上次结果保留":s.note;
    u.text(48,628,note,color(s.busy?0x718094:0x696969),19,1184);
    u.text(48,674,"上下选择  左右切换面板  A 确认  L1/R1 翻页  B 返回/取消  ≡ 暂停菜单",color(0x696969),18,1184);
}
}
