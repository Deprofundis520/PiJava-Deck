#pragma once
#include <algorithm>
#include <charconv>
#include <cstdint>
#include <functional>
#include <limits>
#include <string>
#include <vector>
namespace deck_memory {
enum class Type : char { Byte='B',Short='S',Int='I',Long='J' };
inline const char* type_name(Type t){switch(t){case Type::Byte:return "8位整数";case Type::Short:return "16位整数";case Type::Long:return "64位整数";default:return "32位整数";}}
inline bool fits(Type t,int64_t n){switch(t){case Type::Byte:return n>=-128&&n<=127;case Type::Short:return n>=-32768&&n<=32767;case Type::Int:return n>=INT32_MIN&&n<=INT32_MAX;default:return true;}}
inline bool parse(const std::string&s,Type t,int64_t&n){if(s.empty())return false;auto p=std::from_chars(s.data(),s.data()+s.size(),n);return p.ec==std::errc{}&&p.ptr==s.data()+s.size()&&fits(t,n);}
enum class Kind { Field,Static,Array };
struct Target {
    uint32_t epoch=0,generation=0;uint64_t layout=0;
    int object=0,cls=-1,slot=0;Kind kind=Kind::Field;Type type=Type::Int;
};
inline bool operator==(const Target&a,const Target&b){return a.epoch==b.epoch&&a.generation==b.generation&&a.layout==b.layout&&a.object==b.object&&a.cls==b.cls&&a.slot==b.slot&&a.kind==b.kind&&a.type==b.type;}
struct Span {Target target;size_t count=1;};
struct Backend {
    std::function<uint32_t()> epoch;
    std::function<bool(const Target&,int64_t&)> read;
    std::function<bool(const Target&,int64_t)> write;
    std::function<bool(Type,std::vector<Span>&,std::string&)> plan;
    std::function<std::string(const Target&)> describe;
};
enum class Compare { Exact,Unknown,Increased,Decreased,Changed,Unchanged };
inline bool matches(Compare c,int64_t n,int64_t previous,int64_t wanted){switch(c){case Compare::Exact:return n==wanted;case Compare::Increased:return n>previous;case Compare::Decreased:return n<previous;case Compare::Changed:return n!=previous;case Compare::Unchanged:return n==previous;default:return true;}}
struct Candidate {Target target;int64_t previous=0;};
struct Lock {Target target;int64_t value=0;bool enabled=true;};
struct Undo {Target target;int64_t before=0,after=0;};
class Session {
    Backend backend;uint32_t epoch_=0;std::vector<Span> spans;std::vector<Candidate> staged;
    size_t span_=0,element_=0,refine_=0;bool refining_=false;Compare compare_=Compare::Exact;int64_t wanted_=0;
    Type pending_type=Type::Int;
    bool available(const Target&t,int64_t&n)const{return t.epoch==backend.epoch()&&backend.read(t,n);}
public:
    static constexpr size_t MaxCandidates=100000,MaxSpans=100000,MaxLocks=64,MaxUndo=32;
    std::vector<Candidate> candidates;std::vector<Lock> locks;std::vector<Undo> undo;
    std::string note;Type result_type=Type::Int;bool busy=false,locks_enabled=true;size_t visited=0,total=0;
    explicit Session(Backend b):backend(std::move(b)){epoch_=backend.epoch();}
    void reset(){candidates.clear();locks.clear();undo.clear();spans.clear();staged.clear();busy=false;visited=total=0;locks_enabled=true;epoch_=backend.epoch();note.clear();}
    bool guard(){if(epoch_==backend.epoch())return true;reset();note="运行状态已变化：已清除搜索、锁定和撤销记录";return false;}
    bool read(const Target&t,int64_t&v)const{return available(t,v);}
    std::string describe(const Target&t)const{return backend.describe(t);}
    bool start(Type type,Compare compare,int64_t wanted=0,bool refine=false){
        guard();if(busy){note="请先完成或取消当前搜索";return false;}
        if(compare==Compare::Exact&&!fits(refine?result_type:type,wanted)){note="输入超出此类型范围";return false;}
        if(refine&&candidates.empty()){note="没有可筛选的结果，请先搜索";return false;}
        spans.clear();staged.clear();visited=total=0;span_=element_=refine_=0;refining_=refine;compare_=compare;wanted_=wanted;pending_type=refine?result_type:type;
        if(refine)total=candidates.size();
        else{
            if(!backend.plan(type,spans,note)){spans.clear();return false;}
            if(spans.size()>MaxSpans){spans.clear();note="对象过多，本次搜索取消；请换一种类型";return false;}
            for(auto&s:spans){if(s.count>SIZE_MAX-total){spans.clear();note="搜索范围过大";return false;}total+=s.count;}
        }
        busy=true;note="搜索中，游戏保持暂停；按 B 取消";return true;
    }
    void cancel(){if(!busy)return;busy=false;spans.clear();staged.clear();note="搜索已取消，保留上次结果";}
    void step(size_t budget=4096){
        if(!guard()||!busy)return;
        while(budget--&&visited<total){
            Target target;int64_t previous=0;
            if(refining_){auto&c=candidates[refine_++];target=c.target;previous=c.previous;}
            else{
                while(span_<spans.size()&&element_>=spans[span_].count){++span_;element_=0;}
                if(span_>=spans.size())break;
                target=spans[span_].target;target.slot+=int(element_++);
            }
            ++visited;int64_t value;
            if(available(target,value)&&matches(compare_,value,previous,wanted_)){
                if(staged.size()==MaxCandidates){cancel();note="候选超过10万个，已取消；请指定数值或更换类型";return;}
                staged.push_back({target,value});
            }
        }
        if(visited>=total){candidates.swap(staged);staged.clear();spans.clear();busy=false;result_type=pending_type;note="搜索完成："+std::to_string(candidates.size())+" 项；修改前请核对目标";}
    }
    bool set(const Target&t,int64_t value){
        if(!guard())return false;if(busy){note="搜索期间不能修改";return false;}
        int64_t before;if(!fits(t.type,value)){note="数值超出类型范围，未修改";return false;}
        if(!available(t,before)||!backend.write(t,value)){note="目标已失效，未修改";return false;}
        if(undo.size()==MaxUndo)undo.erase(undo.begin());undo.push_back({t,before,value});
        for(auto&l:locks)if(l.target==t)l.value=value;
        note="已修改："+std::to_string(before)+" → "+std::to_string(value);return true;
    }
    bool revert(){
        if(!guard()||busy)return false;if(undo.empty()){note="没有可撤销的修改";return false;}
        const auto u=undo.back();int64_t now;
        if(!available(u.target,now)||now!=u.after){undo.pop_back();note="目标已失效或游戏已改值，未覆盖当前进度";return false;}
        if(!backend.write(u.target,u.before)){note="撤销失败";return false;}
        undo.pop_back();locks.erase(std::remove_if(locks.begin(),locks.end(),[&](const Lock&l){return l.target==u.target;}),locks.end());note="已撤销上次修改，并取消该目标的锁定";return true;
    }
    bool toggle(const Target&t){
        if(!guard()||busy)return false;
        for(auto&l:locks)if(l.target==t){l.enabled=!l.enabled;note=l.enabled?"已启用此锁定":"已暂停此锁定";return true;}
        if(locks.size()>=MaxLocks){note="最多64条锁定，请先删除不用的条目";return false;}
        int64_t value;if(!available(t,value)){note="目标已失效";return false;}
        locks.push_back({t,value,true});note="已锁定当前值；仅本次运行有效";return true;
    }
    bool locked(const Target&t)const{if(!locks_enabled)return false;for(auto&l:locks)if(l.target==t)return l.enabled;return false;}
    void apply(){
        if(!guard()||busy)return;
        size_t removed=0;
        locks.erase(std::remove_if(locks.begin(),locks.end(),[&](const Lock&l){int64_t n;bool stale=!available(l.target,n);if(!stale&&locks_enabled&&l.enabled&&n!=l.value)stale=!backend.write(l.target,l.value);removed+=stale;return stale;}),locks.end());
        if(removed)note="已移除 "+std::to_string(removed)+" 条失效锁定";
    }
};
}
