#pragma once
#include "deck_memory.h"
#include "deck_navigation.h"
namespace deck_memory {
enum class Prompt { None,NewExact,RefineExact,Modify };
enum class Route { None,Pause,Game,Editor };
struct Panel {
    int control=1,row=0,type_index=0;bool right=false,show_locks=false;Prompt prompt=Prompt::None;Target target;
    static constexpr int ControlCount=12,Page=8;
    Type type()const{const Type types[]={Type::Int,Type::Short,Type::Byte,Type::Long};return types[type_index];}
    size_t count(const Session&s)const{return show_locks?s.locks.size():s.candidates.size();}
    void normalize(const Session&s){row=std::clamp(row,0,std::max(0,int(count(s))-1));}
    bool selected(Session&s,Target&t){normalize(s);if(!count(s)){s.note=show_locks?"没有锁定条目":"没有结果，请先搜索";return false;}t=show_locks?s.locks[row].target:s.candidates[row].target;return true;}
    Route input(Session&s,deck_navigation::Input k){
        using I=deck_navigation::Input;s.guard();normalize(s);
        if(k==I::Menu){s.cancel();return Route::Pause;}
        if(k==I::View){s.cancel();return Route::Game;}
        if(s.busy){if(k==I::Back)s.cancel();return Route::None;}
        if(k==I::Back){if(right)right=false;else return Route::Pause;return Route::None;}
        if(k==I::Up||k==I::Down||k==I::PageLeft||k==I::PageRight){
            int delta=k==I::Up?-1:k==I::Down?1:k==I::PageLeft?-Page:Page;
            if(right){int n=int(count(s));if(n)row=std::clamp(row+delta,0,n-1);}else control=(control+delta%ControlCount+ControlCount)%ControlCount;
        }else if(k==I::Left||k==I::Right){
            if(right&&k==I::Left)right=false;
            else if(!right&&control==0)type_index=(type_index+(k==I::Right?1:3))%4;
            else if(k==I::Right){right=true;show_locks=control==9;row=0;}
        }else if(right){
            if(k==I::Confirm){if(selected(s,target)){int64_t n;if(!s.read(target,n)){s.note="目标已失效，请重新搜索";return Route::None;}prompt=Prompt::Modify;return Route::Editor;}}
            else if(k==I::Reset||k==I::Resume){if(selected(s,target))s.toggle(target);}
            else if(k==I::Save){if(show_locks){if(count(s)){s.locks.erase(s.locks.begin()+row);normalize(s);s.note="已删除此锁定，游戏当前数值保持不变";}}else{s.locks_enabled=!s.locks_enabled;s.note=s.locks_enabled?"锁定总开关已开启":"所有锁定已暂停";}}
        }else if(k==I::Confirm){
            switch(control){
            case 0:type_index=(type_index+1)%4;break;
            case 1:prompt=Prompt::NewExact;return Route::Editor;
            case 2:s.start(type(),Compare::Unknown);break;
            case 3:if(s.candidates.empty())s.note="请先搜索";else{prompt=Prompt::RefineExact;return Route::Editor;}break;
            case 4:s.start(type(),Compare::Increased,0,true);break;
            case 5:s.start(type(),Compare::Decreased,0,true);break;
            case 6:s.start(type(),Compare::Changed,0,true);break;
            case 7:s.start(type(),Compare::Unchanged,0,true);break;
            case 8:show_locks=false;right=true;row=0;break;
            case 9:show_locks=true;right=true;row=0;break;
            case 10:s.revert();break;
            case 11:s.reset();s.note="已清空结果和锁定；没有恢复或更改游戏数值";row=0;break;
            }
        }return Route::None;
    }
    Type prompt_type(const Session&s)const{return prompt==Prompt::Modify?target.type:prompt==Prompt::RefineExact?s.result_type:type();}
    std::string prompt_value(Session&s)const{int64_t n;if(prompt==Prompt::Modify&&s.read(target,n))return std::to_string(n);return {};}
    const char* prompt_title()const{return prompt==Prompt::Modify?"修改目标数值":prompt==Prompt::RefineExact?"再次搜索当前数值":"搜索当前数值";}
    bool submit(Session&s,const std::string&text,std::string&error){
        int64_t n;if(!parse(text,prompt_type(s),n)){error="请输入此类型范围内的十进制整数";return false;}
        bool ok=prompt==Prompt::Modify?s.set(target,n):s.start(type(),Compare::Exact,n,prompt==Prompt::RefineExact);
        if(!ok){error=s.note;return false;}prompt=Prompt::None;return true;
    }
};
}
