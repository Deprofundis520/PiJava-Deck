#pragma once
#include <filesystem>
#include <fstream>
#include "suite_identity.h"
#include "instant_state_file.h"
namespace deck_state {
namespace fs=std::filesystem;
inline std::string identity(const fs::path& jar){
    std::ifstream f(jar,std::ios::binary);if(!f)return {};
    rms_suite_identity_detail::Sha256 hash;char block[16384];
    while(f.read(block,sizeof(block))||f.gcount())hash.update(reinterpret_cast<const uint8_t*>(block),size_t(f.gcount()));
    return f.bad()?std::string{}:hash.finish();
}
struct Store {
    fs::path root,bundle;
    bool prepare()const{std::error_code ec;fs::create_directories(root,ec);return !ec;}
    fs::path primary(const std::string& id)const{
        if(id.size()!=64||id.find_first_not_of("0123456789abcdef")!=std::string::npos)return {};
        return root/(id+".sav");
    }
    static bool exists(const fs::path& p){
        if(p.empty())return false;std::error_code ec;
        if(fs::is_regular_file(p,ec))return true;
        ec.clear();return !fs::exists(p,ec)&&!ec&&fs::is_regular_file(fs::path(p.string()+".previous"),ec);
    }
    fs::path readable(const fs::path& jar,const std::string& id)const{
        auto p=primary(id);if(exists(p))return p;
        // Imported upstream J2S5 files retain the original <game>.jar.sav name.
        for(const auto& dir:{root,bundle}){p=dir/fs::path(jar.filename().string()+".sav");if(exists(p))return p;}
        return {};
    }
};
}
