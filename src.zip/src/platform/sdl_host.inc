// Native Linux/Steam Deck SDL2 frontend. Build only through j2mevm.cpp.
#include <filesystem>
#include "deck_input.h"
#include "../presentation/orientation.h"
#include "deck_ui.h"
#include "deck_launcher.h"
#include "deck_navigation.h"
#include "deck_ui_input.h"
#include "deck_install_ui.h"
#include "deck_state.h"
static deck_state::Store deck_states;
static host_menu::Settings g_menu_settings;
static std::string instant_state_path(const std::string& jar){return deck_states.primary(deck_state::identity(jar)).string();}
#define J2ME_INSTANT_STATE_PREPARE() deck_states.prepare()
#include "../instant_state.inc"
#undef J2ME_INSTANT_STATE_PREPARE
#include "deck_memory_vm.inc"
#include "deck_memory_render.h"
namespace deck {
namespace fs=std::filesystem;
static SDL_Window* window=nullptr;
static SDL_Renderer* renderer=nullptr;
static SDL_Texture* texture=nullptr;
static int tw=0,th=0,selection=0;
static SDL_GameController* controller=nullptr;
static deck_input::State input;
static std::vector<fs::path> games;
static fs::path games_dir,data_dir,active_path,bundle_dir;
static bool explicit_games=false;
static deck_games::Browser folder_browser;
static deck_games::Scan game_catalog;
static fs::path preferred_games;
static std::string scan_summary;
static deck_ui::UI ui;
static presentation::orientation::Cache orientation;
static int active_rotation=0;
static bool menu_open=true,wait_neutral=false,pause_sheet=false;
static deck_navigation::State navigation;
static deck_keymap::Config keymap;
static deck_keymap::Editor keymap_editor;
static deck_game_options::Store game_options;
static deck_game_options::Options editing_options;
static fs::path editing_path;
static std::string editing_identity,editing_skin_name;
static deck_text::Editor text_editor;
static deck_memory::Session memory(deck_memory_vm::backend());
static deck_memory::Panel memory_panel;
static deck_navigation::Screen text_return=deck_navigation::Screen::Settings;
static int text_target=0,text_owner=0;
static uint32_t text_generation=0;
static deck_custom_skin::Store custom_skins;
static deck_games::Browser skin_browser;
static std::vector<deck_custom_skin::Entry> skin_entries;
static int skin_selection=0,skin_layout_selection=0;
static deck_custom_skin::Meta skin_draft;
static host_skin::Pixels skin_draft_image;
static int64_t text_controller_press=-1000;
static bool tool_screen();
static void tool_input(deck_navigation::Input);
static void memory_input(deck_navigation::Input);
static void apply_custom_skin(const deck_game_options::Options&);
static void relabel();
static fs::path settings_target();
static int raw_right_x=0,raw_right_y=0;
static std::vector<std::string> labels;
static std::vector<uint8_t> saved;
static void refresh_saved(){
    saved.assign(games.size(),0);std::error_code ec;
    if(!fs::is_directory(deck_states.root,ec)&&!fs::is_directory(deck_states.bundle,ec))return;
    for(size_t i=0;i<games.size();++i)saved[i]=!deck_states.readable(games[i],game_options.identity(games[i])).empty();
}
static std::map<std::string,int> speeds;
static deck_ui_input::Axis menu_vertical,menu_horizontal;
static deck_ui_input::CommandGate command_gate;
static int64_t fps_since=0;
static unsigned fps_new_frames=0;
static std::string fps_label="0";
static std::string status;
static bool running=true,paused=false,focused=true,fullscreen=true;
static bool& in_game=navigation.active;
static int smoke_frames=0,frame_count=0;
static std::string screenshot;
static bool size_override=false;
static int screen_width=240,screen_height=320;
static void send(int code,bool release){dispatch_key(deck_phone::encode(code),release);}
static void release(){input.clear(send);VMS_PLAT(g_key_states)=0;}
static void controllers(){
    if(controller && !SDL_GameControllerGetAttached(controller)){command_gate.reset();menu_vertical.reset();menu_horizontal.reset();release();SDL_GameControllerClose(controller);controller=nullptr;}
    if(!controller)for(int i=0;i<SDL_NumJoysticks();++i)if(SDL_IsGameController(i)){controller=SDL_GameControllerOpen(i);if(controller)break;}
}
static int key(SDL_Keycode k){
    switch(k){case SDLK_UP:return -1;case SDLK_DOWN:return -2;case SDLK_LEFT:return -3;case SDLK_RIGHT:return -4;
    case SDLK_RETURN:case SDLK_SPACE:return -5;case SDLK_q:return -6;case SDLK_e:return -7;
    case SDLK_ASTERISK:return 42;case SDLK_HASH:return 35;default:return k>=SDLK_0&&k<=SDLK_9?int(k):0;}
}
static int physical_button(int b){
    using namespace deck_keymap;
    switch(b){
    case SDL_CONTROLLER_BUTTON_A:return A;case SDL_CONTROLLER_BUTTON_B:return B;case SDL_CONTROLLER_BUTTON_X:return X;case SDL_CONTROLLER_BUTTON_Y:return Y;
    case SDL_CONTROLLER_BUTTON_LEFTSTICK:return L3;case SDL_CONTROLLER_BUTTON_LEFTSHOULDER:return L1;case SDL_CONTROLLER_BUTTON_RIGHTSHOULDER:return R1;case SDL_CONTROLLER_BUTTON_RIGHTSTICK:return R3;
    case SDL_CONTROLLER_BUTTON_DPAD_UP:return DUp;case SDL_CONTROLLER_BUTTON_DPAD_DOWN:return DDown;case SDL_CONTROLLER_BUTTON_DPAD_LEFT:return DLeft;case SDL_CONTROLLER_BUTTON_DPAD_RIGHT:return DRight;
    default:return -1;}
}
static int ui_button(int b){
    switch(b){case SDL_CONTROLLER_BUTTON_A:return -5;case SDL_CONTROLLER_BUTTON_B:return -7;case SDL_CONTROLLER_BUTTON_X:return -6;
    case SDL_CONTROLLER_BUTTON_DPAD_UP:return -1;case SDL_CONTROLLER_BUTTON_DPAD_DOWN:return -2;case SDL_CONTROLLER_BUTTON_DPAD_LEFT:return -3;case SDL_CONTROLLER_BUTTON_DPAD_RIGHT:return -4;default:return 0;}
}
static void sync_navigation(deck_navigation::Screen previous){
    using deck_navigation::Screen;
    menu_open=navigation.screen!=Screen::Game&&navigation.screen!=Screen::Pause;
    pause_sheet=navigation.screen==Screen::Pause;paused=navigation.frozen();
    if(previous!=navigation.screen){
        if(previous==Screen::Text)SDL_StopTextInput();
        if(navigation.screen==Screen::Text){
            int w=0,h=0;SDL_GetWindowSize(window,&w,&h);double scale=std::min(double(w)/1280,double(h)/720);
            SDL_Rect r{int((w-1280*scale)/2+80*scale),int((h-720*scale)/2+136*scale),int(1120*scale),int(72*scale)};
            SDL_SetTextInputRect(&r);SDL_StartTextInput();
        }
        if(navigation.screen==Screen::Settings){
            editing_path=settings_target();editing_identity=editing_path.empty()?std::string{}:game_options.identity(editing_path);
            editing_options=game_options.load(editing_identity);ui.settings.rotation=editing_options.rotation;editing_skin_name=editing_options.skin.empty()?std::string{}:custom_skins.meta(editing_options.skin).name;
        }
        release();menu_vertical.block_until_release();menu_horizontal.block_until_release();
        if(in_game)host_freeze236(paused||!focused);
        if(in_game&&navigation.screen==Screen::Game){wait_neutral=true;fps_since=paint_clock_us();fps_new_frames=0;}
        log_line("DECKUI screen="+std::to_string(int(navigation.screen))+" active="+std::to_string(in_game));
    }
}
static void scan(){
    fs::path previous=selection>=0&&selection<int(games.size())?games[size_t(selection)]:fs::path{};
    std::vector<fs::path> roots;
    const auto chosen=deck_games::load_root(data_dir/"game-folder.path");
    if(explicit_games)roots.push_back(games_dir);
    else{
        roots={chosen,bundle_dir/"games",games_dir,deck_games::load_root(data_dir/"source-games.path")};
    }
    game_catalog=deck_games::scan(roots);games=game_catalog.games;
    std::error_code chosen_ec;const bool chosen_valid=!chosen.empty()&&fs::is_directory(chosen,chosen_ec);
    preferred_games=chosen_valid?chosen:(explicit_games?games_dir:bundle_dir/"games");
    if(!chosen_valid)for(const auto& root:game_catalog.roots)if(root.jars){preferred_games=root.path;break;}
    for(const auto& root:game_catalog.roots)log_line("GAMESCAN path="+root.path.u8string()+" files="+std::to_string(root.files)+" jars="+std::to_string(root.jars)+" error="+root.error);
    selection=std::min(selection,std::max(0,int(games.size())-1));
    for(size_t i=0;i<games.size();++i)if(games[i]==previous){selection=int(i);break;}
    relabel();
    scan_summary="读取到 "+std::to_string(games.size())+" 个 JAR；目录："+preferred_games.u8string();
    if(game_catalog.truncated)scan_summary="扫描数量达到上限，请选择更具体的游戏文件夹";
    refresh_saved();
    log_line("GAMESCAN total="+std::to_string(games.size())+" truncated="+std::to_string(game_catalog.truncated));
}
static void open_browser_folder(const fs::path& path){folder_browser.open(path);menu_vertical.block_until_release();menu_horizontal.block_until_release();}
static void use_games_folder(const fs::path& path,const fs::path& highlight={}){
    std::error_code ec;if(!fs::is_directory(path,ec)){folder_browser.error="无法读取目录："+path.u8string();status=folder_browser.error;return;}
    fs::directory_iterator probe(path,ec);if(ec){folder_browser.error="无法打开目录："+ec.message();status=folder_browser.error;return;}
    if(!deck_games::save_root(data_dir/"game-folder.path",path)){folder_browser.error="无法保存游戏目录";status=folder_browser.error;return;}
    explicit_games=false;scan();const auto previous=navigation.screen;navigation.screen=deck_navigation::Screen::Library;sync_navigation(previous);
    if(!highlight.empty())for(size_t i=0;i<games.size();++i)if(games[i]==deck_games::normalized(highlight)){selection=int(i);break;}
    status=scan_summary;
}
static void upload(const void* data,int w,int h,Uint32 format,int pitch){
    if(!texture||w!=tw||h!=th){if(texture)SDL_DestroyTexture(texture);texture=SDL_CreateTexture(renderer,format,SDL_TEXTUREACCESS_STREAMING,w,h);tw=w;th=h;}
    if(!texture)die(SDL_GetError());
    if(SDL_UpdateTexture(texture,nullptr,data,pitch)!=0)die(SDL_GetError());
    int rw=0,rh=0;SDL_GetRendererOutputSize(renderer,&rw,&rh);
    const double scale=std::min(double(rw)/w,double(rh)/h);
    SDL_Rect dst{(rw-int(w*scale))/2,(rh-int(h*scale))/2,int(w*scale),int(h*scale)};
    SDL_SetRenderDrawColor(renderer,10,14,22,255);SDL_RenderClear(renderer);SDL_RenderCopy(renderer,texture,nullptr,&dst);SDL_RenderPresent(renderer);
}
static fs::path settings_target(){
    if(in_game&&(navigation.screen==deck_navigation::Screen::Settings||navigation.screen==deck_navigation::Screen::Keymap)&&navigation.settings_return==deck_navigation::Screen::Pause)return active_path;
    return games.empty()?fs::path{}:games[size_t(selection)];
}
static int selected_speed(){const auto target=settings_target();return target.empty()?0:host_speed::normalize(speeds[target.string()]);}
static void menu(){
    using deck_navigation::Screen;
    if(navigation.screen==Screen::Settings)ui.settings_menu(navigation.option,selected_speed(),in_game,status,editing_options,editing_path.filename().u8string(),editing_skin_name);
    else if(navigation.screen==Screen::Memory)deck_memory::render(ui,memory,memory_panel);
    else if(navigation.screen==Screen::Text)ui.text_menu(text_editor);
    else if(navigation.screen==Screen::Skins)ui.skins_menu(skin_entries,skin_selection,status);
    else if(navigation.screen==Screen::SkinFiles)ui.folder_menu(skin_browser);
    else if(navigation.screen==Screen::SkinLayout)ui.skin_layout(skin_draft,skin_draft_image,skin_layout_selection,status);
    else if(navigation.screen==Screen::Keymap)ui.keymap_menu(keymap_editor,status);
    else if(navigation.screen==Screen::Folders)ui.folder_menu(folder_browser);
    else{
        std::string note=status;
        if(note.empty())note=scan_summary;
        static fs::path shown_game;
        const auto selected_game=settings_target();
        if(selected_game!=shown_game){ui.settings.rotation=game_options.load(game_options.identity(selected_game)).rotation;shown_game=selected_game;}
        ui.focus=host_menu::Focus::Games;
        ui.menu(labels,selection,note,selected_speed(),in_game,monotonic_ms(),saved);
    }
    upload(ui.pixels.data(),1280,720,SDL_PIXELFORMAT_ABGR8888,1280*4);
}
static void toggle_fullscreen(){fullscreen=!fullscreen;SDL_SetWindowFullscreen(window,fullscreen?SDL_WINDOW_FULLSCREEN_DESKTOP:0);}
static void set_live_speed(int value){
    VMS_EXEC(g_speed_cap)=host_speed::normalize(value);
    VMS_EXEC(g_speed_last_paint_us)=VMS_EXEC(g_speed_next_us)=VMS_EXEC(g_speed_slept_us)=0;
    VMS_EXEC(g_speed_frame_open)=false;speed_reset_learning();
}
static void change_option(int direction){
    if(navigation.option==10){
        status=deck_i18n::save(!deck_i18n::english)?"语言已保存":"语言保存失败";ui.chrome.clear();return;
    }
    if(navigation.option==9){
        if(editing_identity.empty()){status="请先选择游戏";return;}
        auto next=editing_options;next.rotation=(next.rotation+(direction>0?1:3))%4;
        if(!game_options.save(editing_identity,next)){status="旋转设置保存失败";return;}
        editing_options=next;ui.settings.rotation=next.rotation;
        if(in_game&&game_options.identity(active_path)==editing_identity)active_rotation=next.rotation;
        status="旋转已保存；仅改变显示，方向键保持原映射";return;
    }
    if(navigation.option>=7)return;
    if(navigation.option>=5){
        if(editing_identity.empty()){status="请先选择可读取的游戏";return;}
        auto next=editing_options;
        if(navigation.option==5){const int count=int(deck_game_options::resolutions.size());next.resolution=(next.resolution+(direction>0?1:count-1))%count;}
        else next.profile=(next.profile+(direction>0?1:deck_phone::Count-1))%deck_phone::Count;
        if(!game_options.save(editing_identity,next)){status="游戏设置保存失败，请检查用户目录权限";return;}
        editing_options=next;status="已为此游戏保存，下次按 A 正常开始生效";return;
    }
    if(navigation.option==4)return;
    ui.focus=static_cast<host_menu::Focus>(navigation.option+1);
    if(navigation.option==2){
        const auto target=settings_target();if(target.empty()){status="请先选择游戏";return;}
        const int choices[]={0,30,60};int old=selected_speed(),index=old==30?1:old==60?2:0;
        int value=choices[(index+(direction>0?1:2))%3];speeds[target.string()]=value;
        if(in_game&&target==active_path)set_live_speed(value);
        if(!host_speed::save((data_dir/"deck-speed.cfg").string(),speeds)){status="速度设置保存失败";return;}
    }else{
        ui.change(direction);
        if(!host_menu::save_settings((data_dir/"deck-menu.cfg").string(),ui.settings)){status="显示设置保存失败";return;}
        if(navigation.option==0&&!editing_options.skin.empty()){
            auto next=editing_options;next.skin.clear();
            if(!game_options.save(editing_identity,next)){status="内置遮罩已调整，但取消自定义遮罩未能保存";return;}
            editing_options=next;editing_skin_name.clear();
            if(in_game&&game_options.identity(active_path)==editing_identity)apply_custom_skin(next);
        }
    }
    status="设置已保存";
}
static void leave(){
    memory.reset();memory_panel=deck_memory::Panel{};
    release();if(in_game){host_freeze236(false);lifecycle_destroy();stop_thread();}
    const auto previous=navigation.screen;navigation.stopped();sync_navigation(previous);deck_audio::clear();if(texture)SDL_DestroyTexture(texture);texture=nullptr;
}
static void launch(const fs::path& path,bool restore=false){
    const fs::path target=path;
    std::string restore_path;
    deck_phone::Profile restore_phone=deck_phone::Standard;bool phone_recorded=false;
    if(restore){restore_path=deck_states.readable(target,deck_state::identity(target)).string();if(restore_path.empty()){status="这个游戏没有即时存档，请按 A 开始";return;}
        std::string bytes;SavState probe;
        if(!instant_state_file::load(restore_path,bytes)||!decode_state(bytes,probe)||probe.rms!=deck_state::identity(target)){
            status="即时存档无法读取：文件损坏、游戏不匹配或版本不兼容";return;
        }
        restore_phone=game_options.load_snapshot(rms_jar_identity(reinterpret_cast<const uint8_t*>(bytes.data()),bytes.size()),phone_recorded);
    }
    if(in_game)leave();
    memory.reset();memory_panel=deck_memory::Panel{};
    active_path=target;
    release();VMS_CL(g_jar_files).clear();VMS_CL(g_props).clear();
    std::vector<uint8_t> bytes;std::string error;
    if(!read_whole(path.string(),bytes))die("无法读取 JAR");
    const std::string identity=rms_jar_identity(bytes.data(),bytes.size());
    if(!unzip(bytes,VMS_CL(g_jar_files),error))die(error);
    load_props();load_sidecar_jad(path.string());std::string main=manifest_midlet();if(main.empty())die("游戏清单缺少 MIDlet-1");
    for(char& c:main)if(c=='.')c='/';
    const auto options=game_options.load(identity);
    deck_phone::active=restore?restore_phone:static_cast<deck_phone::Profile>(options.profile);
    log_line("DECKGAME sha256="+identity+" profile="+deck_phone::name(deck_phone::active)+" resolution_requested="+deck_game_options::resolutions[size_t(options.resolution)].label);
    if(size_override){VMS_RS(g_screen_w)=screen_width;VMS_RS(g_screen_h)=screen_height;}
    else if(options.resolution==deck_game_options::automatic_resolution)select_screen_sidecar(path.string(),identity,true);
    else if(options.resolution){const auto choice=deck_game_options::resolutions[size_t(options.resolution)];VMS_RS(g_screen_w)=choice.w;VMS_RS(g_screen_h)=choice.h;}
    else select_screen_sidecar(path.string(),identity,false);
    VMS_RS(g_fb).assign(size_t(VMS_RS(g_screen_w))*VMS_RS(g_screen_h)*3,0);
    if(texture)SDL_DestroyTexture(texture);texture=nullptr;
    set_live_speed(speeds[path.string()]);
    const auto previous=navigation.screen;navigation.launched();sync_navigation(previous);wait_neutral=true;fps_since=paint_clock_us();fps_new_frames=0;VMS_PLAT(g_host_paused)=false;VMS_PLAT(g_host_frozen236)=false;
    if(restore){
        g_menu_settings=ui.settings;
        if(!restore_instant_state(target.string(),identity,restore_path))die("即时存档无法读取：文件损坏、游戏不匹配或版本不兼容");
        VMS_EXEC(g_slices)=0;VMS_EXEC(g_last_console_line).clear();VMS_EXEC(g_self_exit)=false;
        VMS_RS(g_fb_dirty)=true;status=phone_recorded?"已读取即时存档及其机型配置":"已读取即时存档；无机型记录，使用标准机型";
        log_line("DECKGAME restored screen="+std::to_string(VMS_RS(g_screen_w))+"x"+std::to_string(VMS_RS(g_screen_h))+" profile="+deck_phone::name(deck_phone::active));
    }else{launch_class(main,identity);status.clear();}
    active_rotation=options.rotation;apply_custom_skin(options);memory.reset();memory_panel=deck_memory::Panel{};
}
#include "deck_tools.inc"
static void navigate(deck_navigation::Input command){
    if(tool_screen()){tool_input(command);return;}
    using namespace deck_navigation;
    const auto previous=navigation.screen;
    const auto effect=navigation.input(command);
    sync_navigation(previous);
    const bool editing=navigation.screen==Screen::Keymap;
    const bool browsing=navigation.screen==Screen::Folders;
    switch(effect){
    case Effect::OpenMemory:memory.guard();memory_panel.normalize(memory);tool_screen(Screen::Memory);break;
    case Effect::OpenText:open_game_text();break;
    case Effect::Rename:open_rename();break;
    case Effect::OpenSkins:open_skins();break;
    case Effect::Launch:if(!games.empty())launch(games[size_t(selection)]);else status="请先放入游戏";break;
    case Effect::SaveInstant:{
        if(!in_game){status="请先启动游戏";break;}
        release();g_menu_settings=ui.settings;
        deck_audio::pause(true);
        const bool ok=sheet_save_instant_state(active_path.string());
        const bool phone_ok=ok&&game_options.save_snapshot(instant_state_path(active_path.string()),deck_phone::active);
        deck_audio::pause(false);refresh_saved();
        status=!ok?"即时存档保存失败，请重试或检查可用空间":phone_ok?"即时存档与机型已保存，可关闭后用 X 继续":"存档已保存，但机型记录失败；读档将使用标准机型";
        break;
    }
    case Effect::RestoreInstant:
        if(previous==Screen::Pause)launch(active_path,true);
        else if(!games.empty())launch(games[size_t(selection)],true);
        else status="请先选择游戏";
        break;
    case Effect::Stop:leave();break;
    case Effect::Quit:running=false;break;
    case Effect::SelectPrevious:if(browsing)folder_browser.move(-1);else if(editing)keymap_editor.move(-1);else selection=menu_actions::move(selection,-1,int(games.size()));break;
    case Effect::SelectNext:if(browsing)folder_browser.move(1);else if(editing)keymap_editor.move(1);else selection=menu_actions::move(selection,1,int(games.size()));break;
    case Effect::PagePrevious:if(browsing)folder_browser.move(-9);else if(editing)keymap_editor.move(-9);else selection=menu_actions::page(selection,-1,int(games.size()),host_menu::visible_rows);break;
    case Effect::PageNext:if(browsing)folder_browser.move(9);else if(editing)keymap_editor.move(9);else selection=menu_actions::page(selection,1,int(games.size()),host_menu::visible_rows);break;
    case Effect::OpenFolderBrowser:{
        auto path=preferred_games;std::error_code ec;if(!fs::is_directory(path,ec)){const char* home=std::getenv("HOME");path=fs::path(home&&*home?home:".")/"Desktop";}
        open_browser_folder(path);break;
    }
    case Effect::EnterFolder:
        if(!folder_browser.items.empty()){
            const auto item=folder_browser.items[size_t(folder_browser.selected)];
            if(item.directory)open_browser_folder(item.path);
            else if(item.game)use_games_folder(item.path.parent_path(),item.path);
            else folder_browser.error="这个文件不是 JAR，请选择包含 .jar 的文件夹";
        }
        break;
    case Effect::ParentFolder:open_browser_folder(folder_browser.folder.parent_path());break;
    case Effect::UseFolder:use_games_folder(folder_browser.folder);break;
    case Effect::ValuePrevious:change_option(-1);break;
    case Effect::ValueNext:change_option(1);break;
    case Effect::OpenKeymap:keymap_editor.begin(keymap);status.clear();break;
    case Effect::CaptureKeymap:keymap_editor.menu();menu_vertical.block_until_release();menu_horizontal.block_until_release();status.clear();break;
    case Effect::ConfirmKeymap:
        if(keymap_editor.confirm()){status="映射已确认，按视图键保存";menu_vertical.block_until_release();menu_horizontal.block_until_release();}
        else status=keymap_editor.phase==deck_keymap::Phase::Browse?"请先按菜单键开始录入":"请先松开捕获的按键，再按 A 确认";
        break;
    case Effect::BackKeymap:
        if(keymap_editor.phase==deck_keymap::Phase::Capture){keymap_editor.menu();status="已取消本次录入";}
        else if(keymap_editor.phase==deck_keymap::Phase::Review){keymap_editor.retry();status.clear();}
        else{navigation.screen=Screen::Settings;sync_navigation(Screen::Keymap);status="未保存的修改已取消";}
        break;
    case Effect::ClearKeymap:keymap_editor.reset();keymap_editor.draft.codes.fill(0);deck_keymap::fix_directions(keymap_editor.draft);status="已清空可编辑映射，左摇杆方向保留；按视图键保存";break;
    case Effect::ResetKeymap:keymap_editor.reset();status="已恢复默认，按视图键保存";break;
    case Effect::SaveKeymap:
        if(keymap_editor.phase!=deck_keymap::Phase::Browse){status=keymap_editor.phase==deck_keymap::Phase::Capture?"请先录入目标按键，或菜单键取消后保存":"请先松开按键并按 A 确认，或菜单键取消后保存";break;}
        if(deck_keymap::save((data_dir/"deck-keymap.cfg").string(),keymap_editor.draft)){
            release();keymap=keymap_editor.draft;navigation.screen=Screen::Settings;sync_navigation(Screen::Keymap);status="按键映射已保存";
        }else status="按键映射保存失败，请检查目录权限";
        break;
    default:break;
    }
}
static void action(int code){
    using deck_navigation::Input;
    switch(code){case -1:navigate(Input::Up);break;case -2:navigate(Input::Down);break;case -3:navigate(Input::Left);break;case -4:navigate(Input::Right);break;
    case -5:navigate(Input::Confirm);break;case -6:navigate(Input::Resume);break;case -7:navigate(Input::Back);break;default:break;}
}
static void pointer_down(int px,int py){
    using namespace deck_navigation;
    int w=0,h=0,x=0,y=0;SDL_GetWindowSize(window,&w,&h);
    if(!deck_ui::UI::point(w,h,px,py,x,y))return;
    if(navigation.screen==Screen::Memory){
        if(deck_ui::UI::menu_hit(x,y)){navigate(Input::Menu);return;}
        if(memory.busy)return;
        if(x>=48&&x<346&&y>=148&&y<580){memory_panel.right=false;memory_panel.control=(y-148)/36;navigate(Input::Confirm);}
        else if(x>=374&&x<1232&&y>=170&&y<554){int i=memory_panel.row/8*8+(y-170)/48;if(i<int(memory_panel.count(memory))){memory_panel.row=i;memory_panel.right=true;navigate(Input::Confirm);}}
        else if(x>=374&&x<1232&&y>=574&&y<616){memory_panel.right=true;int b=(x-374)/216;navigate(b==0?Input::Confirm:b==1?Input::Reset:b==2?Input::Save:Input::View);}
        return;
    }
    if(navigation.screen==Screen::Text){
        if(x>=80&&x<1200&&y>=296&&y<556){int i=(y-296)/52*10+(x-80)/112;if(i<int(text_editor.keys().size())){text_editor.selected=i;navigate(Input::Confirm);}}
        else if(x>=80&&x<1200&&y>=572&&y<616){int b=(x-80)/224;if(b==0)text_editor.backspace();else if(b==1)text_editor.clear();else if(b==2){if(text_editor.purpose==deck_text::Editor::Purpose::Memory)text_editor.toggle_sign();else text_editor.insert(" ");}else if(b==3)submit_text();else navigate(Input::Back);}
        return;
    }
    if(navigation.screen==Screen::Skins){
        if(deck_ui::UI::menu_hit(x,y)){navigate(Input::Back);return;}
        if(x>=64&&x<1216&&y>=142&&y<558){int i=skin_selection/8*8+(y-142)/52;if(i<int(skin_entries.size())+2){skin_selection=i;navigate(Input::Confirm);}}return;
    }
    if(navigation.screen==Screen::SkinLayout){
        if(x>=884&&x<1232&&y>=154&&y<538){skin_layout_selection=std::min(5,(y-154)/64);navigate(Input::Confirm);}return;
    }
    if(navigation.screen==Screen::SkinFiles){
        if(deck_ui::UI::menu_hit(x,y)){navigate(Input::Back);return;}
        if(x>=890&&x<1232&&y>=638&&y<694){navigate(Input::Confirm);return;}
        if(x>=48&&x<298&&y>=152&&y<418){int row=(y-152)/70;const char* h=std::getenv("HOME");fs::path home=h&&*h?h:".";fs::path paths[]={home/"Desktop",home,fs::path("/run/media"),bundle_dir/"skins"};skin_browser.open(paths[std::min(3,row)]);return;}
        if(x>=330&&x<1232&&y>=142&&y<565){int i=skin_browser.selected/9*9+(y-142)/47;if(i<int(skin_browser.items.size())){skin_browser.selected=i;navigate(Input::Confirm);}}return;
    }
    if(navigation.screen==Screen::Folders){
        if(deck_ui::UI::menu_hit(x,y)){navigate(Input::Back);return;}
        if(x>=890&&x<1232&&y>=638&&y<694){navigate(Input::Save);return;}
        if(x>=48&&x<298&&y>=152&&y<418){
            const int row=(y-152)/70;const char* h=std::getenv("HOME");const fs::path home=h&&*h?h:".";
            const fs::path paths[]={home/"Desktop",home,fs::path("/run/media"),bundle_dir/"games"};open_browser_folder(paths[std::min(3,row)]);return;
        }
        if(x>=330&&x<1232&&y>=142&&y<565){int index=folder_browser.selected/9*9+(y-142)/47;if(index<int(folder_browser.items.size())){folder_browser.selected=index;navigate(Input::Confirm);}}
        return;
    }
    if(navigation.screen==Screen::Library){
        if(x>=936&&x<1076&&y>=638&&y<693){navigate(Input::Resume);return;}
        if(x>=1092&&x<1232&&y>=638&&y<693){navigate(Input::Confirm);return;}
        if(x>=740&&x<904&&y>=28&&y<84){status=deck_i18n::save(!deck_i18n::english)?"语言已保存":"语言保存失败";ui.chrome.clear();return;}
        if(deck_ui::UI::games_hit(x,y)){navigate(Input::OpenGames);return;}
        if(deck_ui::UI::close_hit(x,y)){navigate(Input::Close);return;}
        if(deck_ui::UI::library_settings_hit(x,y)){navigate(Input::Menu);return;}
    }else if(deck_ui::UI::menu_hit(x,y)){navigate(Input::Menu);return;}
    if(navigation.screen==Screen::Keymap&&keymap_editor.phase==deck_keymap::Phase::Browse&&x>=64&&x<574&&y>=138&&y<588){keymap_editor.selected=std::min(14,(y-138)/30);status.clear();return;}
    if(navigation.screen==Screen::Pause&&x>=350&&x<930&&y>=180&&y<564){navigation.pause_selection=std::min(7,(y-180)/48);navigate(Input::Confirm);}
    else if(navigation.screen==Screen::Settings&&x>=80&&x<1200&&y>=160&&y<538){navigation.option=std::min(10,std::max(0,navigation.option-6)+(y-160)/54);navigate(Input::Confirm);}
}
static void ui_direction(int code,deck_ui_input::Source source,bool down){
    const bool vertical=code==-1||code==-2;
    const int direction=code==-1||code==-3?-1:1;
    auto& axis=vertical?menu_vertical:menu_horizontal;
    const int step=axis.button(source,direction,down,monotonic_ms());
    if(step&&navigation.screen!=deck_navigation::Screen::Game&&!(navigation.screen==deck_navigation::Screen::Keymap&&keymap_editor.phase!=deck_keymap::Phase::Browse))action(vertical?(step<0?-1:-2):(step<0?-3:-4));
}
static bool controller_neutral(){
    if(!controller)return true;
    for(int b=0;b<SDL_CONTROLLER_BUTTON_MAX;++b)if(SDL_GameControllerGetButton(controller,SDL_GameControllerButton(b)))return false;
    for(int a=0;a<SDL_CONTROLLER_AXIS_MAX;++a){int v=SDL_GameControllerGetAxis(controller,SDL_GameControllerAxis(a));if(v>16000||v < -16000)return false;}
    return true;
}
static void events(){
    SDL_Event e;
    while(SDL_PollEvent(&e)){
        if(e.type==SDL_QUIT){running=false;continue;}
        if(e.type==SDL_DROPFILE){
            const fs::path path=fs::u8path(e.drop.file?e.drop.file:"");if(e.drop.file)SDL_free(e.drop.file);
            if(navigation.screen==deck_navigation::Screen::Text){text_editor.error="请先完成或取消文字编辑";continue;}
            if(deck_custom_skin::supported(path)){
                if(navigation.screen==deck_navigation::Screen::Skins||navigation.screen==deck_navigation::Screen::SkinFiles||navigation.screen==deck_navigation::Screen::Settings){
                    if(editing_identity.empty())status="请先选择游戏，再导入遮罩";else skin_preview({path,path.stem().u8string(),{}});
                }else status="请先选游戏，在设置管理中打开自定义遮罩再拖入图片";
            }else if(deck_games::jar(path)&&!tool_screen())use_games_folder(path.parent_path(),path);else status="请选择 JAR 游戏或遮罩图片";
            continue;
        }
        if(e.type==SDL_MOUSEBUTTONDOWN&&e.button.button==SDL_BUTTON_LEFT&&e.button.which!=SDL_TOUCH_MOUSEID){pointer_down(e.button.x,e.button.y);continue;}
        if(e.type==SDL_FINGERDOWN){int w=0,h=0;SDL_GetWindowSize(window,&w,&h);pointer_down(int(e.tfinger.x*w),int(e.tfinger.y*h));continue;}
        if(e.type==SDL_CONTROLLERDEVICEADDED||e.type==SDL_CONTROLLERDEVICEREMOVED){controllers();continue;}
        if(e.type==SDL_WINDOWEVENT){
            if(e.window.event==SDL_WINDOWEVENT_FOCUS_LOST){focused=false;command_gate.reset();menu_vertical.reset();menu_horizontal.reset();release();if(in_game)host_freeze236(true);}
            if(e.window.event==SDL_WINDOWEVENT_FOCUS_GAINED){focused=true;if(in_game)host_freeze236(navigation.frozen());if(navigation.screen==deck_navigation::Screen::Library){scan();status=scan_summary;}else if(navigation.screen==deck_navigation::Screen::Folders)folder_browser.open(folder_browser.folder);}
        }
        if(e.type==SDL_TEXTINPUT&&navigation.screen==deck_navigation::Screen::Text){
            const bool space_echo=controller&&std::string(e.text.text)==" "&&(SDL_GameControllerGetButton(controller,SDL_CONTROLLER_BUTTON_A)||SDL_GameControllerGetButton(controller,SDL_CONTROLLER_BUTTON_X)||monotonic_ms()-text_controller_press<150);
            if(!space_echo)text_editor.insert(e.text.text);continue;
        }
        if(e.type==SDL_TEXTEDITING&&navigation.screen==deck_navigation::Screen::Text){text_editor.composition=e.edit.text;continue;}
        if(e.type==SDL_KEYDOWN||e.type==SDL_KEYUP){
            bool down=e.type==SDL_KEYDOWN;auto k=e.key.keysym.sym;
            if(!down)command_gate.release(deck_ui_input::CommandSource::Keyboard,int(e.key.keysym.scancode));
            if(navigation.screen==deck_navigation::Screen::Text){
                if(down&&focused&&(k==SDLK_LEFT||k==SDLK_RIGHT)&&(!controller||(e.key.keysym.mod&(KMOD_ALT|KMOD_CTRL)))){text_editor.move(k==SDLK_LEFT?-1:1);continue;}
                int direction=k==SDLK_UP?-1:k==SDLK_DOWN?-2:k==SDLK_LEFT?-3:k==SDLK_RIGHT?-4:0;
                if(direction&&!e.key.repeat&&focused)ui_direction(direction,deck_ui_input::Keyboard,down);
                if(!down||!focused)continue;
                if(k==SDLK_BACKSPACE)text_editor.backspace();else if(k==SDLK_DELETE)text_editor.erase();
                else if((e.key.keysym.mod&KMOD_CTRL)&&k==SDLK_v){char* clip=SDL_GetClipboardText();if(clip){text_editor.insert(clip);SDL_free(clip);}}
                else if((e.key.keysym.mod&KMOD_CTRL)&&k==SDLK_a)text_editor.all_selected=true;
                else if(k==SDLK_HOME){text_editor.caret=0;text_editor.all_selected=false;}
                else if(k==SDLK_END){text_editor.caret=text_editor.value.size();text_editor.all_selected=false;}
                // With a controller, Return/Escape can be Steam Input echoes of
                // A/B/Start. Gamepad controls own confirmation and cancellation.
                else if(!controller&&!e.key.repeat&&(k==SDLK_RETURN||k==SDLK_KP_ENTER)&&text_editor.composition.empty())submit_text();
                else if(!controller&&!e.key.repeat&&k==SDLK_ESCAPE)navigate(deck_navigation::Input::Back);
                continue;
            }
            if(e.key.repeat)continue;
            // Desktop Steam Input can emit a keyboard Escape/Enter for the same
            // physical button. Mapping capture and confirmation belong only to
            // gamepad events; an emulated key must not cancel or confirm them.
            if(navigation.screen==deck_navigation::Screen::Keymap&&controller){
                const int code=key(k);
                if(code>=-4&&code<=-1&&focused)ui_direction(code,deck_ui_input::Keyboard,down);
                continue;
            }
            if(down&&k==SDLK_F11){toggle_fullscreen();continue;}
            if(down&&k==SDLK_F5&&menu_open){scan();continue;}
            const bool command_key=k==SDLK_ESCAPE||k==SDLK_p||((menu_open||pause_sheet)&&(k==SDLK_RETURN||k==SDLK_SPACE||k==SDLK_q||k==SDLK_e||k==SDLK_PAGEUP||k==SDLK_PAGEDOWN));
            if(down&&command_key&&(!focused||!command_gate.press(deck_ui_input::CommandSource::Keyboard,int(e.key.keysym.scancode),monotonic_ms())))continue;
            if(down&&k==SDLK_ESCAPE){navigate(deck_navigation::Input::Back);continue;}
            if(down&&k==SDLK_p){navigate(deck_navigation::Input::Menu);continue;}
            if(down&&menu_open&&(k==SDLK_PAGEUP||k==SDLK_PAGEDOWN)){navigate(k==SDLK_PAGEUP?deck_navigation::Input::PageLeft:deck_navigation::Input::PageRight);continue;}
            int code=key(k);
            const bool directional=code>=-4&&code<=-1;
            if(directional&&focused)ui_direction(code,deck_ui_input::Keyboard,down);
            if(menu_open||pause_sheet){if(down&&focused&&!directional)action(code);}else if(focused&&!paused)input.update(int(e.key.keysym.scancode),down?code:0,send);
        }
        if(e.type==SDL_CONTROLLERAXISMOTION){
            if(!controller||e.caxis.which!=SDL_JoystickInstanceID(SDL_GameControllerGetJoystick(controller))||!focused)continue;
            if(e.caxis.axis==SDL_CONTROLLER_AXIS_RIGHTX)raw_right_x=e.caxis.value;
            if(e.caxis.axis==SDL_CONTROLLER_AXIS_RIGHTY)raw_right_y=e.caxis.value;
            if(navigation.screen==deck_navigation::Screen::Keymap){
                int physical=-1;bool pressed=false,has_axis=false;
                if(e.caxis.axis==SDL_CONTROLLER_AXIS_TRIGGERLEFT||e.caxis.axis==SDL_CONTROLLER_AXIS_TRIGGERRIGHT){
                    physical=e.caxis.axis==SDL_CONTROLLER_AXIS_TRIGGERLEFT?deck_keymap::L2:deck_keymap::R2;pressed=e.caxis.value>16000;has_axis=true;
                    if(e.caxis.value<11000)keymap_editor.release(physical);
                }else if(e.caxis.axis==SDL_CONTROLLER_AXIS_RIGHTX||e.caxis.axis==SDL_CONTROLLER_AXIS_RIGHTY){
                    physical=deck_keymap::right_source(raw_right_x,raw_right_y);pressed=physical>=0;has_axis=true;
                    if(raw_right_x>-11000&&raw_right_x<11000&&raw_right_y>-11000&&raw_right_y<11000&&keymap_editor.candidate>=deck_keymap::RNW&&keymap_editor.candidate<=deck_keymap::RSE)keymap_editor.release(keymap_editor.candidate);
                }
                if(has_axis){
                    if(pressed&&keymap_editor.capture(physical)){status.clear();menu_vertical.block_until_release();menu_horizontal.block_until_release();}
                    continue;
                }
                if(keymap_editor.phase==deck_keymap::Phase::Capture&&(e.caxis.value>16000||e.caxis.value < -16000))status="左摇杆方向固定保留，请按其他按键";
            }
            const bool vertical=e.caxis.axis==SDL_CONTROLLER_AXIS_LEFTY;
            if(vertical||e.caxis.axis==SDL_CONTROLLER_AXIS_LEFTX){
                auto& axis=vertical?menu_vertical:menu_horizontal;
                const int step=axis.stick(e.caxis.value,monotonic_ms());
                if(step&&navigation.screen!=deck_navigation::Screen::Game&&!(navigation.screen==deck_navigation::Screen::Keymap&&keymap_editor.phase!=deck_keymap::Phase::Browse))action(vertical?(step<0?-1:-2):(step<0?-3:-4));
            }
            continue;
        }
        if(e.type==SDL_CONTROLLERBUTTONDOWN||e.type==SDL_CONTROLLERBUTTONUP){
            if(!controller||e.cbutton.which!=SDL_JoystickInstanceID(SDL_GameControllerGetJoystick(controller)))continue;
            bool down=e.type==SDL_CONTROLLERBUTTONDOWN;int b=e.cbutton.button;
            if(!down)command_gate.release(deck_ui_input::CommandSource::Controller,b);
            const int direction=ui_button(b);const bool directional=direction>=-4&&direction<=-1;
            if(directional&&focused)ui_direction(direction,deck_ui_input::Dpad,down);
            using namespace deck_navigation;
            if(navigation.screen==Screen::Keymap&&focused){
                const int physical=physical_button(b);
                if(!down){keymap_editor.release(physical);continue;}
                if(physical>=0&&keymap_editor.phase==deck_keymap::Phase::Capture){
                    if(keymap_editor.capture(physical)){status.clear();menu_vertical.block_until_release();menu_horizontal.block_until_release();}
                    continue;
                }
                if(physical>=0&&keymap_editor.phase==deck_keymap::Phase::Review){
                    if(keymap_editor.released){if(b==SDL_CONTROLLER_BUTTON_A)navigate(Input::Confirm);else if(b==SDL_CONTROLLER_BUTTON_B)navigate(Input::Back);}
                    continue;
                }
            }
            const bool command_button=b==SDL_CONTROLLER_BUTTON_BACK||b==SDL_CONTROLLER_BUTTON_START||(navigation.screen!=Screen::Game&&navigation.screen!=Screen::Keymap&&!directional);
            if(down&&command_button&&(!focused||!command_gate.press(deck_ui_input::CommandSource::Controller,b,monotonic_ms())))continue;
            if(down&&b==SDL_CONTROLLER_BUTTON_BACK){navigate(Input::View);continue;}
            if(down&&b==SDL_CONTROLLER_BUTTON_START){navigate(Input::Menu);continue;}
            if(navigation.screen!=Screen::Game){
                if(!down||!focused||directional)continue;
                if(navigation.screen==Screen::Text){text_controller_press=monotonic_ms();if(b==SDL_CONTROLLER_BUTTON_X){navigate(Input::Reset);continue;}if(b==SDL_CONTROLLER_BUTTON_Y){navigate(Input::Save);continue;}}
                if(navigation.screen==Screen::Memory){if(b==SDL_CONTROLLER_BUTTON_X){navigate(Input::Reset);continue;}if(b==SDL_CONTROLLER_BUTTON_Y){navigate(Input::Save);continue;}}
                if(navigation.screen==Screen::SkinLayout){if(b==SDL_CONTROLLER_BUTTON_X){navigate(Input::Reset);continue;}if(b==SDL_CONTROLLER_BUTTON_Y){navigate(Input::Save);continue;}}
                if(navigation.screen==Screen::Skins&&b==SDL_CONTROLLER_BUTTON_Y){navigate(Input::Save);continue;}
                if(navigation.screen==Screen::Keymap){
                    if(b==SDL_CONTROLLER_BUTTON_X){navigate(Input::Reset);continue;}
                    if(b==SDL_CONTROLLER_BUTTON_Y){navigate(Input::Save);continue;}
                }
                if(navigation.screen==Screen::Folders&&b==SDL_CONTROLLER_BUTTON_Y){navigate(Input::Save);continue;}
                if(navigation.screen==Screen::Library){
                    if(b==SDL_CONTROLLER_BUTTON_LEFTSTICK){navigate(Input::OpenGames);continue;}
                    if(b==SDL_CONTROLLER_BUTTON_Y){scan();status=scan_summary;continue;}
                    if(b==SDL_CONTROLLER_BUTTON_RIGHTSTICK){toggle_fullscreen();continue;}
                }
                if(b==SDL_CONTROLLER_BUTTON_LEFTSHOULDER||b==SDL_CONTROLLER_BUTTON_RIGHTSHOULDER){navigate(b==SDL_CONTROLLER_BUTTON_LEFTSHOULDER?Input::PageLeft:Input::PageRight);continue;}
                action(ui_button(b));
            }else if(focused&&!wait_neutral){
                const int physical=physical_button(b);
                if(physical>=0)input.update(1000+b,down?keymap.code(physical):0,send);
            }
        }
    }
    if((menu_open||pause_sheet)&&focused){
        int step=menu_vertical.tick(monotonic_ms());if(step)action(step<0?-1:-2);
        step=menu_horizontal.tick(monotonic_ms());if(step)action(step<0?-3:-4);
    }
    if(wait_neutral&&controller_neutral())wait_neutral=false;
    if(controller&&navigation.screen==deck_navigation::Screen::Game&&focused&&!wait_neutral){
        int x=SDL_GameControllerGetAxis(controller,SDL_CONTROLLER_AXIS_LEFTX),y=SDL_GameControllerGetAxis(controller,SDL_CONTROLLER_AXIS_LEFTY);
        input.update(2000,keymap.code(x < -16000 ? deck_keymap::LLeft : x > 16000 ? deck_keymap::LRight : -1),send);
        input.update(2001,keymap.code(y < -16000 ? deck_keymap::LUp : y > 16000 ? deck_keymap::LDown : -1),send);
        input.update(2002,SDL_GameControllerGetAxis(controller,SDL_CONTROLLER_AXIS_TRIGGERLEFT)>16000?keymap.code(deck_keymap::L2):0,send);
        input.update(2003,SDL_GameControllerGetAxis(controller,SDL_CONTROLLER_AXIS_TRIGGERRIGHT)>16000?keymap.code(deck_keymap::R2):0,send);
        input.update(2004,keymap.code(deck_keymap::right_source(SDL_GameControllerGetAxis(controller,SDL_CONTROLLER_AXIS_RIGHTX),SDL_GameControllerGetAxis(controller,SDL_CONTROLLER_AXIS_RIGHTY))),send);
    }
    VMS_PLAT(g_key_states)=0;for(int k:input.codes()){int a=game_key_action(k);if(a)VMS_PLAT(g_key_states)|=1<<a;}
}
}
int main(int argc,char** argv){
    using namespace deck;
    std::error_code location_error;
    const fs::path invoked=argv[0];
    auto executable=fs::read_symlink("/proc/self/exe",location_error);
    if(location_error){location_error.clear();executable=fs::absolute(invoked,location_error);}
    bundle_dir=executable.parent_path();
    // A build-tree executable can use the adjacent source resources; release
    // bundles always carry romfs directly beside the executable.
    if(!fs::is_directory(bundle_dir/"romfs/classes",location_error)){
        location_error.clear();
        if(fs::is_directory(bundle_dir.parent_path()/"romfs/classes",location_error))bundle_dir=bundle_dir.parent_path();
        location_error.clear();
    }
    fs::current_path(bundle_dir,location_error);
    if(location_error){SDL_Init(SDL_INIT_VIDEO);deck_install::message_box(SDL_MESSAGEBOX_ERROR,"PiJava 启动失败","无法定位程序目录，请把模拟器和 romfs 一起解压。",nullptr);SDL_Quit();return 1;}
    const char* langHome=std::getenv("HOME");const char* langXdg=std::getenv("XDG_DATA_HOME");
    deck_i18n::load((langXdg&&*langXdg?fs::path(langXdg):fs::path(langHome&&*langHome?langHome:".")/".local/share")/"pijava/language.cfg");
    const bool import_shortcut=(invoked.filename()=="Add to Gaming Mode"||invoked.filename()==fs::u8path("添加到游戏模式"))||(argc>1&&std::string(argv[1])=="--add-to-steam");
    const bool installer=import_shortcut||invoked.filename()==fs::u8path("安装到桌面")||(invoked.filename()=="Install"||invoked.filename()==fs::u8path("一键安装"))||(argc>1&&std::string(argv[1])=="--install-desktop");
    if(installer)return deck_install::run(bundle_dir,import_shortcut);
    std::string jar;
    const char* home=std::getenv("HOME");const char* xdg=std::getenv("XDG_DATA_HOME");
    fs::path data=xdg&&*xdg?fs::path(xdg)/"pijava":fs::path(home&&*home?home:".")/".local/share/pijava";
    deck_states.root=data/"state";deck_states.bundle=bundle_dir/"state";
    game_options.root=data/"game-options";custom_skins.root=data/"skins";custom_skins.bundle=bundle_dir/"skins";
    data_dir=data;games_dir=data/"games";ui.cjk=[](int cp){return find_cjk(cp);};
    for(int i=1;i<argc;++i){std::string a=argv[i];
        if(a=="--help"){std::cout<<(deck_i18n::english?"PiJava: [--jar GAME] [--games DIR] [--windowed] [--size WxH] [--smoke-frames N] [--screenshot FILE]\n":"PiJava： [--jar 游戏文件] [--games 游戏目录] [--windowed 窗口模式] [--size 宽x高] [--smoke-frames 帧数] [--screenshot 图片路径]\n");return 0;}
        else if(a=="--windowed")fullscreen=false;
        else if(a=="--jar"&&i+1<argc)jar=argv[++i];
        else if(a=="--games"&&i+1<argc){games_dir=fs::absolute(argv[++i]);explicit_games=true;}
        else if(a=="--size"&&i+1<argc){int w,h;if(!logical_screen::parse(argv[++i],w,h))return 2;VMS_RS(g_screen_w)=w;VMS_RS(g_screen_h)=h;size_override=true;screen_width=w;screen_height=h;}
        else if(a=="--smoke-frames"&&i+1<argc){smoke_frames=std::atoi(argv[++i]);if(smoke_frames<1)return 2;}
        else if(a=="--screenshot"&&i+1<argc)screenshot=argv[++i];
        else{std::cerr<<"未知或不完整的启动参数："<<a<<"\n";return 2;}
    }
    std::error_code ec;fs::create_directories(data/"rms",ec);if(ec){std::cerr<<ec.message()<<"\n";return 1;}
    fs::create_directories(games_dir,ec);if(ec){std::cerr<<ec.message()<<"\n";return 1;}
    if(!std::getenv("J2ME_RMS_DIR"))setenv("J2ME_RMS_DIR",(data/"rms").c_str(),1);
    if(!explicit_games&&deck_games::normalized(bundle_dir)!=deck_games::normalized(data_dir/"app")&&fs::is_directory(bundle_dir/"games",ec))deck_games::save_root(data_dir/"source-games.path",bundle_dir/"games");
    ec.clear();
    // SDL frontend keeps audio on the VM thread; diagnostic worker batching discards PCM.
    setenv("J2ME_P7_AUDIO","0",1);
    if(!fs::is_directory("romfs/classes",ec)){SDL_Init(SDL_INIT_VIDEO);deck_install::message_box(SDL_MESSAGEBOX_ERROR,"PiJava 启动失败","缺少 romfs/classes。请完整解压运行包，保留程序旁边的 romfs 文件夹。",nullptr);SDL_Quit();return 1;}
    SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY,"nearest");
    if(SDL_Init(SDL_INIT_VIDEO|SDL_INIT_GAMECONTROLLER)!=0){std::cerr<<SDL_GetError()<<"\n";return 1;}
    SDL_EventState(SDL_DROPFILE,SDL_ENABLE);SDL_StopTextInput();
    window=SDL_CreateWindow("PiJava - Steam Deck 3.14",SDL_WINDOWPOS_CENTERED,SDL_WINDOWPOS_CENTERED,1280,800,SDL_WINDOW_RESIZABLE|(fullscreen?SDL_WINDOW_FULLSCREEN_DESKTOP:0));
    if(window)renderer=SDL_CreateRenderer(window,-1,SDL_RENDERER_ACCELERATED);
    if(window&&!renderer)renderer=SDL_CreateRenderer(window,-1,SDL_RENDERER_SOFTWARE);
    if(!renderer){std::cerr<<SDL_GetError()<<"\n";SDL_Quit();return 1;}
    if(SDL_InitSubSystem(SDL_INIT_AUDIO)!=0||!deck_audio::init())status=std::string("音频设备不可用：")+SDL_GetError();
    VMS_PLAT(g_boot_ms)=now_ms();log_open((data/"pijava.log").c_str(),true);configure_runtime_diagnostics();
    ui.settings.bezel=3;
    host_menu::load_settings((data_dir/"deck-menu.cfg").string(),ui.settings);
    ui.load_fonts();
    host_speed::load((data_dir/"deck-speed.cfg").string(),speeds);
    deck_keymap::load((data_dir/"deck-keymap.cfg").string(),keymap);
    VMS_CL(g_classpath).push_back("romfs/classes");controllers();scan();
    g_die_catch=true;
    if(setjmp(g_die_jmp)!=0){
        status="运行错误："+VMS_EXEC(g_error);
        // An incomplete launch cannot safely call Java destroyApp again.
        memory.reset();input.sources.clear();VMS_PLAT(g_key_states)=0;stop_thread();
        VMS_PLAT(g_host_paused)=false;VMS_PLAT(g_host_frozen236)=false;
        const auto previous=navigation.screen;navigation.stopped();sync_navigation(previous);deck_audio::clear();
        if(texture)SDL_DestroyTexture(texture);texture=nullptr;
        if(smoke_frames)running=false;
    }
    else if(!jar.empty()){
        // CLI size wins over sidecar selection.
        launch(fs::absolute(jar));
    }
    while(running){
        const int64_t begin=paint_clock_us();events();if(!running)break;memory.guard();if(memory.busy)memory.step();diag_host(in_game,paused||!focused);
        if(in_game&&(navigation.screen==deck_navigation::Screen::Game||navigation.screen==deck_navigation::Screen::Pause)){
            if(!paused&&focused){memory.apply();host_lifecycle_poll242();sched_game_work(false,[]{},[](int64_t ms){SDL_Delay(Uint32(std::min<int64_t>(ms,8)));});memory.apply();}
            if(VMS_EXEC(g_midlet_state)==MidletState::Destroyed){leave();continue;}
            if(!paused&&focused)audio_pump();
            if(VMS_RS(g_fb_dirty)&&!paused&&focused)++fps_new_frames;
            const int64_t current=paint_clock_us();
            if(current-fps_since>=1000000){fps_label=std::to_string(int(fps_new_frames*1000000ull/uint64_t(current-fps_since)));fps_since=current;fps_new_frames=0;}
            const auto& image=orientation.apply(VMS_RS(g_fb),VMS_RS(g_screen_w),VMS_RS(g_screen_h),active_rotation,resver::g_epoch,VMS_RS(g_paint_serial),VMS_RS(g_fb_dirty));
            ui.game(image.data(),orientation.width(),orientation.height(),fps_label);
            if(pause_sheet)ui.pause_menu(navigation.pause_selection,status);
            upload(ui.pixels.data(),1280,720,SDL_PIXELFORMAT_ABGR8888,1280*4);
            VMS_PLAT(g_last_present_us)=paint_clock_us();
            if(VMS_RS(g_fb_dirty)&&!paused&&focused)++VMS_RS(g_present_frames);
            if(!paused&&focused)p1_host_post_present(true,false);
        }else menu();
        if(smoke_frames&&++frame_count>=smoke_frames)running=false;
        int64_t left=16667-(paint_clock_us()-begin);if(left>0)SDL_Delay(Uint32(left/1000));
    }
    if(!screenshot.empty()&&in_game)write_png(screenshot,VMS_RS(g_fb),VMS_RS(g_screen_w),VMS_RS(g_screen_h));
    const bool failed=smoke_frames&&!status.empty()&&status.find("运行错误：")==0;
    leave();g_die_catch=false;p7::pool().shutdown();deck_audio::shutdown();
    if(controller)SDL_GameControllerClose(controller);if(texture)SDL_DestroyTexture(texture);SDL_DestroyRenderer(renderer);SDL_DestroyWindow(window);SDL_Quit();
    return failed?1:0;
}
