#pragma once
#include <map>
#include <set>
namespace deck_input {
// Each physical source owns its press. Releasing one source must not release
// another source mapped to the same phone key (e.g. D-pad and left stick).
struct State {
    std::map<int,int> sources;
    std::set<int> codes() const {std::set<int> out;for(auto p:sources)out.insert(p.second);return out;}
    template<class Send> void update(int source,int code,Send send){
        auto before=codes();
        if(code)sources[source]=code;else sources.erase(source);
        auto after=codes();
        for(int k:before)if(!after.count(k))send(k,true);
        for(int k:after)if(!before.count(k))send(k,false);
    }
    template<class Send> void clear(Send send){auto old=codes();sources.clear();for(int k:old)send(k,true);}
};
}
