#pragma once
#include "host_menu_settings.h"
#include "deck_custom_skin.h"
#include <filesystem>
#include <set>
#include <vector>
#include <string>
#include <algorithm>
namespace deck_games {
namespace fs=std::filesystem;
inline bool jar(const fs::path& p){std::string e=p.extension().string();for(char& c:e)if(c>='A'&&c<='Z')c=char(c+32);return e==".jar";}
inline fs::path normalized(const fs::path& p){std::error_code ec;auto c=fs::weakly_canonical(p,ec);return ec?p:c;}
inline bool save_root(const fs::path& file,const fs::path& folder){
    const auto text=normalized(folder).u8string();if(text.empty()||text.size()>4096||text.find_first_of("\r\n\0",0,3)!=std::string::npos)return false;
    return host_menu::save_record(file.string(),"PIJAVA_GAMES_ROOT 1\n"+text+"\n");
}
inline fs::path load_root(const fs::path& file){
    std::ifstream f(file,std::ios::binary);std::string header,path;if(!std::getline(f,header)||header!="PIJAVA_GAMES_ROOT 1"||!std::getline(f,path)||path.empty()||path.size()>4096||path.find('\0')!=std::string::npos)return {};
    return fs::u8path(path);
}
struct Root {fs::path path;size_t jars=0,files=0;std::string error;};
struct Scan {std::vector<fs::path> games;std::vector<Root> roots;bool truncated=false;};
inline Scan scan(const std::vector<fs::path>& folders){
    Scan result;std::set<fs::path> visited,files;size_t entries=0;
    for(const auto& folder:folders){
        if(folder.empty())continue;const auto root=normalized(folder);if(!visited.insert(root).second)continue;
        Root info;info.path=root;std::error_code ec;
        if(!fs::is_directory(root,ec)){info.error=ec?ec.message():"目录不存在";result.roots.push_back(info);continue;}
        fs::directory_iterator probe(root,ec);
        if(ec){info.error=ec.message();result.roots.push_back(info);continue;}
        fs::recursive_directory_iterator it(root,fs::directory_options::skip_permission_denied,ec),end;
        if(ec)info.error=ec.message();
        while(!ec&&it!=end){
            if(++entries>50000||result.games.size()>=10000){result.truncated=true;break;}
            const auto path=it->path();const bool directory=it->is_directory(ec);
            if(ec){ec.clear();it.increment(ec);continue;}
            if(directory&&it.depth()>=8)it.disable_recursion_pending();
            if(!directory&&it->is_regular_file(ec)){
                ++info.files;
                if(jar(path)){++info.jars;auto key=normalized(path);if(files.insert(key).second)result.games.push_back(key);}
            }
            ec.clear();it.increment(ec);
        }
        if(ec)info.error=ec.message();result.roots.push_back(info);if(result.truncated)break;
    }
    std::sort(result.games.begin(),result.games.end(),[](const fs::path& a,const fs::path& b){return a.filename()==b.filename()?a<b:a.filename()<b.filename();});return result;
}
struct Item {fs::path path;bool directory=false,game=false;};
struct Browser {
    bool images=false;fs::path folder;std::vector<Item> items;int selected=0;std::string error;
    void open(const fs::path& p){
        folder=normalized(p);items.clear();selected=0;error.clear();std::error_code ec;
        if(folder.has_parent_path()&&folder.parent_path()!=folder)items.push_back({folder.parent_path(),true,false});
        fs::directory_iterator it(folder,ec),end;
        if(ec){error=ec.message();return;}
        std::vector<Item> found;
        while(it!=end&&found.size()<10000){
            const bool dir=it->is_directory(ec);if(!ec)found.push_back({it->path(),dir,!dir&&(images?deck_custom_skin::supported(it->path()):jar(it->path()))});ec.clear();it.increment(ec);if(ec){error=ec.message();break;}
        }
        std::sort(found.begin(),found.end(),[](const Item& a,const Item& b){return a.directory!=b.directory?a.directory>b.directory:a.path.filename()<b.path.filename();});
        items.insert(items.end(),found.begin(),found.end());
    }
    bool parent(int index)const{return index==0&&!items.empty()&&items[0].path==folder.parent_path();}
    void move(int delta){if(items.empty())selected=0;else{const int n=int(items.size());selected=(selected+delta)%n;if(selected<0)selected+=n;}}
};
}
