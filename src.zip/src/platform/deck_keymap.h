#pragma once
#include "host_menu_settings.h"
#include <array>
#include <set>
#include <sstream>
namespace deck_keymap {
// Keep IDs 0..24 compatible with the first editable mapping format.
enum Physical { A,B,X,Y,L1,R1,L2,R2,R3,DUp,DDown,DLeft,DRight,LUp,LDown,LLeft,LRight,RNW,RN,RNE,RW,RE,RSW,RS,RSE,L3,Count };
inline constexpr std::array<int,20> phone_codes={{0,-1,-2,-3,-4,-5,-6,-7,48,49,50,51,52,53,54,55,56,57,42,35}};
inline constexpr const char* phone_names[]={"未绑定","方向上","方向下","方向左","方向右","确认键","左软键","右软键","数字 0","数字 1","数字 2","数字 3","数字 4","数字 5","数字 6","数字 7","数字 8","数字 9","星号 *","井号 #"};
inline constexpr const char* physical_names[]={"A","B","X","Y","L1","R1","L2","R2","右摇杆按下","十字键上","十字键下","十字键左","十字键右","左摇杆上","左摇杆下","左摇杆左","左摇杆右","右摇杆左上","右摇杆上","右摇杆右上","右摇杆左","右摇杆右","右摇杆左下","右摇杆下","右摇杆右下","左摇杆按下"};
inline constexpr std::array<int,15> editable_codes={{-6,-7,49,50,51,52,53,54,55,56,57,48,42,35,-5}};
inline bool fixed(int physical){return physical>=LUp&&physical<=LRight;}
inline bool assignable(int physical){return physical>=0&&physical<Count&&!fixed(physical);}
inline int phone_index(int code){for(size_t i=0;i<phone_codes.size();++i)if(phone_codes[i]==code)return int(i);return -1;}
inline const char* name(int code){int i=phone_index(code);return i<0?"无效":phone_names[i];}
struct Config {
    std::array<int,Count> codes={{-5,-7,-6,53,49,51,42,35,48,50,56,52,54,-1,-2,-3,-4,0,0,0,0,0,0,57,0,55}};
    int code(int physical)const{
        const int directions[]={-1,-2,-3,-4};
        if(fixed(physical))return directions[physical-LUp];
        return physical>=0&&physical<Count?codes[size_t(physical)]:0;
    }
};
inline void fix_directions(Config& c){
    for(int i=0;i<Count;++i)if(!fixed(i)&&c.codes[size_t(i)]>=-4&&c.codes[size_t(i)]<=-1)c.codes[size_t(i)]=0;
    c.codes[LUp]=-1;c.codes[LDown]=-2;c.codes[LLeft]=-3;c.codes[LRight]=-4;
}
inline bool valid(const Config& c){
    for(int i=0;i<Count;++i){const int code=c.codes[size_t(i)];if(phone_index(code)<0||(!fixed(i)&&code>=-4&&code<=-1))return false;}
    return c.codes[LUp]==-1&&c.codes[LDown]==-2&&c.codes[LLeft]==-3&&c.codes[LRight]==-4;
}
inline bool bind(Config& c,int phone,int physical){
    if(!assignable(physical)||std::find(editable_codes.begin(),editable_codes.end(),phone)==editable_codes.end())return false;
    // One selected phone key gets one physical binding. Reusing a physical
    // input removes its previous phone action, instead of sending two keys.
    for(int i=0;i<Count;++i)if(!fixed(i)&&c.codes[size_t(i)]==phone)c.codes[size_t(i)]=0;
    c.codes[size_t(physical)]=phone;return true;
}
inline std::string bindings(const Config& c,int phone){
    std::string out;for(int i=0;i<Count;++i)if(!fixed(i)&&c.code(i)==phone){if(!out.empty())out+=" / ";out+=physical_names[i];}
    return out.empty()?"未绑定":out;
}
inline bool load(const std::string& path,Config& c){
    std::ifstream f(path,std::ios::binary);if(!f)return false;
    std::string header;if(!std::getline(f,header))return false;if(!header.empty()&&header.back()=='\r')header.pop_back();
    const int count=header=="PIJAVA_DECK_KEYMAP 1"?25:header=="PIJAVA_DECK_KEYMAP 2"?Count:0;if(!count)return false;
    Config loaded;if(count==25)loaded.codes[L3]=0;
    for(int i=0;i<count;++i)if(!(f>>loaded.codes[size_t(i)])||phone_index(loaded.codes[size_t(i)])<0)return false;
    std::string extra;if(f>>extra)return false;fix_directions(loaded);if(!valid(loaded))return false;c=loaded;return true;
}
inline bool save(const std::string& path,const Config& c){
    if(!valid(c))return false;std::ostringstream s;s<<"PIJAVA_DECK_KEYMAP 2\n";for(int code:c.codes)s<<code<<' ';s<<'\n';return host_menu::save_record(path,s.str());
}
enum class Phase { Browse, Capture, Review };
struct Editor {
    Config draft;int selected=0,candidate=-1;bool dirty=false,released=false;Phase phase=Phase::Browse;
    int phone()const{return editable_codes[size_t(selected)];}
    void begin(const Config& c){draft=c;fix_directions(draft);selected=0;dirty=false;candidate=-1;released=false;phase=Phase::Browse;}
    void move(int delta){if(phase==Phase::Browse)selected=(selected+delta+int(editable_codes.size()))%int(editable_codes.size());}
    void menu(){
        if(phase!=Phase::Browse){phase=Phase::Browse;candidate=-1;return;}
        phase=Phase::Capture;candidate=-1;released=false;
    }
    bool capture(int physical){if(phase!=Phase::Capture||!assignable(physical))return false;candidate=physical;phase=Phase::Review;released=false;return true;}
    void release(int physical){if(phase==Phase::Review&&physical==candidate)released=true;}
    bool confirm(){if(phase!=Phase::Review||!released)return false;if(!bind(draft,phone(),candidate))return false;dirty=true;phase=Phase::Browse;candidate=-1;return true;}
    void retry(){phase=Phase::Capture;candidate=-1;released=false;}
    void reset(){draft=Config{};dirty=true;phase=Phase::Browse;candidate=-1;}
};
inline int right_source(int x,int y){
    int col=x < -16000 ? 0 : x > 16000 ? 2 : 1,row=y < -16000 ? 0 : y > 16000 ? 2 : 1;
    const int ids[3][3]={{RNW,RN,RNE},{RW,-1,RE},{RSW,RS,RSE}};return ids[row][col];
}
}
