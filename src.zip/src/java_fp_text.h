#pragma once
#include <charconv>
#include <cmath>
#include <limits>
#include <cstdio>
#include <string>
// Java-style decimal display: shortest roundtrip, decimal point retained,
// scientific notation outside [1e-3,1e7), normalized exponent spelling.
template<class T> inline std::string java_fp_text(T value){
    if(std::isnan(value))return "NaN";
    if(std::isinf(value))return std::signbit(value)?"-Infinity":"Infinity";
    if(value==0)return std::signbit(value)?"-0.0":"0.0";
    char buffer[128];const auto magnitude=std::abs(value);
    const auto result=std::to_chars(buffer,buffer+sizeof(buffer),value,magnitude>=T(0.001)&&magnitude<T(10000000)?std::chars_format::fixed:std::chars_format::scientific);
    std::string text;
    if(result.ec==std::errc{})text.assign(buffer,result.ptr);
    else{std::snprintf(buffer,sizeof(buffer),"%.*g",std::numeric_limits<T>::max_digits10,double(value));text=buffer;}
    // Java keeps at least two significant decimal digits in scientific form,
    // including subnormal minima (1.4E-45 / 4.9E-324).
    if(text.find_first_of("eE")!=std::string::npos&&text.find('.')==std::string::npos){
        auto two=std::to_chars(buffer,buffer+sizeof(buffer),value,std::chars_format::scientific,1);
        if(two.ec==std::errc{})text.assign(buffer,two.ptr);
    }
    const auto e=text.find_first_of("eE");
    std::string mantissa=text.substr(0,e);if(mantissa.find('.')==std::string::npos)mantissa+=".0";
    if(e==std::string::npos)return mantissa;
    size_t i=e+1;bool negative=i<text.size()&&text[i]=='-';if(i<text.size()&&(text[i]=='+'||text[i]=='-'))++i;
    while(i+1<text.size()&&text[i]=='0')++i;
    return mantissa+"E"+(negative?"-":"")+text.substr(i);
}
