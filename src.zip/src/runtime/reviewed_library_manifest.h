#pragma once
// Generated from reviewed sources plus the actual Java compiler output.
struct ReviewedLibraryClass { const char* name; const char* sha256; unsigned char id; };
static const ReviewedLibraryClass kReviewedLibraryClasses[] = {
    {"java/util/Hashtable","ed8a0dbfb9ceb4079f54f21638ecae326cb4ed7173f10154e74ff7f0426a4570",1},
    {"java/lang/Character","b1e510fceec730649800be9ed3d6b56adf1f2f7739a291c9a90d2e31dec56cb4",2},
    {"java/lang/Integer","944681f7503e1ca6f6e1a63a0df10c2963e080362584d2e53c708e8e4fb060bc",3},
    {"java/lang/Long","a90f3d4178acdbebaddcfbf0a38f5d6dc34572fa912a21ef9f2b3cce018e40c8",4},
    {"java/lang/Byte","88455948ca964a9fd6a82f1f5ffe0fa881f11ba212fd6a98947d7f7fc09903c6",5},
    {"java/lang/Short","d81717749b39cfa035979758ed3d33755541b7b554e57f7c91039d5b09bf3391",6},
    {"java/lang/Boolean","2925e911a168cbaa48d702e6c9b7672ba664ffe9aaf28b0ade6a939bbc45fc7c",7},
    {"java/io/ByteArrayInputStream","14d0bae6f7d51452c0c9c00f5d7f190c1dbaef228af51f0e8419fadec7a616b8",8},
    {"java/io/DataInputStream","a950ea62560f3fd41bd14bb61515adbd5bdc9c936835b802e3f34c3589f54108",9},
    {"java/lang/String","cd756a53ee2ae20421ba53df8f65341198e41338505ea1ea6e8836e93d4506c4",10},
    {"java/util/Vector","ec42c9ec0505d50268cc4b3aec3c54e827b678bb5af5871acd486cf91c0697bb",11},
};
